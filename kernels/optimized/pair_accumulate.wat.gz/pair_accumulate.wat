(module (func (export "__imajev_pair_accumulate") (param $q i32) (param $w i32) (param $cols i32) (param $start i32) (param $sx i32) (param $stride i32) (param $sw i32) (param $sums i32) (param $n i32)
(local $t i32) (local $qp i32) (local $wp i32) (local $yp i32) (local $xscale v128) (local $a v128) (local $b v128)
(local $w0_0 v128)
(local $w0_1 v128)
(local $w0_2 v128)
(local $w0_3 v128)
(local $w0_4 v128)
(local $w0_5 v128)
(local $w0_6 v128)
(local $w0_7 v128)
(local $w0_8 v128)
(local $w0_9 v128)
(local $w0_10 v128)
(local $w0_11 v128)
(local $w0_12 v128)
(local $w0_13 v128)
(local $w0_14 v128)
(local $w0_15 v128)
(local $w0_16 v128)
(local $w0_17 v128)
(local $w0_18 v128)
(local $w0_19 v128)
(local $w0_20 v128)
(local $w0_21 v128)
(local $w0_22 v128)
(local $w0_23 v128)
(local $w0_24 v128)
(local $w0_25 v128)
(local $w0_26 v128)
(local $w0_27 v128)
(local $w0_28 v128)
(local $w0_29 v128)
(local $w0_30 v128)
(local $w0_31 v128)
(local $w0_32 v128)
(local $w0_33 v128)
(local $w0_34 v128)
(local $w0_35 v128)
(local $w0_36 v128)
(local $w0_37 v128)
(local $w0_38 v128)
(local $w0_39 v128)
(local $w0_40 v128)
(local $w0_41 v128)
(local $w0_42 v128)
(local $w0_43 v128)
(local $w0_44 v128)
(local $w0_45 v128)
(local $w0_46 v128)
(local $w0_47 v128)
(local $w0_48 v128)
(local $w0_49 v128)
(local $w0_50 v128)
(local $w0_51 v128)
(local $w0_52 v128)
(local $w0_53 v128)
(local $w0_54 v128)
(local $w0_55 v128)
(local $w0_56 v128)
(local $w0_57 v128)
(local $w0_58 v128)
(local $w0_59 v128)
(local $w0_60 v128)
(local $w0_61 v128)
(local $w0_62 v128)
(local $w0_63 v128)
(local $w1_0 v128)
(local $w1_1 v128)
(local $w1_2 v128)
(local $w1_3 v128)
(local $w1_4 v128)
(local $w1_5 v128)
(local $w1_6 v128)
(local $w1_7 v128)
(local $w1_8 v128)
(local $w1_9 v128)
(local $w1_10 v128)
(local $w1_11 v128)
(local $w1_12 v128)
(local $w1_13 v128)
(local $w1_14 v128)
(local $w1_15 v128)
(local $w1_16 v128)
(local $w1_17 v128)
(local $w1_18 v128)
(local $w1_19 v128)
(local $w1_20 v128)
(local $w1_21 v128)
(local $w1_22 v128)
(local $w1_23 v128)
(local $w1_24 v128)
(local $w1_25 v128)
(local $w1_26 v128)
(local $w1_27 v128)
(local $w1_28 v128)
(local $w1_29 v128)
(local $w1_30 v128)
(local $w1_31 v128)
(local $w1_32 v128)
(local $w1_33 v128)
(local $w1_34 v128)
(local $w1_35 v128)
(local $w1_36 v128)
(local $w1_37 v128)
(local $w1_38 v128)
(local $w1_39 v128)
(local $w1_40 v128)
(local $w1_41 v128)
(local $w1_42 v128)
(local $w1_43 v128)
(local $w1_44 v128)
(local $w1_45 v128)
(local $w1_46 v128)
(local $w1_47 v128)
(local $w1_48 v128)
(local $w1_49 v128)
(local $w1_50 v128)
(local $w1_51 v128)
(local $w1_52 v128)
(local $w1_53 v128)
(local $w1_54 v128)
(local $w1_55 v128)
(local $w1_56 v128)
(local $w1_57 v128)
(local $w1_58 v128)
(local $w1_59 v128)
(local $w1_60 v128)
(local $w1_61 v128)
(local $w1_62 v128)
(local $w1_63 v128)
(local $w2_0 v128)
(local $w2_1 v128)
(local $w2_2 v128)
(local $w2_3 v128)
(local $w2_4 v128)
(local $w2_5 v128)
(local $w2_6 v128)
(local $w2_7 v128)
(local $w2_8 v128)
(local $w2_9 v128)
(local $w2_10 v128)
(local $w2_11 v128)
(local $w2_12 v128)
(local $w2_13 v128)
(local $w2_14 v128)
(local $w2_15 v128)
(local $w2_16 v128)
(local $w2_17 v128)
(local $w2_18 v128)
(local $w2_19 v128)
(local $w2_20 v128)
(local $w2_21 v128)
(local $w2_22 v128)
(local $w2_23 v128)
(local $w2_24 v128)
(local $w2_25 v128)
(local $w2_26 v128)
(local $w2_27 v128)
(local $w2_28 v128)
(local $w2_29 v128)
(local $w2_30 v128)
(local $w2_31 v128)
(local $w2_32 v128)
(local $w2_33 v128)
(local $w2_34 v128)
(local $w2_35 v128)
(local $w2_36 v128)
(local $w2_37 v128)
(local $w2_38 v128)
(local $w2_39 v128)
(local $w2_40 v128)
(local $w2_41 v128)
(local $w2_42 v128)
(local $w2_43 v128)
(local $w2_44 v128)
(local $w2_45 v128)
(local $w2_46 v128)
(local $w2_47 v128)
(local $w2_48 v128)
(local $w2_49 v128)
(local $w2_50 v128)
(local $w2_51 v128)
(local $w2_52 v128)
(local $w2_53 v128)
(local $w2_54 v128)
(local $w2_55 v128)
(local $w2_56 v128)
(local $w2_57 v128)
(local $w2_58 v128)
(local $w2_59 v128)
(local $w2_60 v128)
(local $w2_61 v128)
(local $w2_62 v128)
(local $w2_63 v128)
(local $w3_0 v128)
(local $w3_1 v128)
(local $w3_2 v128)
(local $w3_3 v128)
(local $w3_4 v128)
(local $w3_5 v128)
(local $w3_6 v128)
(local $w3_7 v128)
(local $w3_8 v128)
(local $w3_9 v128)
(local $w3_10 v128)
(local $w3_11 v128)
(local $w3_12 v128)
(local $w3_13 v128)
(local $w3_14 v128)
(local $w3_15 v128)
(local $w3_16 v128)
(local $w3_17 v128)
(local $w3_18 v128)
(local $w3_19 v128)
(local $w3_20 v128)
(local $w3_21 v128)
(local $w3_22 v128)
(local $w3_23 v128)
(local $w3_24 v128)
(local $w3_25 v128)
(local $w3_26 v128)
(local $w3_27 v128)
(local $w3_28 v128)
(local $w3_29 v128)
(local $w3_30 v128)
(local $w3_31 v128)
(local $w3_32 v128)
(local $w3_33 v128)
(local $w3_34 v128)
(local $w3_35 v128)
(local $w3_36 v128)
(local $w3_37 v128)
(local $w3_38 v128)
(local $w3_39 v128)
(local $w3_40 v128)
(local $w3_41 v128)
(local $w3_42 v128)
(local $w3_43 v128)
(local $w3_44 v128)
(local $w3_45 v128)
(local $w3_46 v128)
(local $w3_47 v128)
(local $w3_48 v128)
(local $w3_49 v128)
(local $w3_50 v128)
(local $w3_51 v128)
(local $w3_52 v128)
(local $w3_53 v128)
(local $w3_54 v128)
(local $w3_55 v128)
(local $w3_56 v128)
(local $w3_57 v128)
(local $w3_58 v128)
(local $w3_59 v128)
(local $w3_60 v128)
(local $w3_61 v128)
(local $w3_62 v128)
(local $w3_63 v128)
(local $w4_0 v128)
(local $w4_1 v128)
(local $w4_2 v128)
(local $w4_3 v128)
(local $w4_4 v128)
(local $w4_5 v128)
(local $w4_6 v128)
(local $w4_7 v128)
(local $w4_8 v128)
(local $w4_9 v128)
(local $w4_10 v128)
(local $w4_11 v128)
(local $w4_12 v128)
(local $w4_13 v128)
(local $w4_14 v128)
(local $w4_15 v128)
(local $w4_16 v128)
(local $w4_17 v128)
(local $w4_18 v128)
(local $w4_19 v128)
(local $w4_20 v128)
(local $w4_21 v128)
(local $w4_22 v128)
(local $w4_23 v128)
(local $w4_24 v128)
(local $w4_25 v128)
(local $w4_26 v128)
(local $w4_27 v128)
(local $w4_28 v128)
(local $w4_29 v128)
(local $w4_30 v128)
(local $w4_31 v128)
(local $w4_32 v128)
(local $w4_33 v128)
(local $w4_34 v128)
(local $w4_35 v128)
(local $w4_36 v128)
(local $w4_37 v128)
(local $w4_38 v128)
(local $w4_39 v128)
(local $w4_40 v128)
(local $w4_41 v128)
(local $w4_42 v128)
(local $w4_43 v128)
(local $w4_44 v128)
(local $w4_45 v128)
(local $w4_46 v128)
(local $w4_47 v128)
(local $w4_48 v128)
(local $w4_49 v128)
(local $w4_50 v128)
(local $w4_51 v128)
(local $w4_52 v128)
(local $w4_53 v128)
(local $w4_54 v128)
(local $w4_55 v128)
(local $w4_56 v128)
(local $w4_57 v128)
(local $w4_58 v128)
(local $w4_59 v128)
(local $w4_60 v128)
(local $w4_61 v128)
(local $w4_62 v128)
(local $w4_63 v128)
(local $w5_0 v128)
(local $w5_1 v128)
(local $w5_2 v128)
(local $w5_3 v128)
(local $w5_4 v128)
(local $w5_5 v128)
(local $w5_6 v128)
(local $w5_7 v128)
(local $w5_8 v128)
(local $w5_9 v128)
(local $w5_10 v128)
(local $w5_11 v128)
(local $w5_12 v128)
(local $w5_13 v128)
(local $w5_14 v128)
(local $w5_15 v128)
(local $w5_16 v128)
(local $w5_17 v128)
(local $w5_18 v128)
(local $w5_19 v128)
(local $w5_20 v128)
(local $w5_21 v128)
(local $w5_22 v128)
(local $w5_23 v128)
(local $w5_24 v128)
(local $w5_25 v128)
(local $w5_26 v128)
(local $w5_27 v128)
(local $w5_28 v128)
(local $w5_29 v128)
(local $w5_30 v128)
(local $w5_31 v128)
(local $w5_32 v128)
(local $w5_33 v128)
(local $w5_34 v128)
(local $w5_35 v128)
(local $w5_36 v128)
(local $w5_37 v128)
(local $w5_38 v128)
(local $w5_39 v128)
(local $w5_40 v128)
(local $w5_41 v128)
(local $w5_42 v128)
(local $w5_43 v128)
(local $w5_44 v128)
(local $w5_45 v128)
(local $w5_46 v128)
(local $w5_47 v128)
(local $w5_48 v128)
(local $w5_49 v128)
(local $w5_50 v128)
(local $w5_51 v128)
(local $w5_52 v128)
(local $w5_53 v128)
(local $w5_54 v128)
(local $w5_55 v128)
(local $w5_56 v128)
(local $w5_57 v128)
(local $w5_58 v128)
(local $w5_59 v128)
(local $w5_60 v128)
(local $w5_61 v128)
(local $w5_62 v128)
(local $w5_63 v128)
(local $w6_0 v128)
(local $w6_1 v128)
(local $w6_2 v128)
(local $w6_3 v128)
(local $w6_4 v128)
(local $w6_5 v128)
(local $w6_6 v128)
(local $w6_7 v128)
(local $w6_8 v128)
(local $w6_9 v128)
(local $w6_10 v128)
(local $w6_11 v128)
(local $w6_12 v128)
(local $w6_13 v128)
(local $w6_14 v128)
(local $w6_15 v128)
(local $w6_16 v128)
(local $w6_17 v128)
(local $w6_18 v128)
(local $w6_19 v128)
(local $w6_20 v128)
(local $w6_21 v128)
(local $w6_22 v128)
(local $w6_23 v128)
(local $w6_24 v128)
(local $w6_25 v128)
(local $w6_26 v128)
(local $w6_27 v128)
(local $w6_28 v128)
(local $w6_29 v128)
(local $w6_30 v128)
(local $w6_31 v128)
(local $w6_32 v128)
(local $w6_33 v128)
(local $w6_34 v128)
(local $w6_35 v128)
(local $w6_36 v128)
(local $w6_37 v128)
(local $w6_38 v128)
(local $w6_39 v128)
(local $w6_40 v128)
(local $w6_41 v128)
(local $w6_42 v128)
(local $w6_43 v128)
(local $w6_44 v128)
(local $w6_45 v128)
(local $w6_46 v128)
(local $w6_47 v128)
(local $w6_48 v128)
(local $w6_49 v128)
(local $w6_50 v128)
(local $w6_51 v128)
(local $w6_52 v128)
(local $w6_53 v128)
(local $w6_54 v128)
(local $w6_55 v128)
(local $w6_56 v128)
(local $w6_57 v128)
(local $w6_58 v128)
(local $w6_59 v128)
(local $w6_60 v128)
(local $w6_61 v128)
(local $w6_62 v128)
(local $w6_63 v128)
(local $w7_0 v128)
(local $w7_1 v128)
(local $w7_2 v128)
(local $w7_3 v128)
(local $w7_4 v128)
(local $w7_5 v128)
(local $w7_6 v128)
(local $w7_7 v128)
(local $w7_8 v128)
(local $w7_9 v128)
(local $w7_10 v128)
(local $w7_11 v128)
(local $w7_12 v128)
(local $w7_13 v128)
(local $w7_14 v128)
(local $w7_15 v128)
(local $w7_16 v128)
(local $w7_17 v128)
(local $w7_18 v128)
(local $w7_19 v128)
(local $w7_20 v128)
(local $w7_21 v128)
(local $w7_22 v128)
(local $w7_23 v128)
(local $w7_24 v128)
(local $w7_25 v128)
(local $w7_26 v128)
(local $w7_27 v128)
(local $w7_28 v128)
(local $w7_29 v128)
(local $w7_30 v128)
(local $w7_31 v128)
(local $w7_32 v128)
(local $w7_33 v128)
(local $w7_34 v128)
(local $w7_35 v128)
(local $w7_36 v128)
(local $w7_37 v128)
(local $w7_38 v128)
(local $w7_39 v128)
(local $w7_40 v128)
(local $w7_41 v128)
(local $w7_42 v128)
(local $w7_43 v128)
(local $w7_44 v128)
(local $w7_45 v128)
(local $w7_46 v128)
(local $w7_47 v128)
(local $w7_48 v128)
(local $w7_49 v128)
(local $w7_50 v128)
(local $w7_51 v128)
(local $w7_52 v128)
(local $w7_53 v128)
(local $w7_54 v128)
(local $w7_55 v128)
(local $w7_56 v128)
(local $w7_57 v128)
(local $w7_58 v128)
(local $w7_59 v128)
(local $w7_60 v128)
(local $w7_61 v128)
(local $w7_62 v128)
(local $w7_63 v128)
(local $w8_0 v128)
(local $w8_1 v128)
(local $w8_2 v128)
(local $w8_3 v128)
(local $w8_4 v128)
(local $w8_5 v128)
(local $w8_6 v128)
(local $w8_7 v128)
(local $w8_8 v128)
(local $w8_9 v128)
(local $w8_10 v128)
(local $w8_11 v128)
(local $w8_12 v128)
(local $w8_13 v128)
(local $w8_14 v128)
(local $w8_15 v128)
(local $w8_16 v128)
(local $w8_17 v128)
(local $w8_18 v128)
(local $w8_19 v128)
(local $w8_20 v128)
(local $w8_21 v128)
(local $w8_22 v128)
(local $w8_23 v128)
(local $w8_24 v128)
(local $w8_25 v128)
(local $w8_26 v128)
(local $w8_27 v128)
(local $w8_28 v128)
(local $w8_29 v128)
(local $w8_30 v128)
(local $w8_31 v128)
(local $w8_32 v128)
(local $w8_33 v128)
(local $w8_34 v128)
(local $w8_35 v128)
(local $w8_36 v128)
(local $w8_37 v128)
(local $w8_38 v128)
(local $w8_39 v128)
(local $w8_40 v128)
(local $w8_41 v128)
(local $w8_42 v128)
(local $w8_43 v128)
(local $w8_44 v128)
(local $w8_45 v128)
(local $w8_46 v128)
(local $w8_47 v128)
(local $w8_48 v128)
(local $w8_49 v128)
(local $w8_50 v128)
(local $w8_51 v128)
(local $w8_52 v128)
(local $w8_53 v128)
(local $w8_54 v128)
(local $w8_55 v128)
(local $w8_56 v128)
(local $w8_57 v128)
(local $w8_58 v128)
(local $w8_59 v128)
(local $w8_60 v128)
(local $w8_61 v128)
(local $w8_62 v128)
(local $w8_63 v128)
(local $w9_0 v128)
(local $w9_1 v128)
(local $w9_2 v128)
(local $w9_3 v128)
(local $w9_4 v128)
(local $w9_5 v128)
(local $w9_6 v128)
(local $w9_7 v128)
(local $w9_8 v128)
(local $w9_9 v128)
(local $w9_10 v128)
(local $w9_11 v128)
(local $w9_12 v128)
(local $w9_13 v128)
(local $w9_14 v128)
(local $w9_15 v128)
(local $w9_16 v128)
(local $w9_17 v128)
(local $w9_18 v128)
(local $w9_19 v128)
(local $w9_20 v128)
(local $w9_21 v128)
(local $w9_22 v128)
(local $w9_23 v128)
(local $w9_24 v128)
(local $w9_25 v128)
(local $w9_26 v128)
(local $w9_27 v128)
(local $w9_28 v128)
(local $w9_29 v128)
(local $w9_30 v128)
(local $w9_31 v128)
(local $w9_32 v128)
(local $w9_33 v128)
(local $w9_34 v128)
(local $w9_35 v128)
(local $w9_36 v128)
(local $w9_37 v128)
(local $w9_38 v128)
(local $w9_39 v128)
(local $w9_40 v128)
(local $w9_41 v128)
(local $w9_42 v128)
(local $w9_43 v128)
(local $w9_44 v128)
(local $w9_45 v128)
(local $w9_46 v128)
(local $w9_47 v128)
(local $w9_48 v128)
(local $w9_49 v128)
(local $w9_50 v128)
(local $w9_51 v128)
(local $w9_52 v128)
(local $w9_53 v128)
(local $w9_54 v128)
(local $w9_55 v128)
(local $w9_56 v128)
(local $w9_57 v128)
(local $w9_58 v128)
(local $w9_59 v128)
(local $w9_60 v128)
(local $w9_61 v128)
(local $w9_62 v128)
(local $w9_63 v128)
(local $w10_0 v128)
(local $w10_1 v128)
(local $w10_2 v128)
(local $w10_3 v128)
(local $w10_4 v128)
(local $w10_5 v128)
(local $w10_6 v128)
(local $w10_7 v128)
(local $w10_8 v128)
(local $w10_9 v128)
(local $w10_10 v128)
(local $w10_11 v128)
(local $w10_12 v128)
(local $w10_13 v128)
(local $w10_14 v128)
(local $w10_15 v128)
(local $w10_16 v128)
(local $w10_17 v128)
(local $w10_18 v128)
(local $w10_19 v128)
(local $w10_20 v128)
(local $w10_21 v128)
(local $w10_22 v128)
(local $w10_23 v128)
(local $w10_24 v128)
(local $w10_25 v128)
(local $w10_26 v128)
(local $w10_27 v128)
(local $w10_28 v128)
(local $w10_29 v128)
(local $w10_30 v128)
(local $w10_31 v128)
(local $w10_32 v128)
(local $w10_33 v128)
(local $w10_34 v128)
(local $w10_35 v128)
(local $w10_36 v128)
(local $w10_37 v128)
(local $w10_38 v128)
(local $w10_39 v128)
(local $w10_40 v128)
(local $w10_41 v128)
(local $w10_42 v128)
(local $w10_43 v128)
(local $w10_44 v128)
(local $w10_45 v128)
(local $w10_46 v128)
(local $w10_47 v128)
(local $w10_48 v128)
(local $w10_49 v128)
(local $w10_50 v128)
(local $w10_51 v128)
(local $w10_52 v128)
(local $w10_53 v128)
(local $w10_54 v128)
(local $w10_55 v128)
(local $w10_56 v128)
(local $w10_57 v128)
(local $w10_58 v128)
(local $w10_59 v128)
(local $w10_60 v128)
(local $w10_61 v128)
(local $w10_62 v128)
(local $w10_63 v128)
(local $w11_0 v128)
(local $w11_1 v128)
(local $w11_2 v128)
(local $w11_3 v128)
(local $w11_4 v128)
(local $w11_5 v128)
(local $w11_6 v128)
(local $w11_7 v128)
(local $w11_8 v128)
(local $w11_9 v128)
(local $w11_10 v128)
(local $w11_11 v128)
(local $w11_12 v128)
(local $w11_13 v128)
(local $w11_14 v128)
(local $w11_15 v128)
(local $w11_16 v128)
(local $w11_17 v128)
(local $w11_18 v128)
(local $w11_19 v128)
(local $w11_20 v128)
(local $w11_21 v128)
(local $w11_22 v128)
(local $w11_23 v128)
(local $w11_24 v128)
(local $w11_25 v128)
(local $w11_26 v128)
(local $w11_27 v128)
(local $w11_28 v128)
(local $w11_29 v128)
(local $w11_30 v128)
(local $w11_31 v128)
(local $w11_32 v128)
(local $w11_33 v128)
(local $w11_34 v128)
(local $w11_35 v128)
(local $w11_36 v128)
(local $w11_37 v128)
(local $w11_38 v128)
(local $w11_39 v128)
(local $w11_40 v128)
(local $w11_41 v128)
(local $w11_42 v128)
(local $w11_43 v128)
(local $w11_44 v128)
(local $w11_45 v128)
(local $w11_46 v128)
(local $w11_47 v128)
(local $w11_48 v128)
(local $w11_49 v128)
(local $w11_50 v128)
(local $w11_51 v128)
(local $w11_52 v128)
(local $w11_53 v128)
(local $w11_54 v128)
(local $w11_55 v128)
(local $w11_56 v128)
(local $w11_57 v128)
(local $w11_58 v128)
(local $w11_59 v128)
(local $w11_60 v128)
(local $w11_61 v128)
(local $w11_62 v128)
(local $w11_63 v128)
(local $w12_0 v128)
(local $w12_1 v128)
(local $w12_2 v128)
(local $w12_3 v128)
(local $w12_4 v128)
(local $w12_5 v128)
(local $w12_6 v128)
(local $w12_7 v128)
(local $w12_8 v128)
(local $w12_9 v128)
(local $w12_10 v128)
(local $w12_11 v128)
(local $w12_12 v128)
(local $w12_13 v128)
(local $w12_14 v128)
(local $w12_15 v128)
(local $w12_16 v128)
(local $w12_17 v128)
(local $w12_18 v128)
(local $w12_19 v128)
(local $w12_20 v128)
(local $w12_21 v128)
(local $w12_22 v128)
(local $w12_23 v128)
(local $w12_24 v128)
(local $w12_25 v128)
(local $w12_26 v128)
(local $w12_27 v128)
(local $w12_28 v128)
(local $w12_29 v128)
(local $w12_30 v128)
(local $w12_31 v128)
(local $w12_32 v128)
(local $w12_33 v128)
(local $w12_34 v128)
(local $w12_35 v128)
(local $w12_36 v128)
(local $w12_37 v128)
(local $w12_38 v128)
(local $w12_39 v128)
(local $w12_40 v128)
(local $w12_41 v128)
(local $w12_42 v128)
(local $w12_43 v128)
(local $w12_44 v128)
(local $w12_45 v128)
(local $w12_46 v128)
(local $w12_47 v128)
(local $w12_48 v128)
(local $w12_49 v128)
(local $w12_50 v128)
(local $w12_51 v128)
(local $w12_52 v128)
(local $w12_53 v128)
(local $w12_54 v128)
(local $w12_55 v128)
(local $w12_56 v128)
(local $w12_57 v128)
(local $w12_58 v128)
(local $w12_59 v128)
(local $w12_60 v128)
(local $w12_61 v128)
(local $w12_62 v128)
(local $w12_63 v128)
(local $w13_0 v128)
(local $w13_1 v128)
(local $w13_2 v128)
(local $w13_3 v128)
(local $w13_4 v128)
(local $w13_5 v128)
(local $w13_6 v128)
(local $w13_7 v128)
(local $w13_8 v128)
(local $w13_9 v128)
(local $w13_10 v128)
(local $w13_11 v128)
(local $w13_12 v128)
(local $w13_13 v128)
(local $w13_14 v128)
(local $w13_15 v128)
(local $w13_16 v128)
(local $w13_17 v128)
(local $w13_18 v128)
(local $w13_19 v128)
(local $w13_20 v128)
(local $w13_21 v128)
(local $w13_22 v128)
(local $w13_23 v128)
(local $w13_24 v128)
(local $w13_25 v128)
(local $w13_26 v128)
(local $w13_27 v128)
(local $w13_28 v128)
(local $w13_29 v128)
(local $w13_30 v128)
(local $w13_31 v128)
(local $w13_32 v128)
(local $w13_33 v128)
(local $w13_34 v128)
(local $w13_35 v128)
(local $w13_36 v128)
(local $w13_37 v128)
(local $w13_38 v128)
(local $w13_39 v128)
(local $w13_40 v128)
(local $w13_41 v128)
(local $w13_42 v128)
(local $w13_43 v128)
(local $w13_44 v128)
(local $w13_45 v128)
(local $w13_46 v128)
(local $w13_47 v128)
(local $w13_48 v128)
(local $w13_49 v128)
(local $w13_50 v128)
(local $w13_51 v128)
(local $w13_52 v128)
(local $w13_53 v128)
(local $w13_54 v128)
(local $w13_55 v128)
(local $w13_56 v128)
(local $w13_57 v128)
(local $w13_58 v128)
(local $w13_59 v128)
(local $w13_60 v128)
(local $w13_61 v128)
(local $w13_62 v128)
(local $w13_63 v128)
(local $w14_0 v128)
(local $w14_1 v128)
(local $w14_2 v128)
(local $w14_3 v128)
(local $w14_4 v128)
(local $w14_5 v128)
(local $w14_6 v128)
(local $w14_7 v128)
(local $w14_8 v128)
(local $w14_9 v128)
(local $w14_10 v128)
(local $w14_11 v128)
(local $w14_12 v128)
(local $w14_13 v128)
(local $w14_14 v128)
(local $w14_15 v128)
(local $w14_16 v128)
(local $w14_17 v128)
(local $w14_18 v128)
(local $w14_19 v128)
(local $w14_20 v128)
(local $w14_21 v128)
(local $w14_22 v128)
(local $w14_23 v128)
(local $w14_24 v128)
(local $w14_25 v128)
(local $w14_26 v128)
(local $w14_27 v128)
(local $w14_28 v128)
(local $w14_29 v128)
(local $w14_30 v128)
(local $w14_31 v128)
(local $w14_32 v128)
(local $w14_33 v128)
(local $w14_34 v128)
(local $w14_35 v128)
(local $w14_36 v128)
(local $w14_37 v128)
(local $w14_38 v128)
(local $w14_39 v128)
(local $w14_40 v128)
(local $w14_41 v128)
(local $w14_42 v128)
(local $w14_43 v128)
(local $w14_44 v128)
(local $w14_45 v128)
(local $w14_46 v128)
(local $w14_47 v128)
(local $w14_48 v128)
(local $w14_49 v128)
(local $w14_50 v128)
(local $w14_51 v128)
(local $w14_52 v128)
(local $w14_53 v128)
(local $w14_54 v128)
(local $w14_55 v128)
(local $w14_56 v128)
(local $w14_57 v128)
(local $w14_58 v128)
(local $w14_59 v128)
(local $w14_60 v128)
(local $w14_61 v128)
(local $w14_62 v128)
(local $w14_63 v128)
(local $w15_0 v128)
(local $w15_1 v128)
(local $w15_2 v128)
(local $w15_3 v128)
(local $w15_4 v128)
(local $w15_5 v128)
(local $w15_6 v128)
(local $w15_7 v128)
(local $w15_8 v128)
(local $w15_9 v128)
(local $w15_10 v128)
(local $w15_11 v128)
(local $w15_12 v128)
(local $w15_13 v128)
(local $w15_14 v128)
(local $w15_15 v128)
(local $w15_16 v128)
(local $w15_17 v128)
(local $w15_18 v128)
(local $w15_19 v128)
(local $w15_20 v128)
(local $w15_21 v128)
(local $w15_22 v128)
(local $w15_23 v128)
(local $w15_24 v128)
(local $w15_25 v128)
(local $w15_26 v128)
(local $w15_27 v128)
(local $w15_28 v128)
(local $w15_29 v128)
(local $w15_30 v128)
(local $w15_31 v128)
(local $w15_32 v128)
(local $w15_33 v128)
(local $w15_34 v128)
(local $w15_35 v128)
(local $w15_36 v128)
(local $w15_37 v128)
(local $w15_38 v128)
(local $w15_39 v128)
(local $w15_40 v128)
(local $w15_41 v128)
(local $w15_42 v128)
(local $w15_43 v128)
(local $w15_44 v128)
(local $w15_45 v128)
(local $w15_46 v128)
(local $w15_47 v128)
(local $w15_48 v128)
(local $w15_49 v128)
(local $w15_50 v128)
(local $w15_51 v128)
(local $w15_52 v128)
(local $w15_53 v128)
(local $w15_54 v128)
(local $w15_55 v128)
(local $w15_56 v128)
(local $w15_57 v128)
(local $w15_58 v128)
(local $w15_59 v128)
(local $w15_60 v128)
(local $w15_61 v128)
(local $w15_62 v128)
(local $w15_63 v128)
(local $x0 v128)
(local $x1 v128)
(local $x2 v128)
(local $x3 v128)
(local $x4 v128)
(local $x5 v128)
(local $x6 v128)
(local $x7 v128)
(local $x8 v128)
(local $x9 v128)
(local $x10 v128)
(local $x11 v128)
(local $x12 v128)
(local $x13 v128)
(local $x14 v128)
(local $x15 v128)
(local $x16 v128)
(local $x17 v128)
(local $x18 v128)
(local $x19 v128)
(local $x20 v128)
(local $x21 v128)
(local $x22 v128)
(local $x23 v128)
(local $x24 v128)
(local $x25 v128)
(local $x26 v128)
(local $x27 v128)
(local $x28 v128)
(local $x29 v128)
(local $x30 v128)
(local $x31 v128)
(local $x32 v128)
(local $x33 v128)
(local $x34 v128)
(local $x35 v128)
(local $x36 v128)
(local $x37 v128)
(local $x38 v128)
(local $x39 v128)
(local $x40 v128)
(local $x41 v128)
(local $x42 v128)
(local $x43 v128)
(local $x44 v128)
(local $x45 v128)
(local $x46 v128)
(local $x47 v128)
(local $x48 v128)
(local $x49 v128)
(local $x50 v128)
(local $x51 v128)
(local $x52 v128)
(local $x53 v128)
(local $x54 v128)
(local $x55 v128)
(local $x56 v128)
(local $x57 v128)
(local $x58 v128)
(local $x59 v128)
(local $x60 v128)
(local $x61 v128)
(local $x62 v128)
(local $x63 v128)
(local $scale0 v128)
(local $scale1 v128)
(local $scale2 v128)
(local $scale3 v128)
(local $scale4 v128)
(local $scale5 v128)
(local $scale6 v128)
(local $scale7 v128)
(if (i32.gt_u (local.get $n) (i32.const 132)) (then unreachable))
(block $done
(br_if $done (i32.eqz (local.get $n)))
(local.set $t (i32.const 0))
(local.set $qp (i32.add (local.get $q) (i32.shl (i32.add (i32.mul (local.get $t) (local.get $cols)) (local.get $start)) (i32.const 1))))
(local.set $yp (i32.add (local.get $sums) (i32.shl (local.get $t) (i32.const 7))))
local.get $yp
local.get $yp
v128.load offset=0
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 0)) (i32.shl (local.get $start) (i32.const 1)))))
(local.tee $x0 (v128.load64_splat offset=0 (local.get $qp)))
(local.tee $w0_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x1 (v128.load64_splat offset=8 (local.get $qp)))
(local.tee $w0_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2 (v128.load64_splat offset=16 (local.get $qp)))
(local.tee $w0_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x3 (v128.load64_splat offset=24 (local.get $qp)))
(local.tee $w0_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x4 (v128.load64_splat offset=32 (local.get $qp)))
(local.tee $w0_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x5 (v128.load64_splat offset=40 (local.get $qp)))
(local.tee $w0_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6 (v128.load64_splat offset=48 (local.get $qp)))
(local.tee $w0_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x7 (v128.load64_splat offset=56 (local.get $qp)))
(local.tee $w0_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x8 (v128.load64_splat offset=64 (local.get $qp)))
(local.tee $w0_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x9 (v128.load64_splat offset=72 (local.get $qp)))
(local.tee $w0_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10 (v128.load64_splat offset=80 (local.get $qp)))
(local.tee $w0_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x11 (v128.load64_splat offset=88 (local.get $qp)))
(local.tee $w0_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x12 (v128.load64_splat offset=96 (local.get $qp)))
(local.tee $w0_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x13 (v128.load64_splat offset=104 (local.get $qp)))
(local.tee $w0_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14 (v128.load64_splat offset=112 (local.get $qp)))
(local.tee $w0_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x15 (v128.load64_splat offset=120 (local.get $qp)))
(local.tee $w0_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
(local.tee $x16 (v128.load64_splat offset=128 (local.get $qp)))
(local.tee $w0_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x17 (v128.load64_splat offset=136 (local.get $qp)))
(local.tee $w0_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18 (v128.load64_splat offset=144 (local.get $qp)))
(local.tee $w0_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x19 (v128.load64_splat offset=152 (local.get $qp)))
(local.tee $w0_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x20 (v128.load64_splat offset=160 (local.get $qp)))
(local.tee $w0_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x21 (v128.load64_splat offset=168 (local.get $qp)))
(local.tee $w0_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22 (v128.load64_splat offset=176 (local.get $qp)))
(local.tee $w0_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x23 (v128.load64_splat offset=184 (local.get $qp)))
(local.tee $w0_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x24 (v128.load64_splat offset=192 (local.get $qp)))
(local.tee $w0_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x25 (v128.load64_splat offset=200 (local.get $qp)))
(local.tee $w0_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26 (v128.load64_splat offset=208 (local.get $qp)))
(local.tee $w0_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x27 (v128.load64_splat offset=216 (local.get $qp)))
(local.tee $w0_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x28 (v128.load64_splat offset=224 (local.get $qp)))
(local.tee $w0_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x29 (v128.load64_splat offset=232 (local.get $qp)))
(local.tee $w0_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30 (v128.load64_splat offset=240 (local.get $qp)))
(local.tee $w0_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x31 (v128.load64_splat offset=248 (local.get $qp)))
(local.tee $w0_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
(local.tee $x32 (v128.load64_splat offset=256 (local.get $qp)))
(local.tee $w0_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x33 (v128.load64_splat offset=264 (local.get $qp)))
(local.tee $w0_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x34 (v128.load64_splat offset=272 (local.get $qp)))
(local.tee $w0_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x35 (v128.load64_splat offset=280 (local.get $qp)))
(local.tee $w0_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x36 (v128.load64_splat offset=288 (local.get $qp)))
(local.tee $w0_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x37 (v128.load64_splat offset=296 (local.get $qp)))
(local.tee $w0_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x38 (v128.load64_splat offset=304 (local.get $qp)))
(local.tee $w0_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x39 (v128.load64_splat offset=312 (local.get $qp)))
(local.tee $w0_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x40 (v128.load64_splat offset=320 (local.get $qp)))
(local.tee $w0_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x41 (v128.load64_splat offset=328 (local.get $qp)))
(local.tee $w0_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x42 (v128.load64_splat offset=336 (local.get $qp)))
(local.tee $w0_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x43 (v128.load64_splat offset=344 (local.get $qp)))
(local.tee $w0_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x44 (v128.load64_splat offset=352 (local.get $qp)))
(local.tee $w0_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x45 (v128.load64_splat offset=360 (local.get $qp)))
(local.tee $w0_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x46 (v128.load64_splat offset=368 (local.get $qp)))
(local.tee $w0_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x47 (v128.load64_splat offset=376 (local.get $qp)))
(local.tee $w0_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
(local.tee $x48 (v128.load64_splat offset=384 (local.get $qp)))
(local.tee $w0_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x49 (v128.load64_splat offset=392 (local.get $qp)))
(local.tee $w0_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x50 (v128.load64_splat offset=400 (local.get $qp)))
(local.tee $w0_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x51 (v128.load64_splat offset=408 (local.get $qp)))
(local.tee $w0_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x52 (v128.load64_splat offset=416 (local.get $qp)))
(local.tee $w0_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x53 (v128.load64_splat offset=424 (local.get $qp)))
(local.tee $w0_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x54 (v128.load64_splat offset=432 (local.get $qp)))
(local.tee $w0_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x55 (v128.load64_splat offset=440 (local.get $qp)))
(local.tee $w0_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x56 (v128.load64_splat offset=448 (local.get $qp)))
(local.tee $w0_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x57 (v128.load64_splat offset=456 (local.get $qp)))
(local.tee $w0_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x58 (v128.load64_splat offset=464 (local.get $qp)))
(local.tee $w0_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x59 (v128.load64_splat offset=472 (local.get $qp)))
(local.tee $w0_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x60 (v128.load64_splat offset=480 (local.get $qp)))
(local.tee $w0_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x61 (v128.load64_splat offset=488 (local.get $qp)))
(local.tee $w0_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x62 (v128.load64_splat offset=496 (local.get $qp)))
(local.tee $w0_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
(local.tee $x63 (v128.load64_splat offset=504 (local.get $qp)))
(local.tee $w0_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 2)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w1_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w1_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w1_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w1_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w1_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w1_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w1_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w1_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w1_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w1_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w1_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w1_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w1_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w1_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w1_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w1_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w1_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w1_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w1_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w1_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w1_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w1_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w1_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w1_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w1_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w1_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w1_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w1_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w1_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w1_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w1_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w1_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w1_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w1_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w1_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w1_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w1_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w1_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w1_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w1_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w1_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w1_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w1_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w1_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w1_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w1_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w1_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w1_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w1_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w1_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w1_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w1_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w1_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w1_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w1_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w1_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w1_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w1_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w1_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w1_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w1_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w1_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w1_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w1_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
(local.tee $xscale (v128.load32_splat (i32.add (local.get $sx) (i32.shl (i32.mul (local.get $t) (local.get $stride)) (i32.const 2)))))
f32x4.mul
(local.tee $scale0 (v128.load offset=0 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
local.get $yp
v128.load offset=16
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 4)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w2_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w2_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w2_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w2_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w2_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w2_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w2_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w2_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w2_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w2_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w2_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w2_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w2_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w2_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w2_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w2_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w2_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w2_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w2_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w2_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w2_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w2_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w2_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w2_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w2_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w2_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w2_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w2_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w2_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w2_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w2_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w2_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w2_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w2_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w2_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w2_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w2_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w2_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w2_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w2_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w2_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w2_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w2_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w2_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w2_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w2_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w2_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w2_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w2_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w2_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w2_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w2_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w2_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w2_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w2_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w2_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w2_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w2_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w2_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w2_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w2_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w2_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w2_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w2_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 6)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w3_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w3_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w3_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w3_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w3_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w3_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w3_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w3_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w3_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w3_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w3_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w3_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w3_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w3_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w3_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w3_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w3_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w3_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w3_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w3_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w3_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w3_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w3_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w3_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w3_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w3_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w3_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w3_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w3_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w3_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w3_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w3_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w3_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w3_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w3_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w3_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w3_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w3_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w3_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w3_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w3_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w3_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w3_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w3_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w3_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w3_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w3_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w3_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w3_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w3_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w3_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w3_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w3_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w3_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w3_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w3_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w3_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w3_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w3_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w3_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w3_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w3_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w3_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w3_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
(local.tee $scale1 (v128.load offset=16 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
local.get $yp
v128.load offset=32
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 8)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w4_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w4_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w4_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w4_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w4_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w4_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w4_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w4_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w4_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w4_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w4_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w4_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w4_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w4_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w4_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w4_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w4_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w4_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w4_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w4_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w4_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w4_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w4_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w4_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w4_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w4_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w4_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w4_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w4_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w4_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w4_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w4_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w4_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w4_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w4_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w4_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w4_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w4_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w4_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w4_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w4_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w4_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w4_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w4_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w4_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w4_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w4_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w4_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w4_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w4_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w4_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w4_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w4_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w4_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w4_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w4_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w4_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w4_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w4_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w4_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w4_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w4_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w4_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w4_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 10)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w5_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w5_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w5_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w5_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w5_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w5_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w5_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w5_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w5_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w5_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w5_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w5_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w5_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w5_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w5_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w5_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w5_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w5_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w5_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w5_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w5_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w5_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w5_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w5_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w5_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w5_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w5_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w5_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w5_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w5_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w5_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w5_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w5_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w5_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w5_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w5_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w5_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w5_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w5_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w5_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w5_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w5_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w5_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w5_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w5_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w5_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w5_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w5_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w5_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w5_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w5_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w5_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w5_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w5_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w5_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w5_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w5_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w5_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w5_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w5_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w5_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w5_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w5_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w5_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
(local.tee $scale2 (v128.load offset=32 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
local.get $yp
v128.load offset=48
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 12)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w6_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w6_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w6_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w6_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w6_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w6_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w6_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w6_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w6_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w6_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w6_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w6_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w6_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w6_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w6_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w6_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w6_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w6_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w6_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w6_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w6_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w6_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w6_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w6_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w6_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w6_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w6_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w6_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w6_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w6_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w6_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w6_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w6_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w6_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w6_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w6_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w6_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w6_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w6_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w6_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w6_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w6_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w6_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w6_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w6_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w6_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w6_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w6_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w6_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w6_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w6_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w6_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w6_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w6_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w6_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w6_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w6_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w6_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w6_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w6_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w6_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w6_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w6_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w6_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 14)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w7_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w7_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w7_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w7_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w7_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w7_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w7_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w7_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w7_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w7_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w7_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w7_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w7_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w7_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w7_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w7_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w7_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w7_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w7_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w7_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w7_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w7_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w7_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w7_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w7_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w7_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w7_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w7_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w7_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w7_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w7_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w7_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w7_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w7_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w7_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w7_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w7_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w7_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w7_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w7_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w7_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w7_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w7_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w7_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w7_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w7_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w7_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w7_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w7_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w7_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w7_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w7_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w7_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w7_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w7_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w7_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w7_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w7_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w7_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w7_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w7_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w7_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w7_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w7_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
(local.tee $scale3 (v128.load offset=48 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=48
local.get $yp
local.get $yp
v128.load offset=64
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 16)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w8_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w8_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w8_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w8_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w8_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w8_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w8_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w8_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w8_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w8_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w8_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w8_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w8_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w8_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w8_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w8_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w8_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w8_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w8_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w8_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w8_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w8_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w8_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w8_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w8_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w8_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w8_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w8_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w8_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w8_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w8_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w8_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w8_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w8_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w8_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w8_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w8_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w8_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w8_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w8_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w8_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w8_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w8_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w8_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w8_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w8_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w8_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w8_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w8_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w8_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w8_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w8_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w8_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w8_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w8_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w8_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w8_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w8_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w8_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w8_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w8_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w8_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w8_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w8_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 18)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w9_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w9_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w9_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w9_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w9_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w9_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w9_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w9_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w9_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w9_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w9_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w9_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w9_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w9_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w9_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w9_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w9_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w9_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w9_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w9_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w9_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w9_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w9_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w9_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w9_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w9_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w9_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w9_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w9_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w9_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w9_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w9_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w9_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w9_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w9_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w9_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w9_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w9_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w9_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w9_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w9_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w9_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w9_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w9_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w9_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w9_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w9_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w9_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w9_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w9_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w9_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w9_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w9_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w9_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w9_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w9_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w9_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w9_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w9_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w9_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w9_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w9_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w9_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w9_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
(local.tee $scale4 (v128.load offset=64 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp
local.get $yp
v128.load offset=80
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 20)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w10_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w10_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w10_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w10_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w10_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w10_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w10_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w10_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w10_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w10_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w10_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w10_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w10_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w10_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w10_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w10_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w10_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w10_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w10_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w10_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w10_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w10_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w10_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w10_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w10_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w10_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w10_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w10_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w10_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w10_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w10_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w10_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w10_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w10_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w10_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w10_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w10_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w10_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w10_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w10_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w10_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w10_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w10_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w10_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w10_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w10_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w10_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w10_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w10_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w10_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w10_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w10_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w10_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w10_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w10_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w10_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w10_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w10_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w10_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w10_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w10_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w10_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w10_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w10_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 22)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w11_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w11_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w11_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w11_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w11_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w11_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w11_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w11_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w11_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w11_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w11_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w11_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w11_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w11_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w11_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w11_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w11_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w11_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w11_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w11_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w11_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w11_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w11_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w11_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w11_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w11_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w11_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w11_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w11_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w11_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w11_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w11_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w11_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w11_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w11_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w11_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w11_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w11_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w11_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w11_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w11_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w11_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w11_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w11_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w11_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w11_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w11_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w11_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w11_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w11_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w11_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w11_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w11_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w11_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w11_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w11_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w11_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w11_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w11_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w11_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w11_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w11_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w11_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w11_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
(local.tee $scale5 (v128.load offset=80 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=80
local.get $yp
local.get $yp
v128.load offset=96
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 24)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w12_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w12_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w12_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w12_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w12_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w12_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w12_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w12_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w12_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w12_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w12_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w12_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w12_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w12_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w12_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w12_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w12_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w12_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w12_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w12_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w12_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w12_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w12_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w12_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w12_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w12_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w12_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w12_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w12_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w12_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w12_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w12_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w12_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w12_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w12_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w12_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w12_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w12_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w12_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w12_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w12_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w12_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w12_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w12_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w12_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w12_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w12_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w12_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w12_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w12_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w12_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w12_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w12_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w12_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w12_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w12_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w12_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w12_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w12_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w12_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w12_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w12_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w12_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w12_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 26)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w13_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w13_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w13_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w13_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w13_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w13_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w13_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w13_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w13_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w13_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w13_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w13_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w13_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w13_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w13_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w13_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w13_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w13_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w13_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w13_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w13_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w13_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w13_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w13_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w13_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w13_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w13_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w13_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w13_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w13_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w13_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w13_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w13_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w13_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w13_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w13_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w13_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w13_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w13_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w13_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w13_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w13_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w13_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w13_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w13_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w13_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w13_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w13_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w13_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w13_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w13_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w13_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w13_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w13_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w13_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w13_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w13_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w13_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w13_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w13_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w13_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w13_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w13_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w13_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
(local.tee $scale6 (v128.load offset=96 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp
local.get $yp
v128.load offset=112
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 28)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w14_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w14_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w14_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w14_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w14_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w14_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w14_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w14_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w14_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w14_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w14_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w14_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w14_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w14_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w14_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w14_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w14_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w14_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w14_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w14_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w14_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w14_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w14_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w14_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w14_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w14_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w14_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w14_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w14_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w14_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w14_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w14_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w14_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w14_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w14_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w14_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w14_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w14_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w14_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w14_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w14_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w14_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w14_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w14_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w14_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w14_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w14_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w14_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w14_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w14_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w14_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w14_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w14_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w14_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w14_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w14_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w14_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w14_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w14_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w14_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w14_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w14_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w14_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w14_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
(local.set $wp (i32.add (local.get $w) (i32.add (i32.mul (local.get $cols) (i32.const 30)) (i32.shl (local.get $start) (i32.const 1)))))
local.get $x0
(local.tee $w15_0 (v128.load8x8_s offset=0 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x1
(local.tee $w15_1 (v128.load8x8_s offset=8 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
(local.tee $w15_2 (v128.load8x8_s offset=16 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x3
(local.tee $w15_3 (v128.load8x8_s offset=24 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
(local.tee $w15_4 (v128.load8x8_s offset=32 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x5
(local.tee $w15_5 (v128.load8x8_s offset=40 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
(local.tee $w15_6 (v128.load8x8_s offset=48 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x7
(local.tee $w15_7 (v128.load8x8_s offset=56 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
(local.tee $w15_8 (v128.load8x8_s offset=64 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x9
(local.tee $w15_9 (v128.load8x8_s offset=72 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
(local.tee $w15_10 (v128.load8x8_s offset=80 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x11
(local.tee $w15_11 (v128.load8x8_s offset=88 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
(local.tee $w15_12 (v128.load8x8_s offset=96 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x13
(local.tee $w15_13 (v128.load8x8_s offset=104 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
(local.tee $w15_14 (v128.load8x8_s offset=112 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x15
(local.tee $w15_15 (v128.load8x8_s offset=120 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
(local.tee $w15_16 (v128.load8x8_s offset=128 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x17
(local.tee $w15_17 (v128.load8x8_s offset=136 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
(local.tee $w15_18 (v128.load8x8_s offset=144 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x19
(local.tee $w15_19 (v128.load8x8_s offset=152 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
(local.tee $w15_20 (v128.load8x8_s offset=160 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x21
(local.tee $w15_21 (v128.load8x8_s offset=168 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
(local.tee $w15_22 (v128.load8x8_s offset=176 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x23
(local.tee $w15_23 (v128.load8x8_s offset=184 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
(local.tee $w15_24 (v128.load8x8_s offset=192 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x25
(local.tee $w15_25 (v128.load8x8_s offset=200 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
(local.tee $w15_26 (v128.load8x8_s offset=208 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x27
(local.tee $w15_27 (v128.load8x8_s offset=216 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
(local.tee $w15_28 (v128.load8x8_s offset=224 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x29
(local.tee $w15_29 (v128.load8x8_s offset=232 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
(local.tee $w15_30 (v128.load8x8_s offset=240 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x31
(local.tee $w15_31 (v128.load8x8_s offset=248 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
(local.tee $w15_32 (v128.load8x8_s offset=256 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x33
(local.tee $w15_33 (v128.load8x8_s offset=264 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
(local.tee $w15_34 (v128.load8x8_s offset=272 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x35
(local.tee $w15_35 (v128.load8x8_s offset=280 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
(local.tee $w15_36 (v128.load8x8_s offset=288 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x37
(local.tee $w15_37 (v128.load8x8_s offset=296 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
(local.tee $w15_38 (v128.load8x8_s offset=304 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x39
(local.tee $w15_39 (v128.load8x8_s offset=312 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
(local.tee $w15_40 (v128.load8x8_s offset=320 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x41
(local.tee $w15_41 (v128.load8x8_s offset=328 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
(local.tee $w15_42 (v128.load8x8_s offset=336 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x43
(local.tee $w15_43 (v128.load8x8_s offset=344 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
(local.tee $w15_44 (v128.load8x8_s offset=352 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x45
(local.tee $w15_45 (v128.load8x8_s offset=360 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
(local.tee $w15_46 (v128.load8x8_s offset=368 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x47
(local.tee $w15_47 (v128.load8x8_s offset=376 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
(local.tee $w15_48 (v128.load8x8_s offset=384 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x49
(local.tee $w15_49 (v128.load8x8_s offset=392 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
(local.tee $w15_50 (v128.load8x8_s offset=400 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x51
(local.tee $w15_51 (v128.load8x8_s offset=408 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
(local.tee $w15_52 (v128.load8x8_s offset=416 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x53
(local.tee $w15_53 (v128.load8x8_s offset=424 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
(local.tee $w15_54 (v128.load8x8_s offset=432 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x55
(local.tee $w15_55 (v128.load8x8_s offset=440 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
(local.tee $w15_56 (v128.load8x8_s offset=448 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x57
(local.tee $w15_57 (v128.load8x8_s offset=456 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
(local.tee $w15_58 (v128.load8x8_s offset=464 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x59
(local.tee $w15_59 (v128.load8x8_s offset=472 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
(local.tee $w15_60 (v128.load8x8_s offset=480 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x61
(local.tee $w15_61 (v128.load8x8_s offset=488 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
(local.tee $w15_62 (v128.load8x8_s offset=496 (local.get $wp)))
i32x4.dot_i16x8_s
local.get $x63
(local.tee $w15_63 (v128.load8x8_s offset=504 (local.get $wp)))
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
(local.tee $scale7 (v128.load offset=112 (local.get $sw)))
f32x4.mul
f32x4.add
v128.store offset=112
(local.set $t (i32.const 1))
(loop $tokens
(br_if $done (i32.ge_u (local.get $t) (local.get $n)))
(local.set $qp (i32.add (local.get $q) (i32.shl (i32.add (i32.mul (local.get $t) (local.get $cols)) (local.get $start)) (i32.const 1))))
(local.set $yp (i32.add (local.get $sums) (i32.shl (local.get $t) (i32.const 7))))
local.get $yp
local.get $yp
v128.load offset=0
(local.tee $x0 (v128.load64_splat offset=0 (local.get $qp)))
local.get $w0_0
i32x4.dot_i16x8_s
(local.tee $x1 (v128.load64_splat offset=8 (local.get $qp)))
local.get $w0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2 (v128.load64_splat offset=16 (local.get $qp)))
local.get $w0_2
i32x4.dot_i16x8_s
(local.tee $x3 (v128.load64_splat offset=24 (local.get $qp)))
local.get $w0_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x4 (v128.load64_splat offset=32 (local.get $qp)))
local.get $w0_4
i32x4.dot_i16x8_s
(local.tee $x5 (v128.load64_splat offset=40 (local.get $qp)))
local.get $w0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6 (v128.load64_splat offset=48 (local.get $qp)))
local.get $w0_6
i32x4.dot_i16x8_s
(local.tee $x7 (v128.load64_splat offset=56 (local.get $qp)))
local.get $w0_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x8 (v128.load64_splat offset=64 (local.get $qp)))
local.get $w0_8
i32x4.dot_i16x8_s
(local.tee $x9 (v128.load64_splat offset=72 (local.get $qp)))
local.get $w0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10 (v128.load64_splat offset=80 (local.get $qp)))
local.get $w0_10
i32x4.dot_i16x8_s
(local.tee $x11 (v128.load64_splat offset=88 (local.get $qp)))
local.get $w0_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x12 (v128.load64_splat offset=96 (local.get $qp)))
local.get $w0_12
i32x4.dot_i16x8_s
(local.tee $x13 (v128.load64_splat offset=104 (local.get $qp)))
local.get $w0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14 (v128.load64_splat offset=112 (local.get $qp)))
local.get $w0_14
i32x4.dot_i16x8_s
(local.tee $x15 (v128.load64_splat offset=120 (local.get $qp)))
local.get $w0_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
(local.tee $x16 (v128.load64_splat offset=128 (local.get $qp)))
local.get $w0_16
i32x4.dot_i16x8_s
(local.tee $x17 (v128.load64_splat offset=136 (local.get $qp)))
local.get $w0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18 (v128.load64_splat offset=144 (local.get $qp)))
local.get $w0_18
i32x4.dot_i16x8_s
(local.tee $x19 (v128.load64_splat offset=152 (local.get $qp)))
local.get $w0_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x20 (v128.load64_splat offset=160 (local.get $qp)))
local.get $w0_20
i32x4.dot_i16x8_s
(local.tee $x21 (v128.load64_splat offset=168 (local.get $qp)))
local.get $w0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22 (v128.load64_splat offset=176 (local.get $qp)))
local.get $w0_22
i32x4.dot_i16x8_s
(local.tee $x23 (v128.load64_splat offset=184 (local.get $qp)))
local.get $w0_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x24 (v128.load64_splat offset=192 (local.get $qp)))
local.get $w0_24
i32x4.dot_i16x8_s
(local.tee $x25 (v128.load64_splat offset=200 (local.get $qp)))
local.get $w0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26 (v128.load64_splat offset=208 (local.get $qp)))
local.get $w0_26
i32x4.dot_i16x8_s
(local.tee $x27 (v128.load64_splat offset=216 (local.get $qp)))
local.get $w0_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x28 (v128.load64_splat offset=224 (local.get $qp)))
local.get $w0_28
i32x4.dot_i16x8_s
(local.tee $x29 (v128.load64_splat offset=232 (local.get $qp)))
local.get $w0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30 (v128.load64_splat offset=240 (local.get $qp)))
local.get $w0_30
i32x4.dot_i16x8_s
(local.tee $x31 (v128.load64_splat offset=248 (local.get $qp)))
local.get $w0_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
(local.tee $x32 (v128.load64_splat offset=256 (local.get $qp)))
local.get $w0_32
i32x4.dot_i16x8_s
(local.tee $x33 (v128.load64_splat offset=264 (local.get $qp)))
local.get $w0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x34 (v128.load64_splat offset=272 (local.get $qp)))
local.get $w0_34
i32x4.dot_i16x8_s
(local.tee $x35 (v128.load64_splat offset=280 (local.get $qp)))
local.get $w0_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x36 (v128.load64_splat offset=288 (local.get $qp)))
local.get $w0_36
i32x4.dot_i16x8_s
(local.tee $x37 (v128.load64_splat offset=296 (local.get $qp)))
local.get $w0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x38 (v128.load64_splat offset=304 (local.get $qp)))
local.get $w0_38
i32x4.dot_i16x8_s
(local.tee $x39 (v128.load64_splat offset=312 (local.get $qp)))
local.get $w0_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x40 (v128.load64_splat offset=320 (local.get $qp)))
local.get $w0_40
i32x4.dot_i16x8_s
(local.tee $x41 (v128.load64_splat offset=328 (local.get $qp)))
local.get $w0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x42 (v128.load64_splat offset=336 (local.get $qp)))
local.get $w0_42
i32x4.dot_i16x8_s
(local.tee $x43 (v128.load64_splat offset=344 (local.get $qp)))
local.get $w0_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x44 (v128.load64_splat offset=352 (local.get $qp)))
local.get $w0_44
i32x4.dot_i16x8_s
(local.tee $x45 (v128.load64_splat offset=360 (local.get $qp)))
local.get $w0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x46 (v128.load64_splat offset=368 (local.get $qp)))
local.get $w0_46
i32x4.dot_i16x8_s
(local.tee $x47 (v128.load64_splat offset=376 (local.get $qp)))
local.get $w0_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
(local.tee $x48 (v128.load64_splat offset=384 (local.get $qp)))
local.get $w0_48
i32x4.dot_i16x8_s
(local.tee $x49 (v128.load64_splat offset=392 (local.get $qp)))
local.get $w0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x50 (v128.load64_splat offset=400 (local.get $qp)))
local.get $w0_50
i32x4.dot_i16x8_s
(local.tee $x51 (v128.load64_splat offset=408 (local.get $qp)))
local.get $w0_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x52 (v128.load64_splat offset=416 (local.get $qp)))
local.get $w0_52
i32x4.dot_i16x8_s
(local.tee $x53 (v128.load64_splat offset=424 (local.get $qp)))
local.get $w0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x54 (v128.load64_splat offset=432 (local.get $qp)))
local.get $w0_54
i32x4.dot_i16x8_s
(local.tee $x55 (v128.load64_splat offset=440 (local.get $qp)))
local.get $w0_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
(local.tee $x56 (v128.load64_splat offset=448 (local.get $qp)))
local.get $w0_56
i32x4.dot_i16x8_s
(local.tee $x57 (v128.load64_splat offset=456 (local.get $qp)))
local.get $w0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x58 (v128.load64_splat offset=464 (local.get $qp)))
local.get $w0_58
i32x4.dot_i16x8_s
(local.tee $x59 (v128.load64_splat offset=472 (local.get $qp)))
local.get $w0_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
(local.tee $x60 (v128.load64_splat offset=480 (local.get $qp)))
local.get $w0_60
i32x4.dot_i16x8_s
(local.tee $x61 (v128.load64_splat offset=488 (local.get $qp)))
local.get $w0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x62 (v128.load64_splat offset=496 (local.get $qp)))
local.get $w0_62
i32x4.dot_i16x8_s
(local.tee $x63 (v128.load64_splat offset=504 (local.get $qp)))
local.get $w0_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w1_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w1_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w1_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w1_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w1_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w1_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w1_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w1_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w1_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w1_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w1_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w1_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w1_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w1_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w1_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w1_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w1_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w1_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w1_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w1_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w1_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w1_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w1_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w1_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w1_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w1_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w1_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w1_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w1_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w1_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w1_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w1_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w1_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w1_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w1_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w1_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w1_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w1_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w1_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w1_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w1_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w1_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w1_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w1_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w1_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w1_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w1_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w1_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
(local.tee $xscale (v128.load32_splat (i32.add (local.get $sx) (i32.shl (i32.mul (local.get $t) (local.get $stride)) (i32.const 2)))))
f32x4.mul
local.get $scale0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
local.get $yp
v128.load offset=16
local.get $x0
local.get $w2_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w2_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w2_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w2_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w2_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w2_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w2_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w2_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w2_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w2_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w2_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w2_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w2_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w2_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w2_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w2_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w2_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w2_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w2_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w2_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w2_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w2_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w2_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w2_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w2_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w2_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w2_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w2_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w2_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w2_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w2_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w2_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w2_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w2_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w2_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w2_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w2_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w2_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w2_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w2_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w2_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w2_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w2_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w2_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w2_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w2_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w2_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w2_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w3_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w3_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w3_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w3_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w3_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w3_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w3_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w3_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w3_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w3_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w3_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w3_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w3_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w3_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w3_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w3_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w3_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w3_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w3_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w3_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w3_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w3_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w3_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w3_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w3_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w3_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w3_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w3_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w3_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w3_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w3_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w3_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w3_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w3_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w3_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w3_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w3_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w3_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w3_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w3_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w3_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w3_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w3_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w3_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w3_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w3_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w3_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w3_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
local.get $scale1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
local.get $yp
v128.load offset=32
local.get $x0
local.get $w4_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w4_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w4_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w4_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w4_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w4_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w4_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w4_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w4_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w4_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w4_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w4_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w4_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w4_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w4_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w4_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w4_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w4_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w4_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w4_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w4_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w4_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w4_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w4_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w4_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w4_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w4_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w4_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w4_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w4_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w4_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w4_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w4_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w4_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w4_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w4_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w4_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w4_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w4_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w4_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w4_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w4_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w4_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w4_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w4_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w4_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w4_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w4_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w4_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w4_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w4_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w4_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w4_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w4_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w4_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w4_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w5_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w5_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w5_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w5_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w5_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w5_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w5_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w5_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w5_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w5_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w5_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w5_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w5_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w5_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w5_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w5_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w5_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w5_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w5_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w5_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w5_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w5_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w5_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w5_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w5_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w5_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w5_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w5_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w5_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w5_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w5_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w5_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w5_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w5_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w5_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w5_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w5_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w5_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w5_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w5_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w5_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w5_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w5_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w5_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w5_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w5_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w5_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w5_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w5_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w5_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w5_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w5_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w5_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w5_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w5_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w5_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
local.get $scale2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
local.get $yp
v128.load offset=48
local.get $x0
local.get $w6_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w6_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w6_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w6_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w6_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w6_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w6_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w6_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w6_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w6_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w6_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w6_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w6_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w6_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w6_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w6_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w6_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w6_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w6_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w6_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w6_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w6_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w6_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w6_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w6_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w6_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w6_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w6_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w6_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w6_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w6_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w6_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w6_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w6_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w6_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w6_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w6_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w6_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w6_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w6_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w6_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w6_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w6_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w6_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w6_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w6_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w6_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w6_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w6_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w6_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w6_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w6_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w6_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w6_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w6_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w6_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w7_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w7_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w7_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w7_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w7_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w7_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w7_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w7_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w7_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w7_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w7_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w7_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w7_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w7_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w7_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w7_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w7_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w7_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w7_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w7_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w7_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w7_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w7_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w7_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w7_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w7_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w7_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w7_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w7_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w7_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w7_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w7_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w7_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w7_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w7_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w7_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w7_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w7_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w7_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w7_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w7_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w7_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w7_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w7_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w7_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w7_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w7_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w7_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w7_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w7_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w7_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w7_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w7_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w7_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w7_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w7_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
local.get $scale3
f32x4.mul
f32x4.add
v128.store offset=48
local.get $yp
local.get $yp
v128.load offset=64
local.get $x0
local.get $w8_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w8_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w8_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w8_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w8_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w8_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w8_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w8_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w8_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w8_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w8_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w8_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w8_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w8_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w8_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w8_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w8_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w8_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w8_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w8_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w8_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w8_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w8_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w8_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w8_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w8_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w8_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w8_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w8_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w8_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w8_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w8_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w8_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w8_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w8_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w8_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w8_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w8_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w8_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w8_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w8_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w8_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w8_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w8_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w8_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w8_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w8_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w8_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w8_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w8_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w8_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w8_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w8_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w8_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w8_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w8_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w8_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w8_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w8_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w8_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w8_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w8_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w8_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w8_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w9_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w9_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w9_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w9_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w9_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w9_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w9_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w9_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w9_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w9_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w9_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w9_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w9_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w9_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w9_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w9_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w9_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w9_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w9_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w9_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w9_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w9_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w9_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w9_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w9_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w9_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w9_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w9_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w9_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w9_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w9_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w9_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w9_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w9_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w9_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w9_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w9_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w9_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w9_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w9_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w9_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w9_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w9_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w9_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w9_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w9_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w9_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w9_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w9_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w9_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w9_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w9_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w9_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w9_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w9_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w9_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w9_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w9_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w9_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w9_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w9_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w9_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w9_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w9_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
local.get $scale4
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp
local.get $yp
v128.load offset=80
local.get $x0
local.get $w10_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w10_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w10_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w10_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w10_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w10_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w10_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w10_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w10_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w10_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w10_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w10_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w10_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w10_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w10_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w10_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w10_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w10_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w10_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w10_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w10_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w10_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w10_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w10_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w10_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w10_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w10_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w10_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w10_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w10_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w10_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w10_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w10_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w10_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w10_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w10_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w10_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w10_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w10_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w10_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w10_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w10_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w10_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w10_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w10_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w10_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w10_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w10_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w10_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w10_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w10_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w10_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w10_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w10_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w10_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w10_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w10_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w10_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w10_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w10_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w10_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w10_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w10_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w10_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w11_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w11_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w11_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w11_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w11_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w11_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w11_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w11_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w11_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w11_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w11_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w11_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w11_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w11_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w11_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w11_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w11_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w11_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w11_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w11_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w11_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w11_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w11_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w11_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w11_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w11_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w11_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w11_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w11_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w11_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w11_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w11_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w11_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w11_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w11_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w11_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w11_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w11_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w11_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w11_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w11_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w11_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w11_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w11_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w11_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w11_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w11_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w11_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w11_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w11_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w11_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w11_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w11_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w11_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w11_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w11_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w11_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w11_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w11_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w11_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w11_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w11_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w11_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w11_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
local.get $scale5
f32x4.mul
f32x4.add
v128.store offset=80
local.get $yp
local.get $yp
v128.load offset=96
local.get $x0
local.get $w12_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w12_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w12_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w12_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w12_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w12_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w12_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w12_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w12_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w12_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w12_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w12_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w12_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w12_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w12_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w12_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w12_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w12_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w12_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w12_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w12_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w12_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w12_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w12_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w12_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w12_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w12_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w12_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w12_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w12_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w12_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w12_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w12_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w12_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w12_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w12_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w12_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w12_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w12_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w12_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w12_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w12_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w12_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w12_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w12_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w12_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w12_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w12_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w12_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w12_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w12_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w12_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w12_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w12_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w12_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w12_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w12_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w12_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w12_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w12_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w12_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w12_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w12_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w12_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w13_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w13_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w13_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w13_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w13_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w13_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w13_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w13_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w13_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w13_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w13_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w13_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w13_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w13_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w13_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w13_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w13_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w13_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w13_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w13_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w13_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w13_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w13_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w13_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w13_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w13_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w13_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w13_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w13_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w13_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w13_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w13_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w13_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w13_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w13_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w13_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w13_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w13_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w13_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w13_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w13_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w13_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w13_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w13_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w13_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w13_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w13_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w13_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w13_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w13_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w13_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w13_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w13_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w13_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w13_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w13_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w13_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w13_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w13_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w13_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w13_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w13_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w13_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w13_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
local.get $scale6
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp
local.get $yp
v128.load offset=112
local.get $x0
local.get $w14_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w14_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w14_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w14_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w14_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w14_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w14_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w14_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w14_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w14_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w14_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w14_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w14_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w14_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w14_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w14_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w14_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w14_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w14_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w14_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w14_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w14_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w14_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w14_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w14_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w14_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w14_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w14_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w14_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w14_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w14_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w14_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w14_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w14_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w14_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w14_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w14_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w14_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w14_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w14_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w14_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w14_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w14_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w14_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w14_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w14_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w14_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w14_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w14_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w14_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w14_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w14_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w14_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w14_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w14_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w14_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w14_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w14_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w14_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w14_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w14_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w14_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w14_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w14_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $a
local.get $x0
local.get $w15_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w15_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w15_2
i32x4.dot_i16x8_s
local.get $x3
local.get $w15_3
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x4
local.get $w15_4
i32x4.dot_i16x8_s
local.get $x5
local.get $w15_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w15_6
i32x4.dot_i16x8_s
local.get $x7
local.get $w15_7
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x8
local.get $w15_8
i32x4.dot_i16x8_s
local.get $x9
local.get $w15_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w15_10
i32x4.dot_i16x8_s
local.get $x11
local.get $w15_11
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x12
local.get $w15_12
i32x4.dot_i16x8_s
local.get $x13
local.get $w15_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w15_14
i32x4.dot_i16x8_s
local.get $x15
local.get $w15_15
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x16
local.get $w15_16
i32x4.dot_i16x8_s
local.get $x17
local.get $w15_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w15_18
i32x4.dot_i16x8_s
local.get $x19
local.get $w15_19
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x20
local.get $w15_20
i32x4.dot_i16x8_s
local.get $x21
local.get $w15_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w15_22
i32x4.dot_i16x8_s
local.get $x23
local.get $w15_23
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x24
local.get $w15_24
i32x4.dot_i16x8_s
local.get $x25
local.get $w15_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w15_26
i32x4.dot_i16x8_s
local.get $x27
local.get $w15_27
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x28
local.get $w15_28
i32x4.dot_i16x8_s
local.get $x29
local.get $w15_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w15_30
i32x4.dot_i16x8_s
local.get $x31
local.get $w15_31
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x32
local.get $w15_32
i32x4.dot_i16x8_s
local.get $x33
local.get $w15_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x34
local.get $w15_34
i32x4.dot_i16x8_s
local.get $x35
local.get $w15_35
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x36
local.get $w15_36
i32x4.dot_i16x8_s
local.get $x37
local.get $w15_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x38
local.get $w15_38
i32x4.dot_i16x8_s
local.get $x39
local.get $w15_39
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x40
local.get $w15_40
i32x4.dot_i16x8_s
local.get $x41
local.get $w15_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x42
local.get $w15_42
i32x4.dot_i16x8_s
local.get $x43
local.get $w15_43
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x44
local.get $w15_44
i32x4.dot_i16x8_s
local.get $x45
local.get $w15_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x46
local.get $w15_46
i32x4.dot_i16x8_s
local.get $x47
local.get $w15_47
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.get $x48
local.get $w15_48
i32x4.dot_i16x8_s
local.get $x49
local.get $w15_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x50
local.get $w15_50
i32x4.dot_i16x8_s
local.get $x51
local.get $w15_51
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x52
local.get $w15_52
i32x4.dot_i16x8_s
local.get $x53
local.get $w15_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x54
local.get $w15_54
i32x4.dot_i16x8_s
local.get $x55
local.get $w15_55
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
local.get $x56
local.get $w15_56
i32x4.dot_i16x8_s
local.get $x57
local.get $w15_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x58
local.get $w15_58
i32x4.dot_i16x8_s
local.get $x59
local.get $w15_59
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
local.get $x60
local.get $w15_60
i32x4.dot_i16x8_s
local.get $x61
local.get $w15_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x62
local.get $w15_62
i32x4.dot_i16x8_s
local.get $x63
local.get $w15_63
i32x4.dot_i16x8_s
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
i32x4.add
local.tee $b
i8x16.shuffle 0 1 2 3 8 9 10 11 16 17 18 19 24 25 26 27
local.get $a
local.get $b
i8x16.shuffle 4 5 6 7 12 13 14 15 20 21 22 23 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $xscale
f32x4.mul
local.get $scale7
f32x4.mul
f32x4.add
v128.store offset=112
(local.set $t (i32.add (local.get $t) (i32.const 1)))
br $tokens
)))
)
