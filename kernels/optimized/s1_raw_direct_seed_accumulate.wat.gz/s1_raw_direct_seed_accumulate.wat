(module (func (export "__imajev_s1_raw_direct_seed_accumulate") (param $q i32) (param $w i32) (param $cols i32) (param $start i32) (param $sx i32) (param $stride i32) (param $sw i32) (param $sums i32) (param $n i32)
(local $input_stride i32) (local $output_bytes i32) (local $yp1 i32)
(local $t i32) (local $fulln i32) (local $qoffset i32) (local $keep i32) (local $qp i32) (local $wp i32) (local $yp i32) (local $a v128) (local $value v128) (local $sx0 v128) (local $sx1 v128)
(local $wp0 i32) (local $p0 v128)
(local $x0_0 v128)
(local $x0_1 v128)
(local $x0_2 v128)
(local $x0_3 v128)
(local $x0_4 v128)
(local $x0_5 v128)
(local $x0_6 v128)
(local $x0_7 v128)
(local $x0_8 v128)
(local $x0_9 v128)
(local $x0_10 v128)
(local $x0_11 v128)
(local $x0_12 v128)
(local $x0_13 v128)
(local $x0_14 v128)
(local $x0_15 v128)
(local $x0_16 v128)
(local $x0_17 v128)
(local $x0_18 v128)
(local $x0_19 v128)
(local $x0_20 v128)
(local $x0_21 v128)
(local $x0_22 v128)
(local $x0_23 v128)
(local $x0_24 v128)
(local $x0_25 v128)
(local $x0_26 v128)
(local $x0_27 v128)
(local $x0_28 v128)
(local $x0_29 v128)
(local $x0_30 v128)
(local $x0_31 v128)
(local $w0_0_0 v128)
(local $w0_0_1 v128)
(local $w0_0_2 v128)
(local $w0_0_3 v128)
(local $w0_0_4 v128)
(local $w0_0_5 v128)
(local $w0_0_6 v128)
(local $w0_0_7 v128)
(local $w0_0_8 v128)
(local $w0_0_9 v128)
(local $w0_0_10 v128)
(local $w0_0_11 v128)
(local $w0_0_12 v128)
(local $w0_0_13 v128)
(local $w0_0_14 v128)
(local $w0_0_15 v128)
(local $w0_0_16 v128)
(local $w0_0_17 v128)
(local $w0_0_18 v128)
(local $w0_0_19 v128)
(local $w0_0_20 v128)
(local $w0_0_21 v128)
(local $w0_0_22 v128)
(local $w0_0_23 v128)
(local $w0_0_24 v128)
(local $w0_0_25 v128)
(local $w0_0_26 v128)
(local $w0_0_27 v128)
(local $w0_0_28 v128)
(local $w0_0_29 v128)
(local $w0_0_30 v128)
(local $w0_0_31 v128)
(local $w0_1_0 v128)
(local $w0_1_1 v128)
(local $w0_1_2 v128)
(local $w0_1_3 v128)
(local $w0_1_4 v128)
(local $w0_1_5 v128)
(local $w0_1_6 v128)
(local $w0_1_7 v128)
(local $w0_1_8 v128)
(local $w0_1_9 v128)
(local $w0_1_10 v128)
(local $w0_1_11 v128)
(local $w0_1_12 v128)
(local $w0_1_13 v128)
(local $w0_1_14 v128)
(local $w0_1_15 v128)
(local $w0_1_16 v128)
(local $w0_1_17 v128)
(local $w0_1_18 v128)
(local $w0_1_19 v128)
(local $w0_1_20 v128)
(local $w0_1_21 v128)
(local $w0_1_22 v128)
(local $w0_1_23 v128)
(local $w0_1_24 v128)
(local $w0_1_25 v128)
(local $w0_1_26 v128)
(local $w0_1_27 v128)
(local $w0_1_28 v128)
(local $w0_1_29 v128)
(local $w0_1_30 v128)
(local $w0_1_31 v128)
(local $w0_2_0 v128)
(local $w0_2_1 v128)
(local $w0_2_2 v128)
(local $w0_2_3 v128)
(local $w0_2_4 v128)
(local $w0_2_5 v128)
(local $w0_2_6 v128)
(local $w0_2_7 v128)
(local $w0_2_8 v128)
(local $w0_2_9 v128)
(local $w0_2_10 v128)
(local $w0_2_11 v128)
(local $w0_2_12 v128)
(local $w0_2_13 v128)
(local $w0_2_14 v128)
(local $w0_2_15 v128)
(local $w0_2_16 v128)
(local $w0_2_17 v128)
(local $w0_2_18 v128)
(local $w0_2_19 v128)
(local $w0_2_20 v128)
(local $w0_2_21 v128)
(local $w0_2_22 v128)
(local $w0_2_23 v128)
(local $w0_2_24 v128)
(local $w0_2_25 v128)
(local $w0_2_26 v128)
(local $w0_2_27 v128)
(local $w0_2_28 v128)
(local $w0_2_29 v128)
(local $w0_2_30 v128)
(local $w0_2_31 v128)
(local $w0_3_0 v128)
(local $w0_3_1 v128)
(local $w0_3_2 v128)
(local $w0_3_3 v128)
(local $w0_3_4 v128)
(local $w0_3_5 v128)
(local $w0_3_6 v128)
(local $w0_3_7 v128)
(local $w0_3_8 v128)
(local $w0_3_9 v128)
(local $w0_3_10 v128)
(local $w0_3_11 v128)
(local $w0_3_12 v128)
(local $w0_3_13 v128)
(local $w0_3_14 v128)
(local $w0_3_15 v128)
(local $w0_3_16 v128)
(local $w0_3_17 v128)
(local $w0_3_18 v128)
(local $w0_3_19 v128)
(local $w0_3_20 v128)
(local $w0_3_21 v128)
(local $w0_3_22 v128)
(local $w0_3_23 v128)
(local $w0_3_24 v128)
(local $w0_3_25 v128)
(local $w0_3_26 v128)
(local $w0_3_27 v128)
(local $w0_3_28 v128)
(local $w0_3_29 v128)
(local $w0_3_30 v128)
(local $w0_3_31 v128)
(local $w0_4_0 v128)
(local $w0_4_1 v128)
(local $w0_4_2 v128)
(local $w0_4_3 v128)
(local $w0_4_4 v128)
(local $w0_4_5 v128)
(local $w0_4_6 v128)
(local $w0_4_7 v128)
(local $w0_4_8 v128)
(local $w0_4_9 v128)
(local $w0_4_10 v128)
(local $w0_4_11 v128)
(local $w0_4_12 v128)
(local $w0_4_13 v128)
(local $w0_4_14 v128)
(local $w0_4_15 v128)
(local $w0_4_16 v128)
(local $w0_4_17 v128)
(local $w0_4_18 v128)
(local $w0_4_19 v128)
(local $w0_4_20 v128)
(local $w0_4_21 v128)
(local $w0_4_22 v128)
(local $w0_4_23 v128)
(local $w0_4_24 v128)
(local $w0_4_25 v128)
(local $w0_4_26 v128)
(local $w0_4_27 v128)
(local $w0_4_28 v128)
(local $w0_4_29 v128)
(local $w0_4_30 v128)
(local $w0_4_31 v128)
(local $w0_5_0 v128)
(local $w0_5_1 v128)
(local $w0_5_2 v128)
(local $w0_5_3 v128)
(local $w0_5_4 v128)
(local $w0_5_5 v128)
(local $w0_5_6 v128)
(local $w0_5_7 v128)
(local $w0_5_8 v128)
(local $w0_5_9 v128)
(local $w0_5_10 v128)
(local $w0_5_11 v128)
(local $w0_5_12 v128)
(local $w0_5_13 v128)
(local $w0_5_14 v128)
(local $w0_5_15 v128)
(local $w0_5_16 v128)
(local $w0_5_17 v128)
(local $w0_5_18 v128)
(local $w0_5_19 v128)
(local $w0_5_20 v128)
(local $w0_5_21 v128)
(local $w0_5_22 v128)
(local $w0_5_23 v128)
(local $w0_5_24 v128)
(local $w0_5_25 v128)
(local $w0_5_26 v128)
(local $w0_5_27 v128)
(local $w0_5_28 v128)
(local $w0_5_29 v128)
(local $w0_5_30 v128)
(local $w0_5_31 v128)
(local $w0_6_0 v128)
(local $w0_6_1 v128)
(local $w0_6_2 v128)
(local $w0_6_3 v128)
(local $w0_6_4 v128)
(local $w0_6_5 v128)
(local $w0_6_6 v128)
(local $w0_6_7 v128)
(local $w0_6_8 v128)
(local $w0_6_9 v128)
(local $w0_6_10 v128)
(local $w0_6_11 v128)
(local $w0_6_12 v128)
(local $w0_6_13 v128)
(local $w0_6_14 v128)
(local $w0_6_15 v128)
(local $w0_6_16 v128)
(local $w0_6_17 v128)
(local $w0_6_18 v128)
(local $w0_6_19 v128)
(local $w0_6_20 v128)
(local $w0_6_21 v128)
(local $w0_6_22 v128)
(local $w0_6_23 v128)
(local $w0_6_24 v128)
(local $w0_6_25 v128)
(local $w0_6_26 v128)
(local $w0_6_27 v128)
(local $w0_6_28 v128)
(local $w0_6_29 v128)
(local $w0_6_30 v128)
(local $w0_6_31 v128)
(local $w0_7_0 v128)
(local $w0_7_1 v128)
(local $w0_7_2 v128)
(local $w0_7_3 v128)
(local $w0_7_4 v128)
(local $w0_7_5 v128)
(local $w0_7_6 v128)
(local $w0_7_7 v128)
(local $w0_7_8 v128)
(local $w0_7_9 v128)
(local $w0_7_10 v128)
(local $w0_7_11 v128)
(local $w0_7_12 v128)
(local $w0_7_13 v128)
(local $w0_7_14 v128)
(local $w0_7_15 v128)
(local $w0_7_16 v128)
(local $w0_7_17 v128)
(local $w0_7_18 v128)
(local $w0_7_19 v128)
(local $w0_7_20 v128)
(local $w0_7_21 v128)
(local $w0_7_22 v128)
(local $w0_7_23 v128)
(local $w0_7_24 v128)
(local $w0_7_25 v128)
(local $w0_7_26 v128)
(local $w0_7_27 v128)
(local $w0_7_28 v128)
(local $w0_7_29 v128)
(local $w0_7_30 v128)
(local $w0_7_31 v128)
































































































































































































































































































































































































































































































































































































































































































































































































(local $wp1 i32) (local $p1 v128)
(local $x1_0 v128)
(local $x1_1 v128)
(local $x1_2 v128)
(local $x1_3 v128)
(local $x1_4 v128)
(local $x1_5 v128)
(local $x1_6 v128)
(local $x1_7 v128)
(local $x1_8 v128)
(local $x1_9 v128)
(local $x1_10 v128)
(local $x1_11 v128)
(local $x1_12 v128)
(local $x1_13 v128)
(local $x1_14 v128)
(local $x1_15 v128)
(local $x1_16 v128)
(local $x1_17 v128)
(local $x1_18 v128)
(local $x1_19 v128)
(local $x1_20 v128)
(local $x1_21 v128)
(local $x1_22 v128)
(local $x1_23 v128)
(local $x1_24 v128)
(local $x1_25 v128)
(local $x1_26 v128)
(local $x1_27 v128)
(local $x1_28 v128)
(local $x1_29 v128)
(local $x1_30 v128)
(local $x1_31 v128)
(local $w1_0_0 v128)
(local $w1_0_1 v128)
(local $w1_0_2 v128)
(local $w1_0_3 v128)
(local $w1_0_4 v128)
(local $w1_0_5 v128)
(local $w1_0_6 v128)
(local $w1_0_7 v128)
(local $w1_0_8 v128)
(local $w1_0_9 v128)
(local $w1_0_10 v128)
(local $w1_0_11 v128)
(local $w1_0_12 v128)
(local $w1_0_13 v128)
(local $w1_0_14 v128)
(local $w1_0_15 v128)
(local $w1_0_16 v128)
(local $w1_0_17 v128)
(local $w1_0_18 v128)
(local $w1_0_19 v128)
(local $w1_0_20 v128)
(local $w1_0_21 v128)
(local $w1_0_22 v128)
(local $w1_0_23 v128)
(local $w1_0_24 v128)
(local $w1_0_25 v128)
(local $w1_0_26 v128)
(local $w1_0_27 v128)
(local $w1_0_28 v128)
(local $w1_0_29 v128)
(local $w1_0_30 v128)
(local $w1_0_31 v128)
(local $w1_1_0 v128)
(local $w1_1_1 v128)
(local $w1_1_2 v128)
(local $w1_1_3 v128)
(local $w1_1_4 v128)
(local $w1_1_5 v128)
(local $w1_1_6 v128)
(local $w1_1_7 v128)
(local $w1_1_8 v128)
(local $w1_1_9 v128)
(local $w1_1_10 v128)
(local $w1_1_11 v128)
(local $w1_1_12 v128)
(local $w1_1_13 v128)
(local $w1_1_14 v128)
(local $w1_1_15 v128)
(local $w1_1_16 v128)
(local $w1_1_17 v128)
(local $w1_1_18 v128)
(local $w1_1_19 v128)
(local $w1_1_20 v128)
(local $w1_1_21 v128)
(local $w1_1_22 v128)
(local $w1_1_23 v128)
(local $w1_1_24 v128)
(local $w1_1_25 v128)
(local $w1_1_26 v128)
(local $w1_1_27 v128)
(local $w1_1_28 v128)
(local $w1_1_29 v128)
(local $w1_1_30 v128)
(local $w1_1_31 v128)
(local $w1_2_0 v128)
(local $w1_2_1 v128)
(local $w1_2_2 v128)
(local $w1_2_3 v128)
(local $w1_2_4 v128)
(local $w1_2_5 v128)
(local $w1_2_6 v128)
(local $w1_2_7 v128)
(local $w1_2_8 v128)
(local $w1_2_9 v128)
(local $w1_2_10 v128)
(local $w1_2_11 v128)
(local $w1_2_12 v128)
(local $w1_2_13 v128)
(local $w1_2_14 v128)
(local $w1_2_15 v128)
(local $w1_2_16 v128)
(local $w1_2_17 v128)
(local $w1_2_18 v128)
(local $w1_2_19 v128)
(local $w1_2_20 v128)
(local $w1_2_21 v128)
(local $w1_2_22 v128)
(local $w1_2_23 v128)
(local $w1_2_24 v128)
(local $w1_2_25 v128)
(local $w1_2_26 v128)
(local $w1_2_27 v128)
(local $w1_2_28 v128)
(local $w1_2_29 v128)
(local $w1_2_30 v128)
(local $w1_2_31 v128)
(local $w1_3_0 v128)
(local $w1_3_1 v128)
(local $w1_3_2 v128)
(local $w1_3_3 v128)
(local $w1_3_4 v128)
(local $w1_3_5 v128)
(local $w1_3_6 v128)
(local $w1_3_7 v128)
(local $w1_3_8 v128)
(local $w1_3_9 v128)
(local $w1_3_10 v128)
(local $w1_3_11 v128)
(local $w1_3_12 v128)
(local $w1_3_13 v128)
(local $w1_3_14 v128)
(local $w1_3_15 v128)
(local $w1_3_16 v128)
(local $w1_3_17 v128)
(local $w1_3_18 v128)
(local $w1_3_19 v128)
(local $w1_3_20 v128)
(local $w1_3_21 v128)
(local $w1_3_22 v128)
(local $w1_3_23 v128)
(local $w1_3_24 v128)
(local $w1_3_25 v128)
(local $w1_3_26 v128)
(local $w1_3_27 v128)
(local $w1_3_28 v128)
(local $w1_3_29 v128)
(local $w1_3_30 v128)
(local $w1_3_31 v128)
(local $w1_4_0 v128)
(local $w1_4_1 v128)
(local $w1_4_2 v128)
(local $w1_4_3 v128)
(local $w1_4_4 v128)
(local $w1_4_5 v128)
(local $w1_4_6 v128)
(local $w1_4_7 v128)
(local $w1_4_8 v128)
(local $w1_4_9 v128)
(local $w1_4_10 v128)
(local $w1_4_11 v128)
(local $w1_4_12 v128)
(local $w1_4_13 v128)
(local $w1_4_14 v128)
(local $w1_4_15 v128)
(local $w1_4_16 v128)
(local $w1_4_17 v128)
(local $w1_4_18 v128)
(local $w1_4_19 v128)
(local $w1_4_20 v128)
(local $w1_4_21 v128)
(local $w1_4_22 v128)
(local $w1_4_23 v128)
(local $w1_4_24 v128)
(local $w1_4_25 v128)
(local $w1_4_26 v128)
(local $w1_4_27 v128)
(local $w1_4_28 v128)
(local $w1_4_29 v128)
(local $w1_4_30 v128)
(local $w1_4_31 v128)
(local $w1_5_0 v128)
(local $w1_5_1 v128)
(local $w1_5_2 v128)
(local $w1_5_3 v128)
(local $w1_5_4 v128)
(local $w1_5_5 v128)
(local $w1_5_6 v128)
(local $w1_5_7 v128)
(local $w1_5_8 v128)
(local $w1_5_9 v128)
(local $w1_5_10 v128)
(local $w1_5_11 v128)
(local $w1_5_12 v128)
(local $w1_5_13 v128)
(local $w1_5_14 v128)
(local $w1_5_15 v128)
(local $w1_5_16 v128)
(local $w1_5_17 v128)
(local $w1_5_18 v128)
(local $w1_5_19 v128)
(local $w1_5_20 v128)
(local $w1_5_21 v128)
(local $w1_5_22 v128)
(local $w1_5_23 v128)
(local $w1_5_24 v128)
(local $w1_5_25 v128)
(local $w1_5_26 v128)
(local $w1_5_27 v128)
(local $w1_5_28 v128)
(local $w1_5_29 v128)
(local $w1_5_30 v128)
(local $w1_5_31 v128)
(local $w1_6_0 v128)
(local $w1_6_1 v128)
(local $w1_6_2 v128)
(local $w1_6_3 v128)
(local $w1_6_4 v128)
(local $w1_6_5 v128)
(local $w1_6_6 v128)
(local $w1_6_7 v128)
(local $w1_6_8 v128)
(local $w1_6_9 v128)
(local $w1_6_10 v128)
(local $w1_6_11 v128)
(local $w1_6_12 v128)
(local $w1_6_13 v128)
(local $w1_6_14 v128)
(local $w1_6_15 v128)
(local $w1_6_16 v128)
(local $w1_6_17 v128)
(local $w1_6_18 v128)
(local $w1_6_19 v128)
(local $w1_6_20 v128)
(local $w1_6_21 v128)
(local $w1_6_22 v128)
(local $w1_6_23 v128)
(local $w1_6_24 v128)
(local $w1_6_25 v128)
(local $w1_6_26 v128)
(local $w1_6_27 v128)
(local $w1_6_28 v128)
(local $w1_6_29 v128)
(local $w1_6_30 v128)
(local $w1_6_31 v128)
(local $w1_7_0 v128)
(local $w1_7_1 v128)
(local $w1_7_2 v128)
(local $w1_7_3 v128)
(local $w1_7_4 v128)
(local $w1_7_5 v128)
(local $w1_7_6 v128)
(local $w1_7_7 v128)
(local $w1_7_8 v128)
(local $w1_7_9 v128)
(local $w1_7_10 v128)
(local $w1_7_11 v128)
(local $w1_7_12 v128)
(local $w1_7_13 v128)
(local $w1_7_14 v128)
(local $w1_7_15 v128)
(local $w1_7_16 v128)
(local $w1_7_17 v128)
(local $w1_7_18 v128)
(local $w1_7_19 v128)
(local $w1_7_20 v128)
(local $w1_7_21 v128)
(local $w1_7_22 v128)
(local $w1_7_23 v128)
(local $w1_7_24 v128)
(local $w1_7_25 v128)
(local $w1_7_26 v128)
(local $w1_7_27 v128)
(local $w1_7_28 v128)
(local $w1_7_29 v128)
(local $w1_7_30 v128)
(local $w1_7_31 v128)
































































































































































































































































































































































































































































































































































































































































































































































































(local $wp2 i32) (local $p2 v128)
(local $x2_0 v128)
(local $x2_1 v128)
(local $x2_2 v128)
(local $x2_3 v128)
(local $x2_4 v128)
(local $x2_5 v128)
(local $x2_6 v128)
(local $x2_7 v128)
(local $x2_8 v128)
(local $x2_9 v128)
(local $x2_10 v128)
(local $x2_11 v128)
(local $x2_12 v128)
(local $x2_13 v128)
(local $x2_14 v128)
(local $x2_15 v128)
(local $x2_16 v128)
(local $x2_17 v128)
(local $x2_18 v128)
(local $x2_19 v128)
(local $x2_20 v128)
(local $x2_21 v128)
(local $x2_22 v128)
(local $x2_23 v128)
(local $x2_24 v128)
(local $x2_25 v128)
(local $x2_26 v128)
(local $x2_27 v128)
(local $x2_28 v128)
(local $x2_29 v128)
(local $x2_30 v128)
(local $x2_31 v128)
(local $w2_0_0 v128)
(local $w2_0_1 v128)
(local $w2_0_2 v128)
(local $w2_0_3 v128)
(local $w2_0_4 v128)
(local $w2_0_5 v128)
(local $w2_0_6 v128)
(local $w2_0_7 v128)
(local $w2_0_8 v128)
(local $w2_0_9 v128)
(local $w2_0_10 v128)
(local $w2_0_11 v128)
(local $w2_0_12 v128)
(local $w2_0_13 v128)
(local $w2_0_14 v128)
(local $w2_0_15 v128)
(local $w2_0_16 v128)
(local $w2_0_17 v128)
(local $w2_0_18 v128)
(local $w2_0_19 v128)
(local $w2_0_20 v128)
(local $w2_0_21 v128)
(local $w2_0_22 v128)
(local $w2_0_23 v128)
(local $w2_0_24 v128)
(local $w2_0_25 v128)
(local $w2_0_26 v128)
(local $w2_0_27 v128)
(local $w2_0_28 v128)
(local $w2_0_29 v128)
(local $w2_0_30 v128)
(local $w2_0_31 v128)
(local $w2_1_0 v128)
(local $w2_1_1 v128)
(local $w2_1_2 v128)
(local $w2_1_3 v128)
(local $w2_1_4 v128)
(local $w2_1_5 v128)
(local $w2_1_6 v128)
(local $w2_1_7 v128)
(local $w2_1_8 v128)
(local $w2_1_9 v128)
(local $w2_1_10 v128)
(local $w2_1_11 v128)
(local $w2_1_12 v128)
(local $w2_1_13 v128)
(local $w2_1_14 v128)
(local $w2_1_15 v128)
(local $w2_1_16 v128)
(local $w2_1_17 v128)
(local $w2_1_18 v128)
(local $w2_1_19 v128)
(local $w2_1_20 v128)
(local $w2_1_21 v128)
(local $w2_1_22 v128)
(local $w2_1_23 v128)
(local $w2_1_24 v128)
(local $w2_1_25 v128)
(local $w2_1_26 v128)
(local $w2_1_27 v128)
(local $w2_1_28 v128)
(local $w2_1_29 v128)
(local $w2_1_30 v128)
(local $w2_1_31 v128)
(local $w2_2_0 v128)
(local $w2_2_1 v128)
(local $w2_2_2 v128)
(local $w2_2_3 v128)
(local $w2_2_4 v128)
(local $w2_2_5 v128)
(local $w2_2_6 v128)
(local $w2_2_7 v128)
(local $w2_2_8 v128)
(local $w2_2_9 v128)
(local $w2_2_10 v128)
(local $w2_2_11 v128)
(local $w2_2_12 v128)
(local $w2_2_13 v128)
(local $w2_2_14 v128)
(local $w2_2_15 v128)
(local $w2_2_16 v128)
(local $w2_2_17 v128)
(local $w2_2_18 v128)
(local $w2_2_19 v128)
(local $w2_2_20 v128)
(local $w2_2_21 v128)
(local $w2_2_22 v128)
(local $w2_2_23 v128)
(local $w2_2_24 v128)
(local $w2_2_25 v128)
(local $w2_2_26 v128)
(local $w2_2_27 v128)
(local $w2_2_28 v128)
(local $w2_2_29 v128)
(local $w2_2_30 v128)
(local $w2_2_31 v128)
(local $w2_3_0 v128)
(local $w2_3_1 v128)
(local $w2_3_2 v128)
(local $w2_3_3 v128)
(local $w2_3_4 v128)
(local $w2_3_5 v128)
(local $w2_3_6 v128)
(local $w2_3_7 v128)
(local $w2_3_8 v128)
(local $w2_3_9 v128)
(local $w2_3_10 v128)
(local $w2_3_11 v128)
(local $w2_3_12 v128)
(local $w2_3_13 v128)
(local $w2_3_14 v128)
(local $w2_3_15 v128)
(local $w2_3_16 v128)
(local $w2_3_17 v128)
(local $w2_3_18 v128)
(local $w2_3_19 v128)
(local $w2_3_20 v128)
(local $w2_3_21 v128)
(local $w2_3_22 v128)
(local $w2_3_23 v128)
(local $w2_3_24 v128)
(local $w2_3_25 v128)
(local $w2_3_26 v128)
(local $w2_3_27 v128)
(local $w2_3_28 v128)
(local $w2_3_29 v128)
(local $w2_3_30 v128)
(local $w2_3_31 v128)
(local $w2_4_0 v128)
(local $w2_4_1 v128)
(local $w2_4_2 v128)
(local $w2_4_3 v128)
(local $w2_4_4 v128)
(local $w2_4_5 v128)
(local $w2_4_6 v128)
(local $w2_4_7 v128)
(local $w2_4_8 v128)
(local $w2_4_9 v128)
(local $w2_4_10 v128)
(local $w2_4_11 v128)
(local $w2_4_12 v128)
(local $w2_4_13 v128)
(local $w2_4_14 v128)
(local $w2_4_15 v128)
(local $w2_4_16 v128)
(local $w2_4_17 v128)
(local $w2_4_18 v128)
(local $w2_4_19 v128)
(local $w2_4_20 v128)
(local $w2_4_21 v128)
(local $w2_4_22 v128)
(local $w2_4_23 v128)
(local $w2_4_24 v128)
(local $w2_4_25 v128)
(local $w2_4_26 v128)
(local $w2_4_27 v128)
(local $w2_4_28 v128)
(local $w2_4_29 v128)
(local $w2_4_30 v128)
(local $w2_4_31 v128)
(local $w2_5_0 v128)
(local $w2_5_1 v128)
(local $w2_5_2 v128)
(local $w2_5_3 v128)
(local $w2_5_4 v128)
(local $w2_5_5 v128)
(local $w2_5_6 v128)
(local $w2_5_7 v128)
(local $w2_5_8 v128)
(local $w2_5_9 v128)
(local $w2_5_10 v128)
(local $w2_5_11 v128)
(local $w2_5_12 v128)
(local $w2_5_13 v128)
(local $w2_5_14 v128)
(local $w2_5_15 v128)
(local $w2_5_16 v128)
(local $w2_5_17 v128)
(local $w2_5_18 v128)
(local $w2_5_19 v128)
(local $w2_5_20 v128)
(local $w2_5_21 v128)
(local $w2_5_22 v128)
(local $w2_5_23 v128)
(local $w2_5_24 v128)
(local $w2_5_25 v128)
(local $w2_5_26 v128)
(local $w2_5_27 v128)
(local $w2_5_28 v128)
(local $w2_5_29 v128)
(local $w2_5_30 v128)
(local $w2_5_31 v128)
(local $w2_6_0 v128)
(local $w2_6_1 v128)
(local $w2_6_2 v128)
(local $w2_6_3 v128)
(local $w2_6_4 v128)
(local $w2_6_5 v128)
(local $w2_6_6 v128)
(local $w2_6_7 v128)
(local $w2_6_8 v128)
(local $w2_6_9 v128)
(local $w2_6_10 v128)
(local $w2_6_11 v128)
(local $w2_6_12 v128)
(local $w2_6_13 v128)
(local $w2_6_14 v128)
(local $w2_6_15 v128)
(local $w2_6_16 v128)
(local $w2_6_17 v128)
(local $w2_6_18 v128)
(local $w2_6_19 v128)
(local $w2_6_20 v128)
(local $w2_6_21 v128)
(local $w2_6_22 v128)
(local $w2_6_23 v128)
(local $w2_6_24 v128)
(local $w2_6_25 v128)
(local $w2_6_26 v128)
(local $w2_6_27 v128)
(local $w2_6_28 v128)
(local $w2_6_29 v128)
(local $w2_6_30 v128)
(local $w2_6_31 v128)
(local $w2_7_0 v128)
(local $w2_7_1 v128)
(local $w2_7_2 v128)
(local $w2_7_3 v128)
(local $w2_7_4 v128)
(local $w2_7_5 v128)
(local $w2_7_6 v128)
(local $w2_7_7 v128)
(local $w2_7_8 v128)
(local $w2_7_9 v128)
(local $w2_7_10 v128)
(local $w2_7_11 v128)
(local $w2_7_12 v128)
(local $w2_7_13 v128)
(local $w2_7_14 v128)
(local $w2_7_15 v128)
(local $w2_7_16 v128)
(local $w2_7_17 v128)
(local $w2_7_18 v128)
(local $w2_7_19 v128)
(local $w2_7_20 v128)
(local $w2_7_21 v128)
(local $w2_7_22 v128)
(local $w2_7_23 v128)
(local $w2_7_24 v128)
(local $w2_7_25 v128)
(local $w2_7_26 v128)
(local $w2_7_27 v128)
(local $w2_7_28 v128)
(local $w2_7_29 v128)
(local $w2_7_30 v128)
(local $w2_7_31 v128)
































































































































































































































































































































































































































































































































































































































































































































































































(local $wp3 i32) (local $p3 v128)
(local $x3_0 v128)
(local $x3_1 v128)
(local $x3_2 v128)
(local $x3_3 v128)
(local $x3_4 v128)
(local $x3_5 v128)
(local $x3_6 v128)
(local $x3_7 v128)
(local $x3_8 v128)
(local $x3_9 v128)
(local $x3_10 v128)
(local $x3_11 v128)
(local $x3_12 v128)
(local $x3_13 v128)
(local $x3_14 v128)
(local $x3_15 v128)
(local $x3_16 v128)
(local $x3_17 v128)
(local $x3_18 v128)
(local $x3_19 v128)
(local $x3_20 v128)
(local $x3_21 v128)
(local $x3_22 v128)
(local $x3_23 v128)
(local $x3_24 v128)
(local $x3_25 v128)
(local $x3_26 v128)
(local $x3_27 v128)
(local $x3_28 v128)
(local $x3_29 v128)
(local $x3_30 v128)
(local $x3_31 v128)
(local $w3_0_0 v128)
(local $w3_0_1 v128)
(local $w3_0_2 v128)
(local $w3_0_3 v128)
(local $w3_0_4 v128)
(local $w3_0_5 v128)
(local $w3_0_6 v128)
(local $w3_0_7 v128)
(local $w3_0_8 v128)
(local $w3_0_9 v128)
(local $w3_0_10 v128)
(local $w3_0_11 v128)
(local $w3_0_12 v128)
(local $w3_0_13 v128)
(local $w3_0_14 v128)
(local $w3_0_15 v128)
(local $w3_0_16 v128)
(local $w3_0_17 v128)
(local $w3_0_18 v128)
(local $w3_0_19 v128)
(local $w3_0_20 v128)
(local $w3_0_21 v128)
(local $w3_0_22 v128)
(local $w3_0_23 v128)
(local $w3_0_24 v128)
(local $w3_0_25 v128)
(local $w3_0_26 v128)
(local $w3_0_27 v128)
(local $w3_0_28 v128)
(local $w3_0_29 v128)
(local $w3_0_30 v128)
(local $w3_0_31 v128)
(local $w3_1_0 v128)
(local $w3_1_1 v128)
(local $w3_1_2 v128)
(local $w3_1_3 v128)
(local $w3_1_4 v128)
(local $w3_1_5 v128)
(local $w3_1_6 v128)
(local $w3_1_7 v128)
(local $w3_1_8 v128)
(local $w3_1_9 v128)
(local $w3_1_10 v128)
(local $w3_1_11 v128)
(local $w3_1_12 v128)
(local $w3_1_13 v128)
(local $w3_1_14 v128)
(local $w3_1_15 v128)
(local $w3_1_16 v128)
(local $w3_1_17 v128)
(local $w3_1_18 v128)
(local $w3_1_19 v128)
(local $w3_1_20 v128)
(local $w3_1_21 v128)
(local $w3_1_22 v128)
(local $w3_1_23 v128)
(local $w3_1_24 v128)
(local $w3_1_25 v128)
(local $w3_1_26 v128)
(local $w3_1_27 v128)
(local $w3_1_28 v128)
(local $w3_1_29 v128)
(local $w3_1_30 v128)
(local $w3_1_31 v128)
(local $w3_2_0 v128)
(local $w3_2_1 v128)
(local $w3_2_2 v128)
(local $w3_2_3 v128)
(local $w3_2_4 v128)
(local $w3_2_5 v128)
(local $w3_2_6 v128)
(local $w3_2_7 v128)
(local $w3_2_8 v128)
(local $w3_2_9 v128)
(local $w3_2_10 v128)
(local $w3_2_11 v128)
(local $w3_2_12 v128)
(local $w3_2_13 v128)
(local $w3_2_14 v128)
(local $w3_2_15 v128)
(local $w3_2_16 v128)
(local $w3_2_17 v128)
(local $w3_2_18 v128)
(local $w3_2_19 v128)
(local $w3_2_20 v128)
(local $w3_2_21 v128)
(local $w3_2_22 v128)
(local $w3_2_23 v128)
(local $w3_2_24 v128)
(local $w3_2_25 v128)
(local $w3_2_26 v128)
(local $w3_2_27 v128)
(local $w3_2_28 v128)
(local $w3_2_29 v128)
(local $w3_2_30 v128)
(local $w3_2_31 v128)
(local $w3_3_0 v128)
(local $w3_3_1 v128)
(local $w3_3_2 v128)
(local $w3_3_3 v128)
(local $w3_3_4 v128)
(local $w3_3_5 v128)
(local $w3_3_6 v128)
(local $w3_3_7 v128)
(local $w3_3_8 v128)
(local $w3_3_9 v128)
(local $w3_3_10 v128)
(local $w3_3_11 v128)
(local $w3_3_12 v128)
(local $w3_3_13 v128)
(local $w3_3_14 v128)
(local $w3_3_15 v128)
(local $w3_3_16 v128)
(local $w3_3_17 v128)
(local $w3_3_18 v128)
(local $w3_3_19 v128)
(local $w3_3_20 v128)
(local $w3_3_21 v128)
(local $w3_3_22 v128)
(local $w3_3_23 v128)
(local $w3_3_24 v128)
(local $w3_3_25 v128)
(local $w3_3_26 v128)
(local $w3_3_27 v128)
(local $w3_3_28 v128)
(local $w3_3_29 v128)
(local $w3_3_30 v128)
(local $w3_3_31 v128)
(local $w3_4_0 v128)
(local $w3_4_1 v128)
(local $w3_4_2 v128)
(local $w3_4_3 v128)
(local $w3_4_4 v128)
(local $w3_4_5 v128)
(local $w3_4_6 v128)
(local $w3_4_7 v128)
(local $w3_4_8 v128)
(local $w3_4_9 v128)
(local $w3_4_10 v128)
(local $w3_4_11 v128)
(local $w3_4_12 v128)
(local $w3_4_13 v128)
(local $w3_4_14 v128)
(local $w3_4_15 v128)
(local $w3_4_16 v128)
(local $w3_4_17 v128)
(local $w3_4_18 v128)
(local $w3_4_19 v128)
(local $w3_4_20 v128)
(local $w3_4_21 v128)
(local $w3_4_22 v128)
(local $w3_4_23 v128)
(local $w3_4_24 v128)
(local $w3_4_25 v128)
(local $w3_4_26 v128)
(local $w3_4_27 v128)
(local $w3_4_28 v128)
(local $w3_4_29 v128)
(local $w3_4_30 v128)
(local $w3_4_31 v128)
(local $w3_5_0 v128)
(local $w3_5_1 v128)
(local $w3_5_2 v128)
(local $w3_5_3 v128)
(local $w3_5_4 v128)
(local $w3_5_5 v128)
(local $w3_5_6 v128)
(local $w3_5_7 v128)
(local $w3_5_8 v128)
(local $w3_5_9 v128)
(local $w3_5_10 v128)
(local $w3_5_11 v128)
(local $w3_5_12 v128)
(local $w3_5_13 v128)
(local $w3_5_14 v128)
(local $w3_5_15 v128)
(local $w3_5_16 v128)
(local $w3_5_17 v128)
(local $w3_5_18 v128)
(local $w3_5_19 v128)
(local $w3_5_20 v128)
(local $w3_5_21 v128)
(local $w3_5_22 v128)
(local $w3_5_23 v128)
(local $w3_5_24 v128)
(local $w3_5_25 v128)
(local $w3_5_26 v128)
(local $w3_5_27 v128)
(local $w3_5_28 v128)
(local $w3_5_29 v128)
(local $w3_5_30 v128)
(local $w3_5_31 v128)
(local $w3_6_0 v128)
(local $w3_6_1 v128)
(local $w3_6_2 v128)
(local $w3_6_3 v128)
(local $w3_6_4 v128)
(local $w3_6_5 v128)
(local $w3_6_6 v128)
(local $w3_6_7 v128)
(local $w3_6_8 v128)
(local $w3_6_9 v128)
(local $w3_6_10 v128)
(local $w3_6_11 v128)
(local $w3_6_12 v128)
(local $w3_6_13 v128)
(local $w3_6_14 v128)
(local $w3_6_15 v128)
(local $w3_6_16 v128)
(local $w3_6_17 v128)
(local $w3_6_18 v128)
(local $w3_6_19 v128)
(local $w3_6_20 v128)
(local $w3_6_21 v128)
(local $w3_6_22 v128)
(local $w3_6_23 v128)
(local $w3_6_24 v128)
(local $w3_6_25 v128)
(local $w3_6_26 v128)
(local $w3_6_27 v128)
(local $w3_6_28 v128)
(local $w3_6_29 v128)
(local $w3_6_30 v128)
(local $w3_6_31 v128)
(local $w3_7_0 v128)
(local $w3_7_1 v128)
(local $w3_7_2 v128)
(local $w3_7_3 v128)
(local $w3_7_4 v128)
(local $w3_7_5 v128)
(local $w3_7_6 v128)
(local $w3_7_7 v128)
(local $w3_7_8 v128)
(local $w3_7_9 v128)
(local $w3_7_10 v128)
(local $w3_7_11 v128)
(local $w3_7_12 v128)
(local $w3_7_13 v128)
(local $w3_7_14 v128)
(local $w3_7_15 v128)
(local $w3_7_16 v128)
(local $w3_7_17 v128)
(local $w3_7_18 v128)
(local $w3_7_19 v128)
(local $w3_7_20 v128)
(local $w3_7_21 v128)
(local $w3_7_22 v128)
(local $w3_7_23 v128)
(local $w3_7_24 v128)
(local $w3_7_25 v128)
(local $w3_7_26 v128)
(local $w3_7_27 v128)
(local $w3_7_28 v128)
(local $w3_7_29 v128)
(local $w3_7_30 v128)
(local $w3_7_31 v128)
































































































































































































































































































































































































































































































































































































































































































































































































(local $wp4 i32) (local $p4 v128)
(local $x4_0 v128)
(local $x4_1 v128)
(local $x4_2 v128)
(local $x4_3 v128)
(local $x4_4 v128)
(local $x4_5 v128)
(local $x4_6 v128)
(local $x4_7 v128)
(local $x4_8 v128)
(local $x4_9 v128)
(local $x4_10 v128)
(local $x4_11 v128)
(local $x4_12 v128)
(local $x4_13 v128)
(local $x4_14 v128)
(local $x4_15 v128)
(local $x4_16 v128)
(local $x4_17 v128)
(local $x4_18 v128)
(local $x4_19 v128)
(local $x4_20 v128)
(local $x4_21 v128)
(local $x4_22 v128)
(local $x4_23 v128)
(local $x4_24 v128)
(local $x4_25 v128)
(local $x4_26 v128)
(local $x4_27 v128)
(local $x4_28 v128)
(local $x4_29 v128)
(local $x4_30 v128)
(local $x4_31 v128)
(local $w4_0_0 v128)
(local $w4_0_1 v128)
(local $w4_0_2 v128)
(local $w4_0_3 v128)
(local $w4_0_4 v128)
(local $w4_0_5 v128)
(local $w4_0_6 v128)
(local $w4_0_7 v128)
(local $w4_0_8 v128)
(local $w4_0_9 v128)
(local $w4_0_10 v128)
(local $w4_0_11 v128)
(local $w4_0_12 v128)
(local $w4_0_13 v128)
(local $w4_0_14 v128)
(local $w4_0_15 v128)
(local $w4_0_16 v128)
(local $w4_0_17 v128)
(local $w4_0_18 v128)
(local $w4_0_19 v128)
(local $w4_0_20 v128)
(local $w4_0_21 v128)
(local $w4_0_22 v128)
(local $w4_0_23 v128)
(local $w4_0_24 v128)
(local $w4_0_25 v128)
(local $w4_0_26 v128)
(local $w4_0_27 v128)
(local $w4_0_28 v128)
(local $w4_0_29 v128)
(local $w4_0_30 v128)
(local $w4_0_31 v128)
(local $w4_1_0 v128)
(local $w4_1_1 v128)
(local $w4_1_2 v128)
(local $w4_1_3 v128)
(local $w4_1_4 v128)
(local $w4_1_5 v128)
(local $w4_1_6 v128)
(local $w4_1_7 v128)
(local $w4_1_8 v128)
(local $w4_1_9 v128)
(local $w4_1_10 v128)
(local $w4_1_11 v128)
(local $w4_1_12 v128)
(local $w4_1_13 v128)
(local $w4_1_14 v128)
(local $w4_1_15 v128)
(local $w4_1_16 v128)
(local $w4_1_17 v128)
(local $w4_1_18 v128)
(local $w4_1_19 v128)
(local $w4_1_20 v128)
(local $w4_1_21 v128)
(local $w4_1_22 v128)
(local $w4_1_23 v128)
(local $w4_1_24 v128)
(local $w4_1_25 v128)
(local $w4_1_26 v128)
(local $w4_1_27 v128)
(local $w4_1_28 v128)
(local $w4_1_29 v128)
(local $w4_1_30 v128)
(local $w4_1_31 v128)
(local $w4_2_0 v128)
(local $w4_2_1 v128)
(local $w4_2_2 v128)
(local $w4_2_3 v128)
(local $w4_2_4 v128)
(local $w4_2_5 v128)
(local $w4_2_6 v128)
(local $w4_2_7 v128)
(local $w4_2_8 v128)
(local $w4_2_9 v128)
(local $w4_2_10 v128)
(local $w4_2_11 v128)
(local $w4_2_12 v128)
(local $w4_2_13 v128)
(local $w4_2_14 v128)
(local $w4_2_15 v128)
(local $w4_2_16 v128)
(local $w4_2_17 v128)
(local $w4_2_18 v128)
(local $w4_2_19 v128)
(local $w4_2_20 v128)
(local $w4_2_21 v128)
(local $w4_2_22 v128)
(local $w4_2_23 v128)
(local $w4_2_24 v128)
(local $w4_2_25 v128)
(local $w4_2_26 v128)
(local $w4_2_27 v128)
(local $w4_2_28 v128)
(local $w4_2_29 v128)
(local $w4_2_30 v128)
(local $w4_2_31 v128)
(local $w4_3_0 v128)
(local $w4_3_1 v128)
(local $w4_3_2 v128)
(local $w4_3_3 v128)
(local $w4_3_4 v128)
(local $w4_3_5 v128)
(local $w4_3_6 v128)
(local $w4_3_7 v128)
(local $w4_3_8 v128)
(local $w4_3_9 v128)
(local $w4_3_10 v128)
(local $w4_3_11 v128)
(local $w4_3_12 v128)
(local $w4_3_13 v128)
(local $w4_3_14 v128)
(local $w4_3_15 v128)
(local $w4_3_16 v128)
(local $w4_3_17 v128)
(local $w4_3_18 v128)
(local $w4_3_19 v128)
(local $w4_3_20 v128)
(local $w4_3_21 v128)
(local $w4_3_22 v128)
(local $w4_3_23 v128)
(local $w4_3_24 v128)
(local $w4_3_25 v128)
(local $w4_3_26 v128)
(local $w4_3_27 v128)
(local $w4_3_28 v128)
(local $w4_3_29 v128)
(local $w4_3_30 v128)
(local $w4_3_31 v128)
(local $w4_4_0 v128)
(local $w4_4_1 v128)
(local $w4_4_2 v128)
(local $w4_4_3 v128)
(local $w4_4_4 v128)
(local $w4_4_5 v128)
(local $w4_4_6 v128)
(local $w4_4_7 v128)
(local $w4_4_8 v128)
(local $w4_4_9 v128)
(local $w4_4_10 v128)
(local $w4_4_11 v128)
(local $w4_4_12 v128)
(local $w4_4_13 v128)
(local $w4_4_14 v128)
(local $w4_4_15 v128)
(local $w4_4_16 v128)
(local $w4_4_17 v128)
(local $w4_4_18 v128)
(local $w4_4_19 v128)
(local $w4_4_20 v128)
(local $w4_4_21 v128)
(local $w4_4_22 v128)
(local $w4_4_23 v128)
(local $w4_4_24 v128)
(local $w4_4_25 v128)
(local $w4_4_26 v128)
(local $w4_4_27 v128)
(local $w4_4_28 v128)
(local $w4_4_29 v128)
(local $w4_4_30 v128)
(local $w4_4_31 v128)
(local $w4_5_0 v128)
(local $w4_5_1 v128)
(local $w4_5_2 v128)
(local $w4_5_3 v128)
(local $w4_5_4 v128)
(local $w4_5_5 v128)
(local $w4_5_6 v128)
(local $w4_5_7 v128)
(local $w4_5_8 v128)
(local $w4_5_9 v128)
(local $w4_5_10 v128)
(local $w4_5_11 v128)
(local $w4_5_12 v128)
(local $w4_5_13 v128)
(local $w4_5_14 v128)
(local $w4_5_15 v128)
(local $w4_5_16 v128)
(local $w4_5_17 v128)
(local $w4_5_18 v128)
(local $w4_5_19 v128)
(local $w4_5_20 v128)
(local $w4_5_21 v128)
(local $w4_5_22 v128)
(local $w4_5_23 v128)
(local $w4_5_24 v128)
(local $w4_5_25 v128)
(local $w4_5_26 v128)
(local $w4_5_27 v128)
(local $w4_5_28 v128)
(local $w4_5_29 v128)
(local $w4_5_30 v128)
(local $w4_5_31 v128)
(local $w4_6_0 v128)
(local $w4_6_1 v128)
(local $w4_6_2 v128)
(local $w4_6_3 v128)
(local $w4_6_4 v128)
(local $w4_6_5 v128)
(local $w4_6_6 v128)
(local $w4_6_7 v128)
(local $w4_6_8 v128)
(local $w4_6_9 v128)
(local $w4_6_10 v128)
(local $w4_6_11 v128)
(local $w4_6_12 v128)
(local $w4_6_13 v128)
(local $w4_6_14 v128)
(local $w4_6_15 v128)
(local $w4_6_16 v128)
(local $w4_6_17 v128)
(local $w4_6_18 v128)
(local $w4_6_19 v128)
(local $w4_6_20 v128)
(local $w4_6_21 v128)
(local $w4_6_22 v128)
(local $w4_6_23 v128)
(local $w4_6_24 v128)
(local $w4_6_25 v128)
(local $w4_6_26 v128)
(local $w4_6_27 v128)
(local $w4_6_28 v128)
(local $w4_6_29 v128)
(local $w4_6_30 v128)
(local $w4_6_31 v128)
(local $w4_7_0 v128)
(local $w4_7_1 v128)
(local $w4_7_2 v128)
(local $w4_7_3 v128)
(local $w4_7_4 v128)
(local $w4_7_5 v128)
(local $w4_7_6 v128)
(local $w4_7_7 v128)
(local $w4_7_8 v128)
(local $w4_7_9 v128)
(local $w4_7_10 v128)
(local $w4_7_11 v128)
(local $w4_7_12 v128)
(local $w4_7_13 v128)
(local $w4_7_14 v128)
(local $w4_7_15 v128)
(local $w4_7_16 v128)
(local $w4_7_17 v128)
(local $w4_7_18 v128)
(local $w4_7_19 v128)
(local $w4_7_20 v128)
(local $w4_7_21 v128)
(local $w4_7_22 v128)
(local $w4_7_23 v128)
(local $w4_7_24 v128)
(local $w4_7_25 v128)
(local $w4_7_26 v128)
(local $w4_7_27 v128)
(local $w4_7_28 v128)
(local $w4_7_29 v128)
(local $w4_7_30 v128)
(local $w4_7_31 v128)
































































































































































































































































































































































































































































































































































































































































































































































































(local $wp5 i32) (local $p5 v128)
(local $x5_0 v128)
(local $x5_1 v128)
(local $x5_2 v128)
(local $x5_3 v128)
(local $x5_4 v128)
(local $x5_5 v128)
(local $x5_6 v128)
(local $x5_7 v128)
(local $x5_8 v128)
(local $x5_9 v128)
(local $x5_10 v128)
(local $x5_11 v128)
(local $x5_12 v128)
(local $x5_13 v128)
(local $x5_14 v128)
(local $x5_15 v128)
(local $x5_16 v128)
(local $x5_17 v128)
(local $x5_18 v128)
(local $x5_19 v128)
(local $x5_20 v128)
(local $x5_21 v128)
(local $x5_22 v128)
(local $x5_23 v128)
(local $x5_24 v128)
(local $x5_25 v128)
(local $x5_26 v128)
(local $x5_27 v128)
(local $x5_28 v128)
(local $x5_29 v128)
(local $x5_30 v128)
(local $x5_31 v128)
(local $w5_0_0 v128)
(local $w5_0_1 v128)
(local $w5_0_2 v128)
(local $w5_0_3 v128)
(local $w5_0_4 v128)
(local $w5_0_5 v128)
(local $w5_0_6 v128)
(local $w5_0_7 v128)
(local $w5_0_8 v128)
(local $w5_0_9 v128)
(local $w5_0_10 v128)
(local $w5_0_11 v128)
(local $w5_0_12 v128)
(local $w5_0_13 v128)
(local $w5_0_14 v128)
(local $w5_0_15 v128)
(local $w5_0_16 v128)
(local $w5_0_17 v128)
(local $w5_0_18 v128)
(local $w5_0_19 v128)
(local $w5_0_20 v128)
(local $w5_0_21 v128)
(local $w5_0_22 v128)
(local $w5_0_23 v128)
(local $w5_0_24 v128)
(local $w5_0_25 v128)
(local $w5_0_26 v128)
(local $w5_0_27 v128)
(local $w5_0_28 v128)
(local $w5_0_29 v128)
(local $w5_0_30 v128)
(local $w5_0_31 v128)
(local $w5_1_0 v128)
(local $w5_1_1 v128)
(local $w5_1_2 v128)
(local $w5_1_3 v128)
(local $w5_1_4 v128)
(local $w5_1_5 v128)
(local $w5_1_6 v128)
(local $w5_1_7 v128)
(local $w5_1_8 v128)
(local $w5_1_9 v128)
(local $w5_1_10 v128)
(local $w5_1_11 v128)
(local $w5_1_12 v128)
(local $w5_1_13 v128)
(local $w5_1_14 v128)
(local $w5_1_15 v128)
(local $w5_1_16 v128)
(local $w5_1_17 v128)
(local $w5_1_18 v128)
(local $w5_1_19 v128)
(local $w5_1_20 v128)
(local $w5_1_21 v128)
(local $w5_1_22 v128)
(local $w5_1_23 v128)
(local $w5_1_24 v128)
(local $w5_1_25 v128)
(local $w5_1_26 v128)
(local $w5_1_27 v128)
(local $w5_1_28 v128)
(local $w5_1_29 v128)
(local $w5_1_30 v128)
(local $w5_1_31 v128)
(local $w5_2_0 v128)
(local $w5_2_1 v128)
(local $w5_2_2 v128)
(local $w5_2_3 v128)
(local $w5_2_4 v128)
(local $w5_2_5 v128)
(local $w5_2_6 v128)
(local $w5_2_7 v128)
(local $w5_2_8 v128)
(local $w5_2_9 v128)
(local $w5_2_10 v128)
(local $w5_2_11 v128)
(local $w5_2_12 v128)
(local $w5_2_13 v128)
(local $w5_2_14 v128)
(local $w5_2_15 v128)
(local $w5_2_16 v128)
(local $w5_2_17 v128)
(local $w5_2_18 v128)
(local $w5_2_19 v128)
(local $w5_2_20 v128)
(local $w5_2_21 v128)
(local $w5_2_22 v128)
(local $w5_2_23 v128)
(local $w5_2_24 v128)
(local $w5_2_25 v128)
(local $w5_2_26 v128)
(local $w5_2_27 v128)
(local $w5_2_28 v128)
(local $w5_2_29 v128)
(local $w5_2_30 v128)
(local $w5_2_31 v128)
(local $w5_3_0 v128)
(local $w5_3_1 v128)
(local $w5_3_2 v128)
(local $w5_3_3 v128)
(local $w5_3_4 v128)
(local $w5_3_5 v128)
(local $w5_3_6 v128)
(local $w5_3_7 v128)
(local $w5_3_8 v128)
(local $w5_3_9 v128)
(local $w5_3_10 v128)
(local $w5_3_11 v128)
(local $w5_3_12 v128)
(local $w5_3_13 v128)
(local $w5_3_14 v128)
(local $w5_3_15 v128)
(local $w5_3_16 v128)
(local $w5_3_17 v128)
(local $w5_3_18 v128)
(local $w5_3_19 v128)
(local $w5_3_20 v128)
(local $w5_3_21 v128)
(local $w5_3_22 v128)
(local $w5_3_23 v128)
(local $w5_3_24 v128)
(local $w5_3_25 v128)
(local $w5_3_26 v128)
(local $w5_3_27 v128)
(local $w5_3_28 v128)
(local $w5_3_29 v128)
(local $w5_3_30 v128)
(local $w5_3_31 v128)
(local $w5_4_0 v128)
(local $w5_4_1 v128)
(local $w5_4_2 v128)
(local $w5_4_3 v128)
(local $w5_4_4 v128)
(local $w5_4_5 v128)
(local $w5_4_6 v128)
(local $w5_4_7 v128)
(local $w5_4_8 v128)
(local $w5_4_9 v128)
(local $w5_4_10 v128)
(local $w5_4_11 v128)
(local $w5_4_12 v128)
(local $w5_4_13 v128)
(local $w5_4_14 v128)
(local $w5_4_15 v128)
(local $w5_4_16 v128)
(local $w5_4_17 v128)
(local $w5_4_18 v128)
(local $w5_4_19 v128)
(local $w5_4_20 v128)
(local $w5_4_21 v128)
(local $w5_4_22 v128)
(local $w5_4_23 v128)
(local $w5_4_24 v128)
(local $w5_4_25 v128)
(local $w5_4_26 v128)
(local $w5_4_27 v128)
(local $w5_4_28 v128)
(local $w5_4_29 v128)
(local $w5_4_30 v128)
(local $w5_4_31 v128)
(local $w5_5_0 v128)
(local $w5_5_1 v128)
(local $w5_5_2 v128)
(local $w5_5_3 v128)
(local $w5_5_4 v128)
(local $w5_5_5 v128)
(local $w5_5_6 v128)
(local $w5_5_7 v128)
(local $w5_5_8 v128)
(local $w5_5_9 v128)
(local $w5_5_10 v128)
(local $w5_5_11 v128)
(local $w5_5_12 v128)
(local $w5_5_13 v128)
(local $w5_5_14 v128)
(local $w5_5_15 v128)
(local $w5_5_16 v128)
(local $w5_5_17 v128)
(local $w5_5_18 v128)
(local $w5_5_19 v128)
(local $w5_5_20 v128)
(local $w5_5_21 v128)
(local $w5_5_22 v128)
(local $w5_5_23 v128)
(local $w5_5_24 v128)
(local $w5_5_25 v128)
(local $w5_5_26 v128)
(local $w5_5_27 v128)
(local $w5_5_28 v128)
(local $w5_5_29 v128)
(local $w5_5_30 v128)
(local $w5_5_31 v128)
(local $w5_6_0 v128)
(local $w5_6_1 v128)
(local $w5_6_2 v128)
(local $w5_6_3 v128)
(local $w5_6_4 v128)
(local $w5_6_5 v128)
(local $w5_6_6 v128)
(local $w5_6_7 v128)
(local $w5_6_8 v128)
(local $w5_6_9 v128)
(local $w5_6_10 v128)
(local $w5_6_11 v128)
(local $w5_6_12 v128)
(local $w5_6_13 v128)
(local $w5_6_14 v128)
(local $w5_6_15 v128)
(local $w5_6_16 v128)
(local $w5_6_17 v128)
(local $w5_6_18 v128)
(local $w5_6_19 v128)
(local $w5_6_20 v128)
(local $w5_6_21 v128)
(local $w5_6_22 v128)
(local $w5_6_23 v128)
(local $w5_6_24 v128)
(local $w5_6_25 v128)
(local $w5_6_26 v128)
(local $w5_6_27 v128)
(local $w5_6_28 v128)
(local $w5_6_29 v128)
(local $w5_6_30 v128)
(local $w5_6_31 v128)
(local $w5_7_0 v128)
(local $w5_7_1 v128)
(local $w5_7_2 v128)
(local $w5_7_3 v128)
(local $w5_7_4 v128)
(local $w5_7_5 v128)
(local $w5_7_6 v128)
(local $w5_7_7 v128)
(local $w5_7_8 v128)
(local $w5_7_9 v128)
(local $w5_7_10 v128)
(local $w5_7_11 v128)
(local $w5_7_12 v128)
(local $w5_7_13 v128)
(local $w5_7_14 v128)
(local $w5_7_15 v128)
(local $w5_7_16 v128)
(local $w5_7_17 v128)
(local $w5_7_18 v128)
(local $w5_7_19 v128)
(local $w5_7_20 v128)
(local $w5_7_21 v128)
(local $w5_7_22 v128)
(local $w5_7_23 v128)
(local $w5_7_24 v128)
(local $w5_7_25 v128)
(local $w5_7_26 v128)
(local $w5_7_27 v128)
(local $w5_7_28 v128)
(local $w5_7_29 v128)
(local $w5_7_30 v128)
(local $w5_7_31 v128)
































































































































































































































































































































































































































































































































































































































































































































































































(local $wp6 i32) (local $p6 v128)
(local $x6_0 v128)
(local $x6_1 v128)
(local $x6_2 v128)
(local $x6_3 v128)
(local $x6_4 v128)
(local $x6_5 v128)
(local $x6_6 v128)
(local $x6_7 v128)
(local $x6_8 v128)
(local $x6_9 v128)
(local $x6_10 v128)
(local $x6_11 v128)
(local $x6_12 v128)
(local $x6_13 v128)
(local $x6_14 v128)
(local $x6_15 v128)
(local $x6_16 v128)
(local $x6_17 v128)
(local $x6_18 v128)
(local $x6_19 v128)
(local $x6_20 v128)
(local $x6_21 v128)
(local $x6_22 v128)
(local $x6_23 v128)
(local $x6_24 v128)
(local $x6_25 v128)
(local $x6_26 v128)
(local $x6_27 v128)
(local $x6_28 v128)
(local $x6_29 v128)
(local $x6_30 v128)
(local $x6_31 v128)
(local $w6_0_0 v128)
(local $w6_0_1 v128)
(local $w6_0_2 v128)
(local $w6_0_3 v128)
(local $w6_0_4 v128)
(local $w6_0_5 v128)
(local $w6_0_6 v128)
(local $w6_0_7 v128)
(local $w6_0_8 v128)
(local $w6_0_9 v128)
(local $w6_0_10 v128)
(local $w6_0_11 v128)
(local $w6_0_12 v128)
(local $w6_0_13 v128)
(local $w6_0_14 v128)
(local $w6_0_15 v128)
(local $w6_0_16 v128)
(local $w6_0_17 v128)
(local $w6_0_18 v128)
(local $w6_0_19 v128)
(local $w6_0_20 v128)
(local $w6_0_21 v128)
(local $w6_0_22 v128)
(local $w6_0_23 v128)
(local $w6_0_24 v128)
(local $w6_0_25 v128)
(local $w6_0_26 v128)
(local $w6_0_27 v128)
(local $w6_0_28 v128)
(local $w6_0_29 v128)
(local $w6_0_30 v128)
(local $w6_0_31 v128)
(local $w6_1_0 v128)
(local $w6_1_1 v128)
(local $w6_1_2 v128)
(local $w6_1_3 v128)
(local $w6_1_4 v128)
(local $w6_1_5 v128)
(local $w6_1_6 v128)
(local $w6_1_7 v128)
(local $w6_1_8 v128)
(local $w6_1_9 v128)
(local $w6_1_10 v128)
(local $w6_1_11 v128)
(local $w6_1_12 v128)
(local $w6_1_13 v128)
(local $w6_1_14 v128)
(local $w6_1_15 v128)
(local $w6_1_16 v128)
(local $w6_1_17 v128)
(local $w6_1_18 v128)
(local $w6_1_19 v128)
(local $w6_1_20 v128)
(local $w6_1_21 v128)
(local $w6_1_22 v128)
(local $w6_1_23 v128)
(local $w6_1_24 v128)
(local $w6_1_25 v128)
(local $w6_1_26 v128)
(local $w6_1_27 v128)
(local $w6_1_28 v128)
(local $w6_1_29 v128)
(local $w6_1_30 v128)
(local $w6_1_31 v128)
(local $w6_2_0 v128)
(local $w6_2_1 v128)
(local $w6_2_2 v128)
(local $w6_2_3 v128)
(local $w6_2_4 v128)
(local $w6_2_5 v128)
(local $w6_2_6 v128)
(local $w6_2_7 v128)
(local $w6_2_8 v128)
(local $w6_2_9 v128)
(local $w6_2_10 v128)
(local $w6_2_11 v128)
(local $w6_2_12 v128)
(local $w6_2_13 v128)
(local $w6_2_14 v128)
(local $w6_2_15 v128)
(local $w6_2_16 v128)
(local $w6_2_17 v128)
(local $w6_2_18 v128)
(local $w6_2_19 v128)
(local $w6_2_20 v128)
(local $w6_2_21 v128)
(local $w6_2_22 v128)
(local $w6_2_23 v128)
(local $w6_2_24 v128)
(local $w6_2_25 v128)
(local $w6_2_26 v128)
(local $w6_2_27 v128)
(local $w6_2_28 v128)
(local $w6_2_29 v128)
(local $w6_2_30 v128)
(local $w6_2_31 v128)
(local $w6_3_0 v128)
(local $w6_3_1 v128)
(local $w6_3_2 v128)
(local $w6_3_3 v128)
(local $w6_3_4 v128)
(local $w6_3_5 v128)
(local $w6_3_6 v128)
(local $w6_3_7 v128)
(local $w6_3_8 v128)
(local $w6_3_9 v128)
(local $w6_3_10 v128)
(local $w6_3_11 v128)
(local $w6_3_12 v128)
(local $w6_3_13 v128)
(local $w6_3_14 v128)
(local $w6_3_15 v128)
(local $w6_3_16 v128)
(local $w6_3_17 v128)
(local $w6_3_18 v128)
(local $w6_3_19 v128)
(local $w6_3_20 v128)
(local $w6_3_21 v128)
(local $w6_3_22 v128)
(local $w6_3_23 v128)
(local $w6_3_24 v128)
(local $w6_3_25 v128)
(local $w6_3_26 v128)
(local $w6_3_27 v128)
(local $w6_3_28 v128)
(local $w6_3_29 v128)
(local $w6_3_30 v128)
(local $w6_3_31 v128)
(local $w6_4_0 v128)
(local $w6_4_1 v128)
(local $w6_4_2 v128)
(local $w6_4_3 v128)
(local $w6_4_4 v128)
(local $w6_4_5 v128)
(local $w6_4_6 v128)
(local $w6_4_7 v128)
(local $w6_4_8 v128)
(local $w6_4_9 v128)
(local $w6_4_10 v128)
(local $w6_4_11 v128)
(local $w6_4_12 v128)
(local $w6_4_13 v128)
(local $w6_4_14 v128)
(local $w6_4_15 v128)
(local $w6_4_16 v128)
(local $w6_4_17 v128)
(local $w6_4_18 v128)
(local $w6_4_19 v128)
(local $w6_4_20 v128)
(local $w6_4_21 v128)
(local $w6_4_22 v128)
(local $w6_4_23 v128)
(local $w6_4_24 v128)
(local $w6_4_25 v128)
(local $w6_4_26 v128)
(local $w6_4_27 v128)
(local $w6_4_28 v128)
(local $w6_4_29 v128)
(local $w6_4_30 v128)
(local $w6_4_31 v128)
(local $w6_5_0 v128)
(local $w6_5_1 v128)
(local $w6_5_2 v128)
(local $w6_5_3 v128)
(local $w6_5_4 v128)
(local $w6_5_5 v128)
(local $w6_5_6 v128)
(local $w6_5_7 v128)
(local $w6_5_8 v128)
(local $w6_5_9 v128)
(local $w6_5_10 v128)
(local $w6_5_11 v128)
(local $w6_5_12 v128)
(local $w6_5_13 v128)
(local $w6_5_14 v128)
(local $w6_5_15 v128)
(local $w6_5_16 v128)
(local $w6_5_17 v128)
(local $w6_5_18 v128)
(local $w6_5_19 v128)
(local $w6_5_20 v128)
(local $w6_5_21 v128)
(local $w6_5_22 v128)
(local $w6_5_23 v128)
(local $w6_5_24 v128)
(local $w6_5_25 v128)
(local $w6_5_26 v128)
(local $w6_5_27 v128)
(local $w6_5_28 v128)
(local $w6_5_29 v128)
(local $w6_5_30 v128)
(local $w6_5_31 v128)
(local $w6_6_0 v128)
(local $w6_6_1 v128)
(local $w6_6_2 v128)
(local $w6_6_3 v128)
(local $w6_6_4 v128)
(local $w6_6_5 v128)
(local $w6_6_6 v128)
(local $w6_6_7 v128)
(local $w6_6_8 v128)
(local $w6_6_9 v128)
(local $w6_6_10 v128)
(local $w6_6_11 v128)
(local $w6_6_12 v128)
(local $w6_6_13 v128)
(local $w6_6_14 v128)
(local $w6_6_15 v128)
(local $w6_6_16 v128)
(local $w6_6_17 v128)
(local $w6_6_18 v128)
(local $w6_6_19 v128)
(local $w6_6_20 v128)
(local $w6_6_21 v128)
(local $w6_6_22 v128)
(local $w6_6_23 v128)
(local $w6_6_24 v128)
(local $w6_6_25 v128)
(local $w6_6_26 v128)
(local $w6_6_27 v128)
(local $w6_6_28 v128)
(local $w6_6_29 v128)
(local $w6_6_30 v128)
(local $w6_6_31 v128)
(local $w6_7_0 v128)
(local $w6_7_1 v128)
(local $w6_7_2 v128)
(local $w6_7_3 v128)
(local $w6_7_4 v128)
(local $w6_7_5 v128)
(local $w6_7_6 v128)
(local $w6_7_7 v128)
(local $w6_7_8 v128)
(local $w6_7_9 v128)
(local $w6_7_10 v128)
(local $w6_7_11 v128)
(local $w6_7_12 v128)
(local $w6_7_13 v128)
(local $w6_7_14 v128)
(local $w6_7_15 v128)
(local $w6_7_16 v128)
(local $w6_7_17 v128)
(local $w6_7_18 v128)
(local $w6_7_19 v128)
(local $w6_7_20 v128)
(local $w6_7_21 v128)
(local $w6_7_22 v128)
(local $w6_7_23 v128)
(local $w6_7_24 v128)
(local $w6_7_25 v128)
(local $w6_7_26 v128)
(local $w6_7_27 v128)
(local $w6_7_28 v128)
(local $w6_7_29 v128)
(local $w6_7_30 v128)
(local $w6_7_31 v128)
































































































































































































































































































































































































































































































































































































































































































































































































(local $sw0 v128)
(local $sw1 v128)
(local $sw2 v128)
(local $sw3 v128)
(local $sw4 v128)
(local $sw5 v128)
(local $sw6 v128)
(local $sw7 v128)
























(local $b12_0_0 v128) (local $b21_0_0 v128)
(local $b12_0_1 v128) (local $b21_0_1 v128)
(local $b12_0_2 v128) (local $b21_0_2 v128)
(local $b12_0_3 v128) (local $b21_0_3 v128)
(local $b12_0_4 v128) (local $b21_0_4 v128)
(local $b12_0_5 v128) (local $b21_0_5 v128)
(local $b12_0_6 v128) (local $b21_0_6 v128)
(local $b12_0_7 v128) (local $b21_0_7 v128)
(local $b12_0_8 v128) (local $b21_0_8 v128)
(local $b12_0_9 v128) (local $b21_0_9 v128)
(local $b12_0_10 v128) (local $b21_0_10 v128)
(local $b12_0_11 v128) (local $b21_0_11 v128)
(local $b12_0_12 v128) (local $b21_0_12 v128)
(local $b12_0_13 v128) (local $b21_0_13 v128)
(local $b12_0_14 v128) (local $b21_0_14 v128)
(local $b12_0_15 v128) (local $b21_0_15 v128)
(local $b12_0_16 v128) (local $b21_0_16 v128)
(local $b12_0_17 v128) (local $b21_0_17 v128)
(local $b12_0_18 v128) (local $b21_0_18 v128)
(local $b12_0_19 v128) (local $b21_0_19 v128)
(local $b12_0_20 v128) (local $b21_0_20 v128)
(local $b12_0_21 v128) (local $b21_0_21 v128)
(local $b12_0_22 v128) (local $b21_0_22 v128)
(local $b12_0_23 v128) (local $b21_0_23 v128)
(local $b12_0_24 v128) (local $b21_0_24 v128)
(local $b12_0_25 v128) (local $b21_0_25 v128)
(local $b12_0_26 v128) (local $b21_0_26 v128)
(local $b12_0_27 v128) (local $b21_0_27 v128)
(local $b12_0_28 v128) (local $b21_0_28 v128)
(local $b12_0_29 v128) (local $b21_0_29 v128)
(local $b12_0_30 v128) (local $b21_0_30 v128)
(local $b12_0_31 v128) (local $b21_0_31 v128)
(local $b12_1_0 v128) (local $b21_1_0 v128)
(local $b12_1_1 v128) (local $b21_1_1 v128)
(local $b12_1_2 v128) (local $b21_1_2 v128)
(local $b12_1_3 v128) (local $b21_1_3 v128)
(local $b12_1_4 v128) (local $b21_1_4 v128)
(local $b12_1_5 v128) (local $b21_1_5 v128)
(local $b12_1_6 v128) (local $b21_1_6 v128)
(local $b12_1_7 v128) (local $b21_1_7 v128)
(local $b12_1_8 v128) (local $b21_1_8 v128)
(local $b12_1_9 v128) (local $b21_1_9 v128)
(local $b12_1_10 v128) (local $b21_1_10 v128)
(local $b12_1_11 v128) (local $b21_1_11 v128)
(local $b12_1_12 v128) (local $b21_1_12 v128)
(local $b12_1_13 v128) (local $b21_1_13 v128)
(local $b12_1_14 v128) (local $b21_1_14 v128)
(local $b12_1_15 v128) (local $b21_1_15 v128)
(local $b12_1_16 v128) (local $b21_1_16 v128)
(local $b12_1_17 v128) (local $b21_1_17 v128)
(local $b12_1_18 v128) (local $b21_1_18 v128)
(local $b12_1_19 v128) (local $b21_1_19 v128)
(local $b12_1_20 v128) (local $b21_1_20 v128)
(local $b12_1_21 v128) (local $b21_1_21 v128)
(local $b12_1_22 v128) (local $b21_1_22 v128)
(local $b12_1_23 v128) (local $b21_1_23 v128)
(local $b12_1_24 v128) (local $b21_1_24 v128)
(local $b12_1_25 v128) (local $b21_1_25 v128)
(local $b12_1_26 v128) (local $b21_1_26 v128)
(local $b12_1_27 v128) (local $b21_1_27 v128)
(local $b12_1_28 v128) (local $b21_1_28 v128)
(local $b12_1_29 v128) (local $b21_1_29 v128)
(local $b12_1_30 v128) (local $b21_1_30 v128)
(local $b12_1_31 v128) (local $b21_1_31 v128)
(local $b12_2_0 v128) (local $b21_2_0 v128)
(local $b12_2_1 v128) (local $b21_2_1 v128)
(local $b12_2_2 v128) (local $b21_2_2 v128)
(local $b12_2_3 v128) (local $b21_2_3 v128)
(local $b12_2_4 v128) (local $b21_2_4 v128)
(local $b12_2_5 v128) (local $b21_2_5 v128)
(local $b12_2_6 v128) (local $b21_2_6 v128)
(local $b12_2_7 v128) (local $b21_2_7 v128)
(local $b12_2_8 v128) (local $b21_2_8 v128)
(local $b12_2_9 v128) (local $b21_2_9 v128)
(local $b12_2_10 v128) (local $b21_2_10 v128)
(local $b12_2_11 v128) (local $b21_2_11 v128)
(local $b12_2_12 v128) (local $b21_2_12 v128)
(local $b12_2_13 v128) (local $b21_2_13 v128)
(local $b12_2_14 v128) (local $b21_2_14 v128)
(local $b12_2_15 v128) (local $b21_2_15 v128)
(local $b12_2_16 v128) (local $b21_2_16 v128)
(local $b12_2_17 v128) (local $b21_2_17 v128)
(local $b12_2_18 v128) (local $b21_2_18 v128)
(local $b12_2_19 v128) (local $b21_2_19 v128)
(local $b12_2_20 v128) (local $b21_2_20 v128)
(local $b12_2_21 v128) (local $b21_2_21 v128)
(local $b12_2_22 v128) (local $b21_2_22 v128)
(local $b12_2_23 v128) (local $b21_2_23 v128)
(local $b12_2_24 v128) (local $b21_2_24 v128)
(local $b12_2_25 v128) (local $b21_2_25 v128)
(local $b12_2_26 v128) (local $b21_2_26 v128)
(local $b12_2_27 v128) (local $b21_2_27 v128)
(local $b12_2_28 v128) (local $b21_2_28 v128)
(local $b12_2_29 v128) (local $b21_2_29 v128)
(local $b12_2_30 v128) (local $b21_2_30 v128)
(local $b12_2_31 v128) (local $b21_2_31 v128)
(local $b12_3_0 v128) (local $b21_3_0 v128)
(local $b12_3_1 v128) (local $b21_3_1 v128)
(local $b12_3_2 v128) (local $b21_3_2 v128)
(local $b12_3_3 v128) (local $b21_3_3 v128)
(local $b12_3_4 v128) (local $b21_3_4 v128)
(local $b12_3_5 v128) (local $b21_3_5 v128)
(local $b12_3_6 v128) (local $b21_3_6 v128)
(local $b12_3_7 v128) (local $b21_3_7 v128)
(local $b12_3_8 v128) (local $b21_3_8 v128)
(local $b12_3_9 v128) (local $b21_3_9 v128)
(local $b12_3_10 v128) (local $b21_3_10 v128)
(local $b12_3_11 v128) (local $b21_3_11 v128)
(local $b12_3_12 v128) (local $b21_3_12 v128)
(local $b12_3_13 v128) (local $b21_3_13 v128)
(local $b12_3_14 v128) (local $b21_3_14 v128)
(local $b12_3_15 v128) (local $b21_3_15 v128)
(local $b12_3_16 v128) (local $b21_3_16 v128)
(local $b12_3_17 v128) (local $b21_3_17 v128)
(local $b12_3_18 v128) (local $b21_3_18 v128)
(local $b12_3_19 v128) (local $b21_3_19 v128)
(local $b12_3_20 v128) (local $b21_3_20 v128)
(local $b12_3_21 v128) (local $b21_3_21 v128)
(local $b12_3_22 v128) (local $b21_3_22 v128)
(local $b12_3_23 v128) (local $b21_3_23 v128)
(local $b12_3_24 v128) (local $b21_3_24 v128)
(local $b12_3_25 v128) (local $b21_3_25 v128)
(local $b12_3_26 v128) (local $b21_3_26 v128)
(local $b12_3_27 v128) (local $b21_3_27 v128)
(local $b12_3_28 v128) (local $b21_3_28 v128)
(local $b12_3_29 v128) (local $b21_3_29 v128)
(local $b12_3_30 v128) (local $b21_3_30 v128)
(local $b12_3_31 v128) (local $b21_3_31 v128)
(local $b12_4_0 v128) (local $b21_4_0 v128)
(local $b12_4_1 v128) (local $b21_4_1 v128)
(local $b12_4_2 v128) (local $b21_4_2 v128)
(local $b12_4_3 v128) (local $b21_4_3 v128)
(local $b12_4_4 v128) (local $b21_4_4 v128)
(local $b12_4_5 v128) (local $b21_4_5 v128)
(local $b12_4_6 v128) (local $b21_4_6 v128)
(local $b12_4_7 v128) (local $b21_4_7 v128)
(local $b12_4_8 v128) (local $b21_4_8 v128)
(local $b12_4_9 v128) (local $b21_4_9 v128)
(local $b12_4_10 v128) (local $b21_4_10 v128)
(local $b12_4_11 v128) (local $b21_4_11 v128)
(local $b12_4_12 v128) (local $b21_4_12 v128)
(local $b12_4_13 v128) (local $b21_4_13 v128)
(local $b12_4_14 v128) (local $b21_4_14 v128)
(local $b12_4_15 v128) (local $b21_4_15 v128)
(local $b12_4_16 v128) (local $b21_4_16 v128)
(local $b12_4_17 v128) (local $b21_4_17 v128)
(local $b12_4_18 v128) (local $b21_4_18 v128)
(local $b12_4_19 v128) (local $b21_4_19 v128)
(local $b12_4_20 v128) (local $b21_4_20 v128)
(local $b12_4_21 v128) (local $b21_4_21 v128)
(local $b12_4_22 v128) (local $b21_4_22 v128)
(local $b12_4_23 v128) (local $b21_4_23 v128)
(local $b12_4_24 v128) (local $b21_4_24 v128)
(local $b12_4_25 v128) (local $b21_4_25 v128)
(local $b12_4_26 v128) (local $b21_4_26 v128)
(local $b12_4_27 v128) (local $b21_4_27 v128)
(local $b12_4_28 v128) (local $b21_4_28 v128)
(local $b12_4_29 v128) (local $b21_4_29 v128)
(local $b12_4_30 v128) (local $b21_4_30 v128)
(local $b12_4_31 v128) (local $b21_4_31 v128)
(local $b12_5_0 v128) (local $b21_5_0 v128)
(local $b12_5_1 v128) (local $b21_5_1 v128)
(local $b12_5_2 v128) (local $b21_5_2 v128)
(local $b12_5_3 v128) (local $b21_5_3 v128)
(local $b12_5_4 v128) (local $b21_5_4 v128)
(local $b12_5_5 v128) (local $b21_5_5 v128)
(local $b12_5_6 v128) (local $b21_5_6 v128)
(local $b12_5_7 v128) (local $b21_5_7 v128)
(local $b12_5_8 v128) (local $b21_5_8 v128)
(local $b12_5_9 v128) (local $b21_5_9 v128)
(local $b12_5_10 v128) (local $b21_5_10 v128)
(local $b12_5_11 v128) (local $b21_5_11 v128)
(local $b12_5_12 v128) (local $b21_5_12 v128)
(local $b12_5_13 v128) (local $b21_5_13 v128)
(local $b12_5_14 v128) (local $b21_5_14 v128)
(local $b12_5_15 v128) (local $b21_5_15 v128)
(local $b12_5_16 v128) (local $b21_5_16 v128)
(local $b12_5_17 v128) (local $b21_5_17 v128)
(local $b12_5_18 v128) (local $b21_5_18 v128)
(local $b12_5_19 v128) (local $b21_5_19 v128)
(local $b12_5_20 v128) (local $b21_5_20 v128)
(local $b12_5_21 v128) (local $b21_5_21 v128)
(local $b12_5_22 v128) (local $b21_5_22 v128)
(local $b12_5_23 v128) (local $b21_5_23 v128)
(local $b12_5_24 v128) (local $b21_5_24 v128)
(local $b12_5_25 v128) (local $b21_5_25 v128)
(local $b12_5_26 v128) (local $b21_5_26 v128)
(local $b12_5_27 v128) (local $b21_5_27 v128)
(local $b12_5_28 v128) (local $b21_5_28 v128)
(local $b12_5_29 v128) (local $b21_5_29 v128)
(local $b12_5_30 v128) (local $b21_5_30 v128)
(local $b12_5_31 v128) (local $b21_5_31 v128)
(local $b12_6_0 v128) (local $b21_6_0 v128)
(local $b12_6_1 v128) (local $b21_6_1 v128)
(local $b12_6_2 v128) (local $b21_6_2 v128)
(local $b12_6_3 v128) (local $b21_6_3 v128)
(local $b12_6_4 v128) (local $b21_6_4 v128)
(local $b12_6_5 v128) (local $b21_6_5 v128)
(local $b12_6_6 v128) (local $b21_6_6 v128)
(local $b12_6_7 v128) (local $b21_6_7 v128)
(local $b12_6_8 v128) (local $b21_6_8 v128)
(local $b12_6_9 v128) (local $b21_6_9 v128)
(local $b12_6_10 v128) (local $b21_6_10 v128)
(local $b12_6_11 v128) (local $b21_6_11 v128)
(local $b12_6_12 v128) (local $b21_6_12 v128)
(local $b12_6_13 v128) (local $b21_6_13 v128)
(local $b12_6_14 v128) (local $b21_6_14 v128)
(local $b12_6_15 v128) (local $b21_6_15 v128)
(local $b12_6_16 v128) (local $b21_6_16 v128)
(local $b12_6_17 v128) (local $b21_6_17 v128)
(local $b12_6_18 v128) (local $b21_6_18 v128)
(local $b12_6_19 v128) (local $b21_6_19 v128)
(local $b12_6_20 v128) (local $b21_6_20 v128)
(local $b12_6_21 v128) (local $b21_6_21 v128)
(local $b12_6_22 v128) (local $b21_6_22 v128)
(local $b12_6_23 v128) (local $b21_6_23 v128)
(local $b12_6_24 v128) (local $b21_6_24 v128)
(local $b12_6_25 v128) (local $b21_6_25 v128)
(local $b12_6_26 v128) (local $b21_6_26 v128)
(local $b12_6_27 v128) (local $b21_6_27 v128)
(local $b12_6_28 v128) (local $b21_6_28 v128)
(local $b12_6_29 v128) (local $b21_6_29 v128)
(local $b12_6_30 v128) (local $b21_6_30 v128)
(local $b12_6_31 v128) (local $b21_6_31 v128)
(local $b12_7_0 v128) (local $b21_7_0 v128)
(local $b12_7_1 v128) (local $b21_7_1 v128)
(local $b12_7_2 v128) (local $b21_7_2 v128)
(local $b12_7_3 v128) (local $b21_7_3 v128)
(local $b12_7_4 v128) (local $b21_7_4 v128)
(local $b12_7_5 v128) (local $b21_7_5 v128)
(local $b12_7_6 v128) (local $b21_7_6 v128)
(local $b12_7_7 v128) (local $b21_7_7 v128)
(local $b12_7_8 v128) (local $b21_7_8 v128)
(local $b12_7_9 v128) (local $b21_7_9 v128)
(local $b12_7_10 v128) (local $b21_7_10 v128)
(local $b12_7_11 v128) (local $b21_7_11 v128)
(local $b12_7_12 v128) (local $b21_7_12 v128)
(local $b12_7_13 v128) (local $b21_7_13 v128)
(local $b12_7_14 v128) (local $b21_7_14 v128)
(local $b12_7_15 v128) (local $b21_7_15 v128)
(local $b12_7_16 v128) (local $b21_7_16 v128)
(local $b12_7_17 v128) (local $b21_7_17 v128)
(local $b12_7_18 v128) (local $b21_7_18 v128)
(local $b12_7_19 v128) (local $b21_7_19 v128)
(local $b12_7_20 v128) (local $b21_7_20 v128)
(local $b12_7_21 v128) (local $b21_7_21 v128)
(local $b12_7_22 v128) (local $b21_7_22 v128)
(local $b12_7_23 v128) (local $b21_7_23 v128)
(local $b12_7_24 v128) (local $b21_7_24 v128)
(local $b12_7_25 v128) (local $b21_7_25 v128)
(local $b12_7_26 v128) (local $b21_7_26 v128)
(local $b12_7_27 v128) (local $b21_7_27 v128)
(local $b12_7_28 v128) (local $b21_7_28 v128)
(local $b12_7_29 v128) (local $b21_7_29 v128)
(local $b12_7_30 v128) (local $b21_7_30 v128)
(local $b12_7_31 v128) (local $b21_7_31 v128)
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
(local $row0 i32)
(local $row1 i32)
(local $row2 i32)
(local $row3 i32)
(local.set $input_stride (i32.shr_u (local.get $cols) (i32.const 8)))
(local.set $output_bytes (i32.shl (local.get $stride) (i32.const 2)))
(local.set $sw0 (v128.load offset=0 (local.get $sw)))
(local.set $sw1 (v128.load offset=16 (local.get $sw)))
(local.set $sw2 (v128.load offset=32 (local.get $sw)))
(local.set $sw3 (v128.load offset=48 (local.get $sw)))
(local.set $sw4 (v128.load offset=64 (local.get $sw)))
(local.set $sw5 (v128.load offset=80 (local.get $sw)))
(local.set $sw6 (v128.load offset=96 (local.get $sw)))
(local.set $sw7 (v128.load offset=112 (local.get $sw)))
























(local.set $wp0 (i32.add (i32.load offset=0 (local.get $w)) (local.get $start)))
(local.set $wp1 (i32.add (i32.load offset=4 (local.get $w)) (local.get $start)))
(local.set $wp2 (i32.add (i32.load offset=8 (local.get $w)) (local.get $start)))
(local.set $wp3 (i32.add (i32.load offset=12 (local.get $w)) (local.get $start)))
(local.set $t (i32.const 0))
(block $done
(br_if $done (i32.eqz (local.get $n)))
(local.set $qoffset (i32.add (i32.mul (local.get $t) (local.get $cols)) (i32.shl (local.get $start) (i32.const 1))))
(local.set $keep (i32.lt_u (i32.add (local.get $t) (i32.const 1)) (local.get $n)))
(local.set $yp (i32.add (local.get $sums) (i32.mul (local.get $t) (local.get $output_bytes))))
(local.set $yp1 (i32.add (local.get $yp) (local.get $output_bytes)))
(local.set $sx0 (v128.load32_splat (i32.add (local.get $sx) (i32.shl (i32.mul (local.get $t) (local.get $input_stride)) (i32.const 2)))))
(if (local.get $keep) (then (local.set $sx1 (v128.load32_splat (i32.add (local.get $sx) (i32.shl (i32.mul (i32.add (local.get $t) (i32.const 1)) (local.get $input_stride)) (i32.const 2)))))))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 0))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 0))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 0))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 0))))
(local.set $qp (i32.add (i32.load offset=0 (local.get $q)) (local.get $qoffset)))
(local.tee $x0_0 (v128.load offset=0 (local.get $qp)))
(local.tee $w1_0_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_0_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x0_1 (v128.load offset=16 (local.get $qp)))
(local.tee $w1_0_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_0_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_2 (v128.load offset=32 (local.get $qp)))
(local.tee $w1_0_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_0_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_3 (v128.load offset=48 (local.get $qp)))
(local.tee $w1_0_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_0_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_4 (v128.load offset=64 (local.get $qp)))
(local.tee $w1_0_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_0_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_5 (v128.load offset=80 (local.get $qp)))
(local.tee $w1_0_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_0_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_6 (v128.load offset=96 (local.get $qp)))
(local.tee $w1_0_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_0_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_7 (v128.load offset=112 (local.get $qp)))
(local.tee $w1_0_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_0_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_8 (v128.load offset=128 (local.get $qp)))
(local.tee $w1_0_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_0_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_9 (v128.load offset=144 (local.get $qp)))
(local.tee $w1_0_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_0_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_10 (v128.load offset=160 (local.get $qp)))
(local.tee $w1_0_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_0_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_11 (v128.load offset=176 (local.get $qp)))
(local.tee $w1_0_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_0_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_12 (v128.load offset=192 (local.get $qp)))
(local.tee $w1_0_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_0_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_13 (v128.load offset=208 (local.get $qp)))
(local.tee $w1_0_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_0_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_14 (v128.load offset=224 (local.get $qp)))
(local.tee $w1_0_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_0_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_15 (v128.load offset=240 (local.get $qp)))
(local.tee $w1_0_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_0_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_16 (v128.load offset=256 (local.get $qp)))
(local.tee $w1_0_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_0_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_17 (v128.load offset=272 (local.get $qp)))
(local.tee $w1_0_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_0_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_18 (v128.load offset=288 (local.get $qp)))
(local.tee $w1_0_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_0_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_19 (v128.load offset=304 (local.get $qp)))
(local.tee $w1_0_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_0_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_20 (v128.load offset=320 (local.get $qp)))
(local.tee $w1_0_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_0_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_21 (v128.load offset=336 (local.get $qp)))
(local.tee $w1_0_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_0_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_22 (v128.load offset=352 (local.get $qp)))
(local.tee $w1_0_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_0_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_23 (v128.load offset=368 (local.get $qp)))
(local.tee $w1_0_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_0_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_24 (v128.load offset=384 (local.get $qp)))
(local.tee $w1_0_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_0_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_25 (v128.load offset=400 (local.get $qp)))
(local.tee $w1_0_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_0_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_26 (v128.load offset=416 (local.get $qp)))
(local.tee $w1_0_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_0_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_27 (v128.load offset=432 (local.get $qp)))
(local.tee $w1_0_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_0_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_28 (v128.load offset=448 (local.get $qp)))
(local.tee $w1_0_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_0_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_29 (v128.load offset=464 (local.get $qp)))
(local.tee $w1_0_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_0_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_30 (v128.load offset=480 (local.get $qp)))
(local.tee $w1_0_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_0_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_31 (v128.load offset=496 (local.get $qp)))
(local.tee $w1_0_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_0_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
(local.set $qp (i32.add (i32.load offset=4 (local.get $q)) (local.get $qoffset)))
(local.tee $x1_0 (v128.load offset=0 (local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1_1 (v128.load offset=16 (local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_2 (v128.load offset=32 (local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_3 (v128.load offset=48 (local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_4 (v128.load offset=64 (local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_5 (v128.load offset=80 (local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_6 (v128.load offset=96 (local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_7 (v128.load offset=112 (local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_8 (v128.load offset=128 (local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_9 (v128.load offset=144 (local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_10 (v128.load offset=160 (local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_11 (v128.load offset=176 (local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_12 (v128.load offset=192 (local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_13 (v128.load offset=208 (local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_14 (v128.load offset=224 (local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_15 (v128.load offset=240 (local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_16 (v128.load offset=256 (local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_17 (v128.load offset=272 (local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_18 (v128.load offset=288 (local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_19 (v128.load offset=304 (local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_20 (v128.load offset=320 (local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_21 (v128.load offset=336 (local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_22 (v128.load offset=352 (local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_23 (v128.load offset=368 (local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_24 (v128.load offset=384 (local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_25 (v128.load offset=400 (local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_26 (v128.load offset=416 (local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_27 (v128.load offset=432 (local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_28 (v128.load offset=448 (local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_29 (v128.load offset=464 (local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_30 (v128.load offset=480 (local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_31 (v128.load offset=496 (local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
(local.set $qp (i32.add (i32.load offset=8 (local.get $q)) (local.get $qoffset)))
(local.tee $x2_0 (v128.load offset=0 (local.get $qp)))
(local.tee $b12_0_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_0_0
i16x8.sub
local.tee $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x2_1 (v128.load offset=16 (local.get $qp)))
(local.tee $b12_0_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_0_1
i16x8.sub
local.tee $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_2 (v128.load offset=32 (local.get $qp)))
(local.tee $b12_0_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_0_2
i16x8.sub
local.tee $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_3 (v128.load offset=48 (local.get $qp)))
(local.tee $b12_0_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_0_3
i16x8.sub
local.tee $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_4 (v128.load offset=64 (local.get $qp)))
(local.tee $b12_0_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_0_4
i16x8.sub
local.tee $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_5 (v128.load offset=80 (local.get $qp)))
(local.tee $b12_0_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_0_5
i16x8.sub
local.tee $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_6 (v128.load offset=96 (local.get $qp)))
(local.tee $b12_0_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_0_6
i16x8.sub
local.tee $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_7 (v128.load offset=112 (local.get $qp)))
(local.tee $b12_0_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_0_7
i16x8.sub
local.tee $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_8 (v128.load offset=128 (local.get $qp)))
(local.tee $b12_0_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_0_8
i16x8.sub
local.tee $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_9 (v128.load offset=144 (local.get $qp)))
(local.tee $b12_0_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_0_9
i16x8.sub
local.tee $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_10 (v128.load offset=160 (local.get $qp)))
(local.tee $b12_0_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_0_10
i16x8.sub
local.tee $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_11 (v128.load offset=176 (local.get $qp)))
(local.tee $b12_0_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_0_11
i16x8.sub
local.tee $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_12 (v128.load offset=192 (local.get $qp)))
(local.tee $b12_0_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_0_12
i16x8.sub
local.tee $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_13 (v128.load offset=208 (local.get $qp)))
(local.tee $b12_0_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_0_13
i16x8.sub
local.tee $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_14 (v128.load offset=224 (local.get $qp)))
(local.tee $b12_0_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_0_14
i16x8.sub
local.tee $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_15 (v128.load offset=240 (local.get $qp)))
(local.tee $b12_0_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_0_15
i16x8.sub
local.tee $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_16 (v128.load offset=256 (local.get $qp)))
(local.tee $b12_0_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_0_16
i16x8.sub
local.tee $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_17 (v128.load offset=272 (local.get $qp)))
(local.tee $b12_0_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_0_17
i16x8.sub
local.tee $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_18 (v128.load offset=288 (local.get $qp)))
(local.tee $b12_0_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_0_18
i16x8.sub
local.tee $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_19 (v128.load offset=304 (local.get $qp)))
(local.tee $b12_0_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_0_19
i16x8.sub
local.tee $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_20 (v128.load offset=320 (local.get $qp)))
(local.tee $b12_0_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_0_20
i16x8.sub
local.tee $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_21 (v128.load offset=336 (local.get $qp)))
(local.tee $b12_0_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_0_21
i16x8.sub
local.tee $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_22 (v128.load offset=352 (local.get $qp)))
(local.tee $b12_0_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_0_22
i16x8.sub
local.tee $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_23 (v128.load offset=368 (local.get $qp)))
(local.tee $b12_0_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_0_23
i16x8.sub
local.tee $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_24 (v128.load offset=384 (local.get $qp)))
(local.tee $b12_0_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_0_24
i16x8.sub
local.tee $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_25 (v128.load offset=400 (local.get $qp)))
(local.tee $b12_0_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_0_25
i16x8.sub
local.tee $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_26 (v128.load offset=416 (local.get $qp)))
(local.tee $b12_0_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_0_26
i16x8.sub
local.tee $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_27 (v128.load offset=432 (local.get $qp)))
(local.tee $b12_0_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_0_27
i16x8.sub
local.tee $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_28 (v128.load offset=448 (local.get $qp)))
(local.tee $b12_0_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_0_28
i16x8.sub
local.tee $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_29 (v128.load offset=464 (local.get $qp)))
(local.tee $b12_0_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_0_29
i16x8.sub
local.tee $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_30 (v128.load offset=480 (local.get $qp)))
(local.tee $b12_0_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_0_30
i16x8.sub
local.tee $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_31 (v128.load offset=496 (local.get $qp)))
(local.tee $b12_0_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_0_31
i16x8.sub
local.tee $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
(local.set $qp (i32.add (i32.load offset=12 (local.get $q)) (local.get $qoffset)))
(local.tee $x3_0 (v128.load offset=0 (local.get $qp)))
(local.tee $b21_0_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_0_0
i16x8.sub
local.tee $w3_0_0
i32x4.dot_i16x8_s
(local.tee $x3_1 (v128.load offset=16 (local.get $qp)))
(local.tee $b21_0_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_0_1
i16x8.sub
local.tee $w3_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_2 (v128.load offset=32 (local.get $qp)))
(local.tee $b21_0_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_0_2
i16x8.sub
local.tee $w3_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_3 (v128.load offset=48 (local.get $qp)))
(local.tee $b21_0_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_0_3
i16x8.sub
local.tee $w3_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_4 (v128.load offset=64 (local.get $qp)))
(local.tee $b21_0_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_0_4
i16x8.sub
local.tee $w3_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_5 (v128.load offset=80 (local.get $qp)))
(local.tee $b21_0_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_0_5
i16x8.sub
local.tee $w3_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_6 (v128.load offset=96 (local.get $qp)))
(local.tee $b21_0_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_0_6
i16x8.sub
local.tee $w3_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_7 (v128.load offset=112 (local.get $qp)))
(local.tee $b21_0_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_0_7
i16x8.sub
local.tee $w3_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_8 (v128.load offset=128 (local.get $qp)))
(local.tee $b21_0_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_0_8
i16x8.sub
local.tee $w3_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_9 (v128.load offset=144 (local.get $qp)))
(local.tee $b21_0_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_0_9
i16x8.sub
local.tee $w3_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_10 (v128.load offset=160 (local.get $qp)))
(local.tee $b21_0_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_0_10
i16x8.sub
local.tee $w3_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_11 (v128.load offset=176 (local.get $qp)))
(local.tee $b21_0_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_0_11
i16x8.sub
local.tee $w3_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_12 (v128.load offset=192 (local.get $qp)))
(local.tee $b21_0_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_0_12
i16x8.sub
local.tee $w3_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_13 (v128.load offset=208 (local.get $qp)))
(local.tee $b21_0_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_0_13
i16x8.sub
local.tee $w3_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_14 (v128.load offset=224 (local.get $qp)))
(local.tee $b21_0_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_0_14
i16x8.sub
local.tee $w3_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_15 (v128.load offset=240 (local.get $qp)))
(local.tee $b21_0_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_0_15
i16x8.sub
local.tee $w3_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_16 (v128.load offset=256 (local.get $qp)))
(local.tee $b21_0_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_0_16
i16x8.sub
local.tee $w3_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_17 (v128.load offset=272 (local.get $qp)))
(local.tee $b21_0_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_0_17
i16x8.sub
local.tee $w3_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_18 (v128.load offset=288 (local.get $qp)))
(local.tee $b21_0_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_0_18
i16x8.sub
local.tee $w3_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_19 (v128.load offset=304 (local.get $qp)))
(local.tee $b21_0_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_0_19
i16x8.sub
local.tee $w3_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_20 (v128.load offset=320 (local.get $qp)))
(local.tee $b21_0_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_0_20
i16x8.sub
local.tee $w3_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_21 (v128.load offset=336 (local.get $qp)))
(local.tee $b21_0_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_0_21
i16x8.sub
local.tee $w3_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_22 (v128.load offset=352 (local.get $qp)))
(local.tee $b21_0_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_0_22
i16x8.sub
local.tee $w3_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_23 (v128.load offset=368 (local.get $qp)))
(local.tee $b21_0_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_0_23
i16x8.sub
local.tee $w3_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_24 (v128.load offset=384 (local.get $qp)))
(local.tee $b21_0_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_0_24
i16x8.sub
local.tee $w3_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_25 (v128.load offset=400 (local.get $qp)))
(local.tee $b21_0_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_0_25
i16x8.sub
local.tee $w3_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_26 (v128.load offset=416 (local.get $qp)))
(local.tee $b21_0_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_0_26
i16x8.sub
local.tee $w3_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_27 (v128.load offset=432 (local.get $qp)))
(local.tee $b21_0_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_0_27
i16x8.sub
local.tee $w3_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_28 (v128.load offset=448 (local.get $qp)))
(local.tee $b21_0_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_0_28
i16x8.sub
local.tee $w3_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_29 (v128.load offset=464 (local.get $qp)))
(local.tee $b21_0_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_0_29
i16x8.sub
local.tee $w3_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_30 (v128.load offset=480 (local.get $qp)))
(local.tee $b21_0_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_0_30
i16x8.sub
local.tee $w3_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_31 (v128.load offset=496 (local.get $qp)))
(local.tee $b21_0_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_0_31
i16x8.sub
local.tee $w3_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
(local.set $qp (i32.add (i32.load offset=16 (local.get $q)) (local.get $qoffset)))
(local.tee $x4_0 (v128.load offset=0 (local.get $qp)))
local.get $w4_0_0
i32x4.dot_i16x8_s
(local.tee $x4_1 (v128.load offset=16 (local.get $qp)))
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_2 (v128.load offset=32 (local.get $qp)))
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_3 (v128.load offset=48 (local.get $qp)))
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_4 (v128.load offset=64 (local.get $qp)))
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_5 (v128.load offset=80 (local.get $qp)))
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_6 (v128.load offset=96 (local.get $qp)))
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_7 (v128.load offset=112 (local.get $qp)))
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_8 (v128.load offset=128 (local.get $qp)))
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_9 (v128.load offset=144 (local.get $qp)))
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_10 (v128.load offset=160 (local.get $qp)))
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_11 (v128.load offset=176 (local.get $qp)))
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_12 (v128.load offset=192 (local.get $qp)))
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_13 (v128.load offset=208 (local.get $qp)))
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_14 (v128.load offset=224 (local.get $qp)))
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_15 (v128.load offset=240 (local.get $qp)))
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_16 (v128.load offset=256 (local.get $qp)))
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_17 (v128.load offset=272 (local.get $qp)))
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_18 (v128.load offset=288 (local.get $qp)))
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_19 (v128.load offset=304 (local.get $qp)))
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_20 (v128.load offset=320 (local.get $qp)))
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_21 (v128.load offset=336 (local.get $qp)))
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_22 (v128.load offset=352 (local.get $qp)))
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_23 (v128.load offset=368 (local.get $qp)))
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_24 (v128.load offset=384 (local.get $qp)))
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_25 (v128.load offset=400 (local.get $qp)))
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_26 (v128.load offset=416 (local.get $qp)))
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_27 (v128.load offset=432 (local.get $qp)))
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_28 (v128.load offset=448 (local.get $qp)))
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_29 (v128.load offset=464 (local.get $qp)))
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_30 (v128.load offset=480 (local.get $qp)))
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_31 (v128.load offset=496 (local.get $qp)))
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
(local.set $qp (i32.add (i32.load offset=20 (local.get $q)) (local.get $qoffset)))
(local.tee $x5_0 (v128.load offset=0 (local.get $qp)))
local.get $w1_0_0
local.get $b12_0_0
i16x8.add
local.tee $w5_0_0
i32x4.dot_i16x8_s
(local.tee $x5_1 (v128.load offset=16 (local.get $qp)))
local.get $w1_0_1
local.get $b12_0_1
i16x8.add
local.tee $w5_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_2 (v128.load offset=32 (local.get $qp)))
local.get $w1_0_2
local.get $b12_0_2
i16x8.add
local.tee $w5_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_3 (v128.load offset=48 (local.get $qp)))
local.get $w1_0_3
local.get $b12_0_3
i16x8.add
local.tee $w5_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_4 (v128.load offset=64 (local.get $qp)))
local.get $w1_0_4
local.get $b12_0_4
i16x8.add
local.tee $w5_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_5 (v128.load offset=80 (local.get $qp)))
local.get $w1_0_5
local.get $b12_0_5
i16x8.add
local.tee $w5_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_6 (v128.load offset=96 (local.get $qp)))
local.get $w1_0_6
local.get $b12_0_6
i16x8.add
local.tee $w5_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_7 (v128.load offset=112 (local.get $qp)))
local.get $w1_0_7
local.get $b12_0_7
i16x8.add
local.tee $w5_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_8 (v128.load offset=128 (local.get $qp)))
local.get $w1_0_8
local.get $b12_0_8
i16x8.add
local.tee $w5_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_9 (v128.load offset=144 (local.get $qp)))
local.get $w1_0_9
local.get $b12_0_9
i16x8.add
local.tee $w5_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_10 (v128.load offset=160 (local.get $qp)))
local.get $w1_0_10
local.get $b12_0_10
i16x8.add
local.tee $w5_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_11 (v128.load offset=176 (local.get $qp)))
local.get $w1_0_11
local.get $b12_0_11
i16x8.add
local.tee $w5_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_12 (v128.load offset=192 (local.get $qp)))
local.get $w1_0_12
local.get $b12_0_12
i16x8.add
local.tee $w5_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_13 (v128.load offset=208 (local.get $qp)))
local.get $w1_0_13
local.get $b12_0_13
i16x8.add
local.tee $w5_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_14 (v128.load offset=224 (local.get $qp)))
local.get $w1_0_14
local.get $b12_0_14
i16x8.add
local.tee $w5_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_15 (v128.load offset=240 (local.get $qp)))
local.get $w1_0_15
local.get $b12_0_15
i16x8.add
local.tee $w5_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_16 (v128.load offset=256 (local.get $qp)))
local.get $w1_0_16
local.get $b12_0_16
i16x8.add
local.tee $w5_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_17 (v128.load offset=272 (local.get $qp)))
local.get $w1_0_17
local.get $b12_0_17
i16x8.add
local.tee $w5_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_18 (v128.load offset=288 (local.get $qp)))
local.get $w1_0_18
local.get $b12_0_18
i16x8.add
local.tee $w5_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_19 (v128.load offset=304 (local.get $qp)))
local.get $w1_0_19
local.get $b12_0_19
i16x8.add
local.tee $w5_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_20 (v128.load offset=320 (local.get $qp)))
local.get $w1_0_20
local.get $b12_0_20
i16x8.add
local.tee $w5_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_21 (v128.load offset=336 (local.get $qp)))
local.get $w1_0_21
local.get $b12_0_21
i16x8.add
local.tee $w5_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_22 (v128.load offset=352 (local.get $qp)))
local.get $w1_0_22
local.get $b12_0_22
i16x8.add
local.tee $w5_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_23 (v128.load offset=368 (local.get $qp)))
local.get $w1_0_23
local.get $b12_0_23
i16x8.add
local.tee $w5_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_24 (v128.load offset=384 (local.get $qp)))
local.get $w1_0_24
local.get $b12_0_24
i16x8.add
local.tee $w5_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_25 (v128.load offset=400 (local.get $qp)))
local.get $w1_0_25
local.get $b12_0_25
i16x8.add
local.tee $w5_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_26 (v128.load offset=416 (local.get $qp)))
local.get $w1_0_26
local.get $b12_0_26
i16x8.add
local.tee $w5_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_27 (v128.load offset=432 (local.get $qp)))
local.get $w1_0_27
local.get $b12_0_27
i16x8.add
local.tee $w5_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_28 (v128.load offset=448 (local.get $qp)))
local.get $w1_0_28
local.get $b12_0_28
i16x8.add
local.tee $w5_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_29 (v128.load offset=464 (local.get $qp)))
local.get $w1_0_29
local.get $b12_0_29
i16x8.add
local.tee $w5_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_30 (v128.load offset=480 (local.get $qp)))
local.get $w1_0_30
local.get $b12_0_30
i16x8.add
local.tee $w5_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_31 (v128.load offset=496 (local.get $qp)))
local.get $w1_0_31
local.get $b12_0_31
i16x8.add
local.tee $w5_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
(local.set $qp (i32.add (i32.load offset=24 (local.get $q)) (local.get $qoffset)))
(local.tee $x6_0 (v128.load offset=0 (local.get $qp)))
local.get $b21_0_0
local.get $w4_0_0
i16x8.add
local.tee $w6_0_0
i32x4.dot_i16x8_s
(local.tee $x6_1 (v128.load offset=16 (local.get $qp)))
local.get $b21_0_1
local.get $w4_0_1
i16x8.add
local.tee $w6_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_2 (v128.load offset=32 (local.get $qp)))
local.get $b21_0_2
local.get $w4_0_2
i16x8.add
local.tee $w6_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_3 (v128.load offset=48 (local.get $qp)))
local.get $b21_0_3
local.get $w4_0_3
i16x8.add
local.tee $w6_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_4 (v128.load offset=64 (local.get $qp)))
local.get $b21_0_4
local.get $w4_0_4
i16x8.add
local.tee $w6_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_5 (v128.load offset=80 (local.get $qp)))
local.get $b21_0_5
local.get $w4_0_5
i16x8.add
local.tee $w6_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_6 (v128.load offset=96 (local.get $qp)))
local.get $b21_0_6
local.get $w4_0_6
i16x8.add
local.tee $w6_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_7 (v128.load offset=112 (local.get $qp)))
local.get $b21_0_7
local.get $w4_0_7
i16x8.add
local.tee $w6_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_8 (v128.load offset=128 (local.get $qp)))
local.get $b21_0_8
local.get $w4_0_8
i16x8.add
local.tee $w6_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_9 (v128.load offset=144 (local.get $qp)))
local.get $b21_0_9
local.get $w4_0_9
i16x8.add
local.tee $w6_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_10 (v128.load offset=160 (local.get $qp)))
local.get $b21_0_10
local.get $w4_0_10
i16x8.add
local.tee $w6_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_11 (v128.load offset=176 (local.get $qp)))
local.get $b21_0_11
local.get $w4_0_11
i16x8.add
local.tee $w6_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_12 (v128.load offset=192 (local.get $qp)))
local.get $b21_0_12
local.get $w4_0_12
i16x8.add
local.tee $w6_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_13 (v128.load offset=208 (local.get $qp)))
local.get $b21_0_13
local.get $w4_0_13
i16x8.add
local.tee $w6_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_14 (v128.load offset=224 (local.get $qp)))
local.get $b21_0_14
local.get $w4_0_14
i16x8.add
local.tee $w6_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_15 (v128.load offset=240 (local.get $qp)))
local.get $b21_0_15
local.get $w4_0_15
i16x8.add
local.tee $w6_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_16 (v128.load offset=256 (local.get $qp)))
local.get $b21_0_16
local.get $w4_0_16
i16x8.add
local.tee $w6_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_17 (v128.load offset=272 (local.get $qp)))
local.get $b21_0_17
local.get $w4_0_17
i16x8.add
local.tee $w6_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_18 (v128.load offset=288 (local.get $qp)))
local.get $b21_0_18
local.get $w4_0_18
i16x8.add
local.tee $w6_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_19 (v128.load offset=304 (local.get $qp)))
local.get $b21_0_19
local.get $w4_0_19
i16x8.add
local.tee $w6_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_20 (v128.load offset=320 (local.get $qp)))
local.get $b21_0_20
local.get $w4_0_20
i16x8.add
local.tee $w6_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_21 (v128.load offset=336 (local.get $qp)))
local.get $b21_0_21
local.get $w4_0_21
i16x8.add
local.tee $w6_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_22 (v128.load offset=352 (local.get $qp)))
local.get $b21_0_22
local.get $w4_0_22
i16x8.add
local.tee $w6_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_23 (v128.load offset=368 (local.get $qp)))
local.get $b21_0_23
local.get $w4_0_23
i16x8.add
local.tee $w6_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_24 (v128.load offset=384 (local.get $qp)))
local.get $b21_0_24
local.get $w4_0_24
i16x8.add
local.tee $w6_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_25 (v128.load offset=400 (local.get $qp)))
local.get $b21_0_25
local.get $w4_0_25
i16x8.add
local.tee $w6_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_26 (v128.load offset=416 (local.get $qp)))
local.get $b21_0_26
local.get $w4_0_26
i16x8.add
local.tee $w6_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_27 (v128.load offset=432 (local.get $qp)))
local.get $b21_0_27
local.get $w4_0_27
i16x8.add
local.tee $w6_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_28 (v128.load offset=448 (local.get $qp)))
local.get $b21_0_28
local.get $w4_0_28
i16x8.add
local.tee $w6_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_29 (v128.load offset=464 (local.get $qp)))
local.get $b21_0_29
local.get $w4_0_29
i16x8.add
local.tee $w6_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_30 (v128.load offset=480 (local.get $qp)))
local.get $b21_0_30
local.get $w4_0_30
i16x8.add
local.tee $w6_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_31 (v128.load offset=496 (local.get $qp)))
local.get $b21_0_31
local.get $w4_0_31
i16x8.add
local.tee $w6_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 1))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 1))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 1))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 1))))
local.get $x0_0
(local.tee $w1_1_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_1_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_1_0
i32x4.dot_i16x8_s
local.get $x0_1
(local.tee $w1_1_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_1_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(local.tee $w1_1_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_1_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(local.tee $w1_1_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_1_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(local.tee $w1_1_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_1_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(local.tee $w1_1_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_1_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(local.tee $w1_1_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_1_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(local.tee $w1_1_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_1_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(local.tee $w1_1_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_1_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(local.tee $w1_1_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_1_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(local.tee $w1_1_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_1_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(local.tee $w1_1_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_1_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(local.tee $w1_1_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_1_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(local.tee $w1_1_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_1_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(local.tee $w1_1_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_1_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(local.tee $w1_1_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_1_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(local.tee $w1_1_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_1_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(local.tee $w1_1_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_1_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(local.tee $w1_1_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_1_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(local.tee $w1_1_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_1_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(local.tee $w1_1_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_1_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(local.tee $w1_1_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_1_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(local.tee $w1_1_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_1_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(local.tee $w1_1_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_1_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(local.tee $w1_1_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_1_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(local.tee $w1_1_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_1_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(local.tee $w1_1_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_1_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(local.tee $w1_1_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_1_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(local.tee $w1_1_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_1_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(local.tee $w1_1_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_1_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(local.tee $w1_1_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_1_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(local.tee $w1_1_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_1_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_1_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
(local.tee $b12_1_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_1_0
i16x8.sub
local.tee $w2_1_0
i32x4.dot_i16x8_s
local.get $x2_1
(local.tee $b12_1_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_1_1
i16x8.sub
local.tee $w2_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(local.tee $b12_1_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_1_2
i16x8.sub
local.tee $w2_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(local.tee $b12_1_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_1_3
i16x8.sub
local.tee $w2_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(local.tee $b12_1_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_1_4
i16x8.sub
local.tee $w2_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(local.tee $b12_1_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_1_5
i16x8.sub
local.tee $w2_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(local.tee $b12_1_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_1_6
i16x8.sub
local.tee $w2_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(local.tee $b12_1_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_1_7
i16x8.sub
local.tee $w2_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(local.tee $b12_1_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_1_8
i16x8.sub
local.tee $w2_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(local.tee $b12_1_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_1_9
i16x8.sub
local.tee $w2_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(local.tee $b12_1_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_1_10
i16x8.sub
local.tee $w2_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(local.tee $b12_1_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_1_11
i16x8.sub
local.tee $w2_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(local.tee $b12_1_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_1_12
i16x8.sub
local.tee $w2_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(local.tee $b12_1_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_1_13
i16x8.sub
local.tee $w2_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(local.tee $b12_1_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_1_14
i16x8.sub
local.tee $w2_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(local.tee $b12_1_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_1_15
i16x8.sub
local.tee $w2_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(local.tee $b12_1_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_1_16
i16x8.sub
local.tee $w2_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(local.tee $b12_1_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_1_17
i16x8.sub
local.tee $w2_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(local.tee $b12_1_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_1_18
i16x8.sub
local.tee $w2_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(local.tee $b12_1_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_1_19
i16x8.sub
local.tee $w2_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(local.tee $b12_1_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_1_20
i16x8.sub
local.tee $w2_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(local.tee $b12_1_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_1_21
i16x8.sub
local.tee $w2_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(local.tee $b12_1_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_1_22
i16x8.sub
local.tee $w2_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(local.tee $b12_1_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_1_23
i16x8.sub
local.tee $w2_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(local.tee $b12_1_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_1_24
i16x8.sub
local.tee $w2_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(local.tee $b12_1_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_1_25
i16x8.sub
local.tee $w2_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(local.tee $b12_1_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_1_26
i16x8.sub
local.tee $w2_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(local.tee $b12_1_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_1_27
i16x8.sub
local.tee $w2_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(local.tee $b12_1_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_1_28
i16x8.sub
local.tee $w2_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(local.tee $b12_1_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_1_29
i16x8.sub
local.tee $w2_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(local.tee $b12_1_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_1_30
i16x8.sub
local.tee $w2_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(local.tee $b12_1_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_1_31
i16x8.sub
local.tee $w2_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
(local.tee $b21_1_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_1_0
i16x8.sub
local.tee $w3_1_0
i32x4.dot_i16x8_s
local.get $x3_1
(local.tee $b21_1_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_1_1
i16x8.sub
local.tee $w3_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
(local.tee $b21_1_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_1_2
i16x8.sub
local.tee $w3_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
(local.tee $b21_1_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_1_3
i16x8.sub
local.tee $w3_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
(local.tee $b21_1_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_1_4
i16x8.sub
local.tee $w3_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
(local.tee $b21_1_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_1_5
i16x8.sub
local.tee $w3_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
(local.tee $b21_1_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_1_6
i16x8.sub
local.tee $w3_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
(local.tee $b21_1_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_1_7
i16x8.sub
local.tee $w3_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
(local.tee $b21_1_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_1_8
i16x8.sub
local.tee $w3_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
(local.tee $b21_1_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_1_9
i16x8.sub
local.tee $w3_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
(local.tee $b21_1_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_1_10
i16x8.sub
local.tee $w3_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
(local.tee $b21_1_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_1_11
i16x8.sub
local.tee $w3_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
(local.tee $b21_1_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_1_12
i16x8.sub
local.tee $w3_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
(local.tee $b21_1_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_1_13
i16x8.sub
local.tee $w3_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
(local.tee $b21_1_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_1_14
i16x8.sub
local.tee $w3_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
(local.tee $b21_1_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_1_15
i16x8.sub
local.tee $w3_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
(local.tee $b21_1_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_1_16
i16x8.sub
local.tee $w3_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
(local.tee $b21_1_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_1_17
i16x8.sub
local.tee $w3_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
(local.tee $b21_1_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_1_18
i16x8.sub
local.tee $w3_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
(local.tee $b21_1_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_1_19
i16x8.sub
local.tee $w3_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
(local.tee $b21_1_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_1_20
i16x8.sub
local.tee $w3_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
(local.tee $b21_1_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_1_21
i16x8.sub
local.tee $w3_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
(local.tee $b21_1_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_1_22
i16x8.sub
local.tee $w3_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
(local.tee $b21_1_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_1_23
i16x8.sub
local.tee $w3_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
(local.tee $b21_1_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_1_24
i16x8.sub
local.tee $w3_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
(local.tee $b21_1_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_1_25
i16x8.sub
local.tee $w3_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
(local.tee $b21_1_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_1_26
i16x8.sub
local.tee $w3_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
(local.tee $b21_1_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_1_27
i16x8.sub
local.tee $w3_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
(local.tee $b21_1_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_1_28
i16x8.sub
local.tee $w3_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
(local.tee $b21_1_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_1_29
i16x8.sub
local.tee $w3_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
(local.tee $b21_1_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_1_30
i16x8.sub
local.tee $w3_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
(local.tee $b21_1_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_1_31
i16x8.sub
local.tee $w3_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_1_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w1_1_0
local.get $b12_1_0
i16x8.add
local.tee $w5_1_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w1_1_1
local.get $b12_1_1
i16x8.add
local.tee $w5_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w1_1_2
local.get $b12_1_2
i16x8.add
local.tee $w5_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w1_1_3
local.get $b12_1_3
i16x8.add
local.tee $w5_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w1_1_4
local.get $b12_1_4
i16x8.add
local.tee $w5_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w1_1_5
local.get $b12_1_5
i16x8.add
local.tee $w5_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w1_1_6
local.get $b12_1_6
i16x8.add
local.tee $w5_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w1_1_7
local.get $b12_1_7
i16x8.add
local.tee $w5_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w1_1_8
local.get $b12_1_8
i16x8.add
local.tee $w5_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w1_1_9
local.get $b12_1_9
i16x8.add
local.tee $w5_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w1_1_10
local.get $b12_1_10
i16x8.add
local.tee $w5_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w1_1_11
local.get $b12_1_11
i16x8.add
local.tee $w5_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w1_1_12
local.get $b12_1_12
i16x8.add
local.tee $w5_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w1_1_13
local.get $b12_1_13
i16x8.add
local.tee $w5_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w1_1_14
local.get $b12_1_14
i16x8.add
local.tee $w5_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w1_1_15
local.get $b12_1_15
i16x8.add
local.tee $w5_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w1_1_16
local.get $b12_1_16
i16x8.add
local.tee $w5_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w1_1_17
local.get $b12_1_17
i16x8.add
local.tee $w5_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w1_1_18
local.get $b12_1_18
i16x8.add
local.tee $w5_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w1_1_19
local.get $b12_1_19
i16x8.add
local.tee $w5_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w1_1_20
local.get $b12_1_20
i16x8.add
local.tee $w5_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w1_1_21
local.get $b12_1_21
i16x8.add
local.tee $w5_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w1_1_22
local.get $b12_1_22
i16x8.add
local.tee $w5_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w1_1_23
local.get $b12_1_23
i16x8.add
local.tee $w5_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w1_1_24
local.get $b12_1_24
i16x8.add
local.tee $w5_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w1_1_25
local.get $b12_1_25
i16x8.add
local.tee $w5_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w1_1_26
local.get $b12_1_26
i16x8.add
local.tee $w5_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w1_1_27
local.get $b12_1_27
i16x8.add
local.tee $w5_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w1_1_28
local.get $b12_1_28
i16x8.add
local.tee $w5_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w1_1_29
local.get $b12_1_29
i16x8.add
local.tee $w5_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w1_1_30
local.get $b12_1_30
i16x8.add
local.tee $w5_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w1_1_31
local.get $b12_1_31
i16x8.add
local.tee $w5_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $b21_1_0
local.get $w4_1_0
i16x8.add
local.tee $w6_1_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $b21_1_1
local.get $w4_1_1
i16x8.add
local.tee $w6_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $b21_1_2
local.get $w4_1_2
i16x8.add
local.tee $w6_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $b21_1_3
local.get $w4_1_3
i16x8.add
local.tee $w6_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $b21_1_4
local.get $w4_1_4
i16x8.add
local.tee $w6_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $b21_1_5
local.get $w4_1_5
i16x8.add
local.tee $w6_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $b21_1_6
local.get $w4_1_6
i16x8.add
local.tee $w6_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $b21_1_7
local.get $w4_1_7
i16x8.add
local.tee $w6_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $b21_1_8
local.get $w4_1_8
i16x8.add
local.tee $w6_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $b21_1_9
local.get $w4_1_9
i16x8.add
local.tee $w6_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $b21_1_10
local.get $w4_1_10
i16x8.add
local.tee $w6_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $b21_1_11
local.get $w4_1_11
i16x8.add
local.tee $w6_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $b21_1_12
local.get $w4_1_12
i16x8.add
local.tee $w6_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $b21_1_13
local.get $w4_1_13
i16x8.add
local.tee $w6_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $b21_1_14
local.get $w4_1_14
i16x8.add
local.tee $w6_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $b21_1_15
local.get $w4_1_15
i16x8.add
local.tee $w6_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $b21_1_16
local.get $w4_1_16
i16x8.add
local.tee $w6_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $b21_1_17
local.get $w4_1_17
i16x8.add
local.tee $w6_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $b21_1_18
local.get $w4_1_18
i16x8.add
local.tee $w6_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $b21_1_19
local.get $w4_1_19
i16x8.add
local.tee $w6_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $b21_1_20
local.get $w4_1_20
i16x8.add
local.tee $w6_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $b21_1_21
local.get $w4_1_21
i16x8.add
local.tee $w6_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $b21_1_22
local.get $w4_1_22
i16x8.add
local.tee $w6_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $b21_1_23
local.get $w4_1_23
i16x8.add
local.tee $w6_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $b21_1_24
local.get $w4_1_24
i16x8.add
local.tee $w6_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $b21_1_25
local.get $w4_1_25
i16x8.add
local.tee $w6_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $b21_1_26
local.get $w4_1_26
i16x8.add
local.tee $w6_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $b21_1_27
local.get $w4_1_27
i16x8.add
local.tee $w6_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $b21_1_28
local.get $w4_1_28
i16x8.add
local.tee $w6_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $b21_1_29
local.get $w4_1_29
i16x8.add
local.tee $w6_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $b21_1_30
local.get $w4_1_30
i16x8.add
local.tee $w6_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $b21_1_31
local.get $w4_1_31
i16x8.add
local.tee $w6_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 2))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 2))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 2))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 2))))
local.get $x0_0
(local.tee $w1_2_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_2_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_2_0
i32x4.dot_i16x8_s
local.get $x0_1
(local.tee $w1_2_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_2_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(local.tee $w1_2_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_2_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(local.tee $w1_2_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_2_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(local.tee $w1_2_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_2_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(local.tee $w1_2_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_2_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(local.tee $w1_2_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_2_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(local.tee $w1_2_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_2_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(local.tee $w1_2_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_2_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(local.tee $w1_2_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_2_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(local.tee $w1_2_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_2_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(local.tee $w1_2_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_2_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(local.tee $w1_2_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_2_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(local.tee $w1_2_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_2_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(local.tee $w1_2_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_2_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(local.tee $w1_2_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_2_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(local.tee $w1_2_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_2_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(local.tee $w1_2_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_2_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(local.tee $w1_2_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_2_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(local.tee $w1_2_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_2_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(local.tee $w1_2_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_2_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(local.tee $w1_2_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_2_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(local.tee $w1_2_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_2_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(local.tee $w1_2_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_2_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(local.tee $w1_2_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_2_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(local.tee $w1_2_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_2_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(local.tee $w1_2_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_2_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(local.tee $w1_2_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_2_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(local.tee $w1_2_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_2_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(local.tee $w1_2_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_2_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(local.tee $w1_2_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_2_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(local.tee $w1_2_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_2_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_2_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
(local.tee $b12_2_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_2_0
i16x8.sub
local.tee $w2_2_0
i32x4.dot_i16x8_s
local.get $x2_1
(local.tee $b12_2_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_2_1
i16x8.sub
local.tee $w2_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(local.tee $b12_2_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_2_2
i16x8.sub
local.tee $w2_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(local.tee $b12_2_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_2_3
i16x8.sub
local.tee $w2_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(local.tee $b12_2_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_2_4
i16x8.sub
local.tee $w2_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(local.tee $b12_2_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_2_5
i16x8.sub
local.tee $w2_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(local.tee $b12_2_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_2_6
i16x8.sub
local.tee $w2_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(local.tee $b12_2_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_2_7
i16x8.sub
local.tee $w2_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(local.tee $b12_2_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_2_8
i16x8.sub
local.tee $w2_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(local.tee $b12_2_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_2_9
i16x8.sub
local.tee $w2_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(local.tee $b12_2_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_2_10
i16x8.sub
local.tee $w2_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(local.tee $b12_2_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_2_11
i16x8.sub
local.tee $w2_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(local.tee $b12_2_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_2_12
i16x8.sub
local.tee $w2_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(local.tee $b12_2_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_2_13
i16x8.sub
local.tee $w2_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(local.tee $b12_2_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_2_14
i16x8.sub
local.tee $w2_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(local.tee $b12_2_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_2_15
i16x8.sub
local.tee $w2_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(local.tee $b12_2_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_2_16
i16x8.sub
local.tee $w2_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(local.tee $b12_2_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_2_17
i16x8.sub
local.tee $w2_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(local.tee $b12_2_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_2_18
i16x8.sub
local.tee $w2_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(local.tee $b12_2_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_2_19
i16x8.sub
local.tee $w2_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(local.tee $b12_2_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_2_20
i16x8.sub
local.tee $w2_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(local.tee $b12_2_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_2_21
i16x8.sub
local.tee $w2_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(local.tee $b12_2_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_2_22
i16x8.sub
local.tee $w2_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(local.tee $b12_2_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_2_23
i16x8.sub
local.tee $w2_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(local.tee $b12_2_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_2_24
i16x8.sub
local.tee $w2_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(local.tee $b12_2_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_2_25
i16x8.sub
local.tee $w2_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(local.tee $b12_2_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_2_26
i16x8.sub
local.tee $w2_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(local.tee $b12_2_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_2_27
i16x8.sub
local.tee $w2_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(local.tee $b12_2_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_2_28
i16x8.sub
local.tee $w2_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(local.tee $b12_2_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_2_29
i16x8.sub
local.tee $w2_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(local.tee $b12_2_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_2_30
i16x8.sub
local.tee $w2_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(local.tee $b12_2_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_2_31
i16x8.sub
local.tee $w2_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
(local.tee $b21_2_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_2_0
i16x8.sub
local.tee $w3_2_0
i32x4.dot_i16x8_s
local.get $x3_1
(local.tee $b21_2_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_2_1
i16x8.sub
local.tee $w3_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
(local.tee $b21_2_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_2_2
i16x8.sub
local.tee $w3_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
(local.tee $b21_2_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_2_3
i16x8.sub
local.tee $w3_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
(local.tee $b21_2_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_2_4
i16x8.sub
local.tee $w3_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
(local.tee $b21_2_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_2_5
i16x8.sub
local.tee $w3_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
(local.tee $b21_2_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_2_6
i16x8.sub
local.tee $w3_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
(local.tee $b21_2_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_2_7
i16x8.sub
local.tee $w3_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
(local.tee $b21_2_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_2_8
i16x8.sub
local.tee $w3_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
(local.tee $b21_2_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_2_9
i16x8.sub
local.tee $w3_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
(local.tee $b21_2_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_2_10
i16x8.sub
local.tee $w3_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
(local.tee $b21_2_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_2_11
i16x8.sub
local.tee $w3_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
(local.tee $b21_2_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_2_12
i16x8.sub
local.tee $w3_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
(local.tee $b21_2_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_2_13
i16x8.sub
local.tee $w3_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
(local.tee $b21_2_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_2_14
i16x8.sub
local.tee $w3_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
(local.tee $b21_2_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_2_15
i16x8.sub
local.tee $w3_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
(local.tee $b21_2_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_2_16
i16x8.sub
local.tee $w3_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
(local.tee $b21_2_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_2_17
i16x8.sub
local.tee $w3_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
(local.tee $b21_2_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_2_18
i16x8.sub
local.tee $w3_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
(local.tee $b21_2_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_2_19
i16x8.sub
local.tee $w3_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
(local.tee $b21_2_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_2_20
i16x8.sub
local.tee $w3_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
(local.tee $b21_2_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_2_21
i16x8.sub
local.tee $w3_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
(local.tee $b21_2_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_2_22
i16x8.sub
local.tee $w3_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
(local.tee $b21_2_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_2_23
i16x8.sub
local.tee $w3_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
(local.tee $b21_2_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_2_24
i16x8.sub
local.tee $w3_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
(local.tee $b21_2_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_2_25
i16x8.sub
local.tee $w3_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
(local.tee $b21_2_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_2_26
i16x8.sub
local.tee $w3_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
(local.tee $b21_2_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_2_27
i16x8.sub
local.tee $w3_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
(local.tee $b21_2_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_2_28
i16x8.sub
local.tee $w3_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
(local.tee $b21_2_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_2_29
i16x8.sub
local.tee $w3_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
(local.tee $b21_2_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_2_30
i16x8.sub
local.tee $w3_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
(local.tee $b21_2_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_2_31
i16x8.sub
local.tee $w3_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_2_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w1_2_0
local.get $b12_2_0
i16x8.add
local.tee $w5_2_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w1_2_1
local.get $b12_2_1
i16x8.add
local.tee $w5_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w1_2_2
local.get $b12_2_2
i16x8.add
local.tee $w5_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w1_2_3
local.get $b12_2_3
i16x8.add
local.tee $w5_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w1_2_4
local.get $b12_2_4
i16x8.add
local.tee $w5_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w1_2_5
local.get $b12_2_5
i16x8.add
local.tee $w5_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w1_2_6
local.get $b12_2_6
i16x8.add
local.tee $w5_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w1_2_7
local.get $b12_2_7
i16x8.add
local.tee $w5_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w1_2_8
local.get $b12_2_8
i16x8.add
local.tee $w5_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w1_2_9
local.get $b12_2_9
i16x8.add
local.tee $w5_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w1_2_10
local.get $b12_2_10
i16x8.add
local.tee $w5_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w1_2_11
local.get $b12_2_11
i16x8.add
local.tee $w5_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w1_2_12
local.get $b12_2_12
i16x8.add
local.tee $w5_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w1_2_13
local.get $b12_2_13
i16x8.add
local.tee $w5_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w1_2_14
local.get $b12_2_14
i16x8.add
local.tee $w5_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w1_2_15
local.get $b12_2_15
i16x8.add
local.tee $w5_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w1_2_16
local.get $b12_2_16
i16x8.add
local.tee $w5_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w1_2_17
local.get $b12_2_17
i16x8.add
local.tee $w5_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w1_2_18
local.get $b12_2_18
i16x8.add
local.tee $w5_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w1_2_19
local.get $b12_2_19
i16x8.add
local.tee $w5_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w1_2_20
local.get $b12_2_20
i16x8.add
local.tee $w5_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w1_2_21
local.get $b12_2_21
i16x8.add
local.tee $w5_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w1_2_22
local.get $b12_2_22
i16x8.add
local.tee $w5_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w1_2_23
local.get $b12_2_23
i16x8.add
local.tee $w5_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w1_2_24
local.get $b12_2_24
i16x8.add
local.tee $w5_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w1_2_25
local.get $b12_2_25
i16x8.add
local.tee $w5_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w1_2_26
local.get $b12_2_26
i16x8.add
local.tee $w5_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w1_2_27
local.get $b12_2_27
i16x8.add
local.tee $w5_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w1_2_28
local.get $b12_2_28
i16x8.add
local.tee $w5_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w1_2_29
local.get $b12_2_29
i16x8.add
local.tee $w5_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w1_2_30
local.get $b12_2_30
i16x8.add
local.tee $w5_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w1_2_31
local.get $b12_2_31
i16x8.add
local.tee $w5_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $b21_2_0
local.get $w4_2_0
i16x8.add
local.tee $w6_2_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $b21_2_1
local.get $w4_2_1
i16x8.add
local.tee $w6_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $b21_2_2
local.get $w4_2_2
i16x8.add
local.tee $w6_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $b21_2_3
local.get $w4_2_3
i16x8.add
local.tee $w6_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $b21_2_4
local.get $w4_2_4
i16x8.add
local.tee $w6_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $b21_2_5
local.get $w4_2_5
i16x8.add
local.tee $w6_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $b21_2_6
local.get $w4_2_6
i16x8.add
local.tee $w6_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $b21_2_7
local.get $w4_2_7
i16x8.add
local.tee $w6_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $b21_2_8
local.get $w4_2_8
i16x8.add
local.tee $w6_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $b21_2_9
local.get $w4_2_9
i16x8.add
local.tee $w6_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $b21_2_10
local.get $w4_2_10
i16x8.add
local.tee $w6_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $b21_2_11
local.get $w4_2_11
i16x8.add
local.tee $w6_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $b21_2_12
local.get $w4_2_12
i16x8.add
local.tee $w6_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $b21_2_13
local.get $w4_2_13
i16x8.add
local.tee $w6_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $b21_2_14
local.get $w4_2_14
i16x8.add
local.tee $w6_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $b21_2_15
local.get $w4_2_15
i16x8.add
local.tee $w6_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $b21_2_16
local.get $w4_2_16
i16x8.add
local.tee $w6_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $b21_2_17
local.get $w4_2_17
i16x8.add
local.tee $w6_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $b21_2_18
local.get $w4_2_18
i16x8.add
local.tee $w6_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $b21_2_19
local.get $w4_2_19
i16x8.add
local.tee $w6_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $b21_2_20
local.get $w4_2_20
i16x8.add
local.tee $w6_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $b21_2_21
local.get $w4_2_21
i16x8.add
local.tee $w6_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $b21_2_22
local.get $w4_2_22
i16x8.add
local.tee $w6_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $b21_2_23
local.get $w4_2_23
i16x8.add
local.tee $w6_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $b21_2_24
local.get $w4_2_24
i16x8.add
local.tee $w6_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $b21_2_25
local.get $w4_2_25
i16x8.add
local.tee $w6_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $b21_2_26
local.get $w4_2_26
i16x8.add
local.tee $w6_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $b21_2_27
local.get $w4_2_27
i16x8.add
local.tee $w6_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $b21_2_28
local.get $w4_2_28
i16x8.add
local.tee $w6_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $b21_2_29
local.get $w4_2_29
i16x8.add
local.tee $w6_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $b21_2_30
local.get $w4_2_30
i16x8.add
local.tee $w6_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $b21_2_31
local.get $w4_2_31
i16x8.add
local.tee $w6_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 3))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 3))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 3))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 3))))
local.get $x0_0
(local.tee $w1_3_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_3_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_3_0
i32x4.dot_i16x8_s
local.get $x0_1
(local.tee $w1_3_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_3_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(local.tee $w1_3_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_3_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(local.tee $w1_3_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_3_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(local.tee $w1_3_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_3_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(local.tee $w1_3_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_3_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(local.tee $w1_3_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_3_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(local.tee $w1_3_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_3_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(local.tee $w1_3_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_3_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(local.tee $w1_3_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_3_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(local.tee $w1_3_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_3_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(local.tee $w1_3_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_3_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(local.tee $w1_3_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_3_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(local.tee $w1_3_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_3_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(local.tee $w1_3_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_3_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(local.tee $w1_3_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_3_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(local.tee $w1_3_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_3_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(local.tee $w1_3_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_3_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(local.tee $w1_3_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_3_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(local.tee $w1_3_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_3_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(local.tee $w1_3_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_3_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(local.tee $w1_3_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_3_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(local.tee $w1_3_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_3_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(local.tee $w1_3_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_3_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(local.tee $w1_3_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_3_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(local.tee $w1_3_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_3_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(local.tee $w1_3_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_3_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(local.tee $w1_3_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_3_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(local.tee $w1_3_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_3_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(local.tee $w1_3_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_3_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(local.tee $w1_3_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_3_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(local.tee $w1_3_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_3_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_3_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
(local.tee $b12_3_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_3_0
i16x8.sub
local.tee $w2_3_0
i32x4.dot_i16x8_s
local.get $x2_1
(local.tee $b12_3_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_3_1
i16x8.sub
local.tee $w2_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(local.tee $b12_3_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_3_2
i16x8.sub
local.tee $w2_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(local.tee $b12_3_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_3_3
i16x8.sub
local.tee $w2_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(local.tee $b12_3_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_3_4
i16x8.sub
local.tee $w2_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(local.tee $b12_3_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_3_5
i16x8.sub
local.tee $w2_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(local.tee $b12_3_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_3_6
i16x8.sub
local.tee $w2_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(local.tee $b12_3_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_3_7
i16x8.sub
local.tee $w2_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(local.tee $b12_3_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_3_8
i16x8.sub
local.tee $w2_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(local.tee $b12_3_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_3_9
i16x8.sub
local.tee $w2_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(local.tee $b12_3_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_3_10
i16x8.sub
local.tee $w2_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(local.tee $b12_3_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_3_11
i16x8.sub
local.tee $w2_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(local.tee $b12_3_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_3_12
i16x8.sub
local.tee $w2_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(local.tee $b12_3_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_3_13
i16x8.sub
local.tee $w2_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(local.tee $b12_3_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_3_14
i16x8.sub
local.tee $w2_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(local.tee $b12_3_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_3_15
i16x8.sub
local.tee $w2_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(local.tee $b12_3_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_3_16
i16x8.sub
local.tee $w2_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(local.tee $b12_3_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_3_17
i16x8.sub
local.tee $w2_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(local.tee $b12_3_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_3_18
i16x8.sub
local.tee $w2_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(local.tee $b12_3_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_3_19
i16x8.sub
local.tee $w2_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(local.tee $b12_3_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_3_20
i16x8.sub
local.tee $w2_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(local.tee $b12_3_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_3_21
i16x8.sub
local.tee $w2_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(local.tee $b12_3_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_3_22
i16x8.sub
local.tee $w2_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(local.tee $b12_3_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_3_23
i16x8.sub
local.tee $w2_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(local.tee $b12_3_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_3_24
i16x8.sub
local.tee $w2_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(local.tee $b12_3_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_3_25
i16x8.sub
local.tee $w2_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(local.tee $b12_3_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_3_26
i16x8.sub
local.tee $w2_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(local.tee $b12_3_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_3_27
i16x8.sub
local.tee $w2_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(local.tee $b12_3_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_3_28
i16x8.sub
local.tee $w2_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(local.tee $b12_3_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_3_29
i16x8.sub
local.tee $w2_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(local.tee $b12_3_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_3_30
i16x8.sub
local.tee $w2_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(local.tee $b12_3_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_3_31
i16x8.sub
local.tee $w2_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
(local.tee $b21_3_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_3_0
i16x8.sub
local.tee $w3_3_0
i32x4.dot_i16x8_s
local.get $x3_1
(local.tee $b21_3_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_3_1
i16x8.sub
local.tee $w3_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
(local.tee $b21_3_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_3_2
i16x8.sub
local.tee $w3_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
(local.tee $b21_3_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_3_3
i16x8.sub
local.tee $w3_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
(local.tee $b21_3_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_3_4
i16x8.sub
local.tee $w3_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
(local.tee $b21_3_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_3_5
i16x8.sub
local.tee $w3_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
(local.tee $b21_3_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_3_6
i16x8.sub
local.tee $w3_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
(local.tee $b21_3_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_3_7
i16x8.sub
local.tee $w3_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
(local.tee $b21_3_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_3_8
i16x8.sub
local.tee $w3_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
(local.tee $b21_3_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_3_9
i16x8.sub
local.tee $w3_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
(local.tee $b21_3_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_3_10
i16x8.sub
local.tee $w3_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
(local.tee $b21_3_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_3_11
i16x8.sub
local.tee $w3_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
(local.tee $b21_3_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_3_12
i16x8.sub
local.tee $w3_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
(local.tee $b21_3_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_3_13
i16x8.sub
local.tee $w3_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
(local.tee $b21_3_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_3_14
i16x8.sub
local.tee $w3_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
(local.tee $b21_3_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_3_15
i16x8.sub
local.tee $w3_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
(local.tee $b21_3_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_3_16
i16x8.sub
local.tee $w3_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
(local.tee $b21_3_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_3_17
i16x8.sub
local.tee $w3_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
(local.tee $b21_3_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_3_18
i16x8.sub
local.tee $w3_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
(local.tee $b21_3_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_3_19
i16x8.sub
local.tee $w3_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
(local.tee $b21_3_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_3_20
i16x8.sub
local.tee $w3_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
(local.tee $b21_3_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_3_21
i16x8.sub
local.tee $w3_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
(local.tee $b21_3_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_3_22
i16x8.sub
local.tee $w3_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
(local.tee $b21_3_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_3_23
i16x8.sub
local.tee $w3_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
(local.tee $b21_3_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_3_24
i16x8.sub
local.tee $w3_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
(local.tee $b21_3_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_3_25
i16x8.sub
local.tee $w3_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
(local.tee $b21_3_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_3_26
i16x8.sub
local.tee $w3_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
(local.tee $b21_3_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_3_27
i16x8.sub
local.tee $w3_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
(local.tee $b21_3_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_3_28
i16x8.sub
local.tee $w3_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
(local.tee $b21_3_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_3_29
i16x8.sub
local.tee $w3_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
(local.tee $b21_3_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_3_30
i16x8.sub
local.tee $w3_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
(local.tee $b21_3_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_3_31
i16x8.sub
local.tee $w3_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_3_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w1_3_0
local.get $b12_3_0
i16x8.add
local.tee $w5_3_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w1_3_1
local.get $b12_3_1
i16x8.add
local.tee $w5_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w1_3_2
local.get $b12_3_2
i16x8.add
local.tee $w5_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w1_3_3
local.get $b12_3_3
i16x8.add
local.tee $w5_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w1_3_4
local.get $b12_3_4
i16x8.add
local.tee $w5_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w1_3_5
local.get $b12_3_5
i16x8.add
local.tee $w5_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w1_3_6
local.get $b12_3_6
i16x8.add
local.tee $w5_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w1_3_7
local.get $b12_3_7
i16x8.add
local.tee $w5_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w1_3_8
local.get $b12_3_8
i16x8.add
local.tee $w5_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w1_3_9
local.get $b12_3_9
i16x8.add
local.tee $w5_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w1_3_10
local.get $b12_3_10
i16x8.add
local.tee $w5_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w1_3_11
local.get $b12_3_11
i16x8.add
local.tee $w5_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w1_3_12
local.get $b12_3_12
i16x8.add
local.tee $w5_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w1_3_13
local.get $b12_3_13
i16x8.add
local.tee $w5_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w1_3_14
local.get $b12_3_14
i16x8.add
local.tee $w5_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w1_3_15
local.get $b12_3_15
i16x8.add
local.tee $w5_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w1_3_16
local.get $b12_3_16
i16x8.add
local.tee $w5_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w1_3_17
local.get $b12_3_17
i16x8.add
local.tee $w5_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w1_3_18
local.get $b12_3_18
i16x8.add
local.tee $w5_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w1_3_19
local.get $b12_3_19
i16x8.add
local.tee $w5_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w1_3_20
local.get $b12_3_20
i16x8.add
local.tee $w5_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w1_3_21
local.get $b12_3_21
i16x8.add
local.tee $w5_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w1_3_22
local.get $b12_3_22
i16x8.add
local.tee $w5_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w1_3_23
local.get $b12_3_23
i16x8.add
local.tee $w5_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w1_3_24
local.get $b12_3_24
i16x8.add
local.tee $w5_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w1_3_25
local.get $b12_3_25
i16x8.add
local.tee $w5_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w1_3_26
local.get $b12_3_26
i16x8.add
local.tee $w5_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w1_3_27
local.get $b12_3_27
i16x8.add
local.tee $w5_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w1_3_28
local.get $b12_3_28
i16x8.add
local.tee $w5_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w1_3_29
local.get $b12_3_29
i16x8.add
local.tee $w5_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w1_3_30
local.get $b12_3_30
i16x8.add
local.tee $w5_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w1_3_31
local.get $b12_3_31
i16x8.add
local.tee $w5_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $b21_3_0
local.get $w4_3_0
i16x8.add
local.tee $w6_3_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $b21_3_1
local.get $w4_3_1
i16x8.add
local.tee $w6_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $b21_3_2
local.get $w4_3_2
i16x8.add
local.tee $w6_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $b21_3_3
local.get $w4_3_3
i16x8.add
local.tee $w6_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $b21_3_4
local.get $w4_3_4
i16x8.add
local.tee $w6_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $b21_3_5
local.get $w4_3_5
i16x8.add
local.tee $w6_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $b21_3_6
local.get $w4_3_6
i16x8.add
local.tee $w6_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $b21_3_7
local.get $w4_3_7
i16x8.add
local.tee $w6_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $b21_3_8
local.get $w4_3_8
i16x8.add
local.tee $w6_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $b21_3_9
local.get $w4_3_9
i16x8.add
local.tee $w6_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $b21_3_10
local.get $w4_3_10
i16x8.add
local.tee $w6_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $b21_3_11
local.get $w4_3_11
i16x8.add
local.tee $w6_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $b21_3_12
local.get $w4_3_12
i16x8.add
local.tee $w6_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $b21_3_13
local.get $w4_3_13
i16x8.add
local.tee $w6_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $b21_3_14
local.get $w4_3_14
i16x8.add
local.tee $w6_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $b21_3_15
local.get $w4_3_15
i16x8.add
local.tee $w6_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $b21_3_16
local.get $w4_3_16
i16x8.add
local.tee $w6_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $b21_3_17
local.get $w4_3_17
i16x8.add
local.tee $w6_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $b21_3_18
local.get $w4_3_18
i16x8.add
local.tee $w6_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $b21_3_19
local.get $w4_3_19
i16x8.add
local.tee $w6_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $b21_3_20
local.get $w4_3_20
i16x8.add
local.tee $w6_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $b21_3_21
local.get $w4_3_21
i16x8.add
local.tee $w6_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $b21_3_22
local.get $w4_3_22
i16x8.add
local.tee $w6_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $b21_3_23
local.get $w4_3_23
i16x8.add
local.tee $w6_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $b21_3_24
local.get $w4_3_24
i16x8.add
local.tee $w6_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $b21_3_25
local.get $w4_3_25
i16x8.add
local.tee $w6_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $b21_3_26
local.get $w4_3_26
i16x8.add
local.tee $w6_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $b21_3_27
local.get $w4_3_27
i16x8.add
local.tee $w6_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $b21_3_28
local.get $w4_3_28
i16x8.add
local.tee $w6_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $b21_3_29
local.get $w4_3_29
i16x8.add
local.tee $w6_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $b21_3_30
local.get $w4_3_30
i16x8.add
local.tee $w6_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $b21_3_31
local.get $w4_3_31
i16x8.add
local.tee $w6_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 4))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 4))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 4))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 4))))
local.get $x0_0
(local.tee $w1_4_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_4_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_4_0
i32x4.dot_i16x8_s
local.get $x0_1
(local.tee $w1_4_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_4_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(local.tee $w1_4_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_4_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(local.tee $w1_4_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_4_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(local.tee $w1_4_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_4_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(local.tee $w1_4_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_4_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(local.tee $w1_4_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_4_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(local.tee $w1_4_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_4_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(local.tee $w1_4_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_4_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(local.tee $w1_4_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_4_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(local.tee $w1_4_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_4_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(local.tee $w1_4_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_4_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(local.tee $w1_4_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_4_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(local.tee $w1_4_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_4_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(local.tee $w1_4_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_4_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(local.tee $w1_4_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_4_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(local.tee $w1_4_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_4_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(local.tee $w1_4_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_4_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(local.tee $w1_4_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_4_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(local.tee $w1_4_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_4_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(local.tee $w1_4_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_4_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(local.tee $w1_4_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_4_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(local.tee $w1_4_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_4_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(local.tee $w1_4_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_4_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(local.tee $w1_4_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_4_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(local.tee $w1_4_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_4_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(local.tee $w1_4_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_4_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(local.tee $w1_4_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_4_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(local.tee $w1_4_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_4_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(local.tee $w1_4_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_4_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(local.tee $w1_4_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_4_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(local.tee $w1_4_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_4_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_4_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
(local.tee $b12_4_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_4_0
i16x8.sub
local.tee $w2_4_0
i32x4.dot_i16x8_s
local.get $x2_1
(local.tee $b12_4_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_4_1
i16x8.sub
local.tee $w2_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(local.tee $b12_4_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_4_2
i16x8.sub
local.tee $w2_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(local.tee $b12_4_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_4_3
i16x8.sub
local.tee $w2_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(local.tee $b12_4_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_4_4
i16x8.sub
local.tee $w2_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(local.tee $b12_4_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_4_5
i16x8.sub
local.tee $w2_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(local.tee $b12_4_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_4_6
i16x8.sub
local.tee $w2_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(local.tee $b12_4_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_4_7
i16x8.sub
local.tee $w2_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(local.tee $b12_4_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_4_8
i16x8.sub
local.tee $w2_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(local.tee $b12_4_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_4_9
i16x8.sub
local.tee $w2_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(local.tee $b12_4_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_4_10
i16x8.sub
local.tee $w2_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(local.tee $b12_4_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_4_11
i16x8.sub
local.tee $w2_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(local.tee $b12_4_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_4_12
i16x8.sub
local.tee $w2_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(local.tee $b12_4_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_4_13
i16x8.sub
local.tee $w2_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(local.tee $b12_4_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_4_14
i16x8.sub
local.tee $w2_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(local.tee $b12_4_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_4_15
i16x8.sub
local.tee $w2_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(local.tee $b12_4_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_4_16
i16x8.sub
local.tee $w2_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(local.tee $b12_4_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_4_17
i16x8.sub
local.tee $w2_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(local.tee $b12_4_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_4_18
i16x8.sub
local.tee $w2_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(local.tee $b12_4_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_4_19
i16x8.sub
local.tee $w2_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(local.tee $b12_4_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_4_20
i16x8.sub
local.tee $w2_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(local.tee $b12_4_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_4_21
i16x8.sub
local.tee $w2_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(local.tee $b12_4_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_4_22
i16x8.sub
local.tee $w2_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(local.tee $b12_4_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_4_23
i16x8.sub
local.tee $w2_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(local.tee $b12_4_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_4_24
i16x8.sub
local.tee $w2_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(local.tee $b12_4_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_4_25
i16x8.sub
local.tee $w2_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(local.tee $b12_4_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_4_26
i16x8.sub
local.tee $w2_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(local.tee $b12_4_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_4_27
i16x8.sub
local.tee $w2_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(local.tee $b12_4_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_4_28
i16x8.sub
local.tee $w2_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(local.tee $b12_4_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_4_29
i16x8.sub
local.tee $w2_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(local.tee $b12_4_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_4_30
i16x8.sub
local.tee $w2_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(local.tee $b12_4_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_4_31
i16x8.sub
local.tee $w2_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
(local.tee $b21_4_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_4_0
i16x8.sub
local.tee $w3_4_0
i32x4.dot_i16x8_s
local.get $x3_1
(local.tee $b21_4_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_4_1
i16x8.sub
local.tee $w3_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
(local.tee $b21_4_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_4_2
i16x8.sub
local.tee $w3_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
(local.tee $b21_4_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_4_3
i16x8.sub
local.tee $w3_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
(local.tee $b21_4_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_4_4
i16x8.sub
local.tee $w3_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
(local.tee $b21_4_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_4_5
i16x8.sub
local.tee $w3_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
(local.tee $b21_4_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_4_6
i16x8.sub
local.tee $w3_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
(local.tee $b21_4_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_4_7
i16x8.sub
local.tee $w3_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
(local.tee $b21_4_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_4_8
i16x8.sub
local.tee $w3_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
(local.tee $b21_4_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_4_9
i16x8.sub
local.tee $w3_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
(local.tee $b21_4_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_4_10
i16x8.sub
local.tee $w3_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
(local.tee $b21_4_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_4_11
i16x8.sub
local.tee $w3_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
(local.tee $b21_4_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_4_12
i16x8.sub
local.tee $w3_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
(local.tee $b21_4_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_4_13
i16x8.sub
local.tee $w3_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
(local.tee $b21_4_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_4_14
i16x8.sub
local.tee $w3_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
(local.tee $b21_4_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_4_15
i16x8.sub
local.tee $w3_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
(local.tee $b21_4_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_4_16
i16x8.sub
local.tee $w3_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
(local.tee $b21_4_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_4_17
i16x8.sub
local.tee $w3_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
(local.tee $b21_4_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_4_18
i16x8.sub
local.tee $w3_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
(local.tee $b21_4_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_4_19
i16x8.sub
local.tee $w3_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
(local.tee $b21_4_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_4_20
i16x8.sub
local.tee $w3_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
(local.tee $b21_4_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_4_21
i16x8.sub
local.tee $w3_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
(local.tee $b21_4_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_4_22
i16x8.sub
local.tee $w3_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
(local.tee $b21_4_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_4_23
i16x8.sub
local.tee $w3_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
(local.tee $b21_4_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_4_24
i16x8.sub
local.tee $w3_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
(local.tee $b21_4_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_4_25
i16x8.sub
local.tee $w3_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
(local.tee $b21_4_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_4_26
i16x8.sub
local.tee $w3_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
(local.tee $b21_4_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_4_27
i16x8.sub
local.tee $w3_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
(local.tee $b21_4_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_4_28
i16x8.sub
local.tee $w3_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
(local.tee $b21_4_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_4_29
i16x8.sub
local.tee $w3_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
(local.tee $b21_4_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_4_30
i16x8.sub
local.tee $w3_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
(local.tee $b21_4_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_4_31
i16x8.sub
local.tee $w3_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_4_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w1_4_0
local.get $b12_4_0
i16x8.add
local.tee $w5_4_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w1_4_1
local.get $b12_4_1
i16x8.add
local.tee $w5_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w1_4_2
local.get $b12_4_2
i16x8.add
local.tee $w5_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w1_4_3
local.get $b12_4_3
i16x8.add
local.tee $w5_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w1_4_4
local.get $b12_4_4
i16x8.add
local.tee $w5_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w1_4_5
local.get $b12_4_5
i16x8.add
local.tee $w5_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w1_4_6
local.get $b12_4_6
i16x8.add
local.tee $w5_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w1_4_7
local.get $b12_4_7
i16x8.add
local.tee $w5_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w1_4_8
local.get $b12_4_8
i16x8.add
local.tee $w5_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w1_4_9
local.get $b12_4_9
i16x8.add
local.tee $w5_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w1_4_10
local.get $b12_4_10
i16x8.add
local.tee $w5_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w1_4_11
local.get $b12_4_11
i16x8.add
local.tee $w5_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w1_4_12
local.get $b12_4_12
i16x8.add
local.tee $w5_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w1_4_13
local.get $b12_4_13
i16x8.add
local.tee $w5_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w1_4_14
local.get $b12_4_14
i16x8.add
local.tee $w5_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w1_4_15
local.get $b12_4_15
i16x8.add
local.tee $w5_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w1_4_16
local.get $b12_4_16
i16x8.add
local.tee $w5_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w1_4_17
local.get $b12_4_17
i16x8.add
local.tee $w5_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w1_4_18
local.get $b12_4_18
i16x8.add
local.tee $w5_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w1_4_19
local.get $b12_4_19
i16x8.add
local.tee $w5_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w1_4_20
local.get $b12_4_20
i16x8.add
local.tee $w5_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w1_4_21
local.get $b12_4_21
i16x8.add
local.tee $w5_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w1_4_22
local.get $b12_4_22
i16x8.add
local.tee $w5_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w1_4_23
local.get $b12_4_23
i16x8.add
local.tee $w5_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w1_4_24
local.get $b12_4_24
i16x8.add
local.tee $w5_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w1_4_25
local.get $b12_4_25
i16x8.add
local.tee $w5_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w1_4_26
local.get $b12_4_26
i16x8.add
local.tee $w5_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w1_4_27
local.get $b12_4_27
i16x8.add
local.tee $w5_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w1_4_28
local.get $b12_4_28
i16x8.add
local.tee $w5_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w1_4_29
local.get $b12_4_29
i16x8.add
local.tee $w5_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w1_4_30
local.get $b12_4_30
i16x8.add
local.tee $w5_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w1_4_31
local.get $b12_4_31
i16x8.add
local.tee $w5_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $b21_4_0
local.get $w4_4_0
i16x8.add
local.tee $w6_4_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $b21_4_1
local.get $w4_4_1
i16x8.add
local.tee $w6_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $b21_4_2
local.get $w4_4_2
i16x8.add
local.tee $w6_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $b21_4_3
local.get $w4_4_3
i16x8.add
local.tee $w6_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $b21_4_4
local.get $w4_4_4
i16x8.add
local.tee $w6_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $b21_4_5
local.get $w4_4_5
i16x8.add
local.tee $w6_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $b21_4_6
local.get $w4_4_6
i16x8.add
local.tee $w6_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $b21_4_7
local.get $w4_4_7
i16x8.add
local.tee $w6_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $b21_4_8
local.get $w4_4_8
i16x8.add
local.tee $w6_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $b21_4_9
local.get $w4_4_9
i16x8.add
local.tee $w6_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $b21_4_10
local.get $w4_4_10
i16x8.add
local.tee $w6_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $b21_4_11
local.get $w4_4_11
i16x8.add
local.tee $w6_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $b21_4_12
local.get $w4_4_12
i16x8.add
local.tee $w6_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $b21_4_13
local.get $w4_4_13
i16x8.add
local.tee $w6_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $b21_4_14
local.get $w4_4_14
i16x8.add
local.tee $w6_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $b21_4_15
local.get $w4_4_15
i16x8.add
local.tee $w6_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $b21_4_16
local.get $w4_4_16
i16x8.add
local.tee $w6_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $b21_4_17
local.get $w4_4_17
i16x8.add
local.tee $w6_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $b21_4_18
local.get $w4_4_18
i16x8.add
local.tee $w6_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $b21_4_19
local.get $w4_4_19
i16x8.add
local.tee $w6_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $b21_4_20
local.get $w4_4_20
i16x8.add
local.tee $w6_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $b21_4_21
local.get $w4_4_21
i16x8.add
local.tee $w6_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $b21_4_22
local.get $w4_4_22
i16x8.add
local.tee $w6_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $b21_4_23
local.get $w4_4_23
i16x8.add
local.tee $w6_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $b21_4_24
local.get $w4_4_24
i16x8.add
local.tee $w6_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $b21_4_25
local.get $w4_4_25
i16x8.add
local.tee $w6_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $b21_4_26
local.get $w4_4_26
i16x8.add
local.tee $w6_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $b21_4_27
local.get $w4_4_27
i16x8.add
local.tee $w6_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $b21_4_28
local.get $w4_4_28
i16x8.add
local.tee $w6_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $b21_4_29
local.get $w4_4_29
i16x8.add
local.tee $w6_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $b21_4_30
local.get $w4_4_30
i16x8.add
local.tee $w6_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $b21_4_31
local.get $w4_4_31
i16x8.add
local.tee $w6_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64
))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 5))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 5))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 5))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 5))))
local.get $x0_0
(local.tee $w1_5_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_5_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_5_0
i32x4.dot_i16x8_s
local.get $x0_1
(local.tee $w1_5_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_5_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(local.tee $w1_5_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_5_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(local.tee $w1_5_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_5_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(local.tee $w1_5_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_5_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(local.tee $w1_5_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_5_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(local.tee $w1_5_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_5_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(local.tee $w1_5_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_5_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(local.tee $w1_5_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_5_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(local.tee $w1_5_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_5_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(local.tee $w1_5_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_5_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(local.tee $w1_5_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_5_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(local.tee $w1_5_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_5_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(local.tee $w1_5_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_5_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(local.tee $w1_5_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_5_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(local.tee $w1_5_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_5_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(local.tee $w1_5_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_5_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(local.tee $w1_5_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_5_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(local.tee $w1_5_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_5_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(local.tee $w1_5_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_5_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(local.tee $w1_5_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_5_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(local.tee $w1_5_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_5_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(local.tee $w1_5_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_5_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(local.tee $w1_5_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_5_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(local.tee $w1_5_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_5_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(local.tee $w1_5_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_5_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(local.tee $w1_5_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_5_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(local.tee $w1_5_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_5_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(local.tee $w1_5_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_5_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(local.tee $w1_5_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_5_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(local.tee $w1_5_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_5_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(local.tee $w1_5_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_5_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_5_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
(local.tee $b12_5_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_5_0
i16x8.sub
local.tee $w2_5_0
i32x4.dot_i16x8_s
local.get $x2_1
(local.tee $b12_5_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_5_1
i16x8.sub
local.tee $w2_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(local.tee $b12_5_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_5_2
i16x8.sub
local.tee $w2_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(local.tee $b12_5_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_5_3
i16x8.sub
local.tee $w2_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(local.tee $b12_5_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_5_4
i16x8.sub
local.tee $w2_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(local.tee $b12_5_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_5_5
i16x8.sub
local.tee $w2_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(local.tee $b12_5_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_5_6
i16x8.sub
local.tee $w2_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(local.tee $b12_5_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_5_7
i16x8.sub
local.tee $w2_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(local.tee $b12_5_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_5_8
i16x8.sub
local.tee $w2_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(local.tee $b12_5_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_5_9
i16x8.sub
local.tee $w2_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(local.tee $b12_5_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_5_10
i16x8.sub
local.tee $w2_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(local.tee $b12_5_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_5_11
i16x8.sub
local.tee $w2_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(local.tee $b12_5_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_5_12
i16x8.sub
local.tee $w2_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(local.tee $b12_5_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_5_13
i16x8.sub
local.tee $w2_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(local.tee $b12_5_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_5_14
i16x8.sub
local.tee $w2_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(local.tee $b12_5_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_5_15
i16x8.sub
local.tee $w2_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(local.tee $b12_5_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_5_16
i16x8.sub
local.tee $w2_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(local.tee $b12_5_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_5_17
i16x8.sub
local.tee $w2_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(local.tee $b12_5_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_5_18
i16x8.sub
local.tee $w2_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(local.tee $b12_5_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_5_19
i16x8.sub
local.tee $w2_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(local.tee $b12_5_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_5_20
i16x8.sub
local.tee $w2_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(local.tee $b12_5_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_5_21
i16x8.sub
local.tee $w2_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(local.tee $b12_5_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_5_22
i16x8.sub
local.tee $w2_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(local.tee $b12_5_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_5_23
i16x8.sub
local.tee $w2_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(local.tee $b12_5_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_5_24
i16x8.sub
local.tee $w2_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(local.tee $b12_5_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_5_25
i16x8.sub
local.tee $w2_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(local.tee $b12_5_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_5_26
i16x8.sub
local.tee $w2_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(local.tee $b12_5_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_5_27
i16x8.sub
local.tee $w2_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(local.tee $b12_5_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_5_28
i16x8.sub
local.tee $w2_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(local.tee $b12_5_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_5_29
i16x8.sub
local.tee $w2_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(local.tee $b12_5_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_5_30
i16x8.sub
local.tee $w2_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(local.tee $b12_5_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_5_31
i16x8.sub
local.tee $w2_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
(local.tee $b21_5_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_5_0
i16x8.sub
local.tee $w3_5_0
i32x4.dot_i16x8_s
local.get $x3_1
(local.tee $b21_5_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_5_1
i16x8.sub
local.tee $w3_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
(local.tee $b21_5_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_5_2
i16x8.sub
local.tee $w3_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
(local.tee $b21_5_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_5_3
i16x8.sub
local.tee $w3_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
(local.tee $b21_5_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_5_4
i16x8.sub
local.tee $w3_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
(local.tee $b21_5_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_5_5
i16x8.sub
local.tee $w3_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
(local.tee $b21_5_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_5_6
i16x8.sub
local.tee $w3_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
(local.tee $b21_5_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_5_7
i16x8.sub
local.tee $w3_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
(local.tee $b21_5_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_5_8
i16x8.sub
local.tee $w3_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
(local.tee $b21_5_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_5_9
i16x8.sub
local.tee $w3_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
(local.tee $b21_5_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_5_10
i16x8.sub
local.tee $w3_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
(local.tee $b21_5_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_5_11
i16x8.sub
local.tee $w3_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
(local.tee $b21_5_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_5_12
i16x8.sub
local.tee $w3_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
(local.tee $b21_5_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_5_13
i16x8.sub
local.tee $w3_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
(local.tee $b21_5_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_5_14
i16x8.sub
local.tee $w3_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
(local.tee $b21_5_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_5_15
i16x8.sub
local.tee $w3_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
(local.tee $b21_5_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_5_16
i16x8.sub
local.tee $w3_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
(local.tee $b21_5_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_5_17
i16x8.sub
local.tee $w3_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
(local.tee $b21_5_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_5_18
i16x8.sub
local.tee $w3_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
(local.tee $b21_5_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_5_19
i16x8.sub
local.tee $w3_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
(local.tee $b21_5_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_5_20
i16x8.sub
local.tee $w3_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
(local.tee $b21_5_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_5_21
i16x8.sub
local.tee $w3_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
(local.tee $b21_5_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_5_22
i16x8.sub
local.tee $w3_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
(local.tee $b21_5_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_5_23
i16x8.sub
local.tee $w3_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
(local.tee $b21_5_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_5_24
i16x8.sub
local.tee $w3_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
(local.tee $b21_5_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_5_25
i16x8.sub
local.tee $w3_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
(local.tee $b21_5_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_5_26
i16x8.sub
local.tee $w3_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
(local.tee $b21_5_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_5_27
i16x8.sub
local.tee $w3_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
(local.tee $b21_5_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_5_28
i16x8.sub
local.tee $w3_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
(local.tee $b21_5_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_5_29
i16x8.sub
local.tee $w3_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
(local.tee $b21_5_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_5_30
i16x8.sub
local.tee $w3_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
(local.tee $b21_5_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_5_31
i16x8.sub
local.tee $w3_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_5_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w1_5_0
local.get $b12_5_0
i16x8.add
local.tee $w5_5_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w1_5_1
local.get $b12_5_1
i16x8.add
local.tee $w5_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w1_5_2
local.get $b12_5_2
i16x8.add
local.tee $w5_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w1_5_3
local.get $b12_5_3
i16x8.add
local.tee $w5_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w1_5_4
local.get $b12_5_4
i16x8.add
local.tee $w5_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w1_5_5
local.get $b12_5_5
i16x8.add
local.tee $w5_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w1_5_6
local.get $b12_5_6
i16x8.add
local.tee $w5_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w1_5_7
local.get $b12_5_7
i16x8.add
local.tee $w5_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w1_5_8
local.get $b12_5_8
i16x8.add
local.tee $w5_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w1_5_9
local.get $b12_5_9
i16x8.add
local.tee $w5_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w1_5_10
local.get $b12_5_10
i16x8.add
local.tee $w5_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w1_5_11
local.get $b12_5_11
i16x8.add
local.tee $w5_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w1_5_12
local.get $b12_5_12
i16x8.add
local.tee $w5_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w1_5_13
local.get $b12_5_13
i16x8.add
local.tee $w5_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w1_5_14
local.get $b12_5_14
i16x8.add
local.tee $w5_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w1_5_15
local.get $b12_5_15
i16x8.add
local.tee $w5_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w1_5_16
local.get $b12_5_16
i16x8.add
local.tee $w5_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w1_5_17
local.get $b12_5_17
i16x8.add
local.tee $w5_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w1_5_18
local.get $b12_5_18
i16x8.add
local.tee $w5_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w1_5_19
local.get $b12_5_19
i16x8.add
local.tee $w5_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w1_5_20
local.get $b12_5_20
i16x8.add
local.tee $w5_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w1_5_21
local.get $b12_5_21
i16x8.add
local.tee $w5_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w1_5_22
local.get $b12_5_22
i16x8.add
local.tee $w5_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w1_5_23
local.get $b12_5_23
i16x8.add
local.tee $w5_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w1_5_24
local.get $b12_5_24
i16x8.add
local.tee $w5_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w1_5_25
local.get $b12_5_25
i16x8.add
local.tee $w5_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w1_5_26
local.get $b12_5_26
i16x8.add
local.tee $w5_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w1_5_27
local.get $b12_5_27
i16x8.add
local.tee $w5_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w1_5_28
local.get $b12_5_28
i16x8.add
local.tee $w5_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w1_5_29
local.get $b12_5_29
i16x8.add
local.tee $w5_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w1_5_30
local.get $b12_5_30
i16x8.add
local.tee $w5_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w1_5_31
local.get $b12_5_31
i16x8.add
local.tee $w5_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $b21_5_0
local.get $w4_5_0
i16x8.add
local.tee $w6_5_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $b21_5_1
local.get $w4_5_1
i16x8.add
local.tee $w6_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $b21_5_2
local.get $w4_5_2
i16x8.add
local.tee $w6_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $b21_5_3
local.get $w4_5_3
i16x8.add
local.tee $w6_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $b21_5_4
local.get $w4_5_4
i16x8.add
local.tee $w6_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $b21_5_5
local.get $w4_5_5
i16x8.add
local.tee $w6_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $b21_5_6
local.get $w4_5_6
i16x8.add
local.tee $w6_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $b21_5_7
local.get $w4_5_7
i16x8.add
local.tee $w6_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $b21_5_8
local.get $w4_5_8
i16x8.add
local.tee $w6_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $b21_5_9
local.get $w4_5_9
i16x8.add
local.tee $w6_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $b21_5_10
local.get $w4_5_10
i16x8.add
local.tee $w6_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $b21_5_11
local.get $w4_5_11
i16x8.add
local.tee $w6_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $b21_5_12
local.get $w4_5_12
i16x8.add
local.tee $w6_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $b21_5_13
local.get $w4_5_13
i16x8.add
local.tee $w6_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $b21_5_14
local.get $w4_5_14
i16x8.add
local.tee $w6_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $b21_5_15
local.get $w4_5_15
i16x8.add
local.tee $w6_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $b21_5_16
local.get $w4_5_16
i16x8.add
local.tee $w6_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $b21_5_17
local.get $w4_5_17
i16x8.add
local.tee $w6_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $b21_5_18
local.get $w4_5_18
i16x8.add
local.tee $w6_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $b21_5_19
local.get $w4_5_19
i16x8.add
local.tee $w6_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $b21_5_20
local.get $w4_5_20
i16x8.add
local.tee $w6_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $b21_5_21
local.get $w4_5_21
i16x8.add
local.tee $w6_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $b21_5_22
local.get $w4_5_22
i16x8.add
local.tee $w6_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $b21_5_23
local.get $w4_5_23
i16x8.add
local.tee $w6_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $b21_5_24
local.get $w4_5_24
i16x8.add
local.tee $w6_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $b21_5_25
local.get $w4_5_25
i16x8.add
local.tee $w6_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $b21_5_26
local.get $w4_5_26
i16x8.add
local.tee $w6_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $b21_5_27
local.get $w4_5_27
i16x8.add
local.tee $w6_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $b21_5_28
local.get $w4_5_28
i16x8.add
local.tee $w6_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $b21_5_29
local.get $w4_5_29
i16x8.add
local.tee $w6_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $b21_5_30
local.get $w4_5_30
i16x8.add
local.tee $w6_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $b21_5_31
local.get $w4_5_31
i16x8.add
local.tee $w6_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80
))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 6))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 6))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 6))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 6))))
local.get $x0_0
(local.tee $w1_6_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_6_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_6_0
i32x4.dot_i16x8_s
local.get $x0_1
(local.tee $w1_6_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_6_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(local.tee $w1_6_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_6_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(local.tee $w1_6_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_6_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(local.tee $w1_6_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_6_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(local.tee $w1_6_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_6_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(local.tee $w1_6_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_6_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(local.tee $w1_6_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_6_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(local.tee $w1_6_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_6_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(local.tee $w1_6_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_6_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(local.tee $w1_6_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_6_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(local.tee $w1_6_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_6_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(local.tee $w1_6_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_6_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(local.tee $w1_6_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_6_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(local.tee $w1_6_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_6_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(local.tee $w1_6_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_6_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(local.tee $w1_6_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_6_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(local.tee $w1_6_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_6_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(local.tee $w1_6_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_6_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(local.tee $w1_6_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_6_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(local.tee $w1_6_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_6_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(local.tee $w1_6_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_6_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(local.tee $w1_6_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_6_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(local.tee $w1_6_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_6_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(local.tee $w1_6_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_6_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(local.tee $w1_6_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_6_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(local.tee $w1_6_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_6_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(local.tee $w1_6_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_6_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(local.tee $w1_6_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_6_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(local.tee $w1_6_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_6_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(local.tee $w1_6_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_6_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(local.tee $w1_6_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_6_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_6_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
(local.tee $b12_6_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_6_0
i16x8.sub
local.tee $w2_6_0
i32x4.dot_i16x8_s
local.get $x2_1
(local.tee $b12_6_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_6_1
i16x8.sub
local.tee $w2_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(local.tee $b12_6_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_6_2
i16x8.sub
local.tee $w2_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(local.tee $b12_6_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_6_3
i16x8.sub
local.tee $w2_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(local.tee $b12_6_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_6_4
i16x8.sub
local.tee $w2_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(local.tee $b12_6_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_6_5
i16x8.sub
local.tee $w2_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(local.tee $b12_6_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_6_6
i16x8.sub
local.tee $w2_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(local.tee $b12_6_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_6_7
i16x8.sub
local.tee $w2_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(local.tee $b12_6_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_6_8
i16x8.sub
local.tee $w2_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(local.tee $b12_6_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_6_9
i16x8.sub
local.tee $w2_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(local.tee $b12_6_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_6_10
i16x8.sub
local.tee $w2_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(local.tee $b12_6_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_6_11
i16x8.sub
local.tee $w2_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(local.tee $b12_6_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_6_12
i16x8.sub
local.tee $w2_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(local.tee $b12_6_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_6_13
i16x8.sub
local.tee $w2_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(local.tee $b12_6_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_6_14
i16x8.sub
local.tee $w2_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(local.tee $b12_6_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_6_15
i16x8.sub
local.tee $w2_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(local.tee $b12_6_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_6_16
i16x8.sub
local.tee $w2_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(local.tee $b12_6_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_6_17
i16x8.sub
local.tee $w2_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(local.tee $b12_6_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_6_18
i16x8.sub
local.tee $w2_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(local.tee $b12_6_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_6_19
i16x8.sub
local.tee $w2_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(local.tee $b12_6_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_6_20
i16x8.sub
local.tee $w2_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(local.tee $b12_6_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_6_21
i16x8.sub
local.tee $w2_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(local.tee $b12_6_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_6_22
i16x8.sub
local.tee $w2_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(local.tee $b12_6_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_6_23
i16x8.sub
local.tee $w2_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(local.tee $b12_6_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_6_24
i16x8.sub
local.tee $w2_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(local.tee $b12_6_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_6_25
i16x8.sub
local.tee $w2_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(local.tee $b12_6_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_6_26
i16x8.sub
local.tee $w2_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(local.tee $b12_6_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_6_27
i16x8.sub
local.tee $w2_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(local.tee $b12_6_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_6_28
i16x8.sub
local.tee $w2_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(local.tee $b12_6_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_6_29
i16x8.sub
local.tee $w2_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(local.tee $b12_6_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_6_30
i16x8.sub
local.tee $w2_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(local.tee $b12_6_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_6_31
i16x8.sub
local.tee $w2_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
(local.tee $b21_6_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_6_0
i16x8.sub
local.tee $w3_6_0
i32x4.dot_i16x8_s
local.get $x3_1
(local.tee $b21_6_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_6_1
i16x8.sub
local.tee $w3_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
(local.tee $b21_6_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_6_2
i16x8.sub
local.tee $w3_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
(local.tee $b21_6_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_6_3
i16x8.sub
local.tee $w3_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
(local.tee $b21_6_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_6_4
i16x8.sub
local.tee $w3_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
(local.tee $b21_6_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_6_5
i16x8.sub
local.tee $w3_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
(local.tee $b21_6_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_6_6
i16x8.sub
local.tee $w3_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
(local.tee $b21_6_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_6_7
i16x8.sub
local.tee $w3_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
(local.tee $b21_6_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_6_8
i16x8.sub
local.tee $w3_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
(local.tee $b21_6_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_6_9
i16x8.sub
local.tee $w3_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
(local.tee $b21_6_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_6_10
i16x8.sub
local.tee $w3_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
(local.tee $b21_6_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_6_11
i16x8.sub
local.tee $w3_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
(local.tee $b21_6_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_6_12
i16x8.sub
local.tee $w3_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
(local.tee $b21_6_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_6_13
i16x8.sub
local.tee $w3_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
(local.tee $b21_6_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_6_14
i16x8.sub
local.tee $w3_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
(local.tee $b21_6_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_6_15
i16x8.sub
local.tee $w3_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
(local.tee $b21_6_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_6_16
i16x8.sub
local.tee $w3_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
(local.tee $b21_6_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_6_17
i16x8.sub
local.tee $w3_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
(local.tee $b21_6_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_6_18
i16x8.sub
local.tee $w3_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
(local.tee $b21_6_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_6_19
i16x8.sub
local.tee $w3_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
(local.tee $b21_6_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_6_20
i16x8.sub
local.tee $w3_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
(local.tee $b21_6_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_6_21
i16x8.sub
local.tee $w3_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
(local.tee $b21_6_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_6_22
i16x8.sub
local.tee $w3_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
(local.tee $b21_6_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_6_23
i16x8.sub
local.tee $w3_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
(local.tee $b21_6_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_6_24
i16x8.sub
local.tee $w3_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
(local.tee $b21_6_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_6_25
i16x8.sub
local.tee $w3_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
(local.tee $b21_6_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_6_26
i16x8.sub
local.tee $w3_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
(local.tee $b21_6_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_6_27
i16x8.sub
local.tee $w3_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
(local.tee $b21_6_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_6_28
i16x8.sub
local.tee $w3_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
(local.tee $b21_6_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_6_29
i16x8.sub
local.tee $w3_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
(local.tee $b21_6_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_6_30
i16x8.sub
local.tee $w3_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
(local.tee $b21_6_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_6_31
i16x8.sub
local.tee $w3_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_6_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w1_6_0
local.get $b12_6_0
i16x8.add
local.tee $w5_6_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w1_6_1
local.get $b12_6_1
i16x8.add
local.tee $w5_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w1_6_2
local.get $b12_6_2
i16x8.add
local.tee $w5_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w1_6_3
local.get $b12_6_3
i16x8.add
local.tee $w5_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w1_6_4
local.get $b12_6_4
i16x8.add
local.tee $w5_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w1_6_5
local.get $b12_6_5
i16x8.add
local.tee $w5_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w1_6_6
local.get $b12_6_6
i16x8.add
local.tee $w5_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w1_6_7
local.get $b12_6_7
i16x8.add
local.tee $w5_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w1_6_8
local.get $b12_6_8
i16x8.add
local.tee $w5_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w1_6_9
local.get $b12_6_9
i16x8.add
local.tee $w5_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w1_6_10
local.get $b12_6_10
i16x8.add
local.tee $w5_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w1_6_11
local.get $b12_6_11
i16x8.add
local.tee $w5_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w1_6_12
local.get $b12_6_12
i16x8.add
local.tee $w5_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w1_6_13
local.get $b12_6_13
i16x8.add
local.tee $w5_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w1_6_14
local.get $b12_6_14
i16x8.add
local.tee $w5_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w1_6_15
local.get $b12_6_15
i16x8.add
local.tee $w5_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w1_6_16
local.get $b12_6_16
i16x8.add
local.tee $w5_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w1_6_17
local.get $b12_6_17
i16x8.add
local.tee $w5_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w1_6_18
local.get $b12_6_18
i16x8.add
local.tee $w5_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w1_6_19
local.get $b12_6_19
i16x8.add
local.tee $w5_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w1_6_20
local.get $b12_6_20
i16x8.add
local.tee $w5_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w1_6_21
local.get $b12_6_21
i16x8.add
local.tee $w5_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w1_6_22
local.get $b12_6_22
i16x8.add
local.tee $w5_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w1_6_23
local.get $b12_6_23
i16x8.add
local.tee $w5_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w1_6_24
local.get $b12_6_24
i16x8.add
local.tee $w5_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w1_6_25
local.get $b12_6_25
i16x8.add
local.tee $w5_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w1_6_26
local.get $b12_6_26
i16x8.add
local.tee $w5_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w1_6_27
local.get $b12_6_27
i16x8.add
local.tee $w5_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w1_6_28
local.get $b12_6_28
i16x8.add
local.tee $w5_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w1_6_29
local.get $b12_6_29
i16x8.add
local.tee $w5_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w1_6_30
local.get $b12_6_30
i16x8.add
local.tee $w5_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w1_6_31
local.get $b12_6_31
i16x8.add
local.tee $w5_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $b21_6_0
local.get $w4_6_0
i16x8.add
local.tee $w6_6_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $b21_6_1
local.get $w4_6_1
i16x8.add
local.tee $w6_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $b21_6_2
local.get $w4_6_2
i16x8.add
local.tee $w6_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $b21_6_3
local.get $w4_6_3
i16x8.add
local.tee $w6_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $b21_6_4
local.get $w4_6_4
i16x8.add
local.tee $w6_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $b21_6_5
local.get $w4_6_5
i16x8.add
local.tee $w6_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $b21_6_6
local.get $w4_6_6
i16x8.add
local.tee $w6_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $b21_6_7
local.get $w4_6_7
i16x8.add
local.tee $w6_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $b21_6_8
local.get $w4_6_8
i16x8.add
local.tee $w6_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $b21_6_9
local.get $w4_6_9
i16x8.add
local.tee $w6_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $b21_6_10
local.get $w4_6_10
i16x8.add
local.tee $w6_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $b21_6_11
local.get $w4_6_11
i16x8.add
local.tee $w6_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $b21_6_12
local.get $w4_6_12
i16x8.add
local.tee $w6_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $b21_6_13
local.get $w4_6_13
i16x8.add
local.tee $w6_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $b21_6_14
local.get $w4_6_14
i16x8.add
local.tee $w6_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $b21_6_15
local.get $w4_6_15
i16x8.add
local.tee $w6_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $b21_6_16
local.get $w4_6_16
i16x8.add
local.tee $w6_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $b21_6_17
local.get $w4_6_17
i16x8.add
local.tee $w6_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $b21_6_18
local.get $w4_6_18
i16x8.add
local.tee $w6_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $b21_6_19
local.get $w4_6_19
i16x8.add
local.tee $w6_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $b21_6_20
local.get $w4_6_20
i16x8.add
local.tee $w6_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $b21_6_21
local.get $w4_6_21
i16x8.add
local.tee $w6_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $b21_6_22
local.get $w4_6_22
i16x8.add
local.tee $w6_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $b21_6_23
local.get $w4_6_23
i16x8.add
local.tee $w6_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $b21_6_24
local.get $w4_6_24
i16x8.add
local.tee $w6_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $b21_6_25
local.get $w4_6_25
i16x8.add
local.tee $w6_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $b21_6_26
local.get $w4_6_26
i16x8.add
local.tee $w6_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $b21_6_27
local.get $w4_6_27
i16x8.add
local.tee $w6_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $b21_6_28
local.get $w4_6_28
i16x8.add
local.tee $w6_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $b21_6_29
local.get $w4_6_29
i16x8.add
local.tee $w6_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $b21_6_30
local.get $w4_6_30
i16x8.add
local.tee $w6_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $b21_6_31
local.get $w4_6_31
i16x8.add
local.tee $w6_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96
))
(local.set $row0 (i32.add (local.get $wp0) (i32.mul (local.get $cols) (i32.const 7))))
(local.set $row1 (i32.add (local.get $wp1) (i32.mul (local.get $cols) (i32.const 7))))
(local.set $row2 (i32.add (local.get $wp2) (i32.mul (local.get $cols) (i32.const 7))))
(local.set $row3 (i32.add (local.get $wp3) (i32.mul (local.get $cols) (i32.const 7))))
local.get $x0_0
(local.tee $w1_7_0 (v128.load8x8_s offset=0 (local.get $row0)))
(local.tee $w4_7_0 (v128.load8x8_s offset=0 (local.get $row3)))
i16x8.add
local.tee $w0_7_0
i32x4.dot_i16x8_s
local.get $x0_1
(local.tee $w1_7_1 (v128.load8x8_s offset=8 (local.get $row0)))
(local.tee $w4_7_1 (v128.load8x8_s offset=8 (local.get $row3)))
i16x8.add
local.tee $w0_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(local.tee $w1_7_2 (v128.load8x8_s offset=16 (local.get $row0)))
(local.tee $w4_7_2 (v128.load8x8_s offset=16 (local.get $row3)))
i16x8.add
local.tee $w0_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(local.tee $w1_7_3 (v128.load8x8_s offset=24 (local.get $row0)))
(local.tee $w4_7_3 (v128.load8x8_s offset=24 (local.get $row3)))
i16x8.add
local.tee $w0_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(local.tee $w1_7_4 (v128.load8x8_s offset=32 (local.get $row0)))
(local.tee $w4_7_4 (v128.load8x8_s offset=32 (local.get $row3)))
i16x8.add
local.tee $w0_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(local.tee $w1_7_5 (v128.load8x8_s offset=40 (local.get $row0)))
(local.tee $w4_7_5 (v128.load8x8_s offset=40 (local.get $row3)))
i16x8.add
local.tee $w0_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(local.tee $w1_7_6 (v128.load8x8_s offset=48 (local.get $row0)))
(local.tee $w4_7_6 (v128.load8x8_s offset=48 (local.get $row3)))
i16x8.add
local.tee $w0_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(local.tee $w1_7_7 (v128.load8x8_s offset=56 (local.get $row0)))
(local.tee $w4_7_7 (v128.load8x8_s offset=56 (local.get $row3)))
i16x8.add
local.tee $w0_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(local.tee $w1_7_8 (v128.load8x8_s offset=64 (local.get $row0)))
(local.tee $w4_7_8 (v128.load8x8_s offset=64 (local.get $row3)))
i16x8.add
local.tee $w0_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(local.tee $w1_7_9 (v128.load8x8_s offset=72 (local.get $row0)))
(local.tee $w4_7_9 (v128.load8x8_s offset=72 (local.get $row3)))
i16x8.add
local.tee $w0_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(local.tee $w1_7_10 (v128.load8x8_s offset=80 (local.get $row0)))
(local.tee $w4_7_10 (v128.load8x8_s offset=80 (local.get $row3)))
i16x8.add
local.tee $w0_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(local.tee $w1_7_11 (v128.load8x8_s offset=88 (local.get $row0)))
(local.tee $w4_7_11 (v128.load8x8_s offset=88 (local.get $row3)))
i16x8.add
local.tee $w0_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(local.tee $w1_7_12 (v128.load8x8_s offset=96 (local.get $row0)))
(local.tee $w4_7_12 (v128.load8x8_s offset=96 (local.get $row3)))
i16x8.add
local.tee $w0_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(local.tee $w1_7_13 (v128.load8x8_s offset=104 (local.get $row0)))
(local.tee $w4_7_13 (v128.load8x8_s offset=104 (local.get $row3)))
i16x8.add
local.tee $w0_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(local.tee $w1_7_14 (v128.load8x8_s offset=112 (local.get $row0)))
(local.tee $w4_7_14 (v128.load8x8_s offset=112 (local.get $row3)))
i16x8.add
local.tee $w0_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(local.tee $w1_7_15 (v128.load8x8_s offset=120 (local.get $row0)))
(local.tee $w4_7_15 (v128.load8x8_s offset=120 (local.get $row3)))
i16x8.add
local.tee $w0_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(local.tee $w1_7_16 (v128.load8x8_s offset=128 (local.get $row0)))
(local.tee $w4_7_16 (v128.load8x8_s offset=128 (local.get $row3)))
i16x8.add
local.tee $w0_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(local.tee $w1_7_17 (v128.load8x8_s offset=136 (local.get $row0)))
(local.tee $w4_7_17 (v128.load8x8_s offset=136 (local.get $row3)))
i16x8.add
local.tee $w0_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(local.tee $w1_7_18 (v128.load8x8_s offset=144 (local.get $row0)))
(local.tee $w4_7_18 (v128.load8x8_s offset=144 (local.get $row3)))
i16x8.add
local.tee $w0_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(local.tee $w1_7_19 (v128.load8x8_s offset=152 (local.get $row0)))
(local.tee $w4_7_19 (v128.load8x8_s offset=152 (local.get $row3)))
i16x8.add
local.tee $w0_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(local.tee $w1_7_20 (v128.load8x8_s offset=160 (local.get $row0)))
(local.tee $w4_7_20 (v128.load8x8_s offset=160 (local.get $row3)))
i16x8.add
local.tee $w0_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(local.tee $w1_7_21 (v128.load8x8_s offset=168 (local.get $row0)))
(local.tee $w4_7_21 (v128.load8x8_s offset=168 (local.get $row3)))
i16x8.add
local.tee $w0_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(local.tee $w1_7_22 (v128.load8x8_s offset=176 (local.get $row0)))
(local.tee $w4_7_22 (v128.load8x8_s offset=176 (local.get $row3)))
i16x8.add
local.tee $w0_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(local.tee $w1_7_23 (v128.load8x8_s offset=184 (local.get $row0)))
(local.tee $w4_7_23 (v128.load8x8_s offset=184 (local.get $row3)))
i16x8.add
local.tee $w0_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(local.tee $w1_7_24 (v128.load8x8_s offset=192 (local.get $row0)))
(local.tee $w4_7_24 (v128.load8x8_s offset=192 (local.get $row3)))
i16x8.add
local.tee $w0_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(local.tee $w1_7_25 (v128.load8x8_s offset=200 (local.get $row0)))
(local.tee $w4_7_25 (v128.load8x8_s offset=200 (local.get $row3)))
i16x8.add
local.tee $w0_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(local.tee $w1_7_26 (v128.load8x8_s offset=208 (local.get $row0)))
(local.tee $w4_7_26 (v128.load8x8_s offset=208 (local.get $row3)))
i16x8.add
local.tee $w0_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(local.tee $w1_7_27 (v128.load8x8_s offset=216 (local.get $row0)))
(local.tee $w4_7_27 (v128.load8x8_s offset=216 (local.get $row3)))
i16x8.add
local.tee $w0_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(local.tee $w1_7_28 (v128.load8x8_s offset=224 (local.get $row0)))
(local.tee $w4_7_28 (v128.load8x8_s offset=224 (local.get $row3)))
i16x8.add
local.tee $w0_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(local.tee $w1_7_29 (v128.load8x8_s offset=232 (local.get $row0)))
(local.tee $w4_7_29 (v128.load8x8_s offset=232 (local.get $row3)))
i16x8.add
local.tee $w0_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(local.tee $w1_7_30 (v128.load8x8_s offset=240 (local.get $row0)))
(local.tee $w4_7_30 (v128.load8x8_s offset=240 (local.get $row3)))
i16x8.add
local.tee $w0_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(local.tee $w1_7_31 (v128.load8x8_s offset=248 (local.get $row0)))
(local.tee $w4_7_31 (v128.load8x8_s offset=248 (local.get $row3)))
i16x8.add
local.tee $w0_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_7_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
(local.tee $b12_7_0 (v128.load8x8_s offset=0 (local.get $row2)))
local.get $w4_7_0
i16x8.sub
local.tee $w2_7_0
i32x4.dot_i16x8_s
local.get $x2_1
(local.tee $b12_7_1 (v128.load8x8_s offset=8 (local.get $row2)))
local.get $w4_7_1
i16x8.sub
local.tee $w2_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(local.tee $b12_7_2 (v128.load8x8_s offset=16 (local.get $row2)))
local.get $w4_7_2
i16x8.sub
local.tee $w2_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(local.tee $b12_7_3 (v128.load8x8_s offset=24 (local.get $row2)))
local.get $w4_7_3
i16x8.sub
local.tee $w2_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(local.tee $b12_7_4 (v128.load8x8_s offset=32 (local.get $row2)))
local.get $w4_7_4
i16x8.sub
local.tee $w2_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(local.tee $b12_7_5 (v128.load8x8_s offset=40 (local.get $row2)))
local.get $w4_7_5
i16x8.sub
local.tee $w2_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(local.tee $b12_7_6 (v128.load8x8_s offset=48 (local.get $row2)))
local.get $w4_7_6
i16x8.sub
local.tee $w2_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(local.tee $b12_7_7 (v128.load8x8_s offset=56 (local.get $row2)))
local.get $w4_7_7
i16x8.sub
local.tee $w2_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(local.tee $b12_7_8 (v128.load8x8_s offset=64 (local.get $row2)))
local.get $w4_7_8
i16x8.sub
local.tee $w2_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(local.tee $b12_7_9 (v128.load8x8_s offset=72 (local.get $row2)))
local.get $w4_7_9
i16x8.sub
local.tee $w2_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(local.tee $b12_7_10 (v128.load8x8_s offset=80 (local.get $row2)))
local.get $w4_7_10
i16x8.sub
local.tee $w2_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(local.tee $b12_7_11 (v128.load8x8_s offset=88 (local.get $row2)))
local.get $w4_7_11
i16x8.sub
local.tee $w2_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(local.tee $b12_7_12 (v128.load8x8_s offset=96 (local.get $row2)))
local.get $w4_7_12
i16x8.sub
local.tee $w2_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(local.tee $b12_7_13 (v128.load8x8_s offset=104 (local.get $row2)))
local.get $w4_7_13
i16x8.sub
local.tee $w2_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(local.tee $b12_7_14 (v128.load8x8_s offset=112 (local.get $row2)))
local.get $w4_7_14
i16x8.sub
local.tee $w2_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(local.tee $b12_7_15 (v128.load8x8_s offset=120 (local.get $row2)))
local.get $w4_7_15
i16x8.sub
local.tee $w2_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(local.tee $b12_7_16 (v128.load8x8_s offset=128 (local.get $row2)))
local.get $w4_7_16
i16x8.sub
local.tee $w2_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(local.tee $b12_7_17 (v128.load8x8_s offset=136 (local.get $row2)))
local.get $w4_7_17
i16x8.sub
local.tee $w2_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(local.tee $b12_7_18 (v128.load8x8_s offset=144 (local.get $row2)))
local.get $w4_7_18
i16x8.sub
local.tee $w2_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(local.tee $b12_7_19 (v128.load8x8_s offset=152 (local.get $row2)))
local.get $w4_7_19
i16x8.sub
local.tee $w2_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(local.tee $b12_7_20 (v128.load8x8_s offset=160 (local.get $row2)))
local.get $w4_7_20
i16x8.sub
local.tee $w2_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(local.tee $b12_7_21 (v128.load8x8_s offset=168 (local.get $row2)))
local.get $w4_7_21
i16x8.sub
local.tee $w2_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(local.tee $b12_7_22 (v128.load8x8_s offset=176 (local.get $row2)))
local.get $w4_7_22
i16x8.sub
local.tee $w2_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(local.tee $b12_7_23 (v128.load8x8_s offset=184 (local.get $row2)))
local.get $w4_7_23
i16x8.sub
local.tee $w2_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(local.tee $b12_7_24 (v128.load8x8_s offset=192 (local.get $row2)))
local.get $w4_7_24
i16x8.sub
local.tee $w2_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(local.tee $b12_7_25 (v128.load8x8_s offset=200 (local.get $row2)))
local.get $w4_7_25
i16x8.sub
local.tee $w2_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(local.tee $b12_7_26 (v128.load8x8_s offset=208 (local.get $row2)))
local.get $w4_7_26
i16x8.sub
local.tee $w2_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(local.tee $b12_7_27 (v128.load8x8_s offset=216 (local.get $row2)))
local.get $w4_7_27
i16x8.sub
local.tee $w2_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(local.tee $b12_7_28 (v128.load8x8_s offset=224 (local.get $row2)))
local.get $w4_7_28
i16x8.sub
local.tee $w2_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(local.tee $b12_7_29 (v128.load8x8_s offset=232 (local.get $row2)))
local.get $w4_7_29
i16x8.sub
local.tee $w2_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(local.tee $b12_7_30 (v128.load8x8_s offset=240 (local.get $row2)))
local.get $w4_7_30
i16x8.sub
local.tee $w2_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(local.tee $b12_7_31 (v128.load8x8_s offset=248 (local.get $row2)))
local.get $w4_7_31
i16x8.sub
local.tee $w2_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
(local.tee $b21_7_0 (v128.load8x8_s offset=0 (local.get $row1)))
local.get $w1_7_0
i16x8.sub
local.tee $w3_7_0
i32x4.dot_i16x8_s
local.get $x3_1
(local.tee $b21_7_1 (v128.load8x8_s offset=8 (local.get $row1)))
local.get $w1_7_1
i16x8.sub
local.tee $w3_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
(local.tee $b21_7_2 (v128.load8x8_s offset=16 (local.get $row1)))
local.get $w1_7_2
i16x8.sub
local.tee $w3_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
(local.tee $b21_7_3 (v128.load8x8_s offset=24 (local.get $row1)))
local.get $w1_7_3
i16x8.sub
local.tee $w3_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
(local.tee $b21_7_4 (v128.load8x8_s offset=32 (local.get $row1)))
local.get $w1_7_4
i16x8.sub
local.tee $w3_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
(local.tee $b21_7_5 (v128.load8x8_s offset=40 (local.get $row1)))
local.get $w1_7_5
i16x8.sub
local.tee $w3_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
(local.tee $b21_7_6 (v128.load8x8_s offset=48 (local.get $row1)))
local.get $w1_7_6
i16x8.sub
local.tee $w3_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
(local.tee $b21_7_7 (v128.load8x8_s offset=56 (local.get $row1)))
local.get $w1_7_7
i16x8.sub
local.tee $w3_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
(local.tee $b21_7_8 (v128.load8x8_s offset=64 (local.get $row1)))
local.get $w1_7_8
i16x8.sub
local.tee $w3_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
(local.tee $b21_7_9 (v128.load8x8_s offset=72 (local.get $row1)))
local.get $w1_7_9
i16x8.sub
local.tee $w3_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
(local.tee $b21_7_10 (v128.load8x8_s offset=80 (local.get $row1)))
local.get $w1_7_10
i16x8.sub
local.tee $w3_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
(local.tee $b21_7_11 (v128.load8x8_s offset=88 (local.get $row1)))
local.get $w1_7_11
i16x8.sub
local.tee $w3_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
(local.tee $b21_7_12 (v128.load8x8_s offset=96 (local.get $row1)))
local.get $w1_7_12
i16x8.sub
local.tee $w3_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
(local.tee $b21_7_13 (v128.load8x8_s offset=104 (local.get $row1)))
local.get $w1_7_13
i16x8.sub
local.tee $w3_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
(local.tee $b21_7_14 (v128.load8x8_s offset=112 (local.get $row1)))
local.get $w1_7_14
i16x8.sub
local.tee $w3_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
(local.tee $b21_7_15 (v128.load8x8_s offset=120 (local.get $row1)))
local.get $w1_7_15
i16x8.sub
local.tee $w3_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
(local.tee $b21_7_16 (v128.load8x8_s offset=128 (local.get $row1)))
local.get $w1_7_16
i16x8.sub
local.tee $w3_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
(local.tee $b21_7_17 (v128.load8x8_s offset=136 (local.get $row1)))
local.get $w1_7_17
i16x8.sub
local.tee $w3_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
(local.tee $b21_7_18 (v128.load8x8_s offset=144 (local.get $row1)))
local.get $w1_7_18
i16x8.sub
local.tee $w3_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
(local.tee $b21_7_19 (v128.load8x8_s offset=152 (local.get $row1)))
local.get $w1_7_19
i16x8.sub
local.tee $w3_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
(local.tee $b21_7_20 (v128.load8x8_s offset=160 (local.get $row1)))
local.get $w1_7_20
i16x8.sub
local.tee $w3_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
(local.tee $b21_7_21 (v128.load8x8_s offset=168 (local.get $row1)))
local.get $w1_7_21
i16x8.sub
local.tee $w3_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
(local.tee $b21_7_22 (v128.load8x8_s offset=176 (local.get $row1)))
local.get $w1_7_22
i16x8.sub
local.tee $w3_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
(local.tee $b21_7_23 (v128.load8x8_s offset=184 (local.get $row1)))
local.get $w1_7_23
i16x8.sub
local.tee $w3_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
(local.tee $b21_7_24 (v128.load8x8_s offset=192 (local.get $row1)))
local.get $w1_7_24
i16x8.sub
local.tee $w3_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
(local.tee $b21_7_25 (v128.load8x8_s offset=200 (local.get $row1)))
local.get $w1_7_25
i16x8.sub
local.tee $w3_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
(local.tee $b21_7_26 (v128.load8x8_s offset=208 (local.get $row1)))
local.get $w1_7_26
i16x8.sub
local.tee $w3_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
(local.tee $b21_7_27 (v128.load8x8_s offset=216 (local.get $row1)))
local.get $w1_7_27
i16x8.sub
local.tee $w3_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
(local.tee $b21_7_28 (v128.load8x8_s offset=224 (local.get $row1)))
local.get $w1_7_28
i16x8.sub
local.tee $w3_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
(local.tee $b21_7_29 (v128.load8x8_s offset=232 (local.get $row1)))
local.get $w1_7_29
i16x8.sub
local.tee $w3_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
(local.tee $b21_7_30 (v128.load8x8_s offset=240 (local.get $row1)))
local.get $w1_7_30
i16x8.sub
local.tee $w3_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
(local.tee $b21_7_31 (v128.load8x8_s offset=248 (local.get $row1)))
local.get $w1_7_31
i16x8.sub
local.tee $w3_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_7_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w1_7_0
local.get $b12_7_0
i16x8.add
local.tee $w5_7_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w1_7_1
local.get $b12_7_1
i16x8.add
local.tee $w5_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w1_7_2
local.get $b12_7_2
i16x8.add
local.tee $w5_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w1_7_3
local.get $b12_7_3
i16x8.add
local.tee $w5_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w1_7_4
local.get $b12_7_4
i16x8.add
local.tee $w5_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w1_7_5
local.get $b12_7_5
i16x8.add
local.tee $w5_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w1_7_6
local.get $b12_7_6
i16x8.add
local.tee $w5_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w1_7_7
local.get $b12_7_7
i16x8.add
local.tee $w5_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w1_7_8
local.get $b12_7_8
i16x8.add
local.tee $w5_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w1_7_9
local.get $b12_7_9
i16x8.add
local.tee $w5_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w1_7_10
local.get $b12_7_10
i16x8.add
local.tee $w5_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w1_7_11
local.get $b12_7_11
i16x8.add
local.tee $w5_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w1_7_12
local.get $b12_7_12
i16x8.add
local.tee $w5_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w1_7_13
local.get $b12_7_13
i16x8.add
local.tee $w5_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w1_7_14
local.get $b12_7_14
i16x8.add
local.tee $w5_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w1_7_15
local.get $b12_7_15
i16x8.add
local.tee $w5_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w1_7_16
local.get $b12_7_16
i16x8.add
local.tee $w5_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w1_7_17
local.get $b12_7_17
i16x8.add
local.tee $w5_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w1_7_18
local.get $b12_7_18
i16x8.add
local.tee $w5_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w1_7_19
local.get $b12_7_19
i16x8.add
local.tee $w5_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w1_7_20
local.get $b12_7_20
i16x8.add
local.tee $w5_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w1_7_21
local.get $b12_7_21
i16x8.add
local.tee $w5_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w1_7_22
local.get $b12_7_22
i16x8.add
local.tee $w5_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w1_7_23
local.get $b12_7_23
i16x8.add
local.tee $w5_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w1_7_24
local.get $b12_7_24
i16x8.add
local.tee $w5_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w1_7_25
local.get $b12_7_25
i16x8.add
local.tee $w5_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w1_7_26
local.get $b12_7_26
i16x8.add
local.tee $w5_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w1_7_27
local.get $b12_7_27
i16x8.add
local.tee $w5_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w1_7_28
local.get $b12_7_28
i16x8.add
local.tee $w5_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w1_7_29
local.get $b12_7_29
i16x8.add
local.tee $w5_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w1_7_30
local.get $b12_7_30
i16x8.add
local.tee $w5_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w1_7_31
local.get $b12_7_31
i16x8.add
local.tee $w5_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $b21_7_0
local.get $w4_7_0
i16x8.add
local.tee $w6_7_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $b21_7_1
local.get $w4_7_1
i16x8.add
local.tee $w6_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $b21_7_2
local.get $w4_7_2
i16x8.add
local.tee $w6_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $b21_7_3
local.get $w4_7_3
i16x8.add
local.tee $w6_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $b21_7_4
local.get $w4_7_4
i16x8.add
local.tee $w6_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $b21_7_5
local.get $w4_7_5
i16x8.add
local.tee $w6_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $b21_7_6
local.get $w4_7_6
i16x8.add
local.tee $w6_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $b21_7_7
local.get $w4_7_7
i16x8.add
local.tee $w6_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $b21_7_8
local.get $w4_7_8
i16x8.add
local.tee $w6_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $b21_7_9
local.get $w4_7_9
i16x8.add
local.tee $w6_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $b21_7_10
local.get $w4_7_10
i16x8.add
local.tee $w6_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $b21_7_11
local.get $w4_7_11
i16x8.add
local.tee $w6_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $b21_7_12
local.get $w4_7_12
i16x8.add
local.tee $w6_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $b21_7_13
local.get $w4_7_13
i16x8.add
local.tee $w6_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $b21_7_14
local.get $w4_7_14
i16x8.add
local.tee $w6_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $b21_7_15
local.get $w4_7_15
i16x8.add
local.tee $w6_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $b21_7_16
local.get $w4_7_16
i16x8.add
local.tee $w6_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $b21_7_17
local.get $w4_7_17
i16x8.add
local.tee $w6_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $b21_7_18
local.get $w4_7_18
i16x8.add
local.tee $w6_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $b21_7_19
local.get $w4_7_19
i16x8.add
local.tee $w6_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $b21_7_20
local.get $w4_7_20
i16x8.add
local.tee $w6_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $b21_7_21
local.get $w4_7_21
i16x8.add
local.tee $w6_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $b21_7_22
local.get $w4_7_22
i16x8.add
local.tee $w6_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $b21_7_23
local.get $w4_7_23
i16x8.add
local.tee $w6_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $b21_7_24
local.get $w4_7_24
i16x8.add
local.tee $w6_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $b21_7_25
local.get $w4_7_25
i16x8.add
local.tee $w6_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $b21_7_26
local.get $w4_7_26
i16x8.add
local.tee $w6_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $b21_7_27
local.get $w4_7_27
i16x8.add
local.tee $w6_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $b21_7_28
local.get $w4_7_28
i16x8.add
local.tee $w6_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $b21_7_29
local.get $w4_7_29
i16x8.add
local.tee $w6_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $b21_7_30
local.get $w4_7_30
i16x8.add
local.tee $w6_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $b21_7_31
local.get $w4_7_31
i16x8.add
local.tee $w6_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112
(if (local.get $keep) (then
local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112
))
(local.set $t (i32.const 2))
(local.set $fulln (i32.and (local.get $n) (i32.const -2)))
(block $pairs_done
(loop $tokens
(br_if $pairs_done (i32.ge_u (local.get $t) (local.get $fulln)))
(local.set $qoffset (i32.add (i32.mul (local.get $t) (local.get $cols)) (i32.shl (local.get $start) (i32.const 1))))

(local.set $yp (i32.add (local.get $sums) (i32.mul (local.get $t) (local.get $output_bytes))))
(local.set $yp1 (i32.add (local.get $yp) (local.get $output_bytes)))
(local.set $sx0 (v128.load32_splat (i32.add (local.get $sx) (i32.shl (i32.mul (local.get $t) (local.get $input_stride)) (i32.const 2)))))
 (local.set $sx1 (v128.load32_splat (i32.add (local.get $sx) (i32.shl (i32.mul (i32.add (local.get $t) (i32.const 1)) (local.get $input_stride)) (i32.const 2)))))
(local.set $qp (i32.add (i32.load offset=0 (local.get $q)) (local.get $qoffset)))
(local.tee $x0_0 (v128.load offset=0 (local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x0_1 (v128.load offset=16 (local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_2 (v128.load offset=32 (local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_3 (v128.load offset=48 (local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_4 (v128.load offset=64 (local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_5 (v128.load offset=80 (local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_6 (v128.load offset=96 (local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_7 (v128.load offset=112 (local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_8 (v128.load offset=128 (local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_9 (v128.load offset=144 (local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_10 (v128.load offset=160 (local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_11 (v128.load offset=176 (local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_12 (v128.load offset=192 (local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_13 (v128.load offset=208 (local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_14 (v128.load offset=224 (local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_15 (v128.load offset=240 (local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_16 (v128.load offset=256 (local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_17 (v128.load offset=272 (local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_18 (v128.load offset=288 (local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_19 (v128.load offset=304 (local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_20 (v128.load offset=320 (local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_21 (v128.load offset=336 (local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_22 (v128.load offset=352 (local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_23 (v128.load offset=368 (local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_24 (v128.load offset=384 (local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_25 (v128.load offset=400 (local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_26 (v128.load offset=416 (local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_27 (v128.load offset=432 (local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_28 (v128.load offset=448 (local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_29 (v128.load offset=464 (local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_30 (v128.load offset=480 (local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_31 (v128.load offset=496 (local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
(local.set $qp (i32.add (i32.load offset=4 (local.get $q)) (local.get $qoffset)))
(local.tee $x1_0 (v128.load offset=0 (local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1_1 (v128.load offset=16 (local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_2 (v128.load offset=32 (local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_3 (v128.load offset=48 (local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_4 (v128.load offset=64 (local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_5 (v128.load offset=80 (local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_6 (v128.load offset=96 (local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_7 (v128.load offset=112 (local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_8 (v128.load offset=128 (local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_9 (v128.load offset=144 (local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_10 (v128.load offset=160 (local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_11 (v128.load offset=176 (local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_12 (v128.load offset=192 (local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_13 (v128.load offset=208 (local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_14 (v128.load offset=224 (local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_15 (v128.load offset=240 (local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_16 (v128.load offset=256 (local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_17 (v128.load offset=272 (local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_18 (v128.load offset=288 (local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_19 (v128.load offset=304 (local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_20 (v128.load offset=320 (local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_21 (v128.load offset=336 (local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_22 (v128.load offset=352 (local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_23 (v128.load offset=368 (local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_24 (v128.load offset=384 (local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_25 (v128.load offset=400 (local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_26 (v128.load offset=416 (local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_27 (v128.load offset=432 (local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_28 (v128.load offset=448 (local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_29 (v128.load offset=464 (local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_30 (v128.load offset=480 (local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_31 (v128.load offset=496 (local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
(local.set $qp (i32.add (i32.load offset=8 (local.get $q)) (local.get $qoffset)))
(local.tee $x2_0 (v128.load offset=0 (local.get $qp)))
local.get $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x2_1 (v128.load offset=16 (local.get $qp)))
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_2 (v128.load offset=32 (local.get $qp)))
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_3 (v128.load offset=48 (local.get $qp)))
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_4 (v128.load offset=64 (local.get $qp)))
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_5 (v128.load offset=80 (local.get $qp)))
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_6 (v128.load offset=96 (local.get $qp)))
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_7 (v128.load offset=112 (local.get $qp)))
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_8 (v128.load offset=128 (local.get $qp)))
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_9 (v128.load offset=144 (local.get $qp)))
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_10 (v128.load offset=160 (local.get $qp)))
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_11 (v128.load offset=176 (local.get $qp)))
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_12 (v128.load offset=192 (local.get $qp)))
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_13 (v128.load offset=208 (local.get $qp)))
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_14 (v128.load offset=224 (local.get $qp)))
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_15 (v128.load offset=240 (local.get $qp)))
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_16 (v128.load offset=256 (local.get $qp)))
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_17 (v128.load offset=272 (local.get $qp)))
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_18 (v128.load offset=288 (local.get $qp)))
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_19 (v128.load offset=304 (local.get $qp)))
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_20 (v128.load offset=320 (local.get $qp)))
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_21 (v128.load offset=336 (local.get $qp)))
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_22 (v128.load offset=352 (local.get $qp)))
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_23 (v128.load offset=368 (local.get $qp)))
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_24 (v128.load offset=384 (local.get $qp)))
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_25 (v128.load offset=400 (local.get $qp)))
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_26 (v128.load offset=416 (local.get $qp)))
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_27 (v128.load offset=432 (local.get $qp)))
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_28 (v128.load offset=448 (local.get $qp)))
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_29 (v128.load offset=464 (local.get $qp)))
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_30 (v128.load offset=480 (local.get $qp)))
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_31 (v128.load offset=496 (local.get $qp)))
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
(local.set $qp (i32.add (i32.load offset=12 (local.get $q)) (local.get $qoffset)))
(local.tee $x3_0 (v128.load offset=0 (local.get $qp)))
local.get $w3_0_0
i32x4.dot_i16x8_s
(local.tee $x3_1 (v128.load offset=16 (local.get $qp)))
local.get $w3_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_2 (v128.load offset=32 (local.get $qp)))
local.get $w3_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_3 (v128.load offset=48 (local.get $qp)))
local.get $w3_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_4 (v128.load offset=64 (local.get $qp)))
local.get $w3_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_5 (v128.load offset=80 (local.get $qp)))
local.get $w3_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_6 (v128.load offset=96 (local.get $qp)))
local.get $w3_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_7 (v128.load offset=112 (local.get $qp)))
local.get $w3_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_8 (v128.load offset=128 (local.get $qp)))
local.get $w3_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_9 (v128.load offset=144 (local.get $qp)))
local.get $w3_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_10 (v128.load offset=160 (local.get $qp)))
local.get $w3_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_11 (v128.load offset=176 (local.get $qp)))
local.get $w3_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_12 (v128.load offset=192 (local.get $qp)))
local.get $w3_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_13 (v128.load offset=208 (local.get $qp)))
local.get $w3_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_14 (v128.load offset=224 (local.get $qp)))
local.get $w3_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_15 (v128.load offset=240 (local.get $qp)))
local.get $w3_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_16 (v128.load offset=256 (local.get $qp)))
local.get $w3_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_17 (v128.load offset=272 (local.get $qp)))
local.get $w3_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_18 (v128.load offset=288 (local.get $qp)))
local.get $w3_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_19 (v128.load offset=304 (local.get $qp)))
local.get $w3_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_20 (v128.load offset=320 (local.get $qp)))
local.get $w3_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_21 (v128.load offset=336 (local.get $qp)))
local.get $w3_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_22 (v128.load offset=352 (local.get $qp)))
local.get $w3_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_23 (v128.load offset=368 (local.get $qp)))
local.get $w3_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_24 (v128.load offset=384 (local.get $qp)))
local.get $w3_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_25 (v128.load offset=400 (local.get $qp)))
local.get $w3_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_26 (v128.load offset=416 (local.get $qp)))
local.get $w3_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_27 (v128.load offset=432 (local.get $qp)))
local.get $w3_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_28 (v128.load offset=448 (local.get $qp)))
local.get $w3_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_29 (v128.load offset=464 (local.get $qp)))
local.get $w3_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_30 (v128.load offset=480 (local.get $qp)))
local.get $w3_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_31 (v128.load offset=496 (local.get $qp)))
local.get $w3_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
(local.set $qp (i32.add (i32.load offset=16 (local.get $q)) (local.get $qoffset)))
(local.tee $x4_0 (v128.load offset=0 (local.get $qp)))
local.get $w4_0_0
i32x4.dot_i16x8_s
(local.tee $x4_1 (v128.load offset=16 (local.get $qp)))
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_2 (v128.load offset=32 (local.get $qp)))
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_3 (v128.load offset=48 (local.get $qp)))
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_4 (v128.load offset=64 (local.get $qp)))
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_5 (v128.load offset=80 (local.get $qp)))
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_6 (v128.load offset=96 (local.get $qp)))
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_7 (v128.load offset=112 (local.get $qp)))
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_8 (v128.load offset=128 (local.get $qp)))
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_9 (v128.load offset=144 (local.get $qp)))
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_10 (v128.load offset=160 (local.get $qp)))
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_11 (v128.load offset=176 (local.get $qp)))
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_12 (v128.load offset=192 (local.get $qp)))
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_13 (v128.load offset=208 (local.get $qp)))
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_14 (v128.load offset=224 (local.get $qp)))
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_15 (v128.load offset=240 (local.get $qp)))
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_16 (v128.load offset=256 (local.get $qp)))
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_17 (v128.load offset=272 (local.get $qp)))
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_18 (v128.load offset=288 (local.get $qp)))
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_19 (v128.load offset=304 (local.get $qp)))
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_20 (v128.load offset=320 (local.get $qp)))
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_21 (v128.load offset=336 (local.get $qp)))
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_22 (v128.load offset=352 (local.get $qp)))
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_23 (v128.load offset=368 (local.get $qp)))
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_24 (v128.load offset=384 (local.get $qp)))
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_25 (v128.load offset=400 (local.get $qp)))
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_26 (v128.load offset=416 (local.get $qp)))
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_27 (v128.load offset=432 (local.get $qp)))
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_28 (v128.load offset=448 (local.get $qp)))
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_29 (v128.load offset=464 (local.get $qp)))
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_30 (v128.load offset=480 (local.get $qp)))
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_31 (v128.load offset=496 (local.get $qp)))
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
(local.set $qp (i32.add (i32.load offset=20 (local.get $q)) (local.get $qoffset)))
(local.tee $x5_0 (v128.load offset=0 (local.get $qp)))
local.get $w5_0_0
i32x4.dot_i16x8_s
(local.tee $x5_1 (v128.load offset=16 (local.get $qp)))
local.get $w5_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_2 (v128.load offset=32 (local.get $qp)))
local.get $w5_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_3 (v128.load offset=48 (local.get $qp)))
local.get $w5_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_4 (v128.load offset=64 (local.get $qp)))
local.get $w5_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_5 (v128.load offset=80 (local.get $qp)))
local.get $w5_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_6 (v128.load offset=96 (local.get $qp)))
local.get $w5_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_7 (v128.load offset=112 (local.get $qp)))
local.get $w5_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_8 (v128.load offset=128 (local.get $qp)))
local.get $w5_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_9 (v128.load offset=144 (local.get $qp)))
local.get $w5_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_10 (v128.load offset=160 (local.get $qp)))
local.get $w5_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_11 (v128.load offset=176 (local.get $qp)))
local.get $w5_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_12 (v128.load offset=192 (local.get $qp)))
local.get $w5_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_13 (v128.load offset=208 (local.get $qp)))
local.get $w5_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_14 (v128.load offset=224 (local.get $qp)))
local.get $w5_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_15 (v128.load offset=240 (local.get $qp)))
local.get $w5_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_16 (v128.load offset=256 (local.get $qp)))
local.get $w5_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_17 (v128.load offset=272 (local.get $qp)))
local.get $w5_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_18 (v128.load offset=288 (local.get $qp)))
local.get $w5_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_19 (v128.load offset=304 (local.get $qp)))
local.get $w5_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_20 (v128.load offset=320 (local.get $qp)))
local.get $w5_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_21 (v128.load offset=336 (local.get $qp)))
local.get $w5_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_22 (v128.load offset=352 (local.get $qp)))
local.get $w5_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_23 (v128.load offset=368 (local.get $qp)))
local.get $w5_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_24 (v128.load offset=384 (local.get $qp)))
local.get $w5_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_25 (v128.load offset=400 (local.get $qp)))
local.get $w5_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_26 (v128.load offset=416 (local.get $qp)))
local.get $w5_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_27 (v128.load offset=432 (local.get $qp)))
local.get $w5_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_28 (v128.load offset=448 (local.get $qp)))
local.get $w5_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_29 (v128.load offset=464 (local.get $qp)))
local.get $w5_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_30 (v128.load offset=480 (local.get $qp)))
local.get $w5_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_31 (v128.load offset=496 (local.get $qp)))
local.get $w5_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
(local.set $qp (i32.add (i32.load offset=24 (local.get $q)) (local.get $qoffset)))
(local.tee $x6_0 (v128.load offset=0 (local.get $qp)))
local.get $w6_0_0
i32x4.dot_i16x8_s
(local.tee $x6_1 (v128.load offset=16 (local.get $qp)))
local.get $w6_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_2 (v128.load offset=32 (local.get $qp)))
local.get $w6_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_3 (v128.load offset=48 (local.get $qp)))
local.get $w6_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_4 (v128.load offset=64 (local.get $qp)))
local.get $w6_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_5 (v128.load offset=80 (local.get $qp)))
local.get $w6_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_6 (v128.load offset=96 (local.get $qp)))
local.get $w6_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_7 (v128.load offset=112 (local.get $qp)))
local.get $w6_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_8 (v128.load offset=128 (local.get $qp)))
local.get $w6_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_9 (v128.load offset=144 (local.get $qp)))
local.get $w6_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_10 (v128.load offset=160 (local.get $qp)))
local.get $w6_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_11 (v128.load offset=176 (local.get $qp)))
local.get $w6_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_12 (v128.load offset=192 (local.get $qp)))
local.get $w6_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_13 (v128.load offset=208 (local.get $qp)))
local.get $w6_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_14 (v128.load offset=224 (local.get $qp)))
local.get $w6_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_15 (v128.load offset=240 (local.get $qp)))
local.get $w6_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_16 (v128.load offset=256 (local.get $qp)))
local.get $w6_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_17 (v128.load offset=272 (local.get $qp)))
local.get $w6_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_18 (v128.load offset=288 (local.get $qp)))
local.get $w6_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_19 (v128.load offset=304 (local.get $qp)))
local.get $w6_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_20 (v128.load offset=320 (local.get $qp)))
local.get $w6_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_21 (v128.load offset=336 (local.get $qp)))
local.get $w6_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_22 (v128.load offset=352 (local.get $qp)))
local.get $w6_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_23 (v128.load offset=368 (local.get $qp)))
local.get $w6_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_24 (v128.load offset=384 (local.get $qp)))
local.get $w6_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_25 (v128.load offset=400 (local.get $qp)))
local.get $w6_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_26 (v128.load offset=416 (local.get $qp)))
local.get $w6_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_27 (v128.load offset=432 (local.get $qp)))
local.get $w6_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_28 (v128.load offset=448 (local.get $qp)))
local.get $w6_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_29 (v128.load offset=464 (local.get $qp)))
local.get $w6_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_30 (v128.load offset=480 (local.get $qp)))
local.get $w6_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_31 (v128.load offset=496 (local.get $qp)))
local.get $w6_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0

local.get $x0_0
local.get $w0_1_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_1_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
local.get $w2_1_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
local.get $w3_1_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_1_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w5_1_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $w6_1_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16

local.get $x0_0
local.get $w0_2_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_2_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
local.get $w2_2_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
local.get $w3_2_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_2_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w5_2_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $w6_2_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32

local.get $x0_0
local.get $w0_3_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_3_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
local.get $w2_3_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
local.get $w3_3_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_3_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w5_3_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $w6_3_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48

local.get $x0_0
local.get $w0_4_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_4_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
local.get $w2_4_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
local.get $w3_4_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_4_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w5_4_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $w6_4_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64

local.get $x0_0
local.get $w0_5_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_5_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
local.get $w2_5_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
local.get $w3_5_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_5_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w5_5_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $w6_5_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80

local.get $x0_0
local.get $w0_6_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_6_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
local.get $w2_6_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
local.get $w3_6_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_6_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w5_6_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $w6_6_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96

local.get $x0_0
local.get $w0_7_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x1_0
local.get $w1_7_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p1
local.get $x2_0
local.get $w2_7_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x3_0
local.get $w3_7_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p3
local.get $x4_0
local.get $w4_7_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x5_0
local.get $w5_7_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p5
local.get $x6_0
local.get $w6_7_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p3
i32x4.add
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112

local.get $yp1
v128.const i32x4 0 0 0 0
local.get $p1
local.get $p3
i32x4.add
local.set $a
local.get $p0
local.get $p1
i32x4.sub
local.get $p2
i32x4.add
local.get $p5
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112

(local.set $t (i32.add (local.get $t) (i32.const 2)))
br $tokens
))
(if (i32.lt_u (local.get $t) (local.get $n)) (then
(local.set $qoffset (i32.add (i32.mul (local.get $t) (local.get $cols)) (i32.shl (local.get $start) (i32.const 1))))

(local.set $yp (i32.add (local.get $sums) (i32.mul (local.get $t) (local.get $output_bytes))))
(local.set $yp1 (i32.add (local.get $yp) (local.get $output_bytes)))
(local.set $sx0 (v128.load32_splat (i32.add (local.get $sx) (i32.shl (i32.mul (local.get $t) (local.get $input_stride)) (i32.const 2)))))

(local.set $qp (i32.add (i32.load offset=0 (local.get $q)) (local.get $qoffset)))
(local.tee $x0_0 (v128.load offset=0 (local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x0_1 (v128.load offset=16 (local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_2 (v128.load offset=32 (local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_3 (v128.load offset=48 (local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_4 (v128.load offset=64 (local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_5 (v128.load offset=80 (local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_6 (v128.load offset=96 (local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_7 (v128.load offset=112 (local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_8 (v128.load offset=128 (local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_9 (v128.load offset=144 (local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_10 (v128.load offset=160 (local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_11 (v128.load offset=176 (local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_12 (v128.load offset=192 (local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_13 (v128.load offset=208 (local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_14 (v128.load offset=224 (local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_15 (v128.load offset=240 (local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_16 (v128.load offset=256 (local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_17 (v128.load offset=272 (local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_18 (v128.load offset=288 (local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_19 (v128.load offset=304 (local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_20 (v128.load offset=320 (local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_21 (v128.load offset=336 (local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_22 (v128.load offset=352 (local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_23 (v128.load offset=368 (local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_24 (v128.load offset=384 (local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_25 (v128.load offset=400 (local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_26 (v128.load offset=416 (local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_27 (v128.load offset=432 (local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_28 (v128.load offset=448 (local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_29 (v128.load offset=464 (local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_30 (v128.load offset=480 (local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_31 (v128.load offset=496 (local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
(local.set $qp (i32.add (i32.load offset=8 (local.get $q)) (local.get $qoffset)))
(local.tee $x2_0 (v128.load offset=0 (local.get $qp)))
local.get $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x2_1 (v128.load offset=16 (local.get $qp)))
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_2 (v128.load offset=32 (local.get $qp)))
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_3 (v128.load offset=48 (local.get $qp)))
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_4 (v128.load offset=64 (local.get $qp)))
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_5 (v128.load offset=80 (local.get $qp)))
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_6 (v128.load offset=96 (local.get $qp)))
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_7 (v128.load offset=112 (local.get $qp)))
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_8 (v128.load offset=128 (local.get $qp)))
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_9 (v128.load offset=144 (local.get $qp)))
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_10 (v128.load offset=160 (local.get $qp)))
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_11 (v128.load offset=176 (local.get $qp)))
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_12 (v128.load offset=192 (local.get $qp)))
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_13 (v128.load offset=208 (local.get $qp)))
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_14 (v128.load offset=224 (local.get $qp)))
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_15 (v128.load offset=240 (local.get $qp)))
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_16 (v128.load offset=256 (local.get $qp)))
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_17 (v128.load offset=272 (local.get $qp)))
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_18 (v128.load offset=288 (local.get $qp)))
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_19 (v128.load offset=304 (local.get $qp)))
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_20 (v128.load offset=320 (local.get $qp)))
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_21 (v128.load offset=336 (local.get $qp)))
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_22 (v128.load offset=352 (local.get $qp)))
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_23 (v128.load offset=368 (local.get $qp)))
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_24 (v128.load offset=384 (local.get $qp)))
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_25 (v128.load offset=400 (local.get $qp)))
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_26 (v128.load offset=416 (local.get $qp)))
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_27 (v128.load offset=432 (local.get $qp)))
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_28 (v128.load offset=448 (local.get $qp)))
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_29 (v128.load offset=464 (local.get $qp)))
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_30 (v128.load offset=480 (local.get $qp)))
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_31 (v128.load offset=496 (local.get $qp)))
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
(local.set $qp (i32.add (i32.load offset=16 (local.get $q)) (local.get $qoffset)))
(local.tee $x4_0 (v128.load offset=0 (local.get $qp)))
local.get $w4_0_0
i32x4.dot_i16x8_s
(local.tee $x4_1 (v128.load offset=16 (local.get $qp)))
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_2 (v128.load offset=32 (local.get $qp)))
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_3 (v128.load offset=48 (local.get $qp)))
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_4 (v128.load offset=64 (local.get $qp)))
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_5 (v128.load offset=80 (local.get $qp)))
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_6 (v128.load offset=96 (local.get $qp)))
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_7 (v128.load offset=112 (local.get $qp)))
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_8 (v128.load offset=128 (local.get $qp)))
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_9 (v128.load offset=144 (local.get $qp)))
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_10 (v128.load offset=160 (local.get $qp)))
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_11 (v128.load offset=176 (local.get $qp)))
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_12 (v128.load offset=192 (local.get $qp)))
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_13 (v128.load offset=208 (local.get $qp)))
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_14 (v128.load offset=224 (local.get $qp)))
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_15 (v128.load offset=240 (local.get $qp)))
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_16 (v128.load offset=256 (local.get $qp)))
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_17 (v128.load offset=272 (local.get $qp)))
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_18 (v128.load offset=288 (local.get $qp)))
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_19 (v128.load offset=304 (local.get $qp)))
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_20 (v128.load offset=320 (local.get $qp)))
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_21 (v128.load offset=336 (local.get $qp)))
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_22 (v128.load offset=352 (local.get $qp)))
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_23 (v128.load offset=368 (local.get $qp)))
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_24 (v128.load offset=384 (local.get $qp)))
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_25 (v128.load offset=400 (local.get $qp)))
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_26 (v128.load offset=416 (local.get $qp)))
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_27 (v128.load offset=432 (local.get $qp)))
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_28 (v128.load offset=448 (local.get $qp)))
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_29 (v128.load offset=464 (local.get $qp)))
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_30 (v128.load offset=480 (local.get $qp)))
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_31 (v128.load offset=496 (local.get $qp)))
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
(local.set $qp (i32.add (i32.load offset=24 (local.get $q)) (local.get $qoffset)))
(local.tee $x6_0 (v128.load offset=0 (local.get $qp)))
local.get $w6_0_0
i32x4.dot_i16x8_s
(local.tee $x6_1 (v128.load offset=16 (local.get $qp)))
local.get $w6_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_2 (v128.load offset=32 (local.get $qp)))
local.get $w6_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_3 (v128.load offset=48 (local.get $qp)))
local.get $w6_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_4 (v128.load offset=64 (local.get $qp)))
local.get $w6_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_5 (v128.load offset=80 (local.get $qp)))
local.get $w6_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_6 (v128.load offset=96 (local.get $qp)))
local.get $w6_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_7 (v128.load offset=112 (local.get $qp)))
local.get $w6_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_8 (v128.load offset=128 (local.get $qp)))
local.get $w6_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_9 (v128.load offset=144 (local.get $qp)))
local.get $w6_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_10 (v128.load offset=160 (local.get $qp)))
local.get $w6_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_11 (v128.load offset=176 (local.get $qp)))
local.get $w6_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_12 (v128.load offset=192 (local.get $qp)))
local.get $w6_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_13 (v128.load offset=208 (local.get $qp)))
local.get $w6_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_14 (v128.load offset=224 (local.get $qp)))
local.get $w6_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_15 (v128.load offset=240 (local.get $qp)))
local.get $w6_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_16 (v128.load offset=256 (local.get $qp)))
local.get $w6_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_17 (v128.load offset=272 (local.get $qp)))
local.get $w6_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_18 (v128.load offset=288 (local.get $qp)))
local.get $w6_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_19 (v128.load offset=304 (local.get $qp)))
local.get $w6_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_20 (v128.load offset=320 (local.get $qp)))
local.get $w6_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_21 (v128.load offset=336 (local.get $qp)))
local.get $w6_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_22 (v128.load offset=352 (local.get $qp)))
local.get $w6_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_23 (v128.load offset=368 (local.get $qp)))
local.get $w6_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_24 (v128.load offset=384 (local.get $qp)))
local.get $w6_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_25 (v128.load offset=400 (local.get $qp)))
local.get $w6_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_26 (v128.load offset=416 (local.get $qp)))
local.get $w6_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_27 (v128.load offset=432 (local.get $qp)))
local.get $w6_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_28 (v128.load offset=448 (local.get $qp)))
local.get $w6_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_29 (v128.load offset=464 (local.get $qp)))
local.get $w6_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_30 (v128.load offset=480 (local.get $qp)))
local.get $w6_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_31 (v128.load offset=496 (local.get $qp)))
local.get $w6_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0

local.get $x0_0
local.get $w0_1_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x2_0
local.get $w2_1_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x4_0
local.get $w4_1_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x6_0
local.get $w6_1_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_1_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16

local.get $x0_0
local.get $w0_2_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x2_0
local.get $w2_2_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x4_0
local.get $w4_2_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x6_0
local.get $w6_2_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_2_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32

local.get $x0_0
local.get $w0_3_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x2_0
local.get $w2_3_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x4_0
local.get $w4_3_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x6_0
local.get $w6_3_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_3_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48

local.get $x0_0
local.get $w0_4_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x2_0
local.get $w2_4_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x4_0
local.get $w4_4_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x6_0
local.get $w6_4_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_4_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_4_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_4_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_4_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_4_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_4_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_4_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_4_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_4_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_4_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_4_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_4_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_4_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_4_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_4_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_4_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_4_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_4_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_4_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_4_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_4_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_4_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_4_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_4_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_4_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_4_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_4_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_4_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_4_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_4_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_4_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64

local.get $x0_0
local.get $w0_5_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x2_0
local.get $w2_5_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x4_0
local.get $w4_5_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x6_0
local.get $w6_5_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_5_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_5_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_5_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_5_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_5_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_5_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_5_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_5_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_5_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_5_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_5_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_5_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_5_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_5_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_5_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_5_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_5_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_5_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_5_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_5_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_5_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_5_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_5_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_5_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_5_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_5_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_5_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_5_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_5_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_5_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_5_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80

local.get $x0_0
local.get $w0_6_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x2_0
local.get $w2_6_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x4_0
local.get $w4_6_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x6_0
local.get $w6_6_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_6_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_6_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_6_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_6_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_6_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_6_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_6_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_6_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_6_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_6_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_6_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_6_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_6_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_6_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_6_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_6_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_6_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_6_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_6_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_6_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_6_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_6_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_6_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_6_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_6_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_6_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_6_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_6_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_6_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_6_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_6_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96

local.get $x0_0
local.get $w0_7_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0
local.get $x2_0
local.get $w2_7_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p2
local.get $x4_0
local.get $w4_7_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p4
local.get $x6_0
local.get $w6_7_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_7_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_7_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_7_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_7_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_7_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_7_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_7_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_7_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_7_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_7_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_7_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_7_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_7_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_7_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_7_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_7_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_7_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_7_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_7_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_7_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_7_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_7_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_7_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_7_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_7_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_7_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_7_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_7_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_7_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_7_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_7_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p6
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0
local.get $p4
i32x4.sub
local.get $p6
i32x4.add
local.set $a
local.get $p2
local.get $p4
i32x4.add
local.set $value
local.get $a
local.get $value
i8x16.shuffle 0 1 2 3 16 17 18 19 8 9 10 11 24 25 26 27
local.get $a
local.get $value
i8x16.shuffle 4 5 6 7 20 21 22 23 12 13 14 15 28 29 30 31
i32x4.add
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112

))
)
))
