(module(func(export "__imajev_s2_k2_16_seed")(param $q i32)(param $w i32)(param $cols i32)(param $start i32)(param $sx i32)(param $stride i32)(param $sw i32)(param $sums i32)(param $n i32)
(local $t i32)(local $qp i32)(local $yp i32)(local $qoff i32)(local $input_stride i32)(local $output_bytes i32)
(local $wp0 i32)(local $bp0 i32)
(local $wp1 i32)(local $bp1 i32)
(local $b1 v128)
(local $wp2 i32)(local $bp2 i32)
(local $b2 v128)
(local $wp3 i32)(local $bp3 i32)
(local $b3 v128)
(local $wp4 i32)(local $bp4 i32)
(local $wp5 i32)(local $bp5 i32)
(local $wp6 i32)(local $bp6 i32)
(local $b6 v128)
(local $wp7 i32)(local $bp7 i32)
(local $b7 v128)
(local $wp8 i32)(local $bp8 i32)
(local $wp9 i32)(local $bp9 i32)
(local $b9 v128)
(local $wp10 i32)(local $bp10 i32)
(local $wp11 i32)(local $bp11 i32)
(local $b11 v128)
(local $wp12 i32)(local $bp12 i32)
(local $wp13 i32)(local $bp13 i32)
(local $wp14 i32)(local $bp14 i32)
(local $wp15 i32)(local $bp15 i32)
(local $bd1 v128)
(local $bd5 v128)
(local $bd9 v128)
(local $bd13 v128)
(local $pc49 v128)
(local $pc50 v128)
(local $pc51 v128)
(local $pc52 v128)
(local $pc53 v128)
(local $pc54 v128)
(local $pc55 v128)
(local $pc56 v128)
(local $pc57 v128)
(local $pc58 v128)
(local $pc59 v128)
(local $pc60 v128)
(local $pc61 v128)
(local $pc62 v128)
(local $pc63 v128)
(local $pc64 v128)
(local $pc65 v128)
(local $pc66 v128)
(local $pc67 v128)
(local $pc68 v128)
(local $pc69 v128)
(local $pc70 v128)
(local $pc71 v128)
(local $pc72 v128)
(local $pc73 v128)
(local $pc74 v128)
(local $pc75 v128)
(local $pc76 v128)
(local $pc77 v128)
(local $pc78 v128)
(local $pc79 v128)
(local $pc80 v128)
(local $pc81 v128)
(local $pc82 v128)
(local $pc83 v128)
(local $pc84 v128)
(local $pc85 v128)
(local $pc86 v128)
(local $pc87 v128)
(local $pc88 v128)
(local $pc89 v128)
(local $pc90 v128)
(local $pc91 v128)
(local $pc92 v128)
(local $pc93 v128)
(local $pc94 v128)
(local $p0_0 v128)
(local $w0_0_0 v128)
(local $w0_0_1 v128)
(local $w0_0_2 v128)
(local $w0_0_3 v128)
(local $w0_0_4 v128)
(local $w0_0_5 v128)
(local $w0_0_6 v128)
(local $w0_0_7 v128)
(local $w0_0_8 v128)
(local $w0_0_9 v128)
(local $w0_0_10 v128)
(local $w0_0_11 v128)
(local $w0_0_12 v128)
(local $w0_0_13 v128)
(local $w0_0_14 v128)
(local $w0_0_15 v128)
(local $w0_0_16 v128)
(local $w0_0_17 v128)
(local $w0_0_18 v128)
(local $w0_0_19 v128)
(local $w0_0_20 v128)
(local $w0_0_21 v128)
(local $w0_0_22 v128)
(local $w0_0_23 v128)
(local $w0_0_24 v128)
(local $w0_0_25 v128)
(local $w0_0_26 v128)
(local $w0_0_27 v128)
(local $w0_0_28 v128)
(local $w0_0_29 v128)
(local $w0_0_30 v128)
(local $w0_0_31 v128)
(local $p0_1 v128)
(local $w1_0_0 v128)
(local $w1_0_1 v128)
(local $w1_0_2 v128)
(local $w1_0_3 v128)
(local $w1_0_4 v128)
(local $w1_0_5 v128)
(local $w1_0_6 v128)
(local $w1_0_7 v128)
(local $w1_0_8 v128)
(local $w1_0_9 v128)
(local $w1_0_10 v128)
(local $w1_0_11 v128)
(local $w1_0_12 v128)
(local $w1_0_13 v128)
(local $w1_0_14 v128)
(local $w1_0_15 v128)
(local $w1_0_16 v128)
(local $w1_0_17 v128)
(local $w1_0_18 v128)
(local $w1_0_19 v128)
(local $w1_0_20 v128)
(local $w1_0_21 v128)
(local $w1_0_22 v128)
(local $w1_0_23 v128)
(local $w1_0_24 v128)
(local $w1_0_25 v128)
(local $w1_0_26 v128)
(local $w1_0_27 v128)
(local $w1_0_28 v128)
(local $w1_0_29 v128)
(local $w1_0_30 v128)
(local $w1_0_31 v128)
(local $p0_2 v128)
(local $w2_0_0 v128)
(local $w2_0_1 v128)
(local $w2_0_2 v128)
(local $w2_0_3 v128)
(local $w2_0_4 v128)
(local $w2_0_5 v128)
(local $w2_0_6 v128)
(local $w2_0_7 v128)
(local $w2_0_8 v128)
(local $w2_0_9 v128)
(local $w2_0_10 v128)
(local $w2_0_11 v128)
(local $w2_0_12 v128)
(local $w2_0_13 v128)
(local $w2_0_14 v128)
(local $w2_0_15 v128)
(local $w2_0_16 v128)
(local $w2_0_17 v128)
(local $w2_0_18 v128)
(local $w2_0_19 v128)
(local $w2_0_20 v128)
(local $w2_0_21 v128)
(local $w2_0_22 v128)
(local $w2_0_23 v128)
(local $w2_0_24 v128)
(local $w2_0_25 v128)
(local $w2_0_26 v128)
(local $w2_0_27 v128)
(local $w2_0_28 v128)
(local $w2_0_29 v128)
(local $w2_0_30 v128)
(local $w2_0_31 v128)
(local $p0_3 v128)
(local $w3_0_0 v128)
(local $w3_0_1 v128)
(local $w3_0_2 v128)
(local $w3_0_3 v128)
(local $w3_0_4 v128)
(local $w3_0_5 v128)
(local $w3_0_6 v128)
(local $w3_0_7 v128)
(local $w3_0_8 v128)
(local $w3_0_9 v128)
(local $w3_0_10 v128)
(local $w3_0_11 v128)
(local $w3_0_12 v128)
(local $w3_0_13 v128)
(local $w3_0_14 v128)
(local $w3_0_15 v128)
(local $w3_0_16 v128)
(local $w3_0_17 v128)
(local $w3_0_18 v128)
(local $w3_0_19 v128)
(local $w3_0_20 v128)
(local $w3_0_21 v128)
(local $w3_0_22 v128)
(local $w3_0_23 v128)
(local $w3_0_24 v128)
(local $w3_0_25 v128)
(local $w3_0_26 v128)
(local $w3_0_27 v128)
(local $w3_0_28 v128)
(local $w3_0_29 v128)
(local $w3_0_30 v128)
(local $w3_0_31 v128)
(local $p0_4 v128)
(local $w4_0_0 v128)
(local $w4_0_1 v128)
(local $w4_0_2 v128)
(local $w4_0_3 v128)
(local $w4_0_4 v128)
(local $w4_0_5 v128)
(local $w4_0_6 v128)
(local $w4_0_7 v128)
(local $w4_0_8 v128)
(local $w4_0_9 v128)
(local $w4_0_10 v128)
(local $w4_0_11 v128)
(local $w4_0_12 v128)
(local $w4_0_13 v128)
(local $w4_0_14 v128)
(local $w4_0_15 v128)
(local $w4_0_16 v128)
(local $w4_0_17 v128)
(local $w4_0_18 v128)
(local $w4_0_19 v128)
(local $w4_0_20 v128)
(local $w4_0_21 v128)
(local $w4_0_22 v128)
(local $w4_0_23 v128)
(local $w4_0_24 v128)
(local $w4_0_25 v128)
(local $w4_0_26 v128)
(local $w4_0_27 v128)
(local $w4_0_28 v128)
(local $w4_0_29 v128)
(local $w4_0_30 v128)
(local $w4_0_31 v128)
(local $p0_5 v128)
(local $w5_0_0 v128)
(local $w5_0_1 v128)
(local $w5_0_2 v128)
(local $w5_0_3 v128)
(local $w5_0_4 v128)
(local $w5_0_5 v128)
(local $w5_0_6 v128)
(local $w5_0_7 v128)
(local $w5_0_8 v128)
(local $w5_0_9 v128)
(local $w5_0_10 v128)
(local $w5_0_11 v128)
(local $w5_0_12 v128)
(local $w5_0_13 v128)
(local $w5_0_14 v128)
(local $w5_0_15 v128)
(local $w5_0_16 v128)
(local $w5_0_17 v128)
(local $w5_0_18 v128)
(local $w5_0_19 v128)
(local $w5_0_20 v128)
(local $w5_0_21 v128)
(local $w5_0_22 v128)
(local $w5_0_23 v128)
(local $w5_0_24 v128)
(local $w5_0_25 v128)
(local $w5_0_26 v128)
(local $w5_0_27 v128)
(local $w5_0_28 v128)
(local $w5_0_29 v128)
(local $w5_0_30 v128)
(local $w5_0_31 v128)
(local $p0_6 v128)
(local $w6_0_0 v128)
(local $w6_0_1 v128)
(local $w6_0_2 v128)
(local $w6_0_3 v128)
(local $w6_0_4 v128)
(local $w6_0_5 v128)
(local $w6_0_6 v128)
(local $w6_0_7 v128)
(local $w6_0_8 v128)
(local $w6_0_9 v128)
(local $w6_0_10 v128)
(local $w6_0_11 v128)
(local $w6_0_12 v128)
(local $w6_0_13 v128)
(local $w6_0_14 v128)
(local $w6_0_15 v128)
(local $w6_0_16 v128)
(local $w6_0_17 v128)
(local $w6_0_18 v128)
(local $w6_0_19 v128)
(local $w6_0_20 v128)
(local $w6_0_21 v128)
(local $w6_0_22 v128)
(local $w6_0_23 v128)
(local $w6_0_24 v128)
(local $w6_0_25 v128)
(local $w6_0_26 v128)
(local $w6_0_27 v128)
(local $w6_0_28 v128)
(local $w6_0_29 v128)
(local $w6_0_30 v128)
(local $w6_0_31 v128)
(local $p0_7 v128)
(local $w7_0_0 v128)
(local $w7_0_1 v128)
(local $w7_0_2 v128)
(local $w7_0_3 v128)
(local $w7_0_4 v128)
(local $w7_0_5 v128)
(local $w7_0_6 v128)
(local $w7_0_7 v128)
(local $w7_0_8 v128)
(local $w7_0_9 v128)
(local $w7_0_10 v128)
(local $w7_0_11 v128)
(local $w7_0_12 v128)
(local $w7_0_13 v128)
(local $w7_0_14 v128)
(local $w7_0_15 v128)
(local $w7_0_16 v128)
(local $w7_0_17 v128)
(local $w7_0_18 v128)
(local $w7_0_19 v128)
(local $w7_0_20 v128)
(local $w7_0_21 v128)
(local $w7_0_22 v128)
(local $w7_0_23 v128)
(local $w7_0_24 v128)
(local $w7_0_25 v128)
(local $w7_0_26 v128)
(local $w7_0_27 v128)
(local $w7_0_28 v128)
(local $w7_0_29 v128)
(local $w7_0_30 v128)
(local $w7_0_31 v128)
(local $p0_8 v128)
(local $w8_0_0 v128)
(local $w8_0_1 v128)
(local $w8_0_2 v128)
(local $w8_0_3 v128)
(local $w8_0_4 v128)
(local $w8_0_5 v128)
(local $w8_0_6 v128)
(local $w8_0_7 v128)
(local $w8_0_8 v128)
(local $w8_0_9 v128)
(local $w8_0_10 v128)
(local $w8_0_11 v128)
(local $w8_0_12 v128)
(local $w8_0_13 v128)
(local $w8_0_14 v128)
(local $w8_0_15 v128)
(local $w8_0_16 v128)
(local $w8_0_17 v128)
(local $w8_0_18 v128)
(local $w8_0_19 v128)
(local $w8_0_20 v128)
(local $w8_0_21 v128)
(local $w8_0_22 v128)
(local $w8_0_23 v128)
(local $w8_0_24 v128)
(local $w8_0_25 v128)
(local $w8_0_26 v128)
(local $w8_0_27 v128)
(local $w8_0_28 v128)
(local $w8_0_29 v128)
(local $w8_0_30 v128)
(local $w8_0_31 v128)
(local $p0_9 v128)
(local $w9_0_0 v128)
(local $w9_0_1 v128)
(local $w9_0_2 v128)
(local $w9_0_3 v128)
(local $w9_0_4 v128)
(local $w9_0_5 v128)
(local $w9_0_6 v128)
(local $w9_0_7 v128)
(local $w9_0_8 v128)
(local $w9_0_9 v128)
(local $w9_0_10 v128)
(local $w9_0_11 v128)
(local $w9_0_12 v128)
(local $w9_0_13 v128)
(local $w9_0_14 v128)
(local $w9_0_15 v128)
(local $w9_0_16 v128)
(local $w9_0_17 v128)
(local $w9_0_18 v128)
(local $w9_0_19 v128)
(local $w9_0_20 v128)
(local $w9_0_21 v128)
(local $w9_0_22 v128)
(local $w9_0_23 v128)
(local $w9_0_24 v128)
(local $w9_0_25 v128)
(local $w9_0_26 v128)
(local $w9_0_27 v128)
(local $w9_0_28 v128)
(local $w9_0_29 v128)
(local $w9_0_30 v128)
(local $w9_0_31 v128)
(local $p0_10 v128)
(local $w10_0_0 v128)
(local $w10_0_1 v128)
(local $w10_0_2 v128)
(local $w10_0_3 v128)
(local $w10_0_4 v128)
(local $w10_0_5 v128)
(local $w10_0_6 v128)
(local $w10_0_7 v128)
(local $w10_0_8 v128)
(local $w10_0_9 v128)
(local $w10_0_10 v128)
(local $w10_0_11 v128)
(local $w10_0_12 v128)
(local $w10_0_13 v128)
(local $w10_0_14 v128)
(local $w10_0_15 v128)
(local $w10_0_16 v128)
(local $w10_0_17 v128)
(local $w10_0_18 v128)
(local $w10_0_19 v128)
(local $w10_0_20 v128)
(local $w10_0_21 v128)
(local $w10_0_22 v128)
(local $w10_0_23 v128)
(local $w10_0_24 v128)
(local $w10_0_25 v128)
(local $w10_0_26 v128)
(local $w10_0_27 v128)
(local $w10_0_28 v128)
(local $w10_0_29 v128)
(local $w10_0_30 v128)
(local $w10_0_31 v128)
(local $p0_11 v128)
(local $w11_0_0 v128)
(local $w11_0_1 v128)
(local $w11_0_2 v128)
(local $w11_0_3 v128)
(local $w11_0_4 v128)
(local $w11_0_5 v128)
(local $w11_0_6 v128)
(local $w11_0_7 v128)
(local $w11_0_8 v128)
(local $w11_0_9 v128)
(local $w11_0_10 v128)
(local $w11_0_11 v128)
(local $w11_0_12 v128)
(local $w11_0_13 v128)
(local $w11_0_14 v128)
(local $w11_0_15 v128)
(local $w11_0_16 v128)
(local $w11_0_17 v128)
(local $w11_0_18 v128)
(local $w11_0_19 v128)
(local $w11_0_20 v128)
(local $w11_0_21 v128)
(local $w11_0_22 v128)
(local $w11_0_23 v128)
(local $w11_0_24 v128)
(local $w11_0_25 v128)
(local $w11_0_26 v128)
(local $w11_0_27 v128)
(local $w11_0_28 v128)
(local $w11_0_29 v128)
(local $w11_0_30 v128)
(local $w11_0_31 v128)
(local $p0_12 v128)
(local $w12_0_0 v128)
(local $w12_0_1 v128)
(local $w12_0_2 v128)
(local $w12_0_3 v128)
(local $w12_0_4 v128)
(local $w12_0_5 v128)
(local $w12_0_6 v128)
(local $w12_0_7 v128)
(local $w12_0_8 v128)
(local $w12_0_9 v128)
(local $w12_0_10 v128)
(local $w12_0_11 v128)
(local $w12_0_12 v128)
(local $w12_0_13 v128)
(local $w12_0_14 v128)
(local $w12_0_15 v128)
(local $w12_0_16 v128)
(local $w12_0_17 v128)
(local $w12_0_18 v128)
(local $w12_0_19 v128)
(local $w12_0_20 v128)
(local $w12_0_21 v128)
(local $w12_0_22 v128)
(local $w12_0_23 v128)
(local $w12_0_24 v128)
(local $w12_0_25 v128)
(local $w12_0_26 v128)
(local $w12_0_27 v128)
(local $w12_0_28 v128)
(local $w12_0_29 v128)
(local $w12_0_30 v128)
(local $w12_0_31 v128)
(local $p0_13 v128)
(local $w13_0_0 v128)
(local $w13_0_1 v128)
(local $w13_0_2 v128)
(local $w13_0_3 v128)
(local $w13_0_4 v128)
(local $w13_0_5 v128)
(local $w13_0_6 v128)
(local $w13_0_7 v128)
(local $w13_0_8 v128)
(local $w13_0_9 v128)
(local $w13_0_10 v128)
(local $w13_0_11 v128)
(local $w13_0_12 v128)
(local $w13_0_13 v128)
(local $w13_0_14 v128)
(local $w13_0_15 v128)
(local $w13_0_16 v128)
(local $w13_0_17 v128)
(local $w13_0_18 v128)
(local $w13_0_19 v128)
(local $w13_0_20 v128)
(local $w13_0_21 v128)
(local $w13_0_22 v128)
(local $w13_0_23 v128)
(local $w13_0_24 v128)
(local $w13_0_25 v128)
(local $w13_0_26 v128)
(local $w13_0_27 v128)
(local $w13_0_28 v128)
(local $w13_0_29 v128)
(local $w13_0_30 v128)
(local $w13_0_31 v128)
(local $p0_14 v128)
(local $w14_0_0 v128)
(local $w14_0_1 v128)
(local $w14_0_2 v128)
(local $w14_0_3 v128)
(local $w14_0_4 v128)
(local $w14_0_5 v128)
(local $w14_0_6 v128)
(local $w14_0_7 v128)
(local $w14_0_8 v128)
(local $w14_0_9 v128)
(local $w14_0_10 v128)
(local $w14_0_11 v128)
(local $w14_0_12 v128)
(local $w14_0_13 v128)
(local $w14_0_14 v128)
(local $w14_0_15 v128)
(local $w14_0_16 v128)
(local $w14_0_17 v128)
(local $w14_0_18 v128)
(local $w14_0_19 v128)
(local $w14_0_20 v128)
(local $w14_0_21 v128)
(local $w14_0_22 v128)
(local $w14_0_23 v128)
(local $w14_0_24 v128)
(local $w14_0_25 v128)
(local $w14_0_26 v128)
(local $w14_0_27 v128)
(local $w14_0_28 v128)
(local $w14_0_29 v128)
(local $w14_0_30 v128)
(local $w14_0_31 v128)
(local $p0_15 v128)
(local $w15_0_0 v128)
(local $w15_0_1 v128)
(local $w15_0_2 v128)
(local $w15_0_3 v128)
(local $w15_0_4 v128)
(local $w15_0_5 v128)
(local $w15_0_6 v128)
(local $w15_0_7 v128)
(local $w15_0_8 v128)
(local $w15_0_9 v128)
(local $w15_0_10 v128)
(local $w15_0_11 v128)
(local $w15_0_12 v128)
(local $w15_0_13 v128)
(local $w15_0_14 v128)
(local $w15_0_15 v128)
(local $w15_0_16 v128)
(local $w15_0_17 v128)
(local $w15_0_18 v128)
(local $w15_0_19 v128)
(local $w15_0_20 v128)
(local $w15_0_21 v128)
(local $w15_0_22 v128)
(local $w15_0_23 v128)
(local $w15_0_24 v128)
(local $w15_0_25 v128)
(local $w15_0_26 v128)
(local $w15_0_27 v128)
(local $w15_0_28 v128)
(local $w15_0_29 v128)
(local $w15_0_30 v128)
(local $w15_0_31 v128)
(local $p0_16 v128)
(local $w16_0_0 v128)
(local $w16_0_1 v128)
(local $w16_0_2 v128)
(local $w16_0_3 v128)
(local $w16_0_4 v128)
(local $w16_0_5 v128)
(local $w16_0_6 v128)
(local $w16_0_7 v128)
(local $w16_0_8 v128)
(local $w16_0_9 v128)
(local $w16_0_10 v128)
(local $w16_0_11 v128)
(local $w16_0_12 v128)
(local $w16_0_13 v128)
(local $w16_0_14 v128)
(local $w16_0_15 v128)
(local $w16_0_16 v128)
(local $w16_0_17 v128)
(local $w16_0_18 v128)
(local $w16_0_19 v128)
(local $w16_0_20 v128)
(local $w16_0_21 v128)
(local $w16_0_22 v128)
(local $w16_0_23 v128)
(local $w16_0_24 v128)
(local $w16_0_25 v128)
(local $w16_0_26 v128)
(local $w16_0_27 v128)
(local $w16_0_28 v128)
(local $w16_0_29 v128)
(local $w16_0_30 v128)
(local $w16_0_31 v128)
(local $p0_17 v128)
(local $w17_0_0 v128)
(local $w17_0_1 v128)
(local $w17_0_2 v128)
(local $w17_0_3 v128)
(local $w17_0_4 v128)
(local $w17_0_5 v128)
(local $w17_0_6 v128)
(local $w17_0_7 v128)
(local $w17_0_8 v128)
(local $w17_0_9 v128)
(local $w17_0_10 v128)
(local $w17_0_11 v128)
(local $w17_0_12 v128)
(local $w17_0_13 v128)
(local $w17_0_14 v128)
(local $w17_0_15 v128)
(local $w17_0_16 v128)
(local $w17_0_17 v128)
(local $w17_0_18 v128)
(local $w17_0_19 v128)
(local $w17_0_20 v128)
(local $w17_0_21 v128)
(local $w17_0_22 v128)
(local $w17_0_23 v128)
(local $w17_0_24 v128)
(local $w17_0_25 v128)
(local $w17_0_26 v128)
(local $w17_0_27 v128)
(local $w17_0_28 v128)
(local $w17_0_29 v128)
(local $w17_0_30 v128)
(local $w17_0_31 v128)
(local $p0_18 v128)
(local $w18_0_0 v128)
(local $w18_0_1 v128)
(local $w18_0_2 v128)
(local $w18_0_3 v128)
(local $w18_0_4 v128)
(local $w18_0_5 v128)
(local $w18_0_6 v128)
(local $w18_0_7 v128)
(local $w18_0_8 v128)
(local $w18_0_9 v128)
(local $w18_0_10 v128)
(local $w18_0_11 v128)
(local $w18_0_12 v128)
(local $w18_0_13 v128)
(local $w18_0_14 v128)
(local $w18_0_15 v128)
(local $w18_0_16 v128)
(local $w18_0_17 v128)
(local $w18_0_18 v128)
(local $w18_0_19 v128)
(local $w18_0_20 v128)
(local $w18_0_21 v128)
(local $w18_0_22 v128)
(local $w18_0_23 v128)
(local $w18_0_24 v128)
(local $w18_0_25 v128)
(local $w18_0_26 v128)
(local $w18_0_27 v128)
(local $w18_0_28 v128)
(local $w18_0_29 v128)
(local $w18_0_30 v128)
(local $w18_0_31 v128)
(local $p0_19 v128)
(local $w19_0_0 v128)
(local $w19_0_1 v128)
(local $w19_0_2 v128)
(local $w19_0_3 v128)
(local $w19_0_4 v128)
(local $w19_0_5 v128)
(local $w19_0_6 v128)
(local $w19_0_7 v128)
(local $w19_0_8 v128)
(local $w19_0_9 v128)
(local $w19_0_10 v128)
(local $w19_0_11 v128)
(local $w19_0_12 v128)
(local $w19_0_13 v128)
(local $w19_0_14 v128)
(local $w19_0_15 v128)
(local $w19_0_16 v128)
(local $w19_0_17 v128)
(local $w19_0_18 v128)
(local $w19_0_19 v128)
(local $w19_0_20 v128)
(local $w19_0_21 v128)
(local $w19_0_22 v128)
(local $w19_0_23 v128)
(local $w19_0_24 v128)
(local $w19_0_25 v128)
(local $w19_0_26 v128)
(local $w19_0_27 v128)
(local $w19_0_28 v128)
(local $w19_0_29 v128)
(local $w19_0_30 v128)
(local $w19_0_31 v128)
(local $p0_20 v128)
(local $w20_0_0 v128)
(local $w20_0_1 v128)
(local $w20_0_2 v128)
(local $w20_0_3 v128)
(local $w20_0_4 v128)
(local $w20_0_5 v128)
(local $w20_0_6 v128)
(local $w20_0_7 v128)
(local $w20_0_8 v128)
(local $w20_0_9 v128)
(local $w20_0_10 v128)
(local $w20_0_11 v128)
(local $w20_0_12 v128)
(local $w20_0_13 v128)
(local $w20_0_14 v128)
(local $w20_0_15 v128)
(local $w20_0_16 v128)
(local $w20_0_17 v128)
(local $w20_0_18 v128)
(local $w20_0_19 v128)
(local $w20_0_20 v128)
(local $w20_0_21 v128)
(local $w20_0_22 v128)
(local $w20_0_23 v128)
(local $w20_0_24 v128)
(local $w20_0_25 v128)
(local $w20_0_26 v128)
(local $w20_0_27 v128)
(local $w20_0_28 v128)
(local $w20_0_29 v128)
(local $w20_0_30 v128)
(local $w20_0_31 v128)
(local $p0_21 v128)
(local $w21_0_0 v128)
(local $w21_0_1 v128)
(local $w21_0_2 v128)
(local $w21_0_3 v128)
(local $w21_0_4 v128)
(local $w21_0_5 v128)
(local $w21_0_6 v128)
(local $w21_0_7 v128)
(local $w21_0_8 v128)
(local $w21_0_9 v128)
(local $w21_0_10 v128)
(local $w21_0_11 v128)
(local $w21_0_12 v128)
(local $w21_0_13 v128)
(local $w21_0_14 v128)
(local $w21_0_15 v128)
(local $w21_0_16 v128)
(local $w21_0_17 v128)
(local $w21_0_18 v128)
(local $w21_0_19 v128)
(local $w21_0_20 v128)
(local $w21_0_21 v128)
(local $w21_0_22 v128)
(local $w21_0_23 v128)
(local $w21_0_24 v128)
(local $w21_0_25 v128)
(local $w21_0_26 v128)
(local $w21_0_27 v128)
(local $w21_0_28 v128)
(local $w21_0_29 v128)
(local $w21_0_30 v128)
(local $w21_0_31 v128)
(local $p0_22 v128)
(local $w22_0_0 v128)
(local $w22_0_1 v128)
(local $w22_0_2 v128)
(local $w22_0_3 v128)
(local $w22_0_4 v128)
(local $w22_0_5 v128)
(local $w22_0_6 v128)
(local $w22_0_7 v128)
(local $w22_0_8 v128)
(local $w22_0_9 v128)
(local $w22_0_10 v128)
(local $w22_0_11 v128)
(local $w22_0_12 v128)
(local $w22_0_13 v128)
(local $w22_0_14 v128)
(local $w22_0_15 v128)
(local $w22_0_16 v128)
(local $w22_0_17 v128)
(local $w22_0_18 v128)
(local $w22_0_19 v128)
(local $w22_0_20 v128)
(local $w22_0_21 v128)
(local $w22_0_22 v128)
(local $w22_0_23 v128)
(local $w22_0_24 v128)
(local $w22_0_25 v128)
(local $w22_0_26 v128)
(local $w22_0_27 v128)
(local $w22_0_28 v128)
(local $w22_0_29 v128)
(local $w22_0_30 v128)
(local $w22_0_31 v128)
(local $p0_23 v128)
(local $w23_0_0 v128)
(local $w23_0_1 v128)
(local $w23_0_2 v128)
(local $w23_0_3 v128)
(local $w23_0_4 v128)
(local $w23_0_5 v128)
(local $w23_0_6 v128)
(local $w23_0_7 v128)
(local $w23_0_8 v128)
(local $w23_0_9 v128)
(local $w23_0_10 v128)
(local $w23_0_11 v128)
(local $w23_0_12 v128)
(local $w23_0_13 v128)
(local $w23_0_14 v128)
(local $w23_0_15 v128)
(local $w23_0_16 v128)
(local $w23_0_17 v128)
(local $w23_0_18 v128)
(local $w23_0_19 v128)
(local $w23_0_20 v128)
(local $w23_0_21 v128)
(local $w23_0_22 v128)
(local $w23_0_23 v128)
(local $w23_0_24 v128)
(local $w23_0_25 v128)
(local $w23_0_26 v128)
(local $w23_0_27 v128)
(local $w23_0_28 v128)
(local $w23_0_29 v128)
(local $w23_0_30 v128)
(local $w23_0_31 v128)
(local $p0_24 v128)
(local $w24_0_0 v128)
(local $w24_0_1 v128)
(local $w24_0_2 v128)
(local $w24_0_3 v128)
(local $w24_0_4 v128)
(local $w24_0_5 v128)
(local $w24_0_6 v128)
(local $w24_0_7 v128)
(local $w24_0_8 v128)
(local $w24_0_9 v128)
(local $w24_0_10 v128)
(local $w24_0_11 v128)
(local $w24_0_12 v128)
(local $w24_0_13 v128)
(local $w24_0_14 v128)
(local $w24_0_15 v128)
(local $w24_0_16 v128)
(local $w24_0_17 v128)
(local $w24_0_18 v128)
(local $w24_0_19 v128)
(local $w24_0_20 v128)
(local $w24_0_21 v128)
(local $w24_0_22 v128)
(local $w24_0_23 v128)
(local $w24_0_24 v128)
(local $w24_0_25 v128)
(local $w24_0_26 v128)
(local $w24_0_27 v128)
(local $w24_0_28 v128)
(local $w24_0_29 v128)
(local $w24_0_30 v128)
(local $w24_0_31 v128)
(local $p0_25 v128)
(local $w25_0_0 v128)
(local $w25_0_1 v128)
(local $w25_0_2 v128)
(local $w25_0_3 v128)
(local $w25_0_4 v128)
(local $w25_0_5 v128)
(local $w25_0_6 v128)
(local $w25_0_7 v128)
(local $w25_0_8 v128)
(local $w25_0_9 v128)
(local $w25_0_10 v128)
(local $w25_0_11 v128)
(local $w25_0_12 v128)
(local $w25_0_13 v128)
(local $w25_0_14 v128)
(local $w25_0_15 v128)
(local $w25_0_16 v128)
(local $w25_0_17 v128)
(local $w25_0_18 v128)
(local $w25_0_19 v128)
(local $w25_0_20 v128)
(local $w25_0_21 v128)
(local $w25_0_22 v128)
(local $w25_0_23 v128)
(local $w25_0_24 v128)
(local $w25_0_25 v128)
(local $w25_0_26 v128)
(local $w25_0_27 v128)
(local $w25_0_28 v128)
(local $w25_0_29 v128)
(local $w25_0_30 v128)
(local $w25_0_31 v128)
(local $p0_26 v128)
(local $w26_0_0 v128)
(local $w26_0_1 v128)
(local $w26_0_2 v128)
(local $w26_0_3 v128)
(local $w26_0_4 v128)
(local $w26_0_5 v128)
(local $w26_0_6 v128)
(local $w26_0_7 v128)
(local $w26_0_8 v128)
(local $w26_0_9 v128)
(local $w26_0_10 v128)
(local $w26_0_11 v128)
(local $w26_0_12 v128)
(local $w26_0_13 v128)
(local $w26_0_14 v128)
(local $w26_0_15 v128)
(local $w26_0_16 v128)
(local $w26_0_17 v128)
(local $w26_0_18 v128)
(local $w26_0_19 v128)
(local $w26_0_20 v128)
(local $w26_0_21 v128)
(local $w26_0_22 v128)
(local $w26_0_23 v128)
(local $w26_0_24 v128)
(local $w26_0_25 v128)
(local $w26_0_26 v128)
(local $w26_0_27 v128)
(local $w26_0_28 v128)
(local $w26_0_29 v128)
(local $w26_0_30 v128)
(local $w26_0_31 v128)
(local $p0_27 v128)
(local $w27_0_0 v128)
(local $w27_0_1 v128)
(local $w27_0_2 v128)
(local $w27_0_3 v128)
(local $w27_0_4 v128)
(local $w27_0_5 v128)
(local $w27_0_6 v128)
(local $w27_0_7 v128)
(local $w27_0_8 v128)
(local $w27_0_9 v128)
(local $w27_0_10 v128)
(local $w27_0_11 v128)
(local $w27_0_12 v128)
(local $w27_0_13 v128)
(local $w27_0_14 v128)
(local $w27_0_15 v128)
(local $w27_0_16 v128)
(local $w27_0_17 v128)
(local $w27_0_18 v128)
(local $w27_0_19 v128)
(local $w27_0_20 v128)
(local $w27_0_21 v128)
(local $w27_0_22 v128)
(local $w27_0_23 v128)
(local $w27_0_24 v128)
(local $w27_0_25 v128)
(local $w27_0_26 v128)
(local $w27_0_27 v128)
(local $w27_0_28 v128)
(local $w27_0_29 v128)
(local $w27_0_30 v128)
(local $w27_0_31 v128)
(local $p0_28 v128)
(local $w28_0_0 v128)
(local $w28_0_1 v128)
(local $w28_0_2 v128)
(local $w28_0_3 v128)
(local $w28_0_4 v128)
(local $w28_0_5 v128)
(local $w28_0_6 v128)
(local $w28_0_7 v128)
(local $w28_0_8 v128)
(local $w28_0_9 v128)
(local $w28_0_10 v128)
(local $w28_0_11 v128)
(local $w28_0_12 v128)
(local $w28_0_13 v128)
(local $w28_0_14 v128)
(local $w28_0_15 v128)
(local $w28_0_16 v128)
(local $w28_0_17 v128)
(local $w28_0_18 v128)
(local $w28_0_19 v128)
(local $w28_0_20 v128)
(local $w28_0_21 v128)
(local $w28_0_22 v128)
(local $w28_0_23 v128)
(local $w28_0_24 v128)
(local $w28_0_25 v128)
(local $w28_0_26 v128)
(local $w28_0_27 v128)
(local $w28_0_28 v128)
(local $w28_0_29 v128)
(local $w28_0_30 v128)
(local $w28_0_31 v128)
(local $p0_29 v128)
(local $w29_0_0 v128)
(local $w29_0_1 v128)
(local $w29_0_2 v128)
(local $w29_0_3 v128)
(local $w29_0_4 v128)
(local $w29_0_5 v128)
(local $w29_0_6 v128)
(local $w29_0_7 v128)
(local $w29_0_8 v128)
(local $w29_0_9 v128)
(local $w29_0_10 v128)
(local $w29_0_11 v128)
(local $w29_0_12 v128)
(local $w29_0_13 v128)
(local $w29_0_14 v128)
(local $w29_0_15 v128)
(local $w29_0_16 v128)
(local $w29_0_17 v128)
(local $w29_0_18 v128)
(local $w29_0_19 v128)
(local $w29_0_20 v128)
(local $w29_0_21 v128)
(local $w29_0_22 v128)
(local $w29_0_23 v128)
(local $w29_0_24 v128)
(local $w29_0_25 v128)
(local $w29_0_26 v128)
(local $w29_0_27 v128)
(local $w29_0_28 v128)
(local $w29_0_29 v128)
(local $w29_0_30 v128)
(local $w29_0_31 v128)
(local $p0_30 v128)
(local $w30_0_0 v128)
(local $w30_0_1 v128)
(local $w30_0_2 v128)
(local $w30_0_3 v128)
(local $w30_0_4 v128)
(local $w30_0_5 v128)
(local $w30_0_6 v128)
(local $w30_0_7 v128)
(local $w30_0_8 v128)
(local $w30_0_9 v128)
(local $w30_0_10 v128)
(local $w30_0_11 v128)
(local $w30_0_12 v128)
(local $w30_0_13 v128)
(local $w30_0_14 v128)
(local $w30_0_15 v128)
(local $w30_0_16 v128)
(local $w30_0_17 v128)
(local $w30_0_18 v128)
(local $w30_0_19 v128)
(local $w30_0_20 v128)
(local $w30_0_21 v128)
(local $w30_0_22 v128)
(local $w30_0_23 v128)
(local $w30_0_24 v128)
(local $w30_0_25 v128)
(local $w30_0_26 v128)
(local $w30_0_27 v128)
(local $w30_0_28 v128)
(local $w30_0_29 v128)
(local $w30_0_30 v128)
(local $w30_0_31 v128)
(local $p0_31 v128)
(local $w31_0_0 v128)
(local $w31_0_1 v128)
(local $w31_0_2 v128)
(local $w31_0_3 v128)
(local $w31_0_4 v128)
(local $w31_0_5 v128)
(local $w31_0_6 v128)
(local $w31_0_7 v128)
(local $w31_0_8 v128)
(local $w31_0_9 v128)
(local $w31_0_10 v128)
(local $w31_0_11 v128)
(local $w31_0_12 v128)
(local $w31_0_13 v128)
(local $w31_0_14 v128)
(local $w31_0_15 v128)
(local $w31_0_16 v128)
(local $w31_0_17 v128)
(local $w31_0_18 v128)
(local $w31_0_19 v128)
(local $w31_0_20 v128)
(local $w31_0_21 v128)
(local $w31_0_22 v128)
(local $w31_0_23 v128)
(local $w31_0_24 v128)
(local $w31_0_25 v128)
(local $w31_0_26 v128)
(local $w31_0_27 v128)
(local $w31_0_28 v128)
(local $w31_0_29 v128)
(local $w31_0_30 v128)
(local $w31_0_31 v128)
(local $p0_32 v128)
(local $w32_0_0 v128)
(local $w32_0_1 v128)
(local $w32_0_2 v128)
(local $w32_0_3 v128)
(local $w32_0_4 v128)
(local $w32_0_5 v128)
(local $w32_0_6 v128)
(local $w32_0_7 v128)
(local $w32_0_8 v128)
(local $w32_0_9 v128)
(local $w32_0_10 v128)
(local $w32_0_11 v128)
(local $w32_0_12 v128)
(local $w32_0_13 v128)
(local $w32_0_14 v128)
(local $w32_0_15 v128)
(local $w32_0_16 v128)
(local $w32_0_17 v128)
(local $w32_0_18 v128)
(local $w32_0_19 v128)
(local $w32_0_20 v128)
(local $w32_0_21 v128)
(local $w32_0_22 v128)
(local $w32_0_23 v128)
(local $w32_0_24 v128)
(local $w32_0_25 v128)
(local $w32_0_26 v128)
(local $w32_0_27 v128)
(local $w32_0_28 v128)
(local $w32_0_29 v128)
(local $w32_0_30 v128)
(local $w32_0_31 v128)
(local $p0_33 v128)
(local $w33_0_0 v128)
(local $w33_0_1 v128)
(local $w33_0_2 v128)
(local $w33_0_3 v128)
(local $w33_0_4 v128)
(local $w33_0_5 v128)
(local $w33_0_6 v128)
(local $w33_0_7 v128)
(local $w33_0_8 v128)
(local $w33_0_9 v128)
(local $w33_0_10 v128)
(local $w33_0_11 v128)
(local $w33_0_12 v128)
(local $w33_0_13 v128)
(local $w33_0_14 v128)
(local $w33_0_15 v128)
(local $w33_0_16 v128)
(local $w33_0_17 v128)
(local $w33_0_18 v128)
(local $w33_0_19 v128)
(local $w33_0_20 v128)
(local $w33_0_21 v128)
(local $w33_0_22 v128)
(local $w33_0_23 v128)
(local $w33_0_24 v128)
(local $w33_0_25 v128)
(local $w33_0_26 v128)
(local $w33_0_27 v128)
(local $w33_0_28 v128)
(local $w33_0_29 v128)
(local $w33_0_30 v128)
(local $w33_0_31 v128)
(local $p0_34 v128)
(local $w34_0_0 v128)
(local $w34_0_1 v128)
(local $w34_0_2 v128)
(local $w34_0_3 v128)
(local $w34_0_4 v128)
(local $w34_0_5 v128)
(local $w34_0_6 v128)
(local $w34_0_7 v128)
(local $w34_0_8 v128)
(local $w34_0_9 v128)
(local $w34_0_10 v128)
(local $w34_0_11 v128)
(local $w34_0_12 v128)
(local $w34_0_13 v128)
(local $w34_0_14 v128)
(local $w34_0_15 v128)
(local $w34_0_16 v128)
(local $w34_0_17 v128)
(local $w34_0_18 v128)
(local $w34_0_19 v128)
(local $w34_0_20 v128)
(local $w34_0_21 v128)
(local $w34_0_22 v128)
(local $w34_0_23 v128)
(local $w34_0_24 v128)
(local $w34_0_25 v128)
(local $w34_0_26 v128)
(local $w34_0_27 v128)
(local $w34_0_28 v128)
(local $w34_0_29 v128)
(local $w34_0_30 v128)
(local $w34_0_31 v128)
(local $p0_35 v128)
(local $w35_0_0 v128)
(local $w35_0_1 v128)
(local $w35_0_2 v128)
(local $w35_0_3 v128)
(local $w35_0_4 v128)
(local $w35_0_5 v128)
(local $w35_0_6 v128)
(local $w35_0_7 v128)
(local $w35_0_8 v128)
(local $w35_0_9 v128)
(local $w35_0_10 v128)
(local $w35_0_11 v128)
(local $w35_0_12 v128)
(local $w35_0_13 v128)
(local $w35_0_14 v128)
(local $w35_0_15 v128)
(local $w35_0_16 v128)
(local $w35_0_17 v128)
(local $w35_0_18 v128)
(local $w35_0_19 v128)
(local $w35_0_20 v128)
(local $w35_0_21 v128)
(local $w35_0_22 v128)
(local $w35_0_23 v128)
(local $w35_0_24 v128)
(local $w35_0_25 v128)
(local $w35_0_26 v128)
(local $w35_0_27 v128)
(local $w35_0_28 v128)
(local $w35_0_29 v128)
(local $w35_0_30 v128)
(local $w35_0_31 v128)
(local $p0_36 v128)
(local $w36_0_0 v128)
(local $w36_0_1 v128)
(local $w36_0_2 v128)
(local $w36_0_3 v128)
(local $w36_0_4 v128)
(local $w36_0_5 v128)
(local $w36_0_6 v128)
(local $w36_0_7 v128)
(local $w36_0_8 v128)
(local $w36_0_9 v128)
(local $w36_0_10 v128)
(local $w36_0_11 v128)
(local $w36_0_12 v128)
(local $w36_0_13 v128)
(local $w36_0_14 v128)
(local $w36_0_15 v128)
(local $w36_0_16 v128)
(local $w36_0_17 v128)
(local $w36_0_18 v128)
(local $w36_0_19 v128)
(local $w36_0_20 v128)
(local $w36_0_21 v128)
(local $w36_0_22 v128)
(local $w36_0_23 v128)
(local $w36_0_24 v128)
(local $w36_0_25 v128)
(local $w36_0_26 v128)
(local $w36_0_27 v128)
(local $w36_0_28 v128)
(local $w36_0_29 v128)
(local $w36_0_30 v128)
(local $w36_0_31 v128)
(local $p0_37 v128)
(local $w37_0_0 v128)
(local $w37_0_1 v128)
(local $w37_0_2 v128)
(local $w37_0_3 v128)
(local $w37_0_4 v128)
(local $w37_0_5 v128)
(local $w37_0_6 v128)
(local $w37_0_7 v128)
(local $w37_0_8 v128)
(local $w37_0_9 v128)
(local $w37_0_10 v128)
(local $w37_0_11 v128)
(local $w37_0_12 v128)
(local $w37_0_13 v128)
(local $w37_0_14 v128)
(local $w37_0_15 v128)
(local $w37_0_16 v128)
(local $w37_0_17 v128)
(local $w37_0_18 v128)
(local $w37_0_19 v128)
(local $w37_0_20 v128)
(local $w37_0_21 v128)
(local $w37_0_22 v128)
(local $w37_0_23 v128)
(local $w37_0_24 v128)
(local $w37_0_25 v128)
(local $w37_0_26 v128)
(local $w37_0_27 v128)
(local $w37_0_28 v128)
(local $w37_0_29 v128)
(local $w37_0_30 v128)
(local $w37_0_31 v128)
(local $p0_38 v128)
(local $w38_0_0 v128)
(local $w38_0_1 v128)
(local $w38_0_2 v128)
(local $w38_0_3 v128)
(local $w38_0_4 v128)
(local $w38_0_5 v128)
(local $w38_0_6 v128)
(local $w38_0_7 v128)
(local $w38_0_8 v128)
(local $w38_0_9 v128)
(local $w38_0_10 v128)
(local $w38_0_11 v128)
(local $w38_0_12 v128)
(local $w38_0_13 v128)
(local $w38_0_14 v128)
(local $w38_0_15 v128)
(local $w38_0_16 v128)
(local $w38_0_17 v128)
(local $w38_0_18 v128)
(local $w38_0_19 v128)
(local $w38_0_20 v128)
(local $w38_0_21 v128)
(local $w38_0_22 v128)
(local $w38_0_23 v128)
(local $w38_0_24 v128)
(local $w38_0_25 v128)
(local $w38_0_26 v128)
(local $w38_0_27 v128)
(local $w38_0_28 v128)
(local $w38_0_29 v128)
(local $w38_0_30 v128)
(local $w38_0_31 v128)
(local $p0_39 v128)
(local $w39_0_0 v128)
(local $w39_0_1 v128)
(local $w39_0_2 v128)
(local $w39_0_3 v128)
(local $w39_0_4 v128)
(local $w39_0_5 v128)
(local $w39_0_6 v128)
(local $w39_0_7 v128)
(local $w39_0_8 v128)
(local $w39_0_9 v128)
(local $w39_0_10 v128)
(local $w39_0_11 v128)
(local $w39_0_12 v128)
(local $w39_0_13 v128)
(local $w39_0_14 v128)
(local $w39_0_15 v128)
(local $w39_0_16 v128)
(local $w39_0_17 v128)
(local $w39_0_18 v128)
(local $w39_0_19 v128)
(local $w39_0_20 v128)
(local $w39_0_21 v128)
(local $w39_0_22 v128)
(local $w39_0_23 v128)
(local $w39_0_24 v128)
(local $w39_0_25 v128)
(local $w39_0_26 v128)
(local $w39_0_27 v128)
(local $w39_0_28 v128)
(local $w39_0_29 v128)
(local $w39_0_30 v128)
(local $w39_0_31 v128)
(local $p0_40 v128)
(local $w40_0_0 v128)
(local $w40_0_1 v128)
(local $w40_0_2 v128)
(local $w40_0_3 v128)
(local $w40_0_4 v128)
(local $w40_0_5 v128)
(local $w40_0_6 v128)
(local $w40_0_7 v128)
(local $w40_0_8 v128)
(local $w40_0_9 v128)
(local $w40_0_10 v128)
(local $w40_0_11 v128)
(local $w40_0_12 v128)
(local $w40_0_13 v128)
(local $w40_0_14 v128)
(local $w40_0_15 v128)
(local $w40_0_16 v128)
(local $w40_0_17 v128)
(local $w40_0_18 v128)
(local $w40_0_19 v128)
(local $w40_0_20 v128)
(local $w40_0_21 v128)
(local $w40_0_22 v128)
(local $w40_0_23 v128)
(local $w40_0_24 v128)
(local $w40_0_25 v128)
(local $w40_0_26 v128)
(local $w40_0_27 v128)
(local $w40_0_28 v128)
(local $w40_0_29 v128)
(local $w40_0_30 v128)
(local $w40_0_31 v128)
(local $p0_41 v128)
(local $w41_0_0 v128)
(local $w41_0_1 v128)
(local $w41_0_2 v128)
(local $w41_0_3 v128)
(local $w41_0_4 v128)
(local $w41_0_5 v128)
(local $w41_0_6 v128)
(local $w41_0_7 v128)
(local $w41_0_8 v128)
(local $w41_0_9 v128)
(local $w41_0_10 v128)
(local $w41_0_11 v128)
(local $w41_0_12 v128)
(local $w41_0_13 v128)
(local $w41_0_14 v128)
(local $w41_0_15 v128)
(local $w41_0_16 v128)
(local $w41_0_17 v128)
(local $w41_0_18 v128)
(local $w41_0_19 v128)
(local $w41_0_20 v128)
(local $w41_0_21 v128)
(local $w41_0_22 v128)
(local $w41_0_23 v128)
(local $w41_0_24 v128)
(local $w41_0_25 v128)
(local $w41_0_26 v128)
(local $w41_0_27 v128)
(local $w41_0_28 v128)
(local $w41_0_29 v128)
(local $w41_0_30 v128)
(local $w41_0_31 v128)
(local $p0_42 v128)
(local $w42_0_0 v128)
(local $w42_0_1 v128)
(local $w42_0_2 v128)
(local $w42_0_3 v128)
(local $w42_0_4 v128)
(local $w42_0_5 v128)
(local $w42_0_6 v128)
(local $w42_0_7 v128)
(local $w42_0_8 v128)
(local $w42_0_9 v128)
(local $w42_0_10 v128)
(local $w42_0_11 v128)
(local $w42_0_12 v128)
(local $w42_0_13 v128)
(local $w42_0_14 v128)
(local $w42_0_15 v128)
(local $w42_0_16 v128)
(local $w42_0_17 v128)
(local $w42_0_18 v128)
(local $w42_0_19 v128)
(local $w42_0_20 v128)
(local $w42_0_21 v128)
(local $w42_0_22 v128)
(local $w42_0_23 v128)
(local $w42_0_24 v128)
(local $w42_0_25 v128)
(local $w42_0_26 v128)
(local $w42_0_27 v128)
(local $w42_0_28 v128)
(local $w42_0_29 v128)
(local $w42_0_30 v128)
(local $w42_0_31 v128)
(local $p0_43 v128)
(local $w43_0_0 v128)
(local $w43_0_1 v128)
(local $w43_0_2 v128)
(local $w43_0_3 v128)
(local $w43_0_4 v128)
(local $w43_0_5 v128)
(local $w43_0_6 v128)
(local $w43_0_7 v128)
(local $w43_0_8 v128)
(local $w43_0_9 v128)
(local $w43_0_10 v128)
(local $w43_0_11 v128)
(local $w43_0_12 v128)
(local $w43_0_13 v128)
(local $w43_0_14 v128)
(local $w43_0_15 v128)
(local $w43_0_16 v128)
(local $w43_0_17 v128)
(local $w43_0_18 v128)
(local $w43_0_19 v128)
(local $w43_0_20 v128)
(local $w43_0_21 v128)
(local $w43_0_22 v128)
(local $w43_0_23 v128)
(local $w43_0_24 v128)
(local $w43_0_25 v128)
(local $w43_0_26 v128)
(local $w43_0_27 v128)
(local $w43_0_28 v128)
(local $w43_0_29 v128)
(local $w43_0_30 v128)
(local $w43_0_31 v128)
(local $p0_44 v128)
(local $w44_0_0 v128)
(local $w44_0_1 v128)
(local $w44_0_2 v128)
(local $w44_0_3 v128)
(local $w44_0_4 v128)
(local $w44_0_5 v128)
(local $w44_0_6 v128)
(local $w44_0_7 v128)
(local $w44_0_8 v128)
(local $w44_0_9 v128)
(local $w44_0_10 v128)
(local $w44_0_11 v128)
(local $w44_0_12 v128)
(local $w44_0_13 v128)
(local $w44_0_14 v128)
(local $w44_0_15 v128)
(local $w44_0_16 v128)
(local $w44_0_17 v128)
(local $w44_0_18 v128)
(local $w44_0_19 v128)
(local $w44_0_20 v128)
(local $w44_0_21 v128)
(local $w44_0_22 v128)
(local $w44_0_23 v128)
(local $w44_0_24 v128)
(local $w44_0_25 v128)
(local $w44_0_26 v128)
(local $w44_0_27 v128)
(local $w44_0_28 v128)
(local $w44_0_29 v128)
(local $w44_0_30 v128)
(local $w44_0_31 v128)
(local $p0_45 v128)
(local $w45_0_0 v128)
(local $w45_0_1 v128)
(local $w45_0_2 v128)
(local $w45_0_3 v128)
(local $w45_0_4 v128)
(local $w45_0_5 v128)
(local $w45_0_6 v128)
(local $w45_0_7 v128)
(local $w45_0_8 v128)
(local $w45_0_9 v128)
(local $w45_0_10 v128)
(local $w45_0_11 v128)
(local $w45_0_12 v128)
(local $w45_0_13 v128)
(local $w45_0_14 v128)
(local $w45_0_15 v128)
(local $w45_0_16 v128)
(local $w45_0_17 v128)
(local $w45_0_18 v128)
(local $w45_0_19 v128)
(local $w45_0_20 v128)
(local $w45_0_21 v128)
(local $w45_0_22 v128)
(local $w45_0_23 v128)
(local $w45_0_24 v128)
(local $w45_0_25 v128)
(local $w45_0_26 v128)
(local $w45_0_27 v128)
(local $w45_0_28 v128)
(local $w45_0_29 v128)
(local $w45_0_30 v128)
(local $w45_0_31 v128)
(local $p0_46 v128)
(local $w46_0_0 v128)
(local $w46_0_1 v128)
(local $w46_0_2 v128)
(local $w46_0_3 v128)
(local $w46_0_4 v128)
(local $w46_0_5 v128)
(local $w46_0_6 v128)
(local $w46_0_7 v128)
(local $w46_0_8 v128)
(local $w46_0_9 v128)
(local $w46_0_10 v128)
(local $w46_0_11 v128)
(local $w46_0_12 v128)
(local $w46_0_13 v128)
(local $w46_0_14 v128)
(local $w46_0_15 v128)
(local $w46_0_16 v128)
(local $w46_0_17 v128)
(local $w46_0_18 v128)
(local $w46_0_19 v128)
(local $w46_0_20 v128)
(local $w46_0_21 v128)
(local $w46_0_22 v128)
(local $w46_0_23 v128)
(local $w46_0_24 v128)
(local $w46_0_25 v128)
(local $w46_0_26 v128)
(local $w46_0_27 v128)
(local $w46_0_28 v128)
(local $w46_0_29 v128)
(local $w46_0_30 v128)
(local $w46_0_31 v128)
(local $p0_47 v128)
(local $w47_0_0 v128)
(local $w47_0_1 v128)
(local $w47_0_2 v128)
(local $w47_0_3 v128)
(local $w47_0_4 v128)
(local $w47_0_5 v128)
(local $w47_0_6 v128)
(local $w47_0_7 v128)
(local $w47_0_8 v128)
(local $w47_0_9 v128)
(local $w47_0_10 v128)
(local $w47_0_11 v128)
(local $w47_0_12 v128)
(local $w47_0_13 v128)
(local $w47_0_14 v128)
(local $w47_0_15 v128)
(local $w47_0_16 v128)
(local $w47_0_17 v128)
(local $w47_0_18 v128)
(local $w47_0_19 v128)
(local $w47_0_20 v128)
(local $w47_0_21 v128)
(local $w47_0_22 v128)
(local $w47_0_23 v128)
(local $w47_0_24 v128)
(local $w47_0_25 v128)
(local $w47_0_26 v128)
(local $w47_0_27 v128)
(local $w47_0_28 v128)
(local $w47_0_29 v128)
(local $w47_0_30 v128)
(local $w47_0_31 v128)
(local $p0_48 v128)
(local $w48_0_0 v128)
(local $w48_0_1 v128)
(local $w48_0_2 v128)
(local $w48_0_3 v128)
(local $w48_0_4 v128)
(local $w48_0_5 v128)
(local $w48_0_6 v128)
(local $w48_0_7 v128)
(local $w48_0_8 v128)
(local $w48_0_9 v128)
(local $w48_0_10 v128)
(local $w48_0_11 v128)
(local $w48_0_12 v128)
(local $w48_0_13 v128)
(local $w48_0_14 v128)
(local $w48_0_15 v128)
(local $w48_0_16 v128)
(local $w48_0_17 v128)
(local $w48_0_18 v128)
(local $w48_0_19 v128)
(local $w48_0_20 v128)
(local $w48_0_21 v128)
(local $w48_0_22 v128)
(local $w48_0_23 v128)
(local $w48_0_24 v128)
(local $w48_0_25 v128)
(local $w48_0_26 v128)
(local $w48_0_27 v128)
(local $w48_0_28 v128)
(local $w48_0_29 v128)
(local $w48_0_30 v128)
(local $w48_0_31 v128)
(local $x0 v128)
(local $x1 v128)
(local $x2 v128)
(local $x3 v128)
(local $x4 v128)
(local $x5 v128)
(local $x6 v128)
(local $x7 v128)
(local $x8 v128)
(local $x9 v128)
(local $x10 v128)
(local $x11 v128)
(local $x12 v128)
(local $x13 v128)
(local $x14 v128)
(local $x15 v128)
(local $x16 v128)
(local $x17 v128)
(local $x18 v128)
(local $x19 v128)
(local $x20 v128)
(local $x21 v128)
(local $x22 v128)
(local $x23 v128)
(local $x24 v128)
(local $x25 v128)
(local $x26 v128)
(local $x27 v128)
(local $x28 v128)
(local $x29 v128)
(local $x30 v128)
(local $x31 v128)
(local $c0 v128)(local $u0 v128)(local $sx0 v128)
(local $c1 v128)(local $u1 v128)(local $sx1 v128)
(local $c2 v128)(local $u2 v128)(local $sx2 v128)
(local $c3 v128)(local $u3 v128)(local $sx3 v128)
(local $sw0 v128)
(local $sw1 v128)
(local $sw2 v128)
(local $sw3 v128)
(local.set $sw0(v128.load offset=0(local.get $sw)))
(local.set $sw1(v128.load offset=16(local.get $sw)))
(local.set $sw2(v128.load offset=32(local.get $sw)))
(local.set $sw3(v128.load offset=48(local.get $sw)))
(local.set $input_stride(i32.shr_u(local.get $cols)(i32.const 8)))
(local.set $output_bytes(i32.shl(local.get $stride)(i32.const 2)))
(local.set $wp0(i32.add(i32.load offset=0(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp1(i32.add(i32.load offset=4(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp2(i32.add(i32.load offset=8(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp3(i32.add(i32.load offset=12(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp4(i32.add(i32.load offset=16(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp5(i32.add(i32.load offset=20(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp6(i32.add(i32.load offset=24(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp7(i32.add(i32.load offset=28(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp8(i32.add(i32.load offset=32(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp9(i32.add(i32.load offset=36(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp10(i32.add(i32.load offset=40(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp11(i32.add(i32.load offset=44(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp12(i32.add(i32.load offset=48(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp13(i32.add(i32.load offset=52(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp14(i32.add(i32.load offset=56(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp15(i32.add(i32.load offset=60(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(block $done
(br_if $done(i32.eqz(local.get $n)))
(local.set $bp0(i32.add(local.get $wp0)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp1(i32.add(local.get $wp1)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp2(i32.add(local.get $wp2)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp3(i32.add(local.get $wp3)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp4(i32.add(local.get $wp4)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp5(i32.add(local.get $wp5)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp6(i32.add(local.get $wp6)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp7(i32.add(local.get $wp7)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp8(i32.add(local.get $wp8)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp9(i32.add(local.get $wp9)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp10(i32.add(local.get $wp10)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp11(i32.add(local.get $wp11)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp12(i32.add(local.get $wp12)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp13(i32.add(local.get $wp13)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp14(i32.add(local.get $wp14)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp15(i32.add(local.get $wp15)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $w0_0_0(v128.load8x8_s offset=0(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=0(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=0(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=0(local.get $bp3)))
(local.set $w1_0_0(v128.load8x8_s offset=0(local.get $bp4)))
(local.set $w2_0_0(v128.load8x8_s offset=0(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=0(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=0(local.get $bp7)))
(local.set $w7_0_0(v128.load8x8_s offset=0(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=0(local.get $bp9)))
(local.set $w14_0_0(v128.load8x8_s offset=0(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=0(local.get $bp11)))
(local.set $w8_0_0(v128.load8x8_s offset=0(local.get $bp12)))
(local.set $w9_0_0(v128.load8x8_s offset=0(local.get $bp13)))
(local.set $w15_0_0(v128.load8x8_s offset=0(local.get $bp14)))
(local.set $w16_0_0(v128.load8x8_s offset=0(local.get $bp15)))
local.get $b2
local.get $w0_0_0
i16x8.sub
local.set $w28_0_0
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_0
i16x8.sub
local.set $w29_0_0
local.get $b7
local.get $w2_0_0
i16x8.sub
local.set $w30_0_0
local.get $w14_0_0
local.get $w28_0_0
i16x8.sub
local.set $w35_0_0
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_0
local.get $w29_0_0
i16x8.sub
local.set $w36_0_0
local.get $w16_0_0
local.get $w30_0_0
i16x8.sub
local.set $w37_0_0
local.get $w14_0_0
local.get $b2
i16x8.sub
local.set $w42_0_0
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_0
local.get $b6
i16x8.sub
local.set $w43_0_0
local.get $w16_0_0
local.get $b7
i16x8.sub
local.set $w44_0_0
local.get $w35_0_0
local.get $w7_0_0
i16x8.sub
local.set $w21_0_0
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_0
local.get $w8_0_0
i16x8.sub
local.set $w22_0_0
local.get $w37_0_0
local.get $w9_0_0
i16x8.sub
local.set $w23_0_0
local.get $b1
local.get $w0_0_0
i16x8.sub
local.set $w4_0_0
local.get $w2_0_0
local.get $w4_0_0
i16x8.sub
local.set $w5_0_0
local.get $w2_0_0
local.get $b1
i16x8.sub
local.set $w6_0_0
local.get $w5_0_0
local.get $w1_0_0
i16x8.sub
local.set $w3_0_0
local.get $b9
local.get $w7_0_0
i16x8.sub
local.set $w11_0_0
local.get $w9_0_0
local.get $w11_0_0
i16x8.sub
local.set $w12_0_0
local.get $w9_0_0
local.get $b9
i16x8.sub
local.set $w13_0_0
local.get $w12_0_0
local.get $w8_0_0
i16x8.sub
local.set $w10_0_0
local.get $b11
local.get $w14_0_0
i16x8.sub
local.set $w18_0_0
local.get $w16_0_0
local.get $w18_0_0
i16x8.sub
local.set $w19_0_0
local.get $w16_0_0
local.get $b11
i16x8.sub
local.set $w20_0_0
local.get $w19_0_0
local.get $w15_0_0
i16x8.sub
local.set $w17_0_0
local.get $bd13
local.get $w21_0_0
i16x8.sub
local.set $w25_0_0
local.get $w23_0_0
local.get $w25_0_0
i16x8.sub
local.set $w26_0_0
local.get $w23_0_0
local.get $bd13
i16x8.sub
local.set $w27_0_0
local.get $w26_0_0
local.get $w22_0_0
i16x8.sub
local.set $w24_0_0
local.get $bd1
local.get $w28_0_0
i16x8.sub
local.set $w32_0_0
local.get $w30_0_0
local.get $w32_0_0
i16x8.sub
local.set $w33_0_0
local.get $w30_0_0
local.get $bd1
i16x8.sub
local.set $w34_0_0
local.get $w33_0_0
local.get $w29_0_0
i16x8.sub
local.set $w31_0_0
local.get $bd5
local.get $w35_0_0
i16x8.sub
local.set $w39_0_0
local.get $w37_0_0
local.get $w39_0_0
i16x8.sub
local.set $w40_0_0
local.get $w37_0_0
local.get $bd5
i16x8.sub
local.set $w41_0_0
local.get $w40_0_0
local.get $w36_0_0
i16x8.sub
local.set $w38_0_0
local.get $bd9
local.get $w42_0_0
i16x8.sub
local.set $w46_0_0
local.get $w44_0_0
local.get $w46_0_0
i16x8.sub
local.set $w47_0_0
local.get $w44_0_0
local.get $bd9
i16x8.sub
local.set $w48_0_0
local.get $w47_0_0
local.get $w43_0_0
i16x8.sub
local.set $w45_0_0
(local.set $w0_0_1(v128.load8x8_s offset=8(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=8(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=8(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=8(local.get $bp3)))
(local.set $w1_0_1(v128.load8x8_s offset=8(local.get $bp4)))
(local.set $w2_0_1(v128.load8x8_s offset=8(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=8(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=8(local.get $bp7)))
(local.set $w7_0_1(v128.load8x8_s offset=8(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=8(local.get $bp9)))
(local.set $w14_0_1(v128.load8x8_s offset=8(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=8(local.get $bp11)))
(local.set $w8_0_1(v128.load8x8_s offset=8(local.get $bp12)))
(local.set $w9_0_1(v128.load8x8_s offset=8(local.get $bp13)))
(local.set $w15_0_1(v128.load8x8_s offset=8(local.get $bp14)))
(local.set $w16_0_1(v128.load8x8_s offset=8(local.get $bp15)))
local.get $b2
local.get $w0_0_1
i16x8.sub
local.set $w28_0_1
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_1
i16x8.sub
local.set $w29_0_1
local.get $b7
local.get $w2_0_1
i16x8.sub
local.set $w30_0_1
local.get $w14_0_1
local.get $w28_0_1
i16x8.sub
local.set $w35_0_1
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_1
local.get $w29_0_1
i16x8.sub
local.set $w36_0_1
local.get $w16_0_1
local.get $w30_0_1
i16x8.sub
local.set $w37_0_1
local.get $w14_0_1
local.get $b2
i16x8.sub
local.set $w42_0_1
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_1
local.get $b6
i16x8.sub
local.set $w43_0_1
local.get $w16_0_1
local.get $b7
i16x8.sub
local.set $w44_0_1
local.get $w35_0_1
local.get $w7_0_1
i16x8.sub
local.set $w21_0_1
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_1
local.get $w8_0_1
i16x8.sub
local.set $w22_0_1
local.get $w37_0_1
local.get $w9_0_1
i16x8.sub
local.set $w23_0_1
local.get $b1
local.get $w0_0_1
i16x8.sub
local.set $w4_0_1
local.get $w2_0_1
local.get $w4_0_1
i16x8.sub
local.set $w5_0_1
local.get $w2_0_1
local.get $b1
i16x8.sub
local.set $w6_0_1
local.get $w5_0_1
local.get $w1_0_1
i16x8.sub
local.set $w3_0_1
local.get $b9
local.get $w7_0_1
i16x8.sub
local.set $w11_0_1
local.get $w9_0_1
local.get $w11_0_1
i16x8.sub
local.set $w12_0_1
local.get $w9_0_1
local.get $b9
i16x8.sub
local.set $w13_0_1
local.get $w12_0_1
local.get $w8_0_1
i16x8.sub
local.set $w10_0_1
local.get $b11
local.get $w14_0_1
i16x8.sub
local.set $w18_0_1
local.get $w16_0_1
local.get $w18_0_1
i16x8.sub
local.set $w19_0_1
local.get $w16_0_1
local.get $b11
i16x8.sub
local.set $w20_0_1
local.get $w19_0_1
local.get $w15_0_1
i16x8.sub
local.set $w17_0_1
local.get $bd13
local.get $w21_0_1
i16x8.sub
local.set $w25_0_1
local.get $w23_0_1
local.get $w25_0_1
i16x8.sub
local.set $w26_0_1
local.get $w23_0_1
local.get $bd13
i16x8.sub
local.set $w27_0_1
local.get $w26_0_1
local.get $w22_0_1
i16x8.sub
local.set $w24_0_1
local.get $bd1
local.get $w28_0_1
i16x8.sub
local.set $w32_0_1
local.get $w30_0_1
local.get $w32_0_1
i16x8.sub
local.set $w33_0_1
local.get $w30_0_1
local.get $bd1
i16x8.sub
local.set $w34_0_1
local.get $w33_0_1
local.get $w29_0_1
i16x8.sub
local.set $w31_0_1
local.get $bd5
local.get $w35_0_1
i16x8.sub
local.set $w39_0_1
local.get $w37_0_1
local.get $w39_0_1
i16x8.sub
local.set $w40_0_1
local.get $w37_0_1
local.get $bd5
i16x8.sub
local.set $w41_0_1
local.get $w40_0_1
local.get $w36_0_1
i16x8.sub
local.set $w38_0_1
local.get $bd9
local.get $w42_0_1
i16x8.sub
local.set $w46_0_1
local.get $w44_0_1
local.get $w46_0_1
i16x8.sub
local.set $w47_0_1
local.get $w44_0_1
local.get $bd9
i16x8.sub
local.set $w48_0_1
local.get $w47_0_1
local.get $w43_0_1
i16x8.sub
local.set $w45_0_1
(local.set $w0_0_2(v128.load8x8_s offset=16(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=16(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=16(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=16(local.get $bp3)))
(local.set $w1_0_2(v128.load8x8_s offset=16(local.get $bp4)))
(local.set $w2_0_2(v128.load8x8_s offset=16(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=16(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=16(local.get $bp7)))
(local.set $w7_0_2(v128.load8x8_s offset=16(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=16(local.get $bp9)))
(local.set $w14_0_2(v128.load8x8_s offset=16(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=16(local.get $bp11)))
(local.set $w8_0_2(v128.load8x8_s offset=16(local.get $bp12)))
(local.set $w9_0_2(v128.load8x8_s offset=16(local.get $bp13)))
(local.set $w15_0_2(v128.load8x8_s offset=16(local.get $bp14)))
(local.set $w16_0_2(v128.load8x8_s offset=16(local.get $bp15)))
local.get $b2
local.get $w0_0_2
i16x8.sub
local.set $w28_0_2
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_2
i16x8.sub
local.set $w29_0_2
local.get $b7
local.get $w2_0_2
i16x8.sub
local.set $w30_0_2
local.get $w14_0_2
local.get $w28_0_2
i16x8.sub
local.set $w35_0_2
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_2
local.get $w29_0_2
i16x8.sub
local.set $w36_0_2
local.get $w16_0_2
local.get $w30_0_2
i16x8.sub
local.set $w37_0_2
local.get $w14_0_2
local.get $b2
i16x8.sub
local.set $w42_0_2
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_2
local.get $b6
i16x8.sub
local.set $w43_0_2
local.get $w16_0_2
local.get $b7
i16x8.sub
local.set $w44_0_2
local.get $w35_0_2
local.get $w7_0_2
i16x8.sub
local.set $w21_0_2
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_2
local.get $w8_0_2
i16x8.sub
local.set $w22_0_2
local.get $w37_0_2
local.get $w9_0_2
i16x8.sub
local.set $w23_0_2
local.get $b1
local.get $w0_0_2
i16x8.sub
local.set $w4_0_2
local.get $w2_0_2
local.get $w4_0_2
i16x8.sub
local.set $w5_0_2
local.get $w2_0_2
local.get $b1
i16x8.sub
local.set $w6_0_2
local.get $w5_0_2
local.get $w1_0_2
i16x8.sub
local.set $w3_0_2
local.get $b9
local.get $w7_0_2
i16x8.sub
local.set $w11_0_2
local.get $w9_0_2
local.get $w11_0_2
i16x8.sub
local.set $w12_0_2
local.get $w9_0_2
local.get $b9
i16x8.sub
local.set $w13_0_2
local.get $w12_0_2
local.get $w8_0_2
i16x8.sub
local.set $w10_0_2
local.get $b11
local.get $w14_0_2
i16x8.sub
local.set $w18_0_2
local.get $w16_0_2
local.get $w18_0_2
i16x8.sub
local.set $w19_0_2
local.get $w16_0_2
local.get $b11
i16x8.sub
local.set $w20_0_2
local.get $w19_0_2
local.get $w15_0_2
i16x8.sub
local.set $w17_0_2
local.get $bd13
local.get $w21_0_2
i16x8.sub
local.set $w25_0_2
local.get $w23_0_2
local.get $w25_0_2
i16x8.sub
local.set $w26_0_2
local.get $w23_0_2
local.get $bd13
i16x8.sub
local.set $w27_0_2
local.get $w26_0_2
local.get $w22_0_2
i16x8.sub
local.set $w24_0_2
local.get $bd1
local.get $w28_0_2
i16x8.sub
local.set $w32_0_2
local.get $w30_0_2
local.get $w32_0_2
i16x8.sub
local.set $w33_0_2
local.get $w30_0_2
local.get $bd1
i16x8.sub
local.set $w34_0_2
local.get $w33_0_2
local.get $w29_0_2
i16x8.sub
local.set $w31_0_2
local.get $bd5
local.get $w35_0_2
i16x8.sub
local.set $w39_0_2
local.get $w37_0_2
local.get $w39_0_2
i16x8.sub
local.set $w40_0_2
local.get $w37_0_2
local.get $bd5
i16x8.sub
local.set $w41_0_2
local.get $w40_0_2
local.get $w36_0_2
i16x8.sub
local.set $w38_0_2
local.get $bd9
local.get $w42_0_2
i16x8.sub
local.set $w46_0_2
local.get $w44_0_2
local.get $w46_0_2
i16x8.sub
local.set $w47_0_2
local.get $w44_0_2
local.get $bd9
i16x8.sub
local.set $w48_0_2
local.get $w47_0_2
local.get $w43_0_2
i16x8.sub
local.set $w45_0_2
(local.set $w0_0_3(v128.load8x8_s offset=24(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=24(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=24(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=24(local.get $bp3)))
(local.set $w1_0_3(v128.load8x8_s offset=24(local.get $bp4)))
(local.set $w2_0_3(v128.load8x8_s offset=24(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=24(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=24(local.get $bp7)))
(local.set $w7_0_3(v128.load8x8_s offset=24(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=24(local.get $bp9)))
(local.set $w14_0_3(v128.load8x8_s offset=24(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=24(local.get $bp11)))
(local.set $w8_0_3(v128.load8x8_s offset=24(local.get $bp12)))
(local.set $w9_0_3(v128.load8x8_s offset=24(local.get $bp13)))
(local.set $w15_0_3(v128.load8x8_s offset=24(local.get $bp14)))
(local.set $w16_0_3(v128.load8x8_s offset=24(local.get $bp15)))
local.get $b2
local.get $w0_0_3
i16x8.sub
local.set $w28_0_3
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_3
i16x8.sub
local.set $w29_0_3
local.get $b7
local.get $w2_0_3
i16x8.sub
local.set $w30_0_3
local.get $w14_0_3
local.get $w28_0_3
i16x8.sub
local.set $w35_0_3
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_3
local.get $w29_0_3
i16x8.sub
local.set $w36_0_3
local.get $w16_0_3
local.get $w30_0_3
i16x8.sub
local.set $w37_0_3
local.get $w14_0_3
local.get $b2
i16x8.sub
local.set $w42_0_3
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_3
local.get $b6
i16x8.sub
local.set $w43_0_3
local.get $w16_0_3
local.get $b7
i16x8.sub
local.set $w44_0_3
local.get $w35_0_3
local.get $w7_0_3
i16x8.sub
local.set $w21_0_3
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_3
local.get $w8_0_3
i16x8.sub
local.set $w22_0_3
local.get $w37_0_3
local.get $w9_0_3
i16x8.sub
local.set $w23_0_3
local.get $b1
local.get $w0_0_3
i16x8.sub
local.set $w4_0_3
local.get $w2_0_3
local.get $w4_0_3
i16x8.sub
local.set $w5_0_3
local.get $w2_0_3
local.get $b1
i16x8.sub
local.set $w6_0_3
local.get $w5_0_3
local.get $w1_0_3
i16x8.sub
local.set $w3_0_3
local.get $b9
local.get $w7_0_3
i16x8.sub
local.set $w11_0_3
local.get $w9_0_3
local.get $w11_0_3
i16x8.sub
local.set $w12_0_3
local.get $w9_0_3
local.get $b9
i16x8.sub
local.set $w13_0_3
local.get $w12_0_3
local.get $w8_0_3
i16x8.sub
local.set $w10_0_3
local.get $b11
local.get $w14_0_3
i16x8.sub
local.set $w18_0_3
local.get $w16_0_3
local.get $w18_0_3
i16x8.sub
local.set $w19_0_3
local.get $w16_0_3
local.get $b11
i16x8.sub
local.set $w20_0_3
local.get $w19_0_3
local.get $w15_0_3
i16x8.sub
local.set $w17_0_3
local.get $bd13
local.get $w21_0_3
i16x8.sub
local.set $w25_0_3
local.get $w23_0_3
local.get $w25_0_3
i16x8.sub
local.set $w26_0_3
local.get $w23_0_3
local.get $bd13
i16x8.sub
local.set $w27_0_3
local.get $w26_0_3
local.get $w22_0_3
i16x8.sub
local.set $w24_0_3
local.get $bd1
local.get $w28_0_3
i16x8.sub
local.set $w32_0_3
local.get $w30_0_3
local.get $w32_0_3
i16x8.sub
local.set $w33_0_3
local.get $w30_0_3
local.get $bd1
i16x8.sub
local.set $w34_0_3
local.get $w33_0_3
local.get $w29_0_3
i16x8.sub
local.set $w31_0_3
local.get $bd5
local.get $w35_0_3
i16x8.sub
local.set $w39_0_3
local.get $w37_0_3
local.get $w39_0_3
i16x8.sub
local.set $w40_0_3
local.get $w37_0_3
local.get $bd5
i16x8.sub
local.set $w41_0_3
local.get $w40_0_3
local.get $w36_0_3
i16x8.sub
local.set $w38_0_3
local.get $bd9
local.get $w42_0_3
i16x8.sub
local.set $w46_0_3
local.get $w44_0_3
local.get $w46_0_3
i16x8.sub
local.set $w47_0_3
local.get $w44_0_3
local.get $bd9
i16x8.sub
local.set $w48_0_3
local.get $w47_0_3
local.get $w43_0_3
i16x8.sub
local.set $w45_0_3
(local.set $w0_0_4(v128.load8x8_s offset=32(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=32(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=32(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=32(local.get $bp3)))
(local.set $w1_0_4(v128.load8x8_s offset=32(local.get $bp4)))
(local.set $w2_0_4(v128.load8x8_s offset=32(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=32(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=32(local.get $bp7)))
(local.set $w7_0_4(v128.load8x8_s offset=32(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=32(local.get $bp9)))
(local.set $w14_0_4(v128.load8x8_s offset=32(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=32(local.get $bp11)))
(local.set $w8_0_4(v128.load8x8_s offset=32(local.get $bp12)))
(local.set $w9_0_4(v128.load8x8_s offset=32(local.get $bp13)))
(local.set $w15_0_4(v128.load8x8_s offset=32(local.get $bp14)))
(local.set $w16_0_4(v128.load8x8_s offset=32(local.get $bp15)))
local.get $b2
local.get $w0_0_4
i16x8.sub
local.set $w28_0_4
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_4
i16x8.sub
local.set $w29_0_4
local.get $b7
local.get $w2_0_4
i16x8.sub
local.set $w30_0_4
local.get $w14_0_4
local.get $w28_0_4
i16x8.sub
local.set $w35_0_4
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_4
local.get $w29_0_4
i16x8.sub
local.set $w36_0_4
local.get $w16_0_4
local.get $w30_0_4
i16x8.sub
local.set $w37_0_4
local.get $w14_0_4
local.get $b2
i16x8.sub
local.set $w42_0_4
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_4
local.get $b6
i16x8.sub
local.set $w43_0_4
local.get $w16_0_4
local.get $b7
i16x8.sub
local.set $w44_0_4
local.get $w35_0_4
local.get $w7_0_4
i16x8.sub
local.set $w21_0_4
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_4
local.get $w8_0_4
i16x8.sub
local.set $w22_0_4
local.get $w37_0_4
local.get $w9_0_4
i16x8.sub
local.set $w23_0_4
local.get $b1
local.get $w0_0_4
i16x8.sub
local.set $w4_0_4
local.get $w2_0_4
local.get $w4_0_4
i16x8.sub
local.set $w5_0_4
local.get $w2_0_4
local.get $b1
i16x8.sub
local.set $w6_0_4
local.get $w5_0_4
local.get $w1_0_4
i16x8.sub
local.set $w3_0_4
local.get $b9
local.get $w7_0_4
i16x8.sub
local.set $w11_0_4
local.get $w9_0_4
local.get $w11_0_4
i16x8.sub
local.set $w12_0_4
local.get $w9_0_4
local.get $b9
i16x8.sub
local.set $w13_0_4
local.get $w12_0_4
local.get $w8_0_4
i16x8.sub
local.set $w10_0_4
local.get $b11
local.get $w14_0_4
i16x8.sub
local.set $w18_0_4
local.get $w16_0_4
local.get $w18_0_4
i16x8.sub
local.set $w19_0_4
local.get $w16_0_4
local.get $b11
i16x8.sub
local.set $w20_0_4
local.get $w19_0_4
local.get $w15_0_4
i16x8.sub
local.set $w17_0_4
local.get $bd13
local.get $w21_0_4
i16x8.sub
local.set $w25_0_4
local.get $w23_0_4
local.get $w25_0_4
i16x8.sub
local.set $w26_0_4
local.get $w23_0_4
local.get $bd13
i16x8.sub
local.set $w27_0_4
local.get $w26_0_4
local.get $w22_0_4
i16x8.sub
local.set $w24_0_4
local.get $bd1
local.get $w28_0_4
i16x8.sub
local.set $w32_0_4
local.get $w30_0_4
local.get $w32_0_4
i16x8.sub
local.set $w33_0_4
local.get $w30_0_4
local.get $bd1
i16x8.sub
local.set $w34_0_4
local.get $w33_0_4
local.get $w29_0_4
i16x8.sub
local.set $w31_0_4
local.get $bd5
local.get $w35_0_4
i16x8.sub
local.set $w39_0_4
local.get $w37_0_4
local.get $w39_0_4
i16x8.sub
local.set $w40_0_4
local.get $w37_0_4
local.get $bd5
i16x8.sub
local.set $w41_0_4
local.get $w40_0_4
local.get $w36_0_4
i16x8.sub
local.set $w38_0_4
local.get $bd9
local.get $w42_0_4
i16x8.sub
local.set $w46_0_4
local.get $w44_0_4
local.get $w46_0_4
i16x8.sub
local.set $w47_0_4
local.get $w44_0_4
local.get $bd9
i16x8.sub
local.set $w48_0_4
local.get $w47_0_4
local.get $w43_0_4
i16x8.sub
local.set $w45_0_4
(local.set $w0_0_5(v128.load8x8_s offset=40(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=40(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=40(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=40(local.get $bp3)))
(local.set $w1_0_5(v128.load8x8_s offset=40(local.get $bp4)))
(local.set $w2_0_5(v128.load8x8_s offset=40(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=40(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=40(local.get $bp7)))
(local.set $w7_0_5(v128.load8x8_s offset=40(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=40(local.get $bp9)))
(local.set $w14_0_5(v128.load8x8_s offset=40(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=40(local.get $bp11)))
(local.set $w8_0_5(v128.load8x8_s offset=40(local.get $bp12)))
(local.set $w9_0_5(v128.load8x8_s offset=40(local.get $bp13)))
(local.set $w15_0_5(v128.load8x8_s offset=40(local.get $bp14)))
(local.set $w16_0_5(v128.load8x8_s offset=40(local.get $bp15)))
local.get $b2
local.get $w0_0_5
i16x8.sub
local.set $w28_0_5
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_5
i16x8.sub
local.set $w29_0_5
local.get $b7
local.get $w2_0_5
i16x8.sub
local.set $w30_0_5
local.get $w14_0_5
local.get $w28_0_5
i16x8.sub
local.set $w35_0_5
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_5
local.get $w29_0_5
i16x8.sub
local.set $w36_0_5
local.get $w16_0_5
local.get $w30_0_5
i16x8.sub
local.set $w37_0_5
local.get $w14_0_5
local.get $b2
i16x8.sub
local.set $w42_0_5
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_5
local.get $b6
i16x8.sub
local.set $w43_0_5
local.get $w16_0_5
local.get $b7
i16x8.sub
local.set $w44_0_5
local.get $w35_0_5
local.get $w7_0_5
i16x8.sub
local.set $w21_0_5
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_5
local.get $w8_0_5
i16x8.sub
local.set $w22_0_5
local.get $w37_0_5
local.get $w9_0_5
i16x8.sub
local.set $w23_0_5
local.get $b1
local.get $w0_0_5
i16x8.sub
local.set $w4_0_5
local.get $w2_0_5
local.get $w4_0_5
i16x8.sub
local.set $w5_0_5
local.get $w2_0_5
local.get $b1
i16x8.sub
local.set $w6_0_5
local.get $w5_0_5
local.get $w1_0_5
i16x8.sub
local.set $w3_0_5
local.get $b9
local.get $w7_0_5
i16x8.sub
local.set $w11_0_5
local.get $w9_0_5
local.get $w11_0_5
i16x8.sub
local.set $w12_0_5
local.get $w9_0_5
local.get $b9
i16x8.sub
local.set $w13_0_5
local.get $w12_0_5
local.get $w8_0_5
i16x8.sub
local.set $w10_0_5
local.get $b11
local.get $w14_0_5
i16x8.sub
local.set $w18_0_5
local.get $w16_0_5
local.get $w18_0_5
i16x8.sub
local.set $w19_0_5
local.get $w16_0_5
local.get $b11
i16x8.sub
local.set $w20_0_5
local.get $w19_0_5
local.get $w15_0_5
i16x8.sub
local.set $w17_0_5
local.get $bd13
local.get $w21_0_5
i16x8.sub
local.set $w25_0_5
local.get $w23_0_5
local.get $w25_0_5
i16x8.sub
local.set $w26_0_5
local.get $w23_0_5
local.get $bd13
i16x8.sub
local.set $w27_0_5
local.get $w26_0_5
local.get $w22_0_5
i16x8.sub
local.set $w24_0_5
local.get $bd1
local.get $w28_0_5
i16x8.sub
local.set $w32_0_5
local.get $w30_0_5
local.get $w32_0_5
i16x8.sub
local.set $w33_0_5
local.get $w30_0_5
local.get $bd1
i16x8.sub
local.set $w34_0_5
local.get $w33_0_5
local.get $w29_0_5
i16x8.sub
local.set $w31_0_5
local.get $bd5
local.get $w35_0_5
i16x8.sub
local.set $w39_0_5
local.get $w37_0_5
local.get $w39_0_5
i16x8.sub
local.set $w40_0_5
local.get $w37_0_5
local.get $bd5
i16x8.sub
local.set $w41_0_5
local.get $w40_0_5
local.get $w36_0_5
i16x8.sub
local.set $w38_0_5
local.get $bd9
local.get $w42_0_5
i16x8.sub
local.set $w46_0_5
local.get $w44_0_5
local.get $w46_0_5
i16x8.sub
local.set $w47_0_5
local.get $w44_0_5
local.get $bd9
i16x8.sub
local.set $w48_0_5
local.get $w47_0_5
local.get $w43_0_5
i16x8.sub
local.set $w45_0_5
(local.set $w0_0_6(v128.load8x8_s offset=48(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=48(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=48(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=48(local.get $bp3)))
(local.set $w1_0_6(v128.load8x8_s offset=48(local.get $bp4)))
(local.set $w2_0_6(v128.load8x8_s offset=48(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=48(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=48(local.get $bp7)))
(local.set $w7_0_6(v128.load8x8_s offset=48(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=48(local.get $bp9)))
(local.set $w14_0_6(v128.load8x8_s offset=48(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=48(local.get $bp11)))
(local.set $w8_0_6(v128.load8x8_s offset=48(local.get $bp12)))
(local.set $w9_0_6(v128.load8x8_s offset=48(local.get $bp13)))
(local.set $w15_0_6(v128.load8x8_s offset=48(local.get $bp14)))
(local.set $w16_0_6(v128.load8x8_s offset=48(local.get $bp15)))
local.get $b2
local.get $w0_0_6
i16x8.sub
local.set $w28_0_6
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_6
i16x8.sub
local.set $w29_0_6
local.get $b7
local.get $w2_0_6
i16x8.sub
local.set $w30_0_6
local.get $w14_0_6
local.get $w28_0_6
i16x8.sub
local.set $w35_0_6
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_6
local.get $w29_0_6
i16x8.sub
local.set $w36_0_6
local.get $w16_0_6
local.get $w30_0_6
i16x8.sub
local.set $w37_0_6
local.get $w14_0_6
local.get $b2
i16x8.sub
local.set $w42_0_6
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_6
local.get $b6
i16x8.sub
local.set $w43_0_6
local.get $w16_0_6
local.get $b7
i16x8.sub
local.set $w44_0_6
local.get $w35_0_6
local.get $w7_0_6
i16x8.sub
local.set $w21_0_6
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_6
local.get $w8_0_6
i16x8.sub
local.set $w22_0_6
local.get $w37_0_6
local.get $w9_0_6
i16x8.sub
local.set $w23_0_6
local.get $b1
local.get $w0_0_6
i16x8.sub
local.set $w4_0_6
local.get $w2_0_6
local.get $w4_0_6
i16x8.sub
local.set $w5_0_6
local.get $w2_0_6
local.get $b1
i16x8.sub
local.set $w6_0_6
local.get $w5_0_6
local.get $w1_0_6
i16x8.sub
local.set $w3_0_6
local.get $b9
local.get $w7_0_6
i16x8.sub
local.set $w11_0_6
local.get $w9_0_6
local.get $w11_0_6
i16x8.sub
local.set $w12_0_6
local.get $w9_0_6
local.get $b9
i16x8.sub
local.set $w13_0_6
local.get $w12_0_6
local.get $w8_0_6
i16x8.sub
local.set $w10_0_6
local.get $b11
local.get $w14_0_6
i16x8.sub
local.set $w18_0_6
local.get $w16_0_6
local.get $w18_0_6
i16x8.sub
local.set $w19_0_6
local.get $w16_0_6
local.get $b11
i16x8.sub
local.set $w20_0_6
local.get $w19_0_6
local.get $w15_0_6
i16x8.sub
local.set $w17_0_6
local.get $bd13
local.get $w21_0_6
i16x8.sub
local.set $w25_0_6
local.get $w23_0_6
local.get $w25_0_6
i16x8.sub
local.set $w26_0_6
local.get $w23_0_6
local.get $bd13
i16x8.sub
local.set $w27_0_6
local.get $w26_0_6
local.get $w22_0_6
i16x8.sub
local.set $w24_0_6
local.get $bd1
local.get $w28_0_6
i16x8.sub
local.set $w32_0_6
local.get $w30_0_6
local.get $w32_0_6
i16x8.sub
local.set $w33_0_6
local.get $w30_0_6
local.get $bd1
i16x8.sub
local.set $w34_0_6
local.get $w33_0_6
local.get $w29_0_6
i16x8.sub
local.set $w31_0_6
local.get $bd5
local.get $w35_0_6
i16x8.sub
local.set $w39_0_6
local.get $w37_0_6
local.get $w39_0_6
i16x8.sub
local.set $w40_0_6
local.get $w37_0_6
local.get $bd5
i16x8.sub
local.set $w41_0_6
local.get $w40_0_6
local.get $w36_0_6
i16x8.sub
local.set $w38_0_6
local.get $bd9
local.get $w42_0_6
i16x8.sub
local.set $w46_0_6
local.get $w44_0_6
local.get $w46_0_6
i16x8.sub
local.set $w47_0_6
local.get $w44_0_6
local.get $bd9
i16x8.sub
local.set $w48_0_6
local.get $w47_0_6
local.get $w43_0_6
i16x8.sub
local.set $w45_0_6
(local.set $w0_0_7(v128.load8x8_s offset=56(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=56(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=56(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=56(local.get $bp3)))
(local.set $w1_0_7(v128.load8x8_s offset=56(local.get $bp4)))
(local.set $w2_0_7(v128.load8x8_s offset=56(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=56(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=56(local.get $bp7)))
(local.set $w7_0_7(v128.load8x8_s offset=56(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=56(local.get $bp9)))
(local.set $w14_0_7(v128.load8x8_s offset=56(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=56(local.get $bp11)))
(local.set $w8_0_7(v128.load8x8_s offset=56(local.get $bp12)))
(local.set $w9_0_7(v128.load8x8_s offset=56(local.get $bp13)))
(local.set $w15_0_7(v128.load8x8_s offset=56(local.get $bp14)))
(local.set $w16_0_7(v128.load8x8_s offset=56(local.get $bp15)))
local.get $b2
local.get $w0_0_7
i16x8.sub
local.set $w28_0_7
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_7
i16x8.sub
local.set $w29_0_7
local.get $b7
local.get $w2_0_7
i16x8.sub
local.set $w30_0_7
local.get $w14_0_7
local.get $w28_0_7
i16x8.sub
local.set $w35_0_7
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_7
local.get $w29_0_7
i16x8.sub
local.set $w36_0_7
local.get $w16_0_7
local.get $w30_0_7
i16x8.sub
local.set $w37_0_7
local.get $w14_0_7
local.get $b2
i16x8.sub
local.set $w42_0_7
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_7
local.get $b6
i16x8.sub
local.set $w43_0_7
local.get $w16_0_7
local.get $b7
i16x8.sub
local.set $w44_0_7
local.get $w35_0_7
local.get $w7_0_7
i16x8.sub
local.set $w21_0_7
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_7
local.get $w8_0_7
i16x8.sub
local.set $w22_0_7
local.get $w37_0_7
local.get $w9_0_7
i16x8.sub
local.set $w23_0_7
local.get $b1
local.get $w0_0_7
i16x8.sub
local.set $w4_0_7
local.get $w2_0_7
local.get $w4_0_7
i16x8.sub
local.set $w5_0_7
local.get $w2_0_7
local.get $b1
i16x8.sub
local.set $w6_0_7
local.get $w5_0_7
local.get $w1_0_7
i16x8.sub
local.set $w3_0_7
local.get $b9
local.get $w7_0_7
i16x8.sub
local.set $w11_0_7
local.get $w9_0_7
local.get $w11_0_7
i16x8.sub
local.set $w12_0_7
local.get $w9_0_7
local.get $b9
i16x8.sub
local.set $w13_0_7
local.get $w12_0_7
local.get $w8_0_7
i16x8.sub
local.set $w10_0_7
local.get $b11
local.get $w14_0_7
i16x8.sub
local.set $w18_0_7
local.get $w16_0_7
local.get $w18_0_7
i16x8.sub
local.set $w19_0_7
local.get $w16_0_7
local.get $b11
i16x8.sub
local.set $w20_0_7
local.get $w19_0_7
local.get $w15_0_7
i16x8.sub
local.set $w17_0_7
local.get $bd13
local.get $w21_0_7
i16x8.sub
local.set $w25_0_7
local.get $w23_0_7
local.get $w25_0_7
i16x8.sub
local.set $w26_0_7
local.get $w23_0_7
local.get $bd13
i16x8.sub
local.set $w27_0_7
local.get $w26_0_7
local.get $w22_0_7
i16x8.sub
local.set $w24_0_7
local.get $bd1
local.get $w28_0_7
i16x8.sub
local.set $w32_0_7
local.get $w30_0_7
local.get $w32_0_7
i16x8.sub
local.set $w33_0_7
local.get $w30_0_7
local.get $bd1
i16x8.sub
local.set $w34_0_7
local.get $w33_0_7
local.get $w29_0_7
i16x8.sub
local.set $w31_0_7
local.get $bd5
local.get $w35_0_7
i16x8.sub
local.set $w39_0_7
local.get $w37_0_7
local.get $w39_0_7
i16x8.sub
local.set $w40_0_7
local.get $w37_0_7
local.get $bd5
i16x8.sub
local.set $w41_0_7
local.get $w40_0_7
local.get $w36_0_7
i16x8.sub
local.set $w38_0_7
local.get $bd9
local.get $w42_0_7
i16x8.sub
local.set $w46_0_7
local.get $w44_0_7
local.get $w46_0_7
i16x8.sub
local.set $w47_0_7
local.get $w44_0_7
local.get $bd9
i16x8.sub
local.set $w48_0_7
local.get $w47_0_7
local.get $w43_0_7
i16x8.sub
local.set $w45_0_7
(local.set $w0_0_8(v128.load8x8_s offset=64(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=64(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=64(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=64(local.get $bp3)))
(local.set $w1_0_8(v128.load8x8_s offset=64(local.get $bp4)))
(local.set $w2_0_8(v128.load8x8_s offset=64(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=64(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=64(local.get $bp7)))
(local.set $w7_0_8(v128.load8x8_s offset=64(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=64(local.get $bp9)))
(local.set $w14_0_8(v128.load8x8_s offset=64(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=64(local.get $bp11)))
(local.set $w8_0_8(v128.load8x8_s offset=64(local.get $bp12)))
(local.set $w9_0_8(v128.load8x8_s offset=64(local.get $bp13)))
(local.set $w15_0_8(v128.load8x8_s offset=64(local.get $bp14)))
(local.set $w16_0_8(v128.load8x8_s offset=64(local.get $bp15)))
local.get $b2
local.get $w0_0_8
i16x8.sub
local.set $w28_0_8
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_8
i16x8.sub
local.set $w29_0_8
local.get $b7
local.get $w2_0_8
i16x8.sub
local.set $w30_0_8
local.get $w14_0_8
local.get $w28_0_8
i16x8.sub
local.set $w35_0_8
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_8
local.get $w29_0_8
i16x8.sub
local.set $w36_0_8
local.get $w16_0_8
local.get $w30_0_8
i16x8.sub
local.set $w37_0_8
local.get $w14_0_8
local.get $b2
i16x8.sub
local.set $w42_0_8
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_8
local.get $b6
i16x8.sub
local.set $w43_0_8
local.get $w16_0_8
local.get $b7
i16x8.sub
local.set $w44_0_8
local.get $w35_0_8
local.get $w7_0_8
i16x8.sub
local.set $w21_0_8
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_8
local.get $w8_0_8
i16x8.sub
local.set $w22_0_8
local.get $w37_0_8
local.get $w9_0_8
i16x8.sub
local.set $w23_0_8
local.get $b1
local.get $w0_0_8
i16x8.sub
local.set $w4_0_8
local.get $w2_0_8
local.get $w4_0_8
i16x8.sub
local.set $w5_0_8
local.get $w2_0_8
local.get $b1
i16x8.sub
local.set $w6_0_8
local.get $w5_0_8
local.get $w1_0_8
i16x8.sub
local.set $w3_0_8
local.get $b9
local.get $w7_0_8
i16x8.sub
local.set $w11_0_8
local.get $w9_0_8
local.get $w11_0_8
i16x8.sub
local.set $w12_0_8
local.get $w9_0_8
local.get $b9
i16x8.sub
local.set $w13_0_8
local.get $w12_0_8
local.get $w8_0_8
i16x8.sub
local.set $w10_0_8
local.get $b11
local.get $w14_0_8
i16x8.sub
local.set $w18_0_8
local.get $w16_0_8
local.get $w18_0_8
i16x8.sub
local.set $w19_0_8
local.get $w16_0_8
local.get $b11
i16x8.sub
local.set $w20_0_8
local.get $w19_0_8
local.get $w15_0_8
i16x8.sub
local.set $w17_0_8
local.get $bd13
local.get $w21_0_8
i16x8.sub
local.set $w25_0_8
local.get $w23_0_8
local.get $w25_0_8
i16x8.sub
local.set $w26_0_8
local.get $w23_0_8
local.get $bd13
i16x8.sub
local.set $w27_0_8
local.get $w26_0_8
local.get $w22_0_8
i16x8.sub
local.set $w24_0_8
local.get $bd1
local.get $w28_0_8
i16x8.sub
local.set $w32_0_8
local.get $w30_0_8
local.get $w32_0_8
i16x8.sub
local.set $w33_0_8
local.get $w30_0_8
local.get $bd1
i16x8.sub
local.set $w34_0_8
local.get $w33_0_8
local.get $w29_0_8
i16x8.sub
local.set $w31_0_8
local.get $bd5
local.get $w35_0_8
i16x8.sub
local.set $w39_0_8
local.get $w37_0_8
local.get $w39_0_8
i16x8.sub
local.set $w40_0_8
local.get $w37_0_8
local.get $bd5
i16x8.sub
local.set $w41_0_8
local.get $w40_0_8
local.get $w36_0_8
i16x8.sub
local.set $w38_0_8
local.get $bd9
local.get $w42_0_8
i16x8.sub
local.set $w46_0_8
local.get $w44_0_8
local.get $w46_0_8
i16x8.sub
local.set $w47_0_8
local.get $w44_0_8
local.get $bd9
i16x8.sub
local.set $w48_0_8
local.get $w47_0_8
local.get $w43_0_8
i16x8.sub
local.set $w45_0_8
(local.set $w0_0_9(v128.load8x8_s offset=72(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=72(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=72(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=72(local.get $bp3)))
(local.set $w1_0_9(v128.load8x8_s offset=72(local.get $bp4)))
(local.set $w2_0_9(v128.load8x8_s offset=72(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=72(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=72(local.get $bp7)))
(local.set $w7_0_9(v128.load8x8_s offset=72(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=72(local.get $bp9)))
(local.set $w14_0_9(v128.load8x8_s offset=72(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=72(local.get $bp11)))
(local.set $w8_0_9(v128.load8x8_s offset=72(local.get $bp12)))
(local.set $w9_0_9(v128.load8x8_s offset=72(local.get $bp13)))
(local.set $w15_0_9(v128.load8x8_s offset=72(local.get $bp14)))
(local.set $w16_0_9(v128.load8x8_s offset=72(local.get $bp15)))
local.get $b2
local.get $w0_0_9
i16x8.sub
local.set $w28_0_9
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_9
i16x8.sub
local.set $w29_0_9
local.get $b7
local.get $w2_0_9
i16x8.sub
local.set $w30_0_9
local.get $w14_0_9
local.get $w28_0_9
i16x8.sub
local.set $w35_0_9
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_9
local.get $w29_0_9
i16x8.sub
local.set $w36_0_9
local.get $w16_0_9
local.get $w30_0_9
i16x8.sub
local.set $w37_0_9
local.get $w14_0_9
local.get $b2
i16x8.sub
local.set $w42_0_9
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_9
local.get $b6
i16x8.sub
local.set $w43_0_9
local.get $w16_0_9
local.get $b7
i16x8.sub
local.set $w44_0_9
local.get $w35_0_9
local.get $w7_0_9
i16x8.sub
local.set $w21_0_9
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_9
local.get $w8_0_9
i16x8.sub
local.set $w22_0_9
local.get $w37_0_9
local.get $w9_0_9
i16x8.sub
local.set $w23_0_9
local.get $b1
local.get $w0_0_9
i16x8.sub
local.set $w4_0_9
local.get $w2_0_9
local.get $w4_0_9
i16x8.sub
local.set $w5_0_9
local.get $w2_0_9
local.get $b1
i16x8.sub
local.set $w6_0_9
local.get $w5_0_9
local.get $w1_0_9
i16x8.sub
local.set $w3_0_9
local.get $b9
local.get $w7_0_9
i16x8.sub
local.set $w11_0_9
local.get $w9_0_9
local.get $w11_0_9
i16x8.sub
local.set $w12_0_9
local.get $w9_0_9
local.get $b9
i16x8.sub
local.set $w13_0_9
local.get $w12_0_9
local.get $w8_0_9
i16x8.sub
local.set $w10_0_9
local.get $b11
local.get $w14_0_9
i16x8.sub
local.set $w18_0_9
local.get $w16_0_9
local.get $w18_0_9
i16x8.sub
local.set $w19_0_9
local.get $w16_0_9
local.get $b11
i16x8.sub
local.set $w20_0_9
local.get $w19_0_9
local.get $w15_0_9
i16x8.sub
local.set $w17_0_9
local.get $bd13
local.get $w21_0_9
i16x8.sub
local.set $w25_0_9
local.get $w23_0_9
local.get $w25_0_9
i16x8.sub
local.set $w26_0_9
local.get $w23_0_9
local.get $bd13
i16x8.sub
local.set $w27_0_9
local.get $w26_0_9
local.get $w22_0_9
i16x8.sub
local.set $w24_0_9
local.get $bd1
local.get $w28_0_9
i16x8.sub
local.set $w32_0_9
local.get $w30_0_9
local.get $w32_0_9
i16x8.sub
local.set $w33_0_9
local.get $w30_0_9
local.get $bd1
i16x8.sub
local.set $w34_0_9
local.get $w33_0_9
local.get $w29_0_9
i16x8.sub
local.set $w31_0_9
local.get $bd5
local.get $w35_0_9
i16x8.sub
local.set $w39_0_9
local.get $w37_0_9
local.get $w39_0_9
i16x8.sub
local.set $w40_0_9
local.get $w37_0_9
local.get $bd5
i16x8.sub
local.set $w41_0_9
local.get $w40_0_9
local.get $w36_0_9
i16x8.sub
local.set $w38_0_9
local.get $bd9
local.get $w42_0_9
i16x8.sub
local.set $w46_0_9
local.get $w44_0_9
local.get $w46_0_9
i16x8.sub
local.set $w47_0_9
local.get $w44_0_9
local.get $bd9
i16x8.sub
local.set $w48_0_9
local.get $w47_0_9
local.get $w43_0_9
i16x8.sub
local.set $w45_0_9
(local.set $w0_0_10(v128.load8x8_s offset=80(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=80(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=80(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=80(local.get $bp3)))
(local.set $w1_0_10(v128.load8x8_s offset=80(local.get $bp4)))
(local.set $w2_0_10(v128.load8x8_s offset=80(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=80(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=80(local.get $bp7)))
(local.set $w7_0_10(v128.load8x8_s offset=80(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=80(local.get $bp9)))
(local.set $w14_0_10(v128.load8x8_s offset=80(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=80(local.get $bp11)))
(local.set $w8_0_10(v128.load8x8_s offset=80(local.get $bp12)))
(local.set $w9_0_10(v128.load8x8_s offset=80(local.get $bp13)))
(local.set $w15_0_10(v128.load8x8_s offset=80(local.get $bp14)))
(local.set $w16_0_10(v128.load8x8_s offset=80(local.get $bp15)))
local.get $b2
local.get $w0_0_10
i16x8.sub
local.set $w28_0_10
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_10
i16x8.sub
local.set $w29_0_10
local.get $b7
local.get $w2_0_10
i16x8.sub
local.set $w30_0_10
local.get $w14_0_10
local.get $w28_0_10
i16x8.sub
local.set $w35_0_10
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_10
local.get $w29_0_10
i16x8.sub
local.set $w36_0_10
local.get $w16_0_10
local.get $w30_0_10
i16x8.sub
local.set $w37_0_10
local.get $w14_0_10
local.get $b2
i16x8.sub
local.set $w42_0_10
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_10
local.get $b6
i16x8.sub
local.set $w43_0_10
local.get $w16_0_10
local.get $b7
i16x8.sub
local.set $w44_0_10
local.get $w35_0_10
local.get $w7_0_10
i16x8.sub
local.set $w21_0_10
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_10
local.get $w8_0_10
i16x8.sub
local.set $w22_0_10
local.get $w37_0_10
local.get $w9_0_10
i16x8.sub
local.set $w23_0_10
local.get $b1
local.get $w0_0_10
i16x8.sub
local.set $w4_0_10
local.get $w2_0_10
local.get $w4_0_10
i16x8.sub
local.set $w5_0_10
local.get $w2_0_10
local.get $b1
i16x8.sub
local.set $w6_0_10
local.get $w5_0_10
local.get $w1_0_10
i16x8.sub
local.set $w3_0_10
local.get $b9
local.get $w7_0_10
i16x8.sub
local.set $w11_0_10
local.get $w9_0_10
local.get $w11_0_10
i16x8.sub
local.set $w12_0_10
local.get $w9_0_10
local.get $b9
i16x8.sub
local.set $w13_0_10
local.get $w12_0_10
local.get $w8_0_10
i16x8.sub
local.set $w10_0_10
local.get $b11
local.get $w14_0_10
i16x8.sub
local.set $w18_0_10
local.get $w16_0_10
local.get $w18_0_10
i16x8.sub
local.set $w19_0_10
local.get $w16_0_10
local.get $b11
i16x8.sub
local.set $w20_0_10
local.get $w19_0_10
local.get $w15_0_10
i16x8.sub
local.set $w17_0_10
local.get $bd13
local.get $w21_0_10
i16x8.sub
local.set $w25_0_10
local.get $w23_0_10
local.get $w25_0_10
i16x8.sub
local.set $w26_0_10
local.get $w23_0_10
local.get $bd13
i16x8.sub
local.set $w27_0_10
local.get $w26_0_10
local.get $w22_0_10
i16x8.sub
local.set $w24_0_10
local.get $bd1
local.get $w28_0_10
i16x8.sub
local.set $w32_0_10
local.get $w30_0_10
local.get $w32_0_10
i16x8.sub
local.set $w33_0_10
local.get $w30_0_10
local.get $bd1
i16x8.sub
local.set $w34_0_10
local.get $w33_0_10
local.get $w29_0_10
i16x8.sub
local.set $w31_0_10
local.get $bd5
local.get $w35_0_10
i16x8.sub
local.set $w39_0_10
local.get $w37_0_10
local.get $w39_0_10
i16x8.sub
local.set $w40_0_10
local.get $w37_0_10
local.get $bd5
i16x8.sub
local.set $w41_0_10
local.get $w40_0_10
local.get $w36_0_10
i16x8.sub
local.set $w38_0_10
local.get $bd9
local.get $w42_0_10
i16x8.sub
local.set $w46_0_10
local.get $w44_0_10
local.get $w46_0_10
i16x8.sub
local.set $w47_0_10
local.get $w44_0_10
local.get $bd9
i16x8.sub
local.set $w48_0_10
local.get $w47_0_10
local.get $w43_0_10
i16x8.sub
local.set $w45_0_10
(local.set $w0_0_11(v128.load8x8_s offset=88(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=88(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=88(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=88(local.get $bp3)))
(local.set $w1_0_11(v128.load8x8_s offset=88(local.get $bp4)))
(local.set $w2_0_11(v128.load8x8_s offset=88(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=88(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=88(local.get $bp7)))
(local.set $w7_0_11(v128.load8x8_s offset=88(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=88(local.get $bp9)))
(local.set $w14_0_11(v128.load8x8_s offset=88(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=88(local.get $bp11)))
(local.set $w8_0_11(v128.load8x8_s offset=88(local.get $bp12)))
(local.set $w9_0_11(v128.load8x8_s offset=88(local.get $bp13)))
(local.set $w15_0_11(v128.load8x8_s offset=88(local.get $bp14)))
(local.set $w16_0_11(v128.load8x8_s offset=88(local.get $bp15)))
local.get $b2
local.get $w0_0_11
i16x8.sub
local.set $w28_0_11
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_11
i16x8.sub
local.set $w29_0_11
local.get $b7
local.get $w2_0_11
i16x8.sub
local.set $w30_0_11
local.get $w14_0_11
local.get $w28_0_11
i16x8.sub
local.set $w35_0_11
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_11
local.get $w29_0_11
i16x8.sub
local.set $w36_0_11
local.get $w16_0_11
local.get $w30_0_11
i16x8.sub
local.set $w37_0_11
local.get $w14_0_11
local.get $b2
i16x8.sub
local.set $w42_0_11
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_11
local.get $b6
i16x8.sub
local.set $w43_0_11
local.get $w16_0_11
local.get $b7
i16x8.sub
local.set $w44_0_11
local.get $w35_0_11
local.get $w7_0_11
i16x8.sub
local.set $w21_0_11
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_11
local.get $w8_0_11
i16x8.sub
local.set $w22_0_11
local.get $w37_0_11
local.get $w9_0_11
i16x8.sub
local.set $w23_0_11
local.get $b1
local.get $w0_0_11
i16x8.sub
local.set $w4_0_11
local.get $w2_0_11
local.get $w4_0_11
i16x8.sub
local.set $w5_0_11
local.get $w2_0_11
local.get $b1
i16x8.sub
local.set $w6_0_11
local.get $w5_0_11
local.get $w1_0_11
i16x8.sub
local.set $w3_0_11
local.get $b9
local.get $w7_0_11
i16x8.sub
local.set $w11_0_11
local.get $w9_0_11
local.get $w11_0_11
i16x8.sub
local.set $w12_0_11
local.get $w9_0_11
local.get $b9
i16x8.sub
local.set $w13_0_11
local.get $w12_0_11
local.get $w8_0_11
i16x8.sub
local.set $w10_0_11
local.get $b11
local.get $w14_0_11
i16x8.sub
local.set $w18_0_11
local.get $w16_0_11
local.get $w18_0_11
i16x8.sub
local.set $w19_0_11
local.get $w16_0_11
local.get $b11
i16x8.sub
local.set $w20_0_11
local.get $w19_0_11
local.get $w15_0_11
i16x8.sub
local.set $w17_0_11
local.get $bd13
local.get $w21_0_11
i16x8.sub
local.set $w25_0_11
local.get $w23_0_11
local.get $w25_0_11
i16x8.sub
local.set $w26_0_11
local.get $w23_0_11
local.get $bd13
i16x8.sub
local.set $w27_0_11
local.get $w26_0_11
local.get $w22_0_11
i16x8.sub
local.set $w24_0_11
local.get $bd1
local.get $w28_0_11
i16x8.sub
local.set $w32_0_11
local.get $w30_0_11
local.get $w32_0_11
i16x8.sub
local.set $w33_0_11
local.get $w30_0_11
local.get $bd1
i16x8.sub
local.set $w34_0_11
local.get $w33_0_11
local.get $w29_0_11
i16x8.sub
local.set $w31_0_11
local.get $bd5
local.get $w35_0_11
i16x8.sub
local.set $w39_0_11
local.get $w37_0_11
local.get $w39_0_11
i16x8.sub
local.set $w40_0_11
local.get $w37_0_11
local.get $bd5
i16x8.sub
local.set $w41_0_11
local.get $w40_0_11
local.get $w36_0_11
i16x8.sub
local.set $w38_0_11
local.get $bd9
local.get $w42_0_11
i16x8.sub
local.set $w46_0_11
local.get $w44_0_11
local.get $w46_0_11
i16x8.sub
local.set $w47_0_11
local.get $w44_0_11
local.get $bd9
i16x8.sub
local.set $w48_0_11
local.get $w47_0_11
local.get $w43_0_11
i16x8.sub
local.set $w45_0_11
(local.set $w0_0_12(v128.load8x8_s offset=96(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=96(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=96(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=96(local.get $bp3)))
(local.set $w1_0_12(v128.load8x8_s offset=96(local.get $bp4)))
(local.set $w2_0_12(v128.load8x8_s offset=96(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=96(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=96(local.get $bp7)))
(local.set $w7_0_12(v128.load8x8_s offset=96(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=96(local.get $bp9)))
(local.set $w14_0_12(v128.load8x8_s offset=96(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=96(local.get $bp11)))
(local.set $w8_0_12(v128.load8x8_s offset=96(local.get $bp12)))
(local.set $w9_0_12(v128.load8x8_s offset=96(local.get $bp13)))
(local.set $w15_0_12(v128.load8x8_s offset=96(local.get $bp14)))
(local.set $w16_0_12(v128.load8x8_s offset=96(local.get $bp15)))
local.get $b2
local.get $w0_0_12
i16x8.sub
local.set $w28_0_12
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_12
i16x8.sub
local.set $w29_0_12
local.get $b7
local.get $w2_0_12
i16x8.sub
local.set $w30_0_12
local.get $w14_0_12
local.get $w28_0_12
i16x8.sub
local.set $w35_0_12
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_12
local.get $w29_0_12
i16x8.sub
local.set $w36_0_12
local.get $w16_0_12
local.get $w30_0_12
i16x8.sub
local.set $w37_0_12
local.get $w14_0_12
local.get $b2
i16x8.sub
local.set $w42_0_12
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_12
local.get $b6
i16x8.sub
local.set $w43_0_12
local.get $w16_0_12
local.get $b7
i16x8.sub
local.set $w44_0_12
local.get $w35_0_12
local.get $w7_0_12
i16x8.sub
local.set $w21_0_12
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_12
local.get $w8_0_12
i16x8.sub
local.set $w22_0_12
local.get $w37_0_12
local.get $w9_0_12
i16x8.sub
local.set $w23_0_12
local.get $b1
local.get $w0_0_12
i16x8.sub
local.set $w4_0_12
local.get $w2_0_12
local.get $w4_0_12
i16x8.sub
local.set $w5_0_12
local.get $w2_0_12
local.get $b1
i16x8.sub
local.set $w6_0_12
local.get $w5_0_12
local.get $w1_0_12
i16x8.sub
local.set $w3_0_12
local.get $b9
local.get $w7_0_12
i16x8.sub
local.set $w11_0_12
local.get $w9_0_12
local.get $w11_0_12
i16x8.sub
local.set $w12_0_12
local.get $w9_0_12
local.get $b9
i16x8.sub
local.set $w13_0_12
local.get $w12_0_12
local.get $w8_0_12
i16x8.sub
local.set $w10_0_12
local.get $b11
local.get $w14_0_12
i16x8.sub
local.set $w18_0_12
local.get $w16_0_12
local.get $w18_0_12
i16x8.sub
local.set $w19_0_12
local.get $w16_0_12
local.get $b11
i16x8.sub
local.set $w20_0_12
local.get $w19_0_12
local.get $w15_0_12
i16x8.sub
local.set $w17_0_12
local.get $bd13
local.get $w21_0_12
i16x8.sub
local.set $w25_0_12
local.get $w23_0_12
local.get $w25_0_12
i16x8.sub
local.set $w26_0_12
local.get $w23_0_12
local.get $bd13
i16x8.sub
local.set $w27_0_12
local.get $w26_0_12
local.get $w22_0_12
i16x8.sub
local.set $w24_0_12
local.get $bd1
local.get $w28_0_12
i16x8.sub
local.set $w32_0_12
local.get $w30_0_12
local.get $w32_0_12
i16x8.sub
local.set $w33_0_12
local.get $w30_0_12
local.get $bd1
i16x8.sub
local.set $w34_0_12
local.get $w33_0_12
local.get $w29_0_12
i16x8.sub
local.set $w31_0_12
local.get $bd5
local.get $w35_0_12
i16x8.sub
local.set $w39_0_12
local.get $w37_0_12
local.get $w39_0_12
i16x8.sub
local.set $w40_0_12
local.get $w37_0_12
local.get $bd5
i16x8.sub
local.set $w41_0_12
local.get $w40_0_12
local.get $w36_0_12
i16x8.sub
local.set $w38_0_12
local.get $bd9
local.get $w42_0_12
i16x8.sub
local.set $w46_0_12
local.get $w44_0_12
local.get $w46_0_12
i16x8.sub
local.set $w47_0_12
local.get $w44_0_12
local.get $bd9
i16x8.sub
local.set $w48_0_12
local.get $w47_0_12
local.get $w43_0_12
i16x8.sub
local.set $w45_0_12
(local.set $w0_0_13(v128.load8x8_s offset=104(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=104(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=104(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=104(local.get $bp3)))
(local.set $w1_0_13(v128.load8x8_s offset=104(local.get $bp4)))
(local.set $w2_0_13(v128.load8x8_s offset=104(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=104(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=104(local.get $bp7)))
(local.set $w7_0_13(v128.load8x8_s offset=104(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=104(local.get $bp9)))
(local.set $w14_0_13(v128.load8x8_s offset=104(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=104(local.get $bp11)))
(local.set $w8_0_13(v128.load8x8_s offset=104(local.get $bp12)))
(local.set $w9_0_13(v128.load8x8_s offset=104(local.get $bp13)))
(local.set $w15_0_13(v128.load8x8_s offset=104(local.get $bp14)))
(local.set $w16_0_13(v128.load8x8_s offset=104(local.get $bp15)))
local.get $b2
local.get $w0_0_13
i16x8.sub
local.set $w28_0_13
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_13
i16x8.sub
local.set $w29_0_13
local.get $b7
local.get $w2_0_13
i16x8.sub
local.set $w30_0_13
local.get $w14_0_13
local.get $w28_0_13
i16x8.sub
local.set $w35_0_13
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_13
local.get $w29_0_13
i16x8.sub
local.set $w36_0_13
local.get $w16_0_13
local.get $w30_0_13
i16x8.sub
local.set $w37_0_13
local.get $w14_0_13
local.get $b2
i16x8.sub
local.set $w42_0_13
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_13
local.get $b6
i16x8.sub
local.set $w43_0_13
local.get $w16_0_13
local.get $b7
i16x8.sub
local.set $w44_0_13
local.get $w35_0_13
local.get $w7_0_13
i16x8.sub
local.set $w21_0_13
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_13
local.get $w8_0_13
i16x8.sub
local.set $w22_0_13
local.get $w37_0_13
local.get $w9_0_13
i16x8.sub
local.set $w23_0_13
local.get $b1
local.get $w0_0_13
i16x8.sub
local.set $w4_0_13
local.get $w2_0_13
local.get $w4_0_13
i16x8.sub
local.set $w5_0_13
local.get $w2_0_13
local.get $b1
i16x8.sub
local.set $w6_0_13
local.get $w5_0_13
local.get $w1_0_13
i16x8.sub
local.set $w3_0_13
local.get $b9
local.get $w7_0_13
i16x8.sub
local.set $w11_0_13
local.get $w9_0_13
local.get $w11_0_13
i16x8.sub
local.set $w12_0_13
local.get $w9_0_13
local.get $b9
i16x8.sub
local.set $w13_0_13
local.get $w12_0_13
local.get $w8_0_13
i16x8.sub
local.set $w10_0_13
local.get $b11
local.get $w14_0_13
i16x8.sub
local.set $w18_0_13
local.get $w16_0_13
local.get $w18_0_13
i16x8.sub
local.set $w19_0_13
local.get $w16_0_13
local.get $b11
i16x8.sub
local.set $w20_0_13
local.get $w19_0_13
local.get $w15_0_13
i16x8.sub
local.set $w17_0_13
local.get $bd13
local.get $w21_0_13
i16x8.sub
local.set $w25_0_13
local.get $w23_0_13
local.get $w25_0_13
i16x8.sub
local.set $w26_0_13
local.get $w23_0_13
local.get $bd13
i16x8.sub
local.set $w27_0_13
local.get $w26_0_13
local.get $w22_0_13
i16x8.sub
local.set $w24_0_13
local.get $bd1
local.get $w28_0_13
i16x8.sub
local.set $w32_0_13
local.get $w30_0_13
local.get $w32_0_13
i16x8.sub
local.set $w33_0_13
local.get $w30_0_13
local.get $bd1
i16x8.sub
local.set $w34_0_13
local.get $w33_0_13
local.get $w29_0_13
i16x8.sub
local.set $w31_0_13
local.get $bd5
local.get $w35_0_13
i16x8.sub
local.set $w39_0_13
local.get $w37_0_13
local.get $w39_0_13
i16x8.sub
local.set $w40_0_13
local.get $w37_0_13
local.get $bd5
i16x8.sub
local.set $w41_0_13
local.get $w40_0_13
local.get $w36_0_13
i16x8.sub
local.set $w38_0_13
local.get $bd9
local.get $w42_0_13
i16x8.sub
local.set $w46_0_13
local.get $w44_0_13
local.get $w46_0_13
i16x8.sub
local.set $w47_0_13
local.get $w44_0_13
local.get $bd9
i16x8.sub
local.set $w48_0_13
local.get $w47_0_13
local.get $w43_0_13
i16x8.sub
local.set $w45_0_13
(local.set $w0_0_14(v128.load8x8_s offset=112(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=112(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=112(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=112(local.get $bp3)))
(local.set $w1_0_14(v128.load8x8_s offset=112(local.get $bp4)))
(local.set $w2_0_14(v128.load8x8_s offset=112(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=112(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=112(local.get $bp7)))
(local.set $w7_0_14(v128.load8x8_s offset=112(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=112(local.get $bp9)))
(local.set $w14_0_14(v128.load8x8_s offset=112(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=112(local.get $bp11)))
(local.set $w8_0_14(v128.load8x8_s offset=112(local.get $bp12)))
(local.set $w9_0_14(v128.load8x8_s offset=112(local.get $bp13)))
(local.set $w15_0_14(v128.load8x8_s offset=112(local.get $bp14)))
(local.set $w16_0_14(v128.load8x8_s offset=112(local.get $bp15)))
local.get $b2
local.get $w0_0_14
i16x8.sub
local.set $w28_0_14
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_14
i16x8.sub
local.set $w29_0_14
local.get $b7
local.get $w2_0_14
i16x8.sub
local.set $w30_0_14
local.get $w14_0_14
local.get $w28_0_14
i16x8.sub
local.set $w35_0_14
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_14
local.get $w29_0_14
i16x8.sub
local.set $w36_0_14
local.get $w16_0_14
local.get $w30_0_14
i16x8.sub
local.set $w37_0_14
local.get $w14_0_14
local.get $b2
i16x8.sub
local.set $w42_0_14
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_14
local.get $b6
i16x8.sub
local.set $w43_0_14
local.get $w16_0_14
local.get $b7
i16x8.sub
local.set $w44_0_14
local.get $w35_0_14
local.get $w7_0_14
i16x8.sub
local.set $w21_0_14
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_14
local.get $w8_0_14
i16x8.sub
local.set $w22_0_14
local.get $w37_0_14
local.get $w9_0_14
i16x8.sub
local.set $w23_0_14
local.get $b1
local.get $w0_0_14
i16x8.sub
local.set $w4_0_14
local.get $w2_0_14
local.get $w4_0_14
i16x8.sub
local.set $w5_0_14
local.get $w2_0_14
local.get $b1
i16x8.sub
local.set $w6_0_14
local.get $w5_0_14
local.get $w1_0_14
i16x8.sub
local.set $w3_0_14
local.get $b9
local.get $w7_0_14
i16x8.sub
local.set $w11_0_14
local.get $w9_0_14
local.get $w11_0_14
i16x8.sub
local.set $w12_0_14
local.get $w9_0_14
local.get $b9
i16x8.sub
local.set $w13_0_14
local.get $w12_0_14
local.get $w8_0_14
i16x8.sub
local.set $w10_0_14
local.get $b11
local.get $w14_0_14
i16x8.sub
local.set $w18_0_14
local.get $w16_0_14
local.get $w18_0_14
i16x8.sub
local.set $w19_0_14
local.get $w16_0_14
local.get $b11
i16x8.sub
local.set $w20_0_14
local.get $w19_0_14
local.get $w15_0_14
i16x8.sub
local.set $w17_0_14
local.get $bd13
local.get $w21_0_14
i16x8.sub
local.set $w25_0_14
local.get $w23_0_14
local.get $w25_0_14
i16x8.sub
local.set $w26_0_14
local.get $w23_0_14
local.get $bd13
i16x8.sub
local.set $w27_0_14
local.get $w26_0_14
local.get $w22_0_14
i16x8.sub
local.set $w24_0_14
local.get $bd1
local.get $w28_0_14
i16x8.sub
local.set $w32_0_14
local.get $w30_0_14
local.get $w32_0_14
i16x8.sub
local.set $w33_0_14
local.get $w30_0_14
local.get $bd1
i16x8.sub
local.set $w34_0_14
local.get $w33_0_14
local.get $w29_0_14
i16x8.sub
local.set $w31_0_14
local.get $bd5
local.get $w35_0_14
i16x8.sub
local.set $w39_0_14
local.get $w37_0_14
local.get $w39_0_14
i16x8.sub
local.set $w40_0_14
local.get $w37_0_14
local.get $bd5
i16x8.sub
local.set $w41_0_14
local.get $w40_0_14
local.get $w36_0_14
i16x8.sub
local.set $w38_0_14
local.get $bd9
local.get $w42_0_14
i16x8.sub
local.set $w46_0_14
local.get $w44_0_14
local.get $w46_0_14
i16x8.sub
local.set $w47_0_14
local.get $w44_0_14
local.get $bd9
i16x8.sub
local.set $w48_0_14
local.get $w47_0_14
local.get $w43_0_14
i16x8.sub
local.set $w45_0_14
(local.set $w0_0_15(v128.load8x8_s offset=120(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=120(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=120(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=120(local.get $bp3)))
(local.set $w1_0_15(v128.load8x8_s offset=120(local.get $bp4)))
(local.set $w2_0_15(v128.load8x8_s offset=120(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=120(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=120(local.get $bp7)))
(local.set $w7_0_15(v128.load8x8_s offset=120(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=120(local.get $bp9)))
(local.set $w14_0_15(v128.load8x8_s offset=120(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=120(local.get $bp11)))
(local.set $w8_0_15(v128.load8x8_s offset=120(local.get $bp12)))
(local.set $w9_0_15(v128.load8x8_s offset=120(local.get $bp13)))
(local.set $w15_0_15(v128.load8x8_s offset=120(local.get $bp14)))
(local.set $w16_0_15(v128.load8x8_s offset=120(local.get $bp15)))
local.get $b2
local.get $w0_0_15
i16x8.sub
local.set $w28_0_15
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_15
i16x8.sub
local.set $w29_0_15
local.get $b7
local.get $w2_0_15
i16x8.sub
local.set $w30_0_15
local.get $w14_0_15
local.get $w28_0_15
i16x8.sub
local.set $w35_0_15
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_15
local.get $w29_0_15
i16x8.sub
local.set $w36_0_15
local.get $w16_0_15
local.get $w30_0_15
i16x8.sub
local.set $w37_0_15
local.get $w14_0_15
local.get $b2
i16x8.sub
local.set $w42_0_15
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_15
local.get $b6
i16x8.sub
local.set $w43_0_15
local.get $w16_0_15
local.get $b7
i16x8.sub
local.set $w44_0_15
local.get $w35_0_15
local.get $w7_0_15
i16x8.sub
local.set $w21_0_15
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_15
local.get $w8_0_15
i16x8.sub
local.set $w22_0_15
local.get $w37_0_15
local.get $w9_0_15
i16x8.sub
local.set $w23_0_15
local.get $b1
local.get $w0_0_15
i16x8.sub
local.set $w4_0_15
local.get $w2_0_15
local.get $w4_0_15
i16x8.sub
local.set $w5_0_15
local.get $w2_0_15
local.get $b1
i16x8.sub
local.set $w6_0_15
local.get $w5_0_15
local.get $w1_0_15
i16x8.sub
local.set $w3_0_15
local.get $b9
local.get $w7_0_15
i16x8.sub
local.set $w11_0_15
local.get $w9_0_15
local.get $w11_0_15
i16x8.sub
local.set $w12_0_15
local.get $w9_0_15
local.get $b9
i16x8.sub
local.set $w13_0_15
local.get $w12_0_15
local.get $w8_0_15
i16x8.sub
local.set $w10_0_15
local.get $b11
local.get $w14_0_15
i16x8.sub
local.set $w18_0_15
local.get $w16_0_15
local.get $w18_0_15
i16x8.sub
local.set $w19_0_15
local.get $w16_0_15
local.get $b11
i16x8.sub
local.set $w20_0_15
local.get $w19_0_15
local.get $w15_0_15
i16x8.sub
local.set $w17_0_15
local.get $bd13
local.get $w21_0_15
i16x8.sub
local.set $w25_0_15
local.get $w23_0_15
local.get $w25_0_15
i16x8.sub
local.set $w26_0_15
local.get $w23_0_15
local.get $bd13
i16x8.sub
local.set $w27_0_15
local.get $w26_0_15
local.get $w22_0_15
i16x8.sub
local.set $w24_0_15
local.get $bd1
local.get $w28_0_15
i16x8.sub
local.set $w32_0_15
local.get $w30_0_15
local.get $w32_0_15
i16x8.sub
local.set $w33_0_15
local.get $w30_0_15
local.get $bd1
i16x8.sub
local.set $w34_0_15
local.get $w33_0_15
local.get $w29_0_15
i16x8.sub
local.set $w31_0_15
local.get $bd5
local.get $w35_0_15
i16x8.sub
local.set $w39_0_15
local.get $w37_0_15
local.get $w39_0_15
i16x8.sub
local.set $w40_0_15
local.get $w37_0_15
local.get $bd5
i16x8.sub
local.set $w41_0_15
local.get $w40_0_15
local.get $w36_0_15
i16x8.sub
local.set $w38_0_15
local.get $bd9
local.get $w42_0_15
i16x8.sub
local.set $w46_0_15
local.get $w44_0_15
local.get $w46_0_15
i16x8.sub
local.set $w47_0_15
local.get $w44_0_15
local.get $bd9
i16x8.sub
local.set $w48_0_15
local.get $w47_0_15
local.get $w43_0_15
i16x8.sub
local.set $w45_0_15
(local.set $w0_0_16(v128.load8x8_s offset=128(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=128(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=128(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=128(local.get $bp3)))
(local.set $w1_0_16(v128.load8x8_s offset=128(local.get $bp4)))
(local.set $w2_0_16(v128.load8x8_s offset=128(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=128(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=128(local.get $bp7)))
(local.set $w7_0_16(v128.load8x8_s offset=128(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=128(local.get $bp9)))
(local.set $w14_0_16(v128.load8x8_s offset=128(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=128(local.get $bp11)))
(local.set $w8_0_16(v128.load8x8_s offset=128(local.get $bp12)))
(local.set $w9_0_16(v128.load8x8_s offset=128(local.get $bp13)))
(local.set $w15_0_16(v128.load8x8_s offset=128(local.get $bp14)))
(local.set $w16_0_16(v128.load8x8_s offset=128(local.get $bp15)))
local.get $b2
local.get $w0_0_16
i16x8.sub
local.set $w28_0_16
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_16
i16x8.sub
local.set $w29_0_16
local.get $b7
local.get $w2_0_16
i16x8.sub
local.set $w30_0_16
local.get $w14_0_16
local.get $w28_0_16
i16x8.sub
local.set $w35_0_16
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_16
local.get $w29_0_16
i16x8.sub
local.set $w36_0_16
local.get $w16_0_16
local.get $w30_0_16
i16x8.sub
local.set $w37_0_16
local.get $w14_0_16
local.get $b2
i16x8.sub
local.set $w42_0_16
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_16
local.get $b6
i16x8.sub
local.set $w43_0_16
local.get $w16_0_16
local.get $b7
i16x8.sub
local.set $w44_0_16
local.get $w35_0_16
local.get $w7_0_16
i16x8.sub
local.set $w21_0_16
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_16
local.get $w8_0_16
i16x8.sub
local.set $w22_0_16
local.get $w37_0_16
local.get $w9_0_16
i16x8.sub
local.set $w23_0_16
local.get $b1
local.get $w0_0_16
i16x8.sub
local.set $w4_0_16
local.get $w2_0_16
local.get $w4_0_16
i16x8.sub
local.set $w5_0_16
local.get $w2_0_16
local.get $b1
i16x8.sub
local.set $w6_0_16
local.get $w5_0_16
local.get $w1_0_16
i16x8.sub
local.set $w3_0_16
local.get $b9
local.get $w7_0_16
i16x8.sub
local.set $w11_0_16
local.get $w9_0_16
local.get $w11_0_16
i16x8.sub
local.set $w12_0_16
local.get $w9_0_16
local.get $b9
i16x8.sub
local.set $w13_0_16
local.get $w12_0_16
local.get $w8_0_16
i16x8.sub
local.set $w10_0_16
local.get $b11
local.get $w14_0_16
i16x8.sub
local.set $w18_0_16
local.get $w16_0_16
local.get $w18_0_16
i16x8.sub
local.set $w19_0_16
local.get $w16_0_16
local.get $b11
i16x8.sub
local.set $w20_0_16
local.get $w19_0_16
local.get $w15_0_16
i16x8.sub
local.set $w17_0_16
local.get $bd13
local.get $w21_0_16
i16x8.sub
local.set $w25_0_16
local.get $w23_0_16
local.get $w25_0_16
i16x8.sub
local.set $w26_0_16
local.get $w23_0_16
local.get $bd13
i16x8.sub
local.set $w27_0_16
local.get $w26_0_16
local.get $w22_0_16
i16x8.sub
local.set $w24_0_16
local.get $bd1
local.get $w28_0_16
i16x8.sub
local.set $w32_0_16
local.get $w30_0_16
local.get $w32_0_16
i16x8.sub
local.set $w33_0_16
local.get $w30_0_16
local.get $bd1
i16x8.sub
local.set $w34_0_16
local.get $w33_0_16
local.get $w29_0_16
i16x8.sub
local.set $w31_0_16
local.get $bd5
local.get $w35_0_16
i16x8.sub
local.set $w39_0_16
local.get $w37_0_16
local.get $w39_0_16
i16x8.sub
local.set $w40_0_16
local.get $w37_0_16
local.get $bd5
i16x8.sub
local.set $w41_0_16
local.get $w40_0_16
local.get $w36_0_16
i16x8.sub
local.set $w38_0_16
local.get $bd9
local.get $w42_0_16
i16x8.sub
local.set $w46_0_16
local.get $w44_0_16
local.get $w46_0_16
i16x8.sub
local.set $w47_0_16
local.get $w44_0_16
local.get $bd9
i16x8.sub
local.set $w48_0_16
local.get $w47_0_16
local.get $w43_0_16
i16x8.sub
local.set $w45_0_16
(local.set $w0_0_17(v128.load8x8_s offset=136(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=136(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=136(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=136(local.get $bp3)))
(local.set $w1_0_17(v128.load8x8_s offset=136(local.get $bp4)))
(local.set $w2_0_17(v128.load8x8_s offset=136(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=136(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=136(local.get $bp7)))
(local.set $w7_0_17(v128.load8x8_s offset=136(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=136(local.get $bp9)))
(local.set $w14_0_17(v128.load8x8_s offset=136(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=136(local.get $bp11)))
(local.set $w8_0_17(v128.load8x8_s offset=136(local.get $bp12)))
(local.set $w9_0_17(v128.load8x8_s offset=136(local.get $bp13)))
(local.set $w15_0_17(v128.load8x8_s offset=136(local.get $bp14)))
(local.set $w16_0_17(v128.load8x8_s offset=136(local.get $bp15)))
local.get $b2
local.get $w0_0_17
i16x8.sub
local.set $w28_0_17
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_17
i16x8.sub
local.set $w29_0_17
local.get $b7
local.get $w2_0_17
i16x8.sub
local.set $w30_0_17
local.get $w14_0_17
local.get $w28_0_17
i16x8.sub
local.set $w35_0_17
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_17
local.get $w29_0_17
i16x8.sub
local.set $w36_0_17
local.get $w16_0_17
local.get $w30_0_17
i16x8.sub
local.set $w37_0_17
local.get $w14_0_17
local.get $b2
i16x8.sub
local.set $w42_0_17
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_17
local.get $b6
i16x8.sub
local.set $w43_0_17
local.get $w16_0_17
local.get $b7
i16x8.sub
local.set $w44_0_17
local.get $w35_0_17
local.get $w7_0_17
i16x8.sub
local.set $w21_0_17
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_17
local.get $w8_0_17
i16x8.sub
local.set $w22_0_17
local.get $w37_0_17
local.get $w9_0_17
i16x8.sub
local.set $w23_0_17
local.get $b1
local.get $w0_0_17
i16x8.sub
local.set $w4_0_17
local.get $w2_0_17
local.get $w4_0_17
i16x8.sub
local.set $w5_0_17
local.get $w2_0_17
local.get $b1
i16x8.sub
local.set $w6_0_17
local.get $w5_0_17
local.get $w1_0_17
i16x8.sub
local.set $w3_0_17
local.get $b9
local.get $w7_0_17
i16x8.sub
local.set $w11_0_17
local.get $w9_0_17
local.get $w11_0_17
i16x8.sub
local.set $w12_0_17
local.get $w9_0_17
local.get $b9
i16x8.sub
local.set $w13_0_17
local.get $w12_0_17
local.get $w8_0_17
i16x8.sub
local.set $w10_0_17
local.get $b11
local.get $w14_0_17
i16x8.sub
local.set $w18_0_17
local.get $w16_0_17
local.get $w18_0_17
i16x8.sub
local.set $w19_0_17
local.get $w16_0_17
local.get $b11
i16x8.sub
local.set $w20_0_17
local.get $w19_0_17
local.get $w15_0_17
i16x8.sub
local.set $w17_0_17
local.get $bd13
local.get $w21_0_17
i16x8.sub
local.set $w25_0_17
local.get $w23_0_17
local.get $w25_0_17
i16x8.sub
local.set $w26_0_17
local.get $w23_0_17
local.get $bd13
i16x8.sub
local.set $w27_0_17
local.get $w26_0_17
local.get $w22_0_17
i16x8.sub
local.set $w24_0_17
local.get $bd1
local.get $w28_0_17
i16x8.sub
local.set $w32_0_17
local.get $w30_0_17
local.get $w32_0_17
i16x8.sub
local.set $w33_0_17
local.get $w30_0_17
local.get $bd1
i16x8.sub
local.set $w34_0_17
local.get $w33_0_17
local.get $w29_0_17
i16x8.sub
local.set $w31_0_17
local.get $bd5
local.get $w35_0_17
i16x8.sub
local.set $w39_0_17
local.get $w37_0_17
local.get $w39_0_17
i16x8.sub
local.set $w40_0_17
local.get $w37_0_17
local.get $bd5
i16x8.sub
local.set $w41_0_17
local.get $w40_0_17
local.get $w36_0_17
i16x8.sub
local.set $w38_0_17
local.get $bd9
local.get $w42_0_17
i16x8.sub
local.set $w46_0_17
local.get $w44_0_17
local.get $w46_0_17
i16x8.sub
local.set $w47_0_17
local.get $w44_0_17
local.get $bd9
i16x8.sub
local.set $w48_0_17
local.get $w47_0_17
local.get $w43_0_17
i16x8.sub
local.set $w45_0_17
(local.set $w0_0_18(v128.load8x8_s offset=144(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=144(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=144(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=144(local.get $bp3)))
(local.set $w1_0_18(v128.load8x8_s offset=144(local.get $bp4)))
(local.set $w2_0_18(v128.load8x8_s offset=144(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=144(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=144(local.get $bp7)))
(local.set $w7_0_18(v128.load8x8_s offset=144(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=144(local.get $bp9)))
(local.set $w14_0_18(v128.load8x8_s offset=144(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=144(local.get $bp11)))
(local.set $w8_0_18(v128.load8x8_s offset=144(local.get $bp12)))
(local.set $w9_0_18(v128.load8x8_s offset=144(local.get $bp13)))
(local.set $w15_0_18(v128.load8x8_s offset=144(local.get $bp14)))
(local.set $w16_0_18(v128.load8x8_s offset=144(local.get $bp15)))
local.get $b2
local.get $w0_0_18
i16x8.sub
local.set $w28_0_18
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_18
i16x8.sub
local.set $w29_0_18
local.get $b7
local.get $w2_0_18
i16x8.sub
local.set $w30_0_18
local.get $w14_0_18
local.get $w28_0_18
i16x8.sub
local.set $w35_0_18
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_18
local.get $w29_0_18
i16x8.sub
local.set $w36_0_18
local.get $w16_0_18
local.get $w30_0_18
i16x8.sub
local.set $w37_0_18
local.get $w14_0_18
local.get $b2
i16x8.sub
local.set $w42_0_18
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_18
local.get $b6
i16x8.sub
local.set $w43_0_18
local.get $w16_0_18
local.get $b7
i16x8.sub
local.set $w44_0_18
local.get $w35_0_18
local.get $w7_0_18
i16x8.sub
local.set $w21_0_18
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_18
local.get $w8_0_18
i16x8.sub
local.set $w22_0_18
local.get $w37_0_18
local.get $w9_0_18
i16x8.sub
local.set $w23_0_18
local.get $b1
local.get $w0_0_18
i16x8.sub
local.set $w4_0_18
local.get $w2_0_18
local.get $w4_0_18
i16x8.sub
local.set $w5_0_18
local.get $w2_0_18
local.get $b1
i16x8.sub
local.set $w6_0_18
local.get $w5_0_18
local.get $w1_0_18
i16x8.sub
local.set $w3_0_18
local.get $b9
local.get $w7_0_18
i16x8.sub
local.set $w11_0_18
local.get $w9_0_18
local.get $w11_0_18
i16x8.sub
local.set $w12_0_18
local.get $w9_0_18
local.get $b9
i16x8.sub
local.set $w13_0_18
local.get $w12_0_18
local.get $w8_0_18
i16x8.sub
local.set $w10_0_18
local.get $b11
local.get $w14_0_18
i16x8.sub
local.set $w18_0_18
local.get $w16_0_18
local.get $w18_0_18
i16x8.sub
local.set $w19_0_18
local.get $w16_0_18
local.get $b11
i16x8.sub
local.set $w20_0_18
local.get $w19_0_18
local.get $w15_0_18
i16x8.sub
local.set $w17_0_18
local.get $bd13
local.get $w21_0_18
i16x8.sub
local.set $w25_0_18
local.get $w23_0_18
local.get $w25_0_18
i16x8.sub
local.set $w26_0_18
local.get $w23_0_18
local.get $bd13
i16x8.sub
local.set $w27_0_18
local.get $w26_0_18
local.get $w22_0_18
i16x8.sub
local.set $w24_0_18
local.get $bd1
local.get $w28_0_18
i16x8.sub
local.set $w32_0_18
local.get $w30_0_18
local.get $w32_0_18
i16x8.sub
local.set $w33_0_18
local.get $w30_0_18
local.get $bd1
i16x8.sub
local.set $w34_0_18
local.get $w33_0_18
local.get $w29_0_18
i16x8.sub
local.set $w31_0_18
local.get $bd5
local.get $w35_0_18
i16x8.sub
local.set $w39_0_18
local.get $w37_0_18
local.get $w39_0_18
i16x8.sub
local.set $w40_0_18
local.get $w37_0_18
local.get $bd5
i16x8.sub
local.set $w41_0_18
local.get $w40_0_18
local.get $w36_0_18
i16x8.sub
local.set $w38_0_18
local.get $bd9
local.get $w42_0_18
i16x8.sub
local.set $w46_0_18
local.get $w44_0_18
local.get $w46_0_18
i16x8.sub
local.set $w47_0_18
local.get $w44_0_18
local.get $bd9
i16x8.sub
local.set $w48_0_18
local.get $w47_0_18
local.get $w43_0_18
i16x8.sub
local.set $w45_0_18
(local.set $w0_0_19(v128.load8x8_s offset=152(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=152(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=152(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=152(local.get $bp3)))
(local.set $w1_0_19(v128.load8x8_s offset=152(local.get $bp4)))
(local.set $w2_0_19(v128.load8x8_s offset=152(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=152(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=152(local.get $bp7)))
(local.set $w7_0_19(v128.load8x8_s offset=152(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=152(local.get $bp9)))
(local.set $w14_0_19(v128.load8x8_s offset=152(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=152(local.get $bp11)))
(local.set $w8_0_19(v128.load8x8_s offset=152(local.get $bp12)))
(local.set $w9_0_19(v128.load8x8_s offset=152(local.get $bp13)))
(local.set $w15_0_19(v128.load8x8_s offset=152(local.get $bp14)))
(local.set $w16_0_19(v128.load8x8_s offset=152(local.get $bp15)))
local.get $b2
local.get $w0_0_19
i16x8.sub
local.set $w28_0_19
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_19
i16x8.sub
local.set $w29_0_19
local.get $b7
local.get $w2_0_19
i16x8.sub
local.set $w30_0_19
local.get $w14_0_19
local.get $w28_0_19
i16x8.sub
local.set $w35_0_19
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_19
local.get $w29_0_19
i16x8.sub
local.set $w36_0_19
local.get $w16_0_19
local.get $w30_0_19
i16x8.sub
local.set $w37_0_19
local.get $w14_0_19
local.get $b2
i16x8.sub
local.set $w42_0_19
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_19
local.get $b6
i16x8.sub
local.set $w43_0_19
local.get $w16_0_19
local.get $b7
i16x8.sub
local.set $w44_0_19
local.get $w35_0_19
local.get $w7_0_19
i16x8.sub
local.set $w21_0_19
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_19
local.get $w8_0_19
i16x8.sub
local.set $w22_0_19
local.get $w37_0_19
local.get $w9_0_19
i16x8.sub
local.set $w23_0_19
local.get $b1
local.get $w0_0_19
i16x8.sub
local.set $w4_0_19
local.get $w2_0_19
local.get $w4_0_19
i16x8.sub
local.set $w5_0_19
local.get $w2_0_19
local.get $b1
i16x8.sub
local.set $w6_0_19
local.get $w5_0_19
local.get $w1_0_19
i16x8.sub
local.set $w3_0_19
local.get $b9
local.get $w7_0_19
i16x8.sub
local.set $w11_0_19
local.get $w9_0_19
local.get $w11_0_19
i16x8.sub
local.set $w12_0_19
local.get $w9_0_19
local.get $b9
i16x8.sub
local.set $w13_0_19
local.get $w12_0_19
local.get $w8_0_19
i16x8.sub
local.set $w10_0_19
local.get $b11
local.get $w14_0_19
i16x8.sub
local.set $w18_0_19
local.get $w16_0_19
local.get $w18_0_19
i16x8.sub
local.set $w19_0_19
local.get $w16_0_19
local.get $b11
i16x8.sub
local.set $w20_0_19
local.get $w19_0_19
local.get $w15_0_19
i16x8.sub
local.set $w17_0_19
local.get $bd13
local.get $w21_0_19
i16x8.sub
local.set $w25_0_19
local.get $w23_0_19
local.get $w25_0_19
i16x8.sub
local.set $w26_0_19
local.get $w23_0_19
local.get $bd13
i16x8.sub
local.set $w27_0_19
local.get $w26_0_19
local.get $w22_0_19
i16x8.sub
local.set $w24_0_19
local.get $bd1
local.get $w28_0_19
i16x8.sub
local.set $w32_0_19
local.get $w30_0_19
local.get $w32_0_19
i16x8.sub
local.set $w33_0_19
local.get $w30_0_19
local.get $bd1
i16x8.sub
local.set $w34_0_19
local.get $w33_0_19
local.get $w29_0_19
i16x8.sub
local.set $w31_0_19
local.get $bd5
local.get $w35_0_19
i16x8.sub
local.set $w39_0_19
local.get $w37_0_19
local.get $w39_0_19
i16x8.sub
local.set $w40_0_19
local.get $w37_0_19
local.get $bd5
i16x8.sub
local.set $w41_0_19
local.get $w40_0_19
local.get $w36_0_19
i16x8.sub
local.set $w38_0_19
local.get $bd9
local.get $w42_0_19
i16x8.sub
local.set $w46_0_19
local.get $w44_0_19
local.get $w46_0_19
i16x8.sub
local.set $w47_0_19
local.get $w44_0_19
local.get $bd9
i16x8.sub
local.set $w48_0_19
local.get $w47_0_19
local.get $w43_0_19
i16x8.sub
local.set $w45_0_19
(local.set $w0_0_20(v128.load8x8_s offset=160(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=160(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=160(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=160(local.get $bp3)))
(local.set $w1_0_20(v128.load8x8_s offset=160(local.get $bp4)))
(local.set $w2_0_20(v128.load8x8_s offset=160(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=160(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=160(local.get $bp7)))
(local.set $w7_0_20(v128.load8x8_s offset=160(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=160(local.get $bp9)))
(local.set $w14_0_20(v128.load8x8_s offset=160(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=160(local.get $bp11)))
(local.set $w8_0_20(v128.load8x8_s offset=160(local.get $bp12)))
(local.set $w9_0_20(v128.load8x8_s offset=160(local.get $bp13)))
(local.set $w15_0_20(v128.load8x8_s offset=160(local.get $bp14)))
(local.set $w16_0_20(v128.load8x8_s offset=160(local.get $bp15)))
local.get $b2
local.get $w0_0_20
i16x8.sub
local.set $w28_0_20
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_20
i16x8.sub
local.set $w29_0_20
local.get $b7
local.get $w2_0_20
i16x8.sub
local.set $w30_0_20
local.get $w14_0_20
local.get $w28_0_20
i16x8.sub
local.set $w35_0_20
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_20
local.get $w29_0_20
i16x8.sub
local.set $w36_0_20
local.get $w16_0_20
local.get $w30_0_20
i16x8.sub
local.set $w37_0_20
local.get $w14_0_20
local.get $b2
i16x8.sub
local.set $w42_0_20
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_20
local.get $b6
i16x8.sub
local.set $w43_0_20
local.get $w16_0_20
local.get $b7
i16x8.sub
local.set $w44_0_20
local.get $w35_0_20
local.get $w7_0_20
i16x8.sub
local.set $w21_0_20
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_20
local.get $w8_0_20
i16x8.sub
local.set $w22_0_20
local.get $w37_0_20
local.get $w9_0_20
i16x8.sub
local.set $w23_0_20
local.get $b1
local.get $w0_0_20
i16x8.sub
local.set $w4_0_20
local.get $w2_0_20
local.get $w4_0_20
i16x8.sub
local.set $w5_0_20
local.get $w2_0_20
local.get $b1
i16x8.sub
local.set $w6_0_20
local.get $w5_0_20
local.get $w1_0_20
i16x8.sub
local.set $w3_0_20
local.get $b9
local.get $w7_0_20
i16x8.sub
local.set $w11_0_20
local.get $w9_0_20
local.get $w11_0_20
i16x8.sub
local.set $w12_0_20
local.get $w9_0_20
local.get $b9
i16x8.sub
local.set $w13_0_20
local.get $w12_0_20
local.get $w8_0_20
i16x8.sub
local.set $w10_0_20
local.get $b11
local.get $w14_0_20
i16x8.sub
local.set $w18_0_20
local.get $w16_0_20
local.get $w18_0_20
i16x8.sub
local.set $w19_0_20
local.get $w16_0_20
local.get $b11
i16x8.sub
local.set $w20_0_20
local.get $w19_0_20
local.get $w15_0_20
i16x8.sub
local.set $w17_0_20
local.get $bd13
local.get $w21_0_20
i16x8.sub
local.set $w25_0_20
local.get $w23_0_20
local.get $w25_0_20
i16x8.sub
local.set $w26_0_20
local.get $w23_0_20
local.get $bd13
i16x8.sub
local.set $w27_0_20
local.get $w26_0_20
local.get $w22_0_20
i16x8.sub
local.set $w24_0_20
local.get $bd1
local.get $w28_0_20
i16x8.sub
local.set $w32_0_20
local.get $w30_0_20
local.get $w32_0_20
i16x8.sub
local.set $w33_0_20
local.get $w30_0_20
local.get $bd1
i16x8.sub
local.set $w34_0_20
local.get $w33_0_20
local.get $w29_0_20
i16x8.sub
local.set $w31_0_20
local.get $bd5
local.get $w35_0_20
i16x8.sub
local.set $w39_0_20
local.get $w37_0_20
local.get $w39_0_20
i16x8.sub
local.set $w40_0_20
local.get $w37_0_20
local.get $bd5
i16x8.sub
local.set $w41_0_20
local.get $w40_0_20
local.get $w36_0_20
i16x8.sub
local.set $w38_0_20
local.get $bd9
local.get $w42_0_20
i16x8.sub
local.set $w46_0_20
local.get $w44_0_20
local.get $w46_0_20
i16x8.sub
local.set $w47_0_20
local.get $w44_0_20
local.get $bd9
i16x8.sub
local.set $w48_0_20
local.get $w47_0_20
local.get $w43_0_20
i16x8.sub
local.set $w45_0_20
(local.set $w0_0_21(v128.load8x8_s offset=168(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=168(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=168(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=168(local.get $bp3)))
(local.set $w1_0_21(v128.load8x8_s offset=168(local.get $bp4)))
(local.set $w2_0_21(v128.load8x8_s offset=168(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=168(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=168(local.get $bp7)))
(local.set $w7_0_21(v128.load8x8_s offset=168(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=168(local.get $bp9)))
(local.set $w14_0_21(v128.load8x8_s offset=168(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=168(local.get $bp11)))
(local.set $w8_0_21(v128.load8x8_s offset=168(local.get $bp12)))
(local.set $w9_0_21(v128.load8x8_s offset=168(local.get $bp13)))
(local.set $w15_0_21(v128.load8x8_s offset=168(local.get $bp14)))
(local.set $w16_0_21(v128.load8x8_s offset=168(local.get $bp15)))
local.get $b2
local.get $w0_0_21
i16x8.sub
local.set $w28_0_21
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_21
i16x8.sub
local.set $w29_0_21
local.get $b7
local.get $w2_0_21
i16x8.sub
local.set $w30_0_21
local.get $w14_0_21
local.get $w28_0_21
i16x8.sub
local.set $w35_0_21
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_21
local.get $w29_0_21
i16x8.sub
local.set $w36_0_21
local.get $w16_0_21
local.get $w30_0_21
i16x8.sub
local.set $w37_0_21
local.get $w14_0_21
local.get $b2
i16x8.sub
local.set $w42_0_21
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_21
local.get $b6
i16x8.sub
local.set $w43_0_21
local.get $w16_0_21
local.get $b7
i16x8.sub
local.set $w44_0_21
local.get $w35_0_21
local.get $w7_0_21
i16x8.sub
local.set $w21_0_21
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_21
local.get $w8_0_21
i16x8.sub
local.set $w22_0_21
local.get $w37_0_21
local.get $w9_0_21
i16x8.sub
local.set $w23_0_21
local.get $b1
local.get $w0_0_21
i16x8.sub
local.set $w4_0_21
local.get $w2_0_21
local.get $w4_0_21
i16x8.sub
local.set $w5_0_21
local.get $w2_0_21
local.get $b1
i16x8.sub
local.set $w6_0_21
local.get $w5_0_21
local.get $w1_0_21
i16x8.sub
local.set $w3_0_21
local.get $b9
local.get $w7_0_21
i16x8.sub
local.set $w11_0_21
local.get $w9_0_21
local.get $w11_0_21
i16x8.sub
local.set $w12_0_21
local.get $w9_0_21
local.get $b9
i16x8.sub
local.set $w13_0_21
local.get $w12_0_21
local.get $w8_0_21
i16x8.sub
local.set $w10_0_21
local.get $b11
local.get $w14_0_21
i16x8.sub
local.set $w18_0_21
local.get $w16_0_21
local.get $w18_0_21
i16x8.sub
local.set $w19_0_21
local.get $w16_0_21
local.get $b11
i16x8.sub
local.set $w20_0_21
local.get $w19_0_21
local.get $w15_0_21
i16x8.sub
local.set $w17_0_21
local.get $bd13
local.get $w21_0_21
i16x8.sub
local.set $w25_0_21
local.get $w23_0_21
local.get $w25_0_21
i16x8.sub
local.set $w26_0_21
local.get $w23_0_21
local.get $bd13
i16x8.sub
local.set $w27_0_21
local.get $w26_0_21
local.get $w22_0_21
i16x8.sub
local.set $w24_0_21
local.get $bd1
local.get $w28_0_21
i16x8.sub
local.set $w32_0_21
local.get $w30_0_21
local.get $w32_0_21
i16x8.sub
local.set $w33_0_21
local.get $w30_0_21
local.get $bd1
i16x8.sub
local.set $w34_0_21
local.get $w33_0_21
local.get $w29_0_21
i16x8.sub
local.set $w31_0_21
local.get $bd5
local.get $w35_0_21
i16x8.sub
local.set $w39_0_21
local.get $w37_0_21
local.get $w39_0_21
i16x8.sub
local.set $w40_0_21
local.get $w37_0_21
local.get $bd5
i16x8.sub
local.set $w41_0_21
local.get $w40_0_21
local.get $w36_0_21
i16x8.sub
local.set $w38_0_21
local.get $bd9
local.get $w42_0_21
i16x8.sub
local.set $w46_0_21
local.get $w44_0_21
local.get $w46_0_21
i16x8.sub
local.set $w47_0_21
local.get $w44_0_21
local.get $bd9
i16x8.sub
local.set $w48_0_21
local.get $w47_0_21
local.get $w43_0_21
i16x8.sub
local.set $w45_0_21
(local.set $w0_0_22(v128.load8x8_s offset=176(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=176(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=176(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=176(local.get $bp3)))
(local.set $w1_0_22(v128.load8x8_s offset=176(local.get $bp4)))
(local.set $w2_0_22(v128.load8x8_s offset=176(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=176(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=176(local.get $bp7)))
(local.set $w7_0_22(v128.load8x8_s offset=176(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=176(local.get $bp9)))
(local.set $w14_0_22(v128.load8x8_s offset=176(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=176(local.get $bp11)))
(local.set $w8_0_22(v128.load8x8_s offset=176(local.get $bp12)))
(local.set $w9_0_22(v128.load8x8_s offset=176(local.get $bp13)))
(local.set $w15_0_22(v128.load8x8_s offset=176(local.get $bp14)))
(local.set $w16_0_22(v128.load8x8_s offset=176(local.get $bp15)))
local.get $b2
local.get $w0_0_22
i16x8.sub
local.set $w28_0_22
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_22
i16x8.sub
local.set $w29_0_22
local.get $b7
local.get $w2_0_22
i16x8.sub
local.set $w30_0_22
local.get $w14_0_22
local.get $w28_0_22
i16x8.sub
local.set $w35_0_22
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_22
local.get $w29_0_22
i16x8.sub
local.set $w36_0_22
local.get $w16_0_22
local.get $w30_0_22
i16x8.sub
local.set $w37_0_22
local.get $w14_0_22
local.get $b2
i16x8.sub
local.set $w42_0_22
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_22
local.get $b6
i16x8.sub
local.set $w43_0_22
local.get $w16_0_22
local.get $b7
i16x8.sub
local.set $w44_0_22
local.get $w35_0_22
local.get $w7_0_22
i16x8.sub
local.set $w21_0_22
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_22
local.get $w8_0_22
i16x8.sub
local.set $w22_0_22
local.get $w37_0_22
local.get $w9_0_22
i16x8.sub
local.set $w23_0_22
local.get $b1
local.get $w0_0_22
i16x8.sub
local.set $w4_0_22
local.get $w2_0_22
local.get $w4_0_22
i16x8.sub
local.set $w5_0_22
local.get $w2_0_22
local.get $b1
i16x8.sub
local.set $w6_0_22
local.get $w5_0_22
local.get $w1_0_22
i16x8.sub
local.set $w3_0_22
local.get $b9
local.get $w7_0_22
i16x8.sub
local.set $w11_0_22
local.get $w9_0_22
local.get $w11_0_22
i16x8.sub
local.set $w12_0_22
local.get $w9_0_22
local.get $b9
i16x8.sub
local.set $w13_0_22
local.get $w12_0_22
local.get $w8_0_22
i16x8.sub
local.set $w10_0_22
local.get $b11
local.get $w14_0_22
i16x8.sub
local.set $w18_0_22
local.get $w16_0_22
local.get $w18_0_22
i16x8.sub
local.set $w19_0_22
local.get $w16_0_22
local.get $b11
i16x8.sub
local.set $w20_0_22
local.get $w19_0_22
local.get $w15_0_22
i16x8.sub
local.set $w17_0_22
local.get $bd13
local.get $w21_0_22
i16x8.sub
local.set $w25_0_22
local.get $w23_0_22
local.get $w25_0_22
i16x8.sub
local.set $w26_0_22
local.get $w23_0_22
local.get $bd13
i16x8.sub
local.set $w27_0_22
local.get $w26_0_22
local.get $w22_0_22
i16x8.sub
local.set $w24_0_22
local.get $bd1
local.get $w28_0_22
i16x8.sub
local.set $w32_0_22
local.get $w30_0_22
local.get $w32_0_22
i16x8.sub
local.set $w33_0_22
local.get $w30_0_22
local.get $bd1
i16x8.sub
local.set $w34_0_22
local.get $w33_0_22
local.get $w29_0_22
i16x8.sub
local.set $w31_0_22
local.get $bd5
local.get $w35_0_22
i16x8.sub
local.set $w39_0_22
local.get $w37_0_22
local.get $w39_0_22
i16x8.sub
local.set $w40_0_22
local.get $w37_0_22
local.get $bd5
i16x8.sub
local.set $w41_0_22
local.get $w40_0_22
local.get $w36_0_22
i16x8.sub
local.set $w38_0_22
local.get $bd9
local.get $w42_0_22
i16x8.sub
local.set $w46_0_22
local.get $w44_0_22
local.get $w46_0_22
i16x8.sub
local.set $w47_0_22
local.get $w44_0_22
local.get $bd9
i16x8.sub
local.set $w48_0_22
local.get $w47_0_22
local.get $w43_0_22
i16x8.sub
local.set $w45_0_22
(local.set $w0_0_23(v128.load8x8_s offset=184(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=184(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=184(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=184(local.get $bp3)))
(local.set $w1_0_23(v128.load8x8_s offset=184(local.get $bp4)))
(local.set $w2_0_23(v128.load8x8_s offset=184(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=184(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=184(local.get $bp7)))
(local.set $w7_0_23(v128.load8x8_s offset=184(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=184(local.get $bp9)))
(local.set $w14_0_23(v128.load8x8_s offset=184(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=184(local.get $bp11)))
(local.set $w8_0_23(v128.load8x8_s offset=184(local.get $bp12)))
(local.set $w9_0_23(v128.load8x8_s offset=184(local.get $bp13)))
(local.set $w15_0_23(v128.load8x8_s offset=184(local.get $bp14)))
(local.set $w16_0_23(v128.load8x8_s offset=184(local.get $bp15)))
local.get $b2
local.get $w0_0_23
i16x8.sub
local.set $w28_0_23
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_23
i16x8.sub
local.set $w29_0_23
local.get $b7
local.get $w2_0_23
i16x8.sub
local.set $w30_0_23
local.get $w14_0_23
local.get $w28_0_23
i16x8.sub
local.set $w35_0_23
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_23
local.get $w29_0_23
i16x8.sub
local.set $w36_0_23
local.get $w16_0_23
local.get $w30_0_23
i16x8.sub
local.set $w37_0_23
local.get $w14_0_23
local.get $b2
i16x8.sub
local.set $w42_0_23
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_23
local.get $b6
i16x8.sub
local.set $w43_0_23
local.get $w16_0_23
local.get $b7
i16x8.sub
local.set $w44_0_23
local.get $w35_0_23
local.get $w7_0_23
i16x8.sub
local.set $w21_0_23
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_23
local.get $w8_0_23
i16x8.sub
local.set $w22_0_23
local.get $w37_0_23
local.get $w9_0_23
i16x8.sub
local.set $w23_0_23
local.get $b1
local.get $w0_0_23
i16x8.sub
local.set $w4_0_23
local.get $w2_0_23
local.get $w4_0_23
i16x8.sub
local.set $w5_0_23
local.get $w2_0_23
local.get $b1
i16x8.sub
local.set $w6_0_23
local.get $w5_0_23
local.get $w1_0_23
i16x8.sub
local.set $w3_0_23
local.get $b9
local.get $w7_0_23
i16x8.sub
local.set $w11_0_23
local.get $w9_0_23
local.get $w11_0_23
i16x8.sub
local.set $w12_0_23
local.get $w9_0_23
local.get $b9
i16x8.sub
local.set $w13_0_23
local.get $w12_0_23
local.get $w8_0_23
i16x8.sub
local.set $w10_0_23
local.get $b11
local.get $w14_0_23
i16x8.sub
local.set $w18_0_23
local.get $w16_0_23
local.get $w18_0_23
i16x8.sub
local.set $w19_0_23
local.get $w16_0_23
local.get $b11
i16x8.sub
local.set $w20_0_23
local.get $w19_0_23
local.get $w15_0_23
i16x8.sub
local.set $w17_0_23
local.get $bd13
local.get $w21_0_23
i16x8.sub
local.set $w25_0_23
local.get $w23_0_23
local.get $w25_0_23
i16x8.sub
local.set $w26_0_23
local.get $w23_0_23
local.get $bd13
i16x8.sub
local.set $w27_0_23
local.get $w26_0_23
local.get $w22_0_23
i16x8.sub
local.set $w24_0_23
local.get $bd1
local.get $w28_0_23
i16x8.sub
local.set $w32_0_23
local.get $w30_0_23
local.get $w32_0_23
i16x8.sub
local.set $w33_0_23
local.get $w30_0_23
local.get $bd1
i16x8.sub
local.set $w34_0_23
local.get $w33_0_23
local.get $w29_0_23
i16x8.sub
local.set $w31_0_23
local.get $bd5
local.get $w35_0_23
i16x8.sub
local.set $w39_0_23
local.get $w37_0_23
local.get $w39_0_23
i16x8.sub
local.set $w40_0_23
local.get $w37_0_23
local.get $bd5
i16x8.sub
local.set $w41_0_23
local.get $w40_0_23
local.get $w36_0_23
i16x8.sub
local.set $w38_0_23
local.get $bd9
local.get $w42_0_23
i16x8.sub
local.set $w46_0_23
local.get $w44_0_23
local.get $w46_0_23
i16x8.sub
local.set $w47_0_23
local.get $w44_0_23
local.get $bd9
i16x8.sub
local.set $w48_0_23
local.get $w47_0_23
local.get $w43_0_23
i16x8.sub
local.set $w45_0_23
(local.set $w0_0_24(v128.load8x8_s offset=192(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=192(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=192(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=192(local.get $bp3)))
(local.set $w1_0_24(v128.load8x8_s offset=192(local.get $bp4)))
(local.set $w2_0_24(v128.load8x8_s offset=192(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=192(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=192(local.get $bp7)))
(local.set $w7_0_24(v128.load8x8_s offset=192(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=192(local.get $bp9)))
(local.set $w14_0_24(v128.load8x8_s offset=192(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=192(local.get $bp11)))
(local.set $w8_0_24(v128.load8x8_s offset=192(local.get $bp12)))
(local.set $w9_0_24(v128.load8x8_s offset=192(local.get $bp13)))
(local.set $w15_0_24(v128.load8x8_s offset=192(local.get $bp14)))
(local.set $w16_0_24(v128.load8x8_s offset=192(local.get $bp15)))
local.get $b2
local.get $w0_0_24
i16x8.sub
local.set $w28_0_24
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_24
i16x8.sub
local.set $w29_0_24
local.get $b7
local.get $w2_0_24
i16x8.sub
local.set $w30_0_24
local.get $w14_0_24
local.get $w28_0_24
i16x8.sub
local.set $w35_0_24
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_24
local.get $w29_0_24
i16x8.sub
local.set $w36_0_24
local.get $w16_0_24
local.get $w30_0_24
i16x8.sub
local.set $w37_0_24
local.get $w14_0_24
local.get $b2
i16x8.sub
local.set $w42_0_24
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_24
local.get $b6
i16x8.sub
local.set $w43_0_24
local.get $w16_0_24
local.get $b7
i16x8.sub
local.set $w44_0_24
local.get $w35_0_24
local.get $w7_0_24
i16x8.sub
local.set $w21_0_24
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_24
local.get $w8_0_24
i16x8.sub
local.set $w22_0_24
local.get $w37_0_24
local.get $w9_0_24
i16x8.sub
local.set $w23_0_24
local.get $b1
local.get $w0_0_24
i16x8.sub
local.set $w4_0_24
local.get $w2_0_24
local.get $w4_0_24
i16x8.sub
local.set $w5_0_24
local.get $w2_0_24
local.get $b1
i16x8.sub
local.set $w6_0_24
local.get $w5_0_24
local.get $w1_0_24
i16x8.sub
local.set $w3_0_24
local.get $b9
local.get $w7_0_24
i16x8.sub
local.set $w11_0_24
local.get $w9_0_24
local.get $w11_0_24
i16x8.sub
local.set $w12_0_24
local.get $w9_0_24
local.get $b9
i16x8.sub
local.set $w13_0_24
local.get $w12_0_24
local.get $w8_0_24
i16x8.sub
local.set $w10_0_24
local.get $b11
local.get $w14_0_24
i16x8.sub
local.set $w18_0_24
local.get $w16_0_24
local.get $w18_0_24
i16x8.sub
local.set $w19_0_24
local.get $w16_0_24
local.get $b11
i16x8.sub
local.set $w20_0_24
local.get $w19_0_24
local.get $w15_0_24
i16x8.sub
local.set $w17_0_24
local.get $bd13
local.get $w21_0_24
i16x8.sub
local.set $w25_0_24
local.get $w23_0_24
local.get $w25_0_24
i16x8.sub
local.set $w26_0_24
local.get $w23_0_24
local.get $bd13
i16x8.sub
local.set $w27_0_24
local.get $w26_0_24
local.get $w22_0_24
i16x8.sub
local.set $w24_0_24
local.get $bd1
local.get $w28_0_24
i16x8.sub
local.set $w32_0_24
local.get $w30_0_24
local.get $w32_0_24
i16x8.sub
local.set $w33_0_24
local.get $w30_0_24
local.get $bd1
i16x8.sub
local.set $w34_0_24
local.get $w33_0_24
local.get $w29_0_24
i16x8.sub
local.set $w31_0_24
local.get $bd5
local.get $w35_0_24
i16x8.sub
local.set $w39_0_24
local.get $w37_0_24
local.get $w39_0_24
i16x8.sub
local.set $w40_0_24
local.get $w37_0_24
local.get $bd5
i16x8.sub
local.set $w41_0_24
local.get $w40_0_24
local.get $w36_0_24
i16x8.sub
local.set $w38_0_24
local.get $bd9
local.get $w42_0_24
i16x8.sub
local.set $w46_0_24
local.get $w44_0_24
local.get $w46_0_24
i16x8.sub
local.set $w47_0_24
local.get $w44_0_24
local.get $bd9
i16x8.sub
local.set $w48_0_24
local.get $w47_0_24
local.get $w43_0_24
i16x8.sub
local.set $w45_0_24
(local.set $w0_0_25(v128.load8x8_s offset=200(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=200(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=200(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=200(local.get $bp3)))
(local.set $w1_0_25(v128.load8x8_s offset=200(local.get $bp4)))
(local.set $w2_0_25(v128.load8x8_s offset=200(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=200(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=200(local.get $bp7)))
(local.set $w7_0_25(v128.load8x8_s offset=200(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=200(local.get $bp9)))
(local.set $w14_0_25(v128.load8x8_s offset=200(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=200(local.get $bp11)))
(local.set $w8_0_25(v128.load8x8_s offset=200(local.get $bp12)))
(local.set $w9_0_25(v128.load8x8_s offset=200(local.get $bp13)))
(local.set $w15_0_25(v128.load8x8_s offset=200(local.get $bp14)))
(local.set $w16_0_25(v128.load8x8_s offset=200(local.get $bp15)))
local.get $b2
local.get $w0_0_25
i16x8.sub
local.set $w28_0_25
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_25
i16x8.sub
local.set $w29_0_25
local.get $b7
local.get $w2_0_25
i16x8.sub
local.set $w30_0_25
local.get $w14_0_25
local.get $w28_0_25
i16x8.sub
local.set $w35_0_25
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_25
local.get $w29_0_25
i16x8.sub
local.set $w36_0_25
local.get $w16_0_25
local.get $w30_0_25
i16x8.sub
local.set $w37_0_25
local.get $w14_0_25
local.get $b2
i16x8.sub
local.set $w42_0_25
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_25
local.get $b6
i16x8.sub
local.set $w43_0_25
local.get $w16_0_25
local.get $b7
i16x8.sub
local.set $w44_0_25
local.get $w35_0_25
local.get $w7_0_25
i16x8.sub
local.set $w21_0_25
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_25
local.get $w8_0_25
i16x8.sub
local.set $w22_0_25
local.get $w37_0_25
local.get $w9_0_25
i16x8.sub
local.set $w23_0_25
local.get $b1
local.get $w0_0_25
i16x8.sub
local.set $w4_0_25
local.get $w2_0_25
local.get $w4_0_25
i16x8.sub
local.set $w5_0_25
local.get $w2_0_25
local.get $b1
i16x8.sub
local.set $w6_0_25
local.get $w5_0_25
local.get $w1_0_25
i16x8.sub
local.set $w3_0_25
local.get $b9
local.get $w7_0_25
i16x8.sub
local.set $w11_0_25
local.get $w9_0_25
local.get $w11_0_25
i16x8.sub
local.set $w12_0_25
local.get $w9_0_25
local.get $b9
i16x8.sub
local.set $w13_0_25
local.get $w12_0_25
local.get $w8_0_25
i16x8.sub
local.set $w10_0_25
local.get $b11
local.get $w14_0_25
i16x8.sub
local.set $w18_0_25
local.get $w16_0_25
local.get $w18_0_25
i16x8.sub
local.set $w19_0_25
local.get $w16_0_25
local.get $b11
i16x8.sub
local.set $w20_0_25
local.get $w19_0_25
local.get $w15_0_25
i16x8.sub
local.set $w17_0_25
local.get $bd13
local.get $w21_0_25
i16x8.sub
local.set $w25_0_25
local.get $w23_0_25
local.get $w25_0_25
i16x8.sub
local.set $w26_0_25
local.get $w23_0_25
local.get $bd13
i16x8.sub
local.set $w27_0_25
local.get $w26_0_25
local.get $w22_0_25
i16x8.sub
local.set $w24_0_25
local.get $bd1
local.get $w28_0_25
i16x8.sub
local.set $w32_0_25
local.get $w30_0_25
local.get $w32_0_25
i16x8.sub
local.set $w33_0_25
local.get $w30_0_25
local.get $bd1
i16x8.sub
local.set $w34_0_25
local.get $w33_0_25
local.get $w29_0_25
i16x8.sub
local.set $w31_0_25
local.get $bd5
local.get $w35_0_25
i16x8.sub
local.set $w39_0_25
local.get $w37_0_25
local.get $w39_0_25
i16x8.sub
local.set $w40_0_25
local.get $w37_0_25
local.get $bd5
i16x8.sub
local.set $w41_0_25
local.get $w40_0_25
local.get $w36_0_25
i16x8.sub
local.set $w38_0_25
local.get $bd9
local.get $w42_0_25
i16x8.sub
local.set $w46_0_25
local.get $w44_0_25
local.get $w46_0_25
i16x8.sub
local.set $w47_0_25
local.get $w44_0_25
local.get $bd9
i16x8.sub
local.set $w48_0_25
local.get $w47_0_25
local.get $w43_0_25
i16x8.sub
local.set $w45_0_25
(local.set $w0_0_26(v128.load8x8_s offset=208(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=208(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=208(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=208(local.get $bp3)))
(local.set $w1_0_26(v128.load8x8_s offset=208(local.get $bp4)))
(local.set $w2_0_26(v128.load8x8_s offset=208(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=208(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=208(local.get $bp7)))
(local.set $w7_0_26(v128.load8x8_s offset=208(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=208(local.get $bp9)))
(local.set $w14_0_26(v128.load8x8_s offset=208(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=208(local.get $bp11)))
(local.set $w8_0_26(v128.load8x8_s offset=208(local.get $bp12)))
(local.set $w9_0_26(v128.load8x8_s offset=208(local.get $bp13)))
(local.set $w15_0_26(v128.load8x8_s offset=208(local.get $bp14)))
(local.set $w16_0_26(v128.load8x8_s offset=208(local.get $bp15)))
local.get $b2
local.get $w0_0_26
i16x8.sub
local.set $w28_0_26
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_26
i16x8.sub
local.set $w29_0_26
local.get $b7
local.get $w2_0_26
i16x8.sub
local.set $w30_0_26
local.get $w14_0_26
local.get $w28_0_26
i16x8.sub
local.set $w35_0_26
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_26
local.get $w29_0_26
i16x8.sub
local.set $w36_0_26
local.get $w16_0_26
local.get $w30_0_26
i16x8.sub
local.set $w37_0_26
local.get $w14_0_26
local.get $b2
i16x8.sub
local.set $w42_0_26
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_26
local.get $b6
i16x8.sub
local.set $w43_0_26
local.get $w16_0_26
local.get $b7
i16x8.sub
local.set $w44_0_26
local.get $w35_0_26
local.get $w7_0_26
i16x8.sub
local.set $w21_0_26
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_26
local.get $w8_0_26
i16x8.sub
local.set $w22_0_26
local.get $w37_0_26
local.get $w9_0_26
i16x8.sub
local.set $w23_0_26
local.get $b1
local.get $w0_0_26
i16x8.sub
local.set $w4_0_26
local.get $w2_0_26
local.get $w4_0_26
i16x8.sub
local.set $w5_0_26
local.get $w2_0_26
local.get $b1
i16x8.sub
local.set $w6_0_26
local.get $w5_0_26
local.get $w1_0_26
i16x8.sub
local.set $w3_0_26
local.get $b9
local.get $w7_0_26
i16x8.sub
local.set $w11_0_26
local.get $w9_0_26
local.get $w11_0_26
i16x8.sub
local.set $w12_0_26
local.get $w9_0_26
local.get $b9
i16x8.sub
local.set $w13_0_26
local.get $w12_0_26
local.get $w8_0_26
i16x8.sub
local.set $w10_0_26
local.get $b11
local.get $w14_0_26
i16x8.sub
local.set $w18_0_26
local.get $w16_0_26
local.get $w18_0_26
i16x8.sub
local.set $w19_0_26
local.get $w16_0_26
local.get $b11
i16x8.sub
local.set $w20_0_26
local.get $w19_0_26
local.get $w15_0_26
i16x8.sub
local.set $w17_0_26
local.get $bd13
local.get $w21_0_26
i16x8.sub
local.set $w25_0_26
local.get $w23_0_26
local.get $w25_0_26
i16x8.sub
local.set $w26_0_26
local.get $w23_0_26
local.get $bd13
i16x8.sub
local.set $w27_0_26
local.get $w26_0_26
local.get $w22_0_26
i16x8.sub
local.set $w24_0_26
local.get $bd1
local.get $w28_0_26
i16x8.sub
local.set $w32_0_26
local.get $w30_0_26
local.get $w32_0_26
i16x8.sub
local.set $w33_0_26
local.get $w30_0_26
local.get $bd1
i16x8.sub
local.set $w34_0_26
local.get $w33_0_26
local.get $w29_0_26
i16x8.sub
local.set $w31_0_26
local.get $bd5
local.get $w35_0_26
i16x8.sub
local.set $w39_0_26
local.get $w37_0_26
local.get $w39_0_26
i16x8.sub
local.set $w40_0_26
local.get $w37_0_26
local.get $bd5
i16x8.sub
local.set $w41_0_26
local.get $w40_0_26
local.get $w36_0_26
i16x8.sub
local.set $w38_0_26
local.get $bd9
local.get $w42_0_26
i16x8.sub
local.set $w46_0_26
local.get $w44_0_26
local.get $w46_0_26
i16x8.sub
local.set $w47_0_26
local.get $w44_0_26
local.get $bd9
i16x8.sub
local.set $w48_0_26
local.get $w47_0_26
local.get $w43_0_26
i16x8.sub
local.set $w45_0_26
(local.set $w0_0_27(v128.load8x8_s offset=216(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=216(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=216(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=216(local.get $bp3)))
(local.set $w1_0_27(v128.load8x8_s offset=216(local.get $bp4)))
(local.set $w2_0_27(v128.load8x8_s offset=216(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=216(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=216(local.get $bp7)))
(local.set $w7_0_27(v128.load8x8_s offset=216(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=216(local.get $bp9)))
(local.set $w14_0_27(v128.load8x8_s offset=216(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=216(local.get $bp11)))
(local.set $w8_0_27(v128.load8x8_s offset=216(local.get $bp12)))
(local.set $w9_0_27(v128.load8x8_s offset=216(local.get $bp13)))
(local.set $w15_0_27(v128.load8x8_s offset=216(local.get $bp14)))
(local.set $w16_0_27(v128.load8x8_s offset=216(local.get $bp15)))
local.get $b2
local.get $w0_0_27
i16x8.sub
local.set $w28_0_27
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_27
i16x8.sub
local.set $w29_0_27
local.get $b7
local.get $w2_0_27
i16x8.sub
local.set $w30_0_27
local.get $w14_0_27
local.get $w28_0_27
i16x8.sub
local.set $w35_0_27
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_27
local.get $w29_0_27
i16x8.sub
local.set $w36_0_27
local.get $w16_0_27
local.get $w30_0_27
i16x8.sub
local.set $w37_0_27
local.get $w14_0_27
local.get $b2
i16x8.sub
local.set $w42_0_27
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_27
local.get $b6
i16x8.sub
local.set $w43_0_27
local.get $w16_0_27
local.get $b7
i16x8.sub
local.set $w44_0_27
local.get $w35_0_27
local.get $w7_0_27
i16x8.sub
local.set $w21_0_27
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_27
local.get $w8_0_27
i16x8.sub
local.set $w22_0_27
local.get $w37_0_27
local.get $w9_0_27
i16x8.sub
local.set $w23_0_27
local.get $b1
local.get $w0_0_27
i16x8.sub
local.set $w4_0_27
local.get $w2_0_27
local.get $w4_0_27
i16x8.sub
local.set $w5_0_27
local.get $w2_0_27
local.get $b1
i16x8.sub
local.set $w6_0_27
local.get $w5_0_27
local.get $w1_0_27
i16x8.sub
local.set $w3_0_27
local.get $b9
local.get $w7_0_27
i16x8.sub
local.set $w11_0_27
local.get $w9_0_27
local.get $w11_0_27
i16x8.sub
local.set $w12_0_27
local.get $w9_0_27
local.get $b9
i16x8.sub
local.set $w13_0_27
local.get $w12_0_27
local.get $w8_0_27
i16x8.sub
local.set $w10_0_27
local.get $b11
local.get $w14_0_27
i16x8.sub
local.set $w18_0_27
local.get $w16_0_27
local.get $w18_0_27
i16x8.sub
local.set $w19_0_27
local.get $w16_0_27
local.get $b11
i16x8.sub
local.set $w20_0_27
local.get $w19_0_27
local.get $w15_0_27
i16x8.sub
local.set $w17_0_27
local.get $bd13
local.get $w21_0_27
i16x8.sub
local.set $w25_0_27
local.get $w23_0_27
local.get $w25_0_27
i16x8.sub
local.set $w26_0_27
local.get $w23_0_27
local.get $bd13
i16x8.sub
local.set $w27_0_27
local.get $w26_0_27
local.get $w22_0_27
i16x8.sub
local.set $w24_0_27
local.get $bd1
local.get $w28_0_27
i16x8.sub
local.set $w32_0_27
local.get $w30_0_27
local.get $w32_0_27
i16x8.sub
local.set $w33_0_27
local.get $w30_0_27
local.get $bd1
i16x8.sub
local.set $w34_0_27
local.get $w33_0_27
local.get $w29_0_27
i16x8.sub
local.set $w31_0_27
local.get $bd5
local.get $w35_0_27
i16x8.sub
local.set $w39_0_27
local.get $w37_0_27
local.get $w39_0_27
i16x8.sub
local.set $w40_0_27
local.get $w37_0_27
local.get $bd5
i16x8.sub
local.set $w41_0_27
local.get $w40_0_27
local.get $w36_0_27
i16x8.sub
local.set $w38_0_27
local.get $bd9
local.get $w42_0_27
i16x8.sub
local.set $w46_0_27
local.get $w44_0_27
local.get $w46_0_27
i16x8.sub
local.set $w47_0_27
local.get $w44_0_27
local.get $bd9
i16x8.sub
local.set $w48_0_27
local.get $w47_0_27
local.get $w43_0_27
i16x8.sub
local.set $w45_0_27
(local.set $w0_0_28(v128.load8x8_s offset=224(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=224(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=224(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=224(local.get $bp3)))
(local.set $w1_0_28(v128.load8x8_s offset=224(local.get $bp4)))
(local.set $w2_0_28(v128.load8x8_s offset=224(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=224(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=224(local.get $bp7)))
(local.set $w7_0_28(v128.load8x8_s offset=224(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=224(local.get $bp9)))
(local.set $w14_0_28(v128.load8x8_s offset=224(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=224(local.get $bp11)))
(local.set $w8_0_28(v128.load8x8_s offset=224(local.get $bp12)))
(local.set $w9_0_28(v128.load8x8_s offset=224(local.get $bp13)))
(local.set $w15_0_28(v128.load8x8_s offset=224(local.get $bp14)))
(local.set $w16_0_28(v128.load8x8_s offset=224(local.get $bp15)))
local.get $b2
local.get $w0_0_28
i16x8.sub
local.set $w28_0_28
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_28
i16x8.sub
local.set $w29_0_28
local.get $b7
local.get $w2_0_28
i16x8.sub
local.set $w30_0_28
local.get $w14_0_28
local.get $w28_0_28
i16x8.sub
local.set $w35_0_28
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_28
local.get $w29_0_28
i16x8.sub
local.set $w36_0_28
local.get $w16_0_28
local.get $w30_0_28
i16x8.sub
local.set $w37_0_28
local.get $w14_0_28
local.get $b2
i16x8.sub
local.set $w42_0_28
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_28
local.get $b6
i16x8.sub
local.set $w43_0_28
local.get $w16_0_28
local.get $b7
i16x8.sub
local.set $w44_0_28
local.get $w35_0_28
local.get $w7_0_28
i16x8.sub
local.set $w21_0_28
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_28
local.get $w8_0_28
i16x8.sub
local.set $w22_0_28
local.get $w37_0_28
local.get $w9_0_28
i16x8.sub
local.set $w23_0_28
local.get $b1
local.get $w0_0_28
i16x8.sub
local.set $w4_0_28
local.get $w2_0_28
local.get $w4_0_28
i16x8.sub
local.set $w5_0_28
local.get $w2_0_28
local.get $b1
i16x8.sub
local.set $w6_0_28
local.get $w5_0_28
local.get $w1_0_28
i16x8.sub
local.set $w3_0_28
local.get $b9
local.get $w7_0_28
i16x8.sub
local.set $w11_0_28
local.get $w9_0_28
local.get $w11_0_28
i16x8.sub
local.set $w12_0_28
local.get $w9_0_28
local.get $b9
i16x8.sub
local.set $w13_0_28
local.get $w12_0_28
local.get $w8_0_28
i16x8.sub
local.set $w10_0_28
local.get $b11
local.get $w14_0_28
i16x8.sub
local.set $w18_0_28
local.get $w16_0_28
local.get $w18_0_28
i16x8.sub
local.set $w19_0_28
local.get $w16_0_28
local.get $b11
i16x8.sub
local.set $w20_0_28
local.get $w19_0_28
local.get $w15_0_28
i16x8.sub
local.set $w17_0_28
local.get $bd13
local.get $w21_0_28
i16x8.sub
local.set $w25_0_28
local.get $w23_0_28
local.get $w25_0_28
i16x8.sub
local.set $w26_0_28
local.get $w23_0_28
local.get $bd13
i16x8.sub
local.set $w27_0_28
local.get $w26_0_28
local.get $w22_0_28
i16x8.sub
local.set $w24_0_28
local.get $bd1
local.get $w28_0_28
i16x8.sub
local.set $w32_0_28
local.get $w30_0_28
local.get $w32_0_28
i16x8.sub
local.set $w33_0_28
local.get $w30_0_28
local.get $bd1
i16x8.sub
local.set $w34_0_28
local.get $w33_0_28
local.get $w29_0_28
i16x8.sub
local.set $w31_0_28
local.get $bd5
local.get $w35_0_28
i16x8.sub
local.set $w39_0_28
local.get $w37_0_28
local.get $w39_0_28
i16x8.sub
local.set $w40_0_28
local.get $w37_0_28
local.get $bd5
i16x8.sub
local.set $w41_0_28
local.get $w40_0_28
local.get $w36_0_28
i16x8.sub
local.set $w38_0_28
local.get $bd9
local.get $w42_0_28
i16x8.sub
local.set $w46_0_28
local.get $w44_0_28
local.get $w46_0_28
i16x8.sub
local.set $w47_0_28
local.get $w44_0_28
local.get $bd9
i16x8.sub
local.set $w48_0_28
local.get $w47_0_28
local.get $w43_0_28
i16x8.sub
local.set $w45_0_28
(local.set $w0_0_29(v128.load8x8_s offset=232(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=232(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=232(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=232(local.get $bp3)))
(local.set $w1_0_29(v128.load8x8_s offset=232(local.get $bp4)))
(local.set $w2_0_29(v128.load8x8_s offset=232(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=232(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=232(local.get $bp7)))
(local.set $w7_0_29(v128.load8x8_s offset=232(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=232(local.get $bp9)))
(local.set $w14_0_29(v128.load8x8_s offset=232(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=232(local.get $bp11)))
(local.set $w8_0_29(v128.load8x8_s offset=232(local.get $bp12)))
(local.set $w9_0_29(v128.load8x8_s offset=232(local.get $bp13)))
(local.set $w15_0_29(v128.load8x8_s offset=232(local.get $bp14)))
(local.set $w16_0_29(v128.load8x8_s offset=232(local.get $bp15)))
local.get $b2
local.get $w0_0_29
i16x8.sub
local.set $w28_0_29
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_29
i16x8.sub
local.set $w29_0_29
local.get $b7
local.get $w2_0_29
i16x8.sub
local.set $w30_0_29
local.get $w14_0_29
local.get $w28_0_29
i16x8.sub
local.set $w35_0_29
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_29
local.get $w29_0_29
i16x8.sub
local.set $w36_0_29
local.get $w16_0_29
local.get $w30_0_29
i16x8.sub
local.set $w37_0_29
local.get $w14_0_29
local.get $b2
i16x8.sub
local.set $w42_0_29
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_29
local.get $b6
i16x8.sub
local.set $w43_0_29
local.get $w16_0_29
local.get $b7
i16x8.sub
local.set $w44_0_29
local.get $w35_0_29
local.get $w7_0_29
i16x8.sub
local.set $w21_0_29
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_29
local.get $w8_0_29
i16x8.sub
local.set $w22_0_29
local.get $w37_0_29
local.get $w9_0_29
i16x8.sub
local.set $w23_0_29
local.get $b1
local.get $w0_0_29
i16x8.sub
local.set $w4_0_29
local.get $w2_0_29
local.get $w4_0_29
i16x8.sub
local.set $w5_0_29
local.get $w2_0_29
local.get $b1
i16x8.sub
local.set $w6_0_29
local.get $w5_0_29
local.get $w1_0_29
i16x8.sub
local.set $w3_0_29
local.get $b9
local.get $w7_0_29
i16x8.sub
local.set $w11_0_29
local.get $w9_0_29
local.get $w11_0_29
i16x8.sub
local.set $w12_0_29
local.get $w9_0_29
local.get $b9
i16x8.sub
local.set $w13_0_29
local.get $w12_0_29
local.get $w8_0_29
i16x8.sub
local.set $w10_0_29
local.get $b11
local.get $w14_0_29
i16x8.sub
local.set $w18_0_29
local.get $w16_0_29
local.get $w18_0_29
i16x8.sub
local.set $w19_0_29
local.get $w16_0_29
local.get $b11
i16x8.sub
local.set $w20_0_29
local.get $w19_0_29
local.get $w15_0_29
i16x8.sub
local.set $w17_0_29
local.get $bd13
local.get $w21_0_29
i16x8.sub
local.set $w25_0_29
local.get $w23_0_29
local.get $w25_0_29
i16x8.sub
local.set $w26_0_29
local.get $w23_0_29
local.get $bd13
i16x8.sub
local.set $w27_0_29
local.get $w26_0_29
local.get $w22_0_29
i16x8.sub
local.set $w24_0_29
local.get $bd1
local.get $w28_0_29
i16x8.sub
local.set $w32_0_29
local.get $w30_0_29
local.get $w32_0_29
i16x8.sub
local.set $w33_0_29
local.get $w30_0_29
local.get $bd1
i16x8.sub
local.set $w34_0_29
local.get $w33_0_29
local.get $w29_0_29
i16x8.sub
local.set $w31_0_29
local.get $bd5
local.get $w35_0_29
i16x8.sub
local.set $w39_0_29
local.get $w37_0_29
local.get $w39_0_29
i16x8.sub
local.set $w40_0_29
local.get $w37_0_29
local.get $bd5
i16x8.sub
local.set $w41_0_29
local.get $w40_0_29
local.get $w36_0_29
i16x8.sub
local.set $w38_0_29
local.get $bd9
local.get $w42_0_29
i16x8.sub
local.set $w46_0_29
local.get $w44_0_29
local.get $w46_0_29
i16x8.sub
local.set $w47_0_29
local.get $w44_0_29
local.get $bd9
i16x8.sub
local.set $w48_0_29
local.get $w47_0_29
local.get $w43_0_29
i16x8.sub
local.set $w45_0_29
(local.set $w0_0_30(v128.load8x8_s offset=240(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=240(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=240(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=240(local.get $bp3)))
(local.set $w1_0_30(v128.load8x8_s offset=240(local.get $bp4)))
(local.set $w2_0_30(v128.load8x8_s offset=240(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=240(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=240(local.get $bp7)))
(local.set $w7_0_30(v128.load8x8_s offset=240(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=240(local.get $bp9)))
(local.set $w14_0_30(v128.load8x8_s offset=240(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=240(local.get $bp11)))
(local.set $w8_0_30(v128.load8x8_s offset=240(local.get $bp12)))
(local.set $w9_0_30(v128.load8x8_s offset=240(local.get $bp13)))
(local.set $w15_0_30(v128.load8x8_s offset=240(local.get $bp14)))
(local.set $w16_0_30(v128.load8x8_s offset=240(local.get $bp15)))
local.get $b2
local.get $w0_0_30
i16x8.sub
local.set $w28_0_30
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_30
i16x8.sub
local.set $w29_0_30
local.get $b7
local.get $w2_0_30
i16x8.sub
local.set $w30_0_30
local.get $w14_0_30
local.get $w28_0_30
i16x8.sub
local.set $w35_0_30
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_30
local.get $w29_0_30
i16x8.sub
local.set $w36_0_30
local.get $w16_0_30
local.get $w30_0_30
i16x8.sub
local.set $w37_0_30
local.get $w14_0_30
local.get $b2
i16x8.sub
local.set $w42_0_30
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_30
local.get $b6
i16x8.sub
local.set $w43_0_30
local.get $w16_0_30
local.get $b7
i16x8.sub
local.set $w44_0_30
local.get $w35_0_30
local.get $w7_0_30
i16x8.sub
local.set $w21_0_30
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_30
local.get $w8_0_30
i16x8.sub
local.set $w22_0_30
local.get $w37_0_30
local.get $w9_0_30
i16x8.sub
local.set $w23_0_30
local.get $b1
local.get $w0_0_30
i16x8.sub
local.set $w4_0_30
local.get $w2_0_30
local.get $w4_0_30
i16x8.sub
local.set $w5_0_30
local.get $w2_0_30
local.get $b1
i16x8.sub
local.set $w6_0_30
local.get $w5_0_30
local.get $w1_0_30
i16x8.sub
local.set $w3_0_30
local.get $b9
local.get $w7_0_30
i16x8.sub
local.set $w11_0_30
local.get $w9_0_30
local.get $w11_0_30
i16x8.sub
local.set $w12_0_30
local.get $w9_0_30
local.get $b9
i16x8.sub
local.set $w13_0_30
local.get $w12_0_30
local.get $w8_0_30
i16x8.sub
local.set $w10_0_30
local.get $b11
local.get $w14_0_30
i16x8.sub
local.set $w18_0_30
local.get $w16_0_30
local.get $w18_0_30
i16x8.sub
local.set $w19_0_30
local.get $w16_0_30
local.get $b11
i16x8.sub
local.set $w20_0_30
local.get $w19_0_30
local.get $w15_0_30
i16x8.sub
local.set $w17_0_30
local.get $bd13
local.get $w21_0_30
i16x8.sub
local.set $w25_0_30
local.get $w23_0_30
local.get $w25_0_30
i16x8.sub
local.set $w26_0_30
local.get $w23_0_30
local.get $bd13
i16x8.sub
local.set $w27_0_30
local.get $w26_0_30
local.get $w22_0_30
i16x8.sub
local.set $w24_0_30
local.get $bd1
local.get $w28_0_30
i16x8.sub
local.set $w32_0_30
local.get $w30_0_30
local.get $w32_0_30
i16x8.sub
local.set $w33_0_30
local.get $w30_0_30
local.get $bd1
i16x8.sub
local.set $w34_0_30
local.get $w33_0_30
local.get $w29_0_30
i16x8.sub
local.set $w31_0_30
local.get $bd5
local.get $w35_0_30
i16x8.sub
local.set $w39_0_30
local.get $w37_0_30
local.get $w39_0_30
i16x8.sub
local.set $w40_0_30
local.get $w37_0_30
local.get $bd5
i16x8.sub
local.set $w41_0_30
local.get $w40_0_30
local.get $w36_0_30
i16x8.sub
local.set $w38_0_30
local.get $bd9
local.get $w42_0_30
i16x8.sub
local.set $w46_0_30
local.get $w44_0_30
local.get $w46_0_30
i16x8.sub
local.set $w47_0_30
local.get $w44_0_30
local.get $bd9
i16x8.sub
local.set $w48_0_30
local.get $w47_0_30
local.get $w43_0_30
i16x8.sub
local.set $w45_0_30
(local.set $w0_0_31(v128.load8x8_s offset=248(local.get $bp0)))
(local.set $b1(v128.load8x8_s offset=248(local.get $bp1)))
(local.set $b2(v128.load8x8_s offset=248(local.get $bp2)))
(local.set $b3(v128.load8x8_s offset=248(local.get $bp3)))
(local.set $w1_0_31(v128.load8x8_s offset=248(local.get $bp4)))
(local.set $w2_0_31(v128.load8x8_s offset=248(local.get $bp5)))
(local.set $b6(v128.load8x8_s offset=248(local.get $bp6)))
(local.set $b7(v128.load8x8_s offset=248(local.get $bp7)))
(local.set $w7_0_31(v128.load8x8_s offset=248(local.get $bp8)))
(local.set $b9(v128.load8x8_s offset=248(local.get $bp9)))
(local.set $w14_0_31(v128.load8x8_s offset=248(local.get $bp10)))
(local.set $b11(v128.load8x8_s offset=248(local.get $bp11)))
(local.set $w8_0_31(v128.load8x8_s offset=248(local.get $bp12)))
(local.set $w9_0_31(v128.load8x8_s offset=248(local.get $bp13)))
(local.set $w15_0_31(v128.load8x8_s offset=248(local.get $bp14)))
(local.set $w16_0_31(v128.load8x8_s offset=248(local.get $bp15)))
local.get $b2
local.get $w0_0_31
i16x8.sub
local.set $w28_0_31
local.get $b3
local.get $b1
i16x8.sub
local.set $bd1
local.get $b6
local.get $w1_0_31
i16x8.sub
local.set $w29_0_31
local.get $b7
local.get $w2_0_31
i16x8.sub
local.set $w30_0_31
local.get $w14_0_31
local.get $w28_0_31
i16x8.sub
local.set $w35_0_31
local.get $b11
local.get $bd1
i16x8.sub
local.set $bd5
local.get $w15_0_31
local.get $w29_0_31
i16x8.sub
local.set $w36_0_31
local.get $w16_0_31
local.get $w30_0_31
i16x8.sub
local.set $w37_0_31
local.get $w14_0_31
local.get $b2
i16x8.sub
local.set $w42_0_31
local.get $b11
local.get $b3
i16x8.sub
local.set $bd9
local.get $w15_0_31
local.get $b6
i16x8.sub
local.set $w43_0_31
local.get $w16_0_31
local.get $b7
i16x8.sub
local.set $w44_0_31
local.get $w35_0_31
local.get $w7_0_31
i16x8.sub
local.set $w21_0_31
local.get $bd5
local.get $b9
i16x8.sub
local.set $bd13
local.get $w36_0_31
local.get $w8_0_31
i16x8.sub
local.set $w22_0_31
local.get $w37_0_31
local.get $w9_0_31
i16x8.sub
local.set $w23_0_31
local.get $b1
local.get $w0_0_31
i16x8.sub
local.set $w4_0_31
local.get $w2_0_31
local.get $w4_0_31
i16x8.sub
local.set $w5_0_31
local.get $w2_0_31
local.get $b1
i16x8.sub
local.set $w6_0_31
local.get $w5_0_31
local.get $w1_0_31
i16x8.sub
local.set $w3_0_31
local.get $b9
local.get $w7_0_31
i16x8.sub
local.set $w11_0_31
local.get $w9_0_31
local.get $w11_0_31
i16x8.sub
local.set $w12_0_31
local.get $w9_0_31
local.get $b9
i16x8.sub
local.set $w13_0_31
local.get $w12_0_31
local.get $w8_0_31
i16x8.sub
local.set $w10_0_31
local.get $b11
local.get $w14_0_31
i16x8.sub
local.set $w18_0_31
local.get $w16_0_31
local.get $w18_0_31
i16x8.sub
local.set $w19_0_31
local.get $w16_0_31
local.get $b11
i16x8.sub
local.set $w20_0_31
local.get $w19_0_31
local.get $w15_0_31
i16x8.sub
local.set $w17_0_31
local.get $bd13
local.get $w21_0_31
i16x8.sub
local.set $w25_0_31
local.get $w23_0_31
local.get $w25_0_31
i16x8.sub
local.set $w26_0_31
local.get $w23_0_31
local.get $bd13
i16x8.sub
local.set $w27_0_31
local.get $w26_0_31
local.get $w22_0_31
i16x8.sub
local.set $w24_0_31
local.get $bd1
local.get $w28_0_31
i16x8.sub
local.set $w32_0_31
local.get $w30_0_31
local.get $w32_0_31
i16x8.sub
local.set $w33_0_31
local.get $w30_0_31
local.get $bd1
i16x8.sub
local.set $w34_0_31
local.get $w33_0_31
local.get $w29_0_31
i16x8.sub
local.set $w31_0_31
local.get $bd5
local.get $w35_0_31
i16x8.sub
local.set $w39_0_31
local.get $w37_0_31
local.get $w39_0_31
i16x8.sub
local.set $w40_0_31
local.get $w37_0_31
local.get $bd5
i16x8.sub
local.set $w41_0_31
local.get $w40_0_31
local.get $w36_0_31
i16x8.sub
local.set $w38_0_31
local.get $bd9
local.get $w42_0_31
i16x8.sub
local.set $w46_0_31
local.get $w44_0_31
local.get $w46_0_31
i16x8.sub
local.set $w47_0_31
local.get $w44_0_31
local.get $bd9
i16x8.sub
local.set $w48_0_31
local.get $w47_0_31
local.get $w43_0_31
i16x8.sub
local.set $w45_0_31
(if(i32.eq(i32.sub(local.get $n)(local.get $t))(i32.const 1))(then
(local.set $qoff(i32.add(i32.shr_u(i32.mul(local.get $t)(local.get $cols))(i32.const 3))(i32.shr_u(local.get $start)(i32.const 1))))
(local.set $sx0(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(local.get $t)(local.get $input_stride))(i32.const 2)))))
(local.set $yp(i32.add(local.get $sums)(i32.mul(local.get $t)(local.get $output_bytes))))
(local.set $qp(i32.add(i32.load offset=0(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_0
local.get $p0_0
local.get $x0
local.get $w4_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_1
local.get $p0_0
local.get $x0
local.get $w28_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w28_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w28_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w28_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w28_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w28_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w28_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w28_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w28_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w28_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w28_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w28_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w28_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w28_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w28_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w28_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w28_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w28_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w28_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w28_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w28_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w28_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w28_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w28_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w28_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w28_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w28_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w28_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w28_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w28_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w28_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w28_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_2
local.get $p0_1
local.get $p0_2
i32x4.add
local.get $p0_0
i32x4.sub
local.get $x0
local.get $w32_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w32_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w32_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w32_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w32_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w32_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w32_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w32_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w32_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w32_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w32_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w32_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w32_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w32_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w32_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w32_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w32_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w32_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w32_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w32_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w32_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w32_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w32_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w32_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w32_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w32_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w32_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w32_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w32_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w32_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w32_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w32_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=4(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_4
local.get $x0
local.get $w2_0_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_5
local.get $p0_4
local.get $x0
local.get $w29_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w29_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w29_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w29_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w29_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w29_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w29_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w29_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w29_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w29_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w29_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w29_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w29_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w29_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w29_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w29_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w29_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w29_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w29_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w29_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w29_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w29_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w29_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w29_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w29_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w29_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w29_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w29_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w29_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w29_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w29_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w29_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_6
local.get $p0_5
local.get $x0
local.get $w30_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w30_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w30_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w30_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w30_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w30_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w30_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w30_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w30_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w30_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w30_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w30_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w30_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w30_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w30_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w30_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w30_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w30_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w30_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w30_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w30_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w30_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w30_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w30_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w30_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w30_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w30_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w30_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w30_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w30_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w30_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w30_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_7
local.get $p0_0
local.get $p0_4
i32x4.add
local.set $p0_0
local.get $p0_1
local.get $p0_5
i32x4.add
local.set $p0_1
local.get $p0_2
local.get $p0_6
i32x4.add
local.set $p0_2
local.get $p0_3
local.get $p0_7
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=28(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w7_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w7_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w7_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w7_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w7_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w7_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w7_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w7_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w7_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w7_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w7_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w7_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w7_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w7_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w7_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w7_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w7_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w7_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w7_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w7_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w7_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w7_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w7_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w7_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w7_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w7_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w7_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w7_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w7_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w7_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w7_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w7_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_4
local.get $p0_4
local.get $x0
local.get $w11_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w11_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w11_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w11_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w11_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w11_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w11_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w11_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w11_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w11_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w11_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w11_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w11_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w11_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w11_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w11_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w11_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w11_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w11_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w11_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w11_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w11_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w11_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w11_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w11_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w11_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w11_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w11_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w11_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w11_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w11_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w11_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_5
local.get $x0
local.get $w14_0_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w14_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w14_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w14_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w14_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w14_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w14_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w14_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w14_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w14_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w14_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w14_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w14_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w14_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w14_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w14_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w14_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w14_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w14_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w14_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w14_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w14_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w14_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w14_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w14_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w14_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w14_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w14_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w14_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w14_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w14_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w14_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_6
local.get $p0_6
local.get $x0
local.get $w18_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w18_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w18_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w18_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w18_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w18_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w18_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w18_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w18_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w18_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w18_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w18_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w18_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w18_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w18_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w18_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w18_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w18_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w18_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w18_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w18_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w18_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w18_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w18_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w18_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w18_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w18_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w18_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w18_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w18_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w18_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w18_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_7
local.get $p0_0
local.get $p0_4
i32x4.add
local.set $p0_0
local.get $p0_1
local.get $p0_5
i32x4.add
local.set $p0_1
local.get $p0_2
local.get $p0_6
i32x4.add
local.set $p0_2
local.get $p0_3
local.get $p0_7
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=32(local.get $q))(local.get $qoff)))
local.get $p0_0
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w8_0_0
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w8_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w8_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w8_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w8_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w8_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w8_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w8_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w8_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w8_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w8_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w8_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w8_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w8_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w8_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w8_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w8_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w8_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w8_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w8_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w8_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w8_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w8_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w8_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w8_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w8_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w8_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w8_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w8_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w8_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w8_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w8_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_0
local.get $p0_1
local.get $x0
local.get $w9_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w9_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w9_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w9_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w9_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w9_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w9_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w9_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w9_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w9_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w9_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w9_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w9_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w9_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w9_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w9_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w9_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w9_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w9_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w9_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w9_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w9_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w9_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w9_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w9_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w9_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w9_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w9_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w9_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w9_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w9_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w9_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_1
local.get $p0_2
local.get $x0
local.get $w15_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w15_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w15_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w15_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w15_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w15_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w15_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w15_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w15_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w15_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w15_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w15_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w15_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w15_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w15_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w15_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w15_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w15_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w15_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w15_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w15_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w15_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w15_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w15_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w15_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w15_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w15_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w15_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w15_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w15_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w15_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w15_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_2
local.get $p0_3
local.get $x0
local.get $w16_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w16_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w16_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w16_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w16_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w16_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w16_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w16_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w16_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w16_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w16_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w16_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w16_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w16_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w16_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w16_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w16_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w16_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w16_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w16_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w16_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w16_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w16_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w16_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w16_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w16_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w16_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w16_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w16_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w16_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w16_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w16_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_3
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_0
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_1
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_2
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_3
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
)(else
(local.set $qoff(i32.add(i32.shr_u(i32.mul(local.get $t)(local.get $cols))(i32.const 3))(i32.shr_u(local.get $start)(i32.const 1))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 0))(local.get $n))(then(local.set $sx0(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 0))(local.get $input_stride))(i32.const 2)))))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 1))(local.get $n))(then(local.set $sx1(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 1))(local.get $input_stride))(i32.const 2)))))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 2))(local.get $n))(then(local.set $sx2(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 2))(local.get $input_stride))(i32.const 2)))))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 3))(local.get $n))(then(local.set $sx3(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 3))(local.get $input_stride))(i32.const 2)))))))
(local.set $qp(i32.add(i32.load offset=0(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_0
(local.set $qp(i32.add(i32.load offset=4(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_1
(local.set $qp(i32.add(i32.load offset=8(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_2
(local.set $qp(i32.add(i32.load offset=12(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w3_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w3_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w3_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w3_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w3_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w3_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w3_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w3_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w3_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w3_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w3_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w3_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w3_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w3_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w3_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w3_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w3_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w3_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w3_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w3_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w3_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w3_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w3_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w3_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w3_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w3_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w3_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w3_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w3_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w3_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w3_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w3_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=16(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w4_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_4
(local.set $qp(i32.add(i32.load offset=20(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w5_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w5_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w5_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w5_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w5_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w5_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w5_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w5_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w5_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w5_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w5_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w5_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w5_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w5_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w5_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w5_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w5_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w5_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w5_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w5_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w5_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w5_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w5_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w5_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w5_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w5_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w5_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w5_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w5_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w5_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w5_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w5_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_5
(local.set $qp(i32.add(i32.load offset=24(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w6_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w6_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w6_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w6_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w6_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w6_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w6_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w6_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w6_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w6_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w6_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w6_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w6_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w6_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w6_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w6_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w6_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w6_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w6_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w6_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w6_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w6_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w6_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w6_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w6_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w6_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w6_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w6_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w6_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w6_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w6_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w6_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_6
(local.set $qp(i32.add(i32.load offset=28(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w7_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w7_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w7_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w7_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w7_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w7_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w7_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w7_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w7_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w7_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w7_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w7_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w7_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w7_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w7_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w7_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w7_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w7_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w7_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w7_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w7_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w7_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w7_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w7_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w7_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w7_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w7_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w7_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w7_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w7_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w7_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w7_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_7
(local.set $qp(i32.add(i32.load offset=32(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w8_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w8_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w8_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w8_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w8_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w8_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w8_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w8_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w8_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w8_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w8_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w8_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w8_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w8_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w8_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w8_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w8_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w8_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w8_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w8_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w8_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w8_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w8_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w8_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w8_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w8_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w8_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w8_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w8_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w8_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w8_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w8_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_8
(local.set $qp(i32.add(i32.load offset=36(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w9_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w9_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w9_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w9_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w9_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w9_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w9_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w9_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w9_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w9_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w9_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w9_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w9_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w9_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w9_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w9_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w9_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w9_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w9_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w9_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w9_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w9_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w9_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w9_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w9_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w9_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w9_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w9_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w9_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w9_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w9_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w9_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_9
(local.set $qp(i32.add(i32.load offset=40(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w10_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w10_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w10_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w10_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w10_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w10_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w10_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w10_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w10_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w10_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w10_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w10_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w10_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w10_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w10_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w10_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w10_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w10_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w10_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w10_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w10_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w10_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w10_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w10_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w10_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w10_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w10_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w10_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w10_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w10_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w10_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w10_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_10
(local.set $qp(i32.add(i32.load offset=44(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w11_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w11_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w11_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w11_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w11_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w11_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w11_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w11_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w11_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w11_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w11_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w11_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w11_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w11_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w11_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w11_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w11_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w11_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w11_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w11_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w11_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w11_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w11_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w11_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w11_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w11_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w11_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w11_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w11_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w11_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w11_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w11_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_11
(local.set $qp(i32.add(i32.load offset=48(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w12_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w12_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w12_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w12_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w12_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w12_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w12_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w12_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w12_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w12_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w12_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w12_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w12_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w12_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w12_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w12_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w12_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w12_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w12_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w12_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w12_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w12_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w12_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w12_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w12_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w12_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w12_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w12_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w12_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w12_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w12_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w12_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_12
(local.set $qp(i32.add(i32.load offset=52(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w13_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w13_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w13_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w13_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w13_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w13_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w13_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w13_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w13_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w13_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w13_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w13_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w13_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w13_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w13_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w13_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w13_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w13_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w13_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w13_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w13_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w13_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w13_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w13_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w13_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w13_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w13_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w13_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w13_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w13_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w13_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w13_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_13
(local.set $qp(i32.add(i32.load offset=56(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w14_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w14_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w14_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w14_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w14_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w14_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w14_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w14_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w14_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w14_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w14_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w14_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w14_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w14_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w14_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w14_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w14_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w14_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w14_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w14_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w14_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w14_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w14_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w14_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w14_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w14_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w14_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w14_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w14_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w14_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w14_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w14_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_14
(local.set $qp(i32.add(i32.load offset=60(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w15_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w15_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w15_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w15_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w15_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w15_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w15_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w15_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w15_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w15_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w15_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w15_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w15_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w15_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w15_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w15_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w15_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w15_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w15_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w15_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w15_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w15_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w15_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w15_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w15_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w15_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w15_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w15_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w15_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w15_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w15_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w15_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_15
(local.set $qp(i32.add(i32.load offset=64(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w16_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w16_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w16_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w16_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w16_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w16_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w16_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w16_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w16_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w16_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w16_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w16_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w16_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w16_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w16_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w16_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w16_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w16_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w16_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w16_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w16_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w16_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w16_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w16_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w16_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w16_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w16_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w16_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w16_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w16_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w16_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w16_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_16
(local.set $qp(i32.add(i32.load offset=68(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w17_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w17_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w17_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w17_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w17_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w17_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w17_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w17_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w17_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w17_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w17_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w17_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w17_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w17_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w17_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w17_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w17_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w17_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w17_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w17_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w17_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w17_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w17_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w17_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w17_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w17_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w17_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w17_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w17_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w17_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w17_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w17_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_17
(local.set $qp(i32.add(i32.load offset=72(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w18_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w18_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w18_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w18_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w18_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w18_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w18_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w18_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w18_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w18_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w18_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w18_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w18_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w18_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w18_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w18_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w18_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w18_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w18_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w18_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w18_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w18_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w18_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w18_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w18_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w18_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w18_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w18_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w18_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w18_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w18_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w18_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_18
(local.set $qp(i32.add(i32.load offset=76(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w19_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w19_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w19_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w19_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w19_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w19_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w19_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w19_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w19_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w19_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w19_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w19_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w19_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w19_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w19_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w19_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w19_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w19_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w19_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w19_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w19_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w19_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w19_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w19_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w19_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w19_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w19_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w19_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w19_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w19_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w19_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w19_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_19
(local.set $qp(i32.add(i32.load offset=80(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w20_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w20_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w20_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w20_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w20_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w20_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w20_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w20_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w20_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w20_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w20_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w20_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w20_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w20_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w20_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w20_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w20_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w20_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w20_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w20_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w20_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w20_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w20_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w20_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w20_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w20_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w20_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w20_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w20_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w20_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w20_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w20_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_20
(local.set $qp(i32.add(i32.load offset=84(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w21_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w21_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w21_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w21_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w21_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w21_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w21_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w21_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w21_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w21_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w21_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w21_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w21_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w21_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w21_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w21_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w21_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w21_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w21_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w21_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w21_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w21_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w21_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w21_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w21_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w21_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w21_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w21_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w21_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w21_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w21_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w21_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_21
(local.set $qp(i32.add(i32.load offset=88(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w22_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w22_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w22_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w22_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w22_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w22_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w22_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w22_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w22_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w22_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w22_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w22_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w22_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w22_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w22_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w22_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w22_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w22_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w22_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w22_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w22_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w22_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w22_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w22_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w22_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w22_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w22_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w22_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w22_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w22_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w22_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w22_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_22
(local.set $qp(i32.add(i32.load offset=92(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w23_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w23_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w23_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w23_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w23_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w23_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w23_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w23_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w23_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w23_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w23_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w23_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w23_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w23_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w23_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w23_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w23_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w23_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w23_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w23_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w23_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w23_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w23_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w23_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w23_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w23_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w23_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w23_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w23_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w23_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w23_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w23_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_23
(local.set $qp(i32.add(i32.load offset=96(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w24_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w24_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w24_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w24_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w24_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w24_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w24_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w24_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w24_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w24_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w24_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w24_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w24_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w24_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w24_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w24_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w24_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w24_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w24_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w24_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w24_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w24_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w24_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w24_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w24_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w24_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w24_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w24_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w24_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w24_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w24_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w24_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_24
(local.set $qp(i32.add(i32.load offset=100(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w25_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w25_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w25_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w25_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w25_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w25_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w25_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w25_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w25_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w25_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w25_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w25_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w25_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w25_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w25_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w25_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w25_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w25_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w25_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w25_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w25_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w25_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w25_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w25_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w25_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w25_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w25_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w25_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w25_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w25_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w25_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w25_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_25
(local.set $qp(i32.add(i32.load offset=104(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w26_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w26_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w26_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w26_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w26_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w26_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w26_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w26_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w26_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w26_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w26_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w26_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w26_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w26_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w26_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w26_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w26_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w26_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w26_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w26_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w26_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w26_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w26_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w26_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w26_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w26_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w26_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w26_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w26_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w26_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w26_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w26_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_26
(local.set $qp(i32.add(i32.load offset=108(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w27_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w27_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w27_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w27_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w27_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w27_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w27_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w27_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w27_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w27_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w27_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w27_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w27_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w27_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w27_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w27_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w27_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w27_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w27_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w27_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w27_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w27_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w27_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w27_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w27_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w27_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w27_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w27_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w27_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w27_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w27_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w27_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_27
(local.set $qp(i32.add(i32.load offset=112(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w28_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w28_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w28_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w28_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w28_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w28_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w28_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w28_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w28_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w28_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w28_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w28_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w28_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w28_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w28_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w28_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w28_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w28_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w28_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w28_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w28_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w28_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w28_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w28_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w28_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w28_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w28_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w28_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w28_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w28_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w28_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w28_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_28
(local.set $qp(i32.add(i32.load offset=116(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w29_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w29_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w29_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w29_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w29_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w29_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w29_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w29_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w29_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w29_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w29_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w29_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w29_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w29_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w29_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w29_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w29_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w29_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w29_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w29_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w29_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w29_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w29_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w29_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w29_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w29_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w29_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w29_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w29_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w29_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w29_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w29_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_29
(local.set $qp(i32.add(i32.load offset=120(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w30_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w30_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w30_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w30_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w30_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w30_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w30_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w30_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w30_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w30_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w30_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w30_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w30_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w30_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w30_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w30_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w30_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w30_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w30_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w30_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w30_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w30_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w30_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w30_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w30_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w30_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w30_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w30_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w30_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w30_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w30_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w30_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_30
(local.set $qp(i32.add(i32.load offset=124(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w31_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w31_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w31_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w31_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w31_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w31_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w31_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w31_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w31_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w31_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w31_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w31_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w31_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w31_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w31_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w31_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w31_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w31_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w31_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w31_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w31_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w31_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w31_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w31_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w31_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w31_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w31_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w31_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w31_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w31_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w31_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w31_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_31
(local.set $qp(i32.add(i32.load offset=128(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w32_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w32_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w32_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w32_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w32_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w32_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w32_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w32_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w32_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w32_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w32_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w32_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w32_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w32_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w32_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w32_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w32_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w32_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w32_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w32_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w32_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w32_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w32_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w32_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w32_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w32_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w32_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w32_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w32_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w32_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w32_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w32_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_32
(local.set $qp(i32.add(i32.load offset=132(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w33_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w33_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w33_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w33_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w33_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w33_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w33_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w33_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w33_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w33_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w33_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w33_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w33_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w33_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w33_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w33_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w33_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w33_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w33_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w33_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w33_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w33_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w33_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w33_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w33_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w33_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w33_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w33_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w33_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w33_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w33_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w33_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_33
(local.set $qp(i32.add(i32.load offset=136(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w34_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w34_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w34_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w34_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w34_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w34_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w34_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w34_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w34_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w34_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w34_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w34_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w34_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w34_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w34_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w34_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w34_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w34_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w34_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w34_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w34_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w34_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w34_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w34_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w34_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w34_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w34_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w34_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w34_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w34_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w34_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w34_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_34
(local.set $qp(i32.add(i32.load offset=140(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w35_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w35_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w35_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w35_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w35_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w35_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w35_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w35_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w35_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w35_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w35_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w35_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w35_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w35_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w35_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w35_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w35_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w35_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w35_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w35_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w35_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w35_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w35_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w35_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w35_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w35_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w35_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w35_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w35_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w35_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w35_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w35_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_35
(local.set $qp(i32.add(i32.load offset=144(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w36_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w36_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w36_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w36_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w36_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w36_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w36_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w36_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w36_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w36_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w36_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w36_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w36_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w36_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w36_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w36_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w36_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w36_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w36_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w36_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w36_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w36_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w36_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w36_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w36_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w36_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w36_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w36_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w36_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w36_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w36_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w36_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_36
(local.set $qp(i32.add(i32.load offset=148(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w37_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w37_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w37_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w37_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w37_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w37_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w37_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w37_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w37_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w37_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w37_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w37_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w37_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w37_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w37_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w37_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w37_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w37_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w37_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w37_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w37_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w37_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w37_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w37_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w37_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w37_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w37_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w37_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w37_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w37_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w37_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w37_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_37
(local.set $qp(i32.add(i32.load offset=152(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w38_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w38_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w38_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w38_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w38_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w38_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w38_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w38_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w38_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w38_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w38_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w38_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w38_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w38_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w38_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w38_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w38_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w38_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w38_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w38_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w38_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w38_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w38_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w38_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w38_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w38_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w38_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w38_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w38_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w38_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w38_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w38_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_38
(local.set $qp(i32.add(i32.load offset=156(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w39_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w39_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w39_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w39_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w39_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w39_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w39_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w39_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w39_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w39_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w39_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w39_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w39_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w39_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w39_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w39_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w39_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w39_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w39_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w39_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w39_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w39_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w39_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w39_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w39_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w39_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w39_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w39_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w39_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w39_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w39_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w39_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_39
(local.set $qp(i32.add(i32.load offset=160(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w40_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w40_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w40_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w40_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w40_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w40_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w40_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w40_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w40_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w40_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w40_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w40_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w40_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w40_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w40_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w40_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w40_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w40_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w40_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w40_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w40_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w40_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w40_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w40_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w40_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w40_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w40_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w40_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w40_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w40_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w40_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w40_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_40
(local.set $qp(i32.add(i32.load offset=164(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w41_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w41_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w41_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w41_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w41_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w41_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w41_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w41_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w41_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w41_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w41_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w41_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w41_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w41_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w41_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w41_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w41_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w41_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w41_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w41_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w41_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w41_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w41_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w41_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w41_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w41_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w41_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w41_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w41_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w41_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w41_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w41_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_41
(local.set $qp(i32.add(i32.load offset=168(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w42_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w42_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w42_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w42_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w42_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w42_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w42_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w42_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w42_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w42_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w42_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w42_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w42_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w42_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w42_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w42_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w42_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w42_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w42_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w42_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w42_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w42_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w42_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w42_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w42_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w42_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w42_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w42_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w42_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w42_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w42_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w42_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_42
(local.set $qp(i32.add(i32.load offset=172(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w43_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w43_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w43_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w43_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w43_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w43_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w43_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w43_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w43_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w43_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w43_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w43_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w43_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w43_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w43_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w43_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w43_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w43_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w43_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w43_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w43_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w43_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w43_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w43_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w43_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w43_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w43_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w43_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w43_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w43_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w43_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w43_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_43
(local.set $qp(i32.add(i32.load offset=176(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w44_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w44_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w44_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w44_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w44_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w44_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w44_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w44_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w44_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w44_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w44_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w44_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w44_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w44_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w44_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w44_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w44_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w44_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w44_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w44_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w44_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w44_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w44_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w44_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w44_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w44_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w44_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w44_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w44_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w44_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w44_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w44_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_44
(local.set $qp(i32.add(i32.load offset=180(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w45_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w45_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w45_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w45_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w45_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w45_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w45_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w45_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w45_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w45_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w45_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w45_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w45_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w45_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w45_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w45_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w45_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w45_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w45_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w45_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w45_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w45_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w45_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w45_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w45_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w45_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w45_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w45_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w45_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w45_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w45_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w45_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_45
(local.set $qp(i32.add(i32.load offset=184(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w46_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w46_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w46_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w46_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w46_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w46_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w46_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w46_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w46_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w46_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w46_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w46_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w46_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w46_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w46_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w46_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w46_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w46_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w46_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w46_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w46_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w46_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w46_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w46_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w46_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w46_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w46_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w46_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w46_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w46_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w46_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w46_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_46
(local.set $qp(i32.add(i32.load offset=188(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w47_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w47_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w47_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w47_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w47_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w47_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w47_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w47_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w47_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w47_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w47_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w47_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w47_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w47_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w47_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w47_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w47_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w47_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w47_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w47_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w47_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w47_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w47_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w47_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w47_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w47_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w47_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w47_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w47_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w47_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w47_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w47_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_47
(local.set $qp(i32.add(i32.load offset=192(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w48_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w48_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w48_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w48_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w48_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w48_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w48_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w48_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w48_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w48_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w48_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w48_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w48_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w48_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w48_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w48_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w48_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w48_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w48_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w48_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w48_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w48_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w48_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w48_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w48_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w48_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w48_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w48_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w48_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w48_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w48_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w48_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_48
local.get $p0_0
local.get $p0_1
i32x4.add
local.set $pc49
local.get $p0_0
local.get $p0_5
i32x4.add
local.set $pc50
local.get $pc50
local.get $p0_6
i32x4.add
local.set $pc51
local.get $pc50
local.get $p0_4
i32x4.add
local.get $p0_2
i32x4.add
local.set $pc52
local.get $pc51
local.get $p0_3
i32x4.sub
local.set $pc53
local.get $pc51
local.get $p0_4
i32x4.add
local.set $pc54
local.get $p0_7
local.get $p0_12
i32x4.add
local.set $pc55
local.get $pc55
local.get $p0_13
i32x4.add
local.set $pc56
local.get $p0_14
local.get $p0_19
i32x4.add
local.set $pc57
local.get $pc57
local.get $p0_20
i32x4.add
local.set $pc58
local.get $p0_21
local.get $p0_26
i32x4.add
local.set $pc59
local.get $pc59
local.get $p0_27
i32x4.add
local.set $pc60
local.get $p0_28
local.get $p0_29
i32x4.add
local.set $pc61
local.get $p0_28
local.get $p0_33
i32x4.add
local.set $pc62
local.get $pc62
local.get $p0_34
i32x4.add
local.set $pc63
local.get $pc62
local.get $p0_32
i32x4.add
local.get $p0_30
i32x4.add
local.set $pc64
local.get $pc63
local.get $p0_31
i32x4.sub
local.set $pc65
local.get $pc63
local.get $p0_32
i32x4.add
local.set $pc66
local.get $p0_35
local.get $p0_40
i32x4.add
local.set $pc67
local.get $pc67
local.get $p0_41
i32x4.add
local.set $pc68
local.get $p0_42
local.get $p0_47
i32x4.add
local.set $pc69
local.get $pc69
local.get $p0_48
i32x4.add
local.set $pc70
local.get $pc49
local.get $p0_7
local.get $p0_8
i32x4.add
i32x4.add
local.set $pc71
local.get $pc52
local.get $pc55
local.get $p0_11
i32x4.add
local.get $p0_9
i32x4.add
i32x4.add
local.set $pc72
local.get $pc53
local.get $pc56
local.get $p0_10
i32x4.sub
i32x4.add
local.set $pc73
local.get $pc54
local.get $pc56
local.get $p0_11
i32x4.add
i32x4.add
local.set $pc74
local.get $pc49
local.get $p0_35
local.get $p0_36
i32x4.add
i32x4.add
local.set $pc75
local.get $pc52
local.get $pc67
local.get $p0_39
i32x4.add
local.get $p0_37
i32x4.add
i32x4.add
local.set $pc76
local.get $pc53
local.get $pc68
local.get $p0_38
i32x4.sub
i32x4.add
local.set $pc77
local.get $pc54
local.get $pc68
local.get $p0_39
i32x4.add
i32x4.add
local.set $pc78
local.get $pc75
local.get $p0_42
local.get $p0_43
i32x4.add
i32x4.add
local.set $pc79
local.get $pc76
local.get $pc69
local.get $p0_46
i32x4.add
local.get $p0_44
i32x4.add
i32x4.add
local.set $pc80
local.get $pc77
local.get $pc70
local.get $p0_45
i32x4.sub
i32x4.add
local.set $pc81
local.get $pc78
local.get $pc70
local.get $p0_46
i32x4.add
i32x4.add
local.set $pc82
local.get $pc75
local.get $pc61
i32x4.add
local.get $p0_14
local.get $p0_15
i32x4.add
i32x4.add
local.set $pc83
local.get $pc76
local.get $pc64
i32x4.add
local.get $pc57
local.get $p0_18
i32x4.add
local.get $p0_16
i32x4.add
i32x4.add
local.set $pc84
local.get $pc77
local.get $pc65
i32x4.add
local.get $pc58
local.get $p0_17
i32x4.sub
i32x4.add
local.set $pc85
local.get $pc78
local.get $pc66
i32x4.add
local.get $pc58
local.get $p0_18
i32x4.add
i32x4.add
local.set $pc86
local.get $pc79
local.get $p0_21
local.get $p0_22
i32x4.add
i32x4.sub
local.set $pc87
local.get $pc80
local.get $pc59
local.get $p0_25
i32x4.add
local.get $p0_23
i32x4.add
i32x4.sub
local.set $pc88
local.get $pc81
local.get $pc60
local.get $p0_24
i32x4.sub
i32x4.sub
local.set $pc89
local.get $pc82
local.get $pc60
local.get $p0_25
i32x4.add
i32x4.sub
local.set $pc90
local.get $pc79
local.get $pc61
i32x4.add
local.set $pc91
local.get $pc80
local.get $pc64
i32x4.add
local.set $pc92
local.get $pc81
local.get $pc65
i32x4.add
local.set $pc93
local.get $pc82
local.get $pc66
i32x4.add
local.set $pc94
(if(i32.lt_u(i32.add(local.get $t)(i32.const 0))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 0))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc71
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc72
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc83
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc84
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 1))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 1))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc73
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc74
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc85
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc86
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 2))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 2))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc87
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc88
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc91
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc92
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 3))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 3))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc89
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc90
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc93
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc94
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
))
(local.set $t(i32.const 4))
(loop $tokens
(br_if $done(i32.ge_u(local.get $t)(local.get $n)))
(if(i32.eq(i32.sub(local.get $n)(local.get $t))(i32.const 1))(then
(local.set $qoff(i32.add(i32.shr_u(i32.mul(local.get $t)(local.get $cols))(i32.const 3))(i32.shr_u(local.get $start)(i32.const 1))))
(local.set $sx0(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(local.get $t)(local.get $input_stride))(i32.const 2)))))
(local.set $yp(i32.add(local.get $sums)(i32.mul(local.get $t)(local.get $output_bytes))))
(local.set $qp(i32.add(i32.load offset=0(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_0
local.get $p0_0
local.get $x0
local.get $w4_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_1
local.get $p0_0
local.get $x0
local.get $w28_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w28_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w28_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w28_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w28_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w28_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w28_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w28_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w28_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w28_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w28_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w28_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w28_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w28_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w28_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w28_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w28_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w28_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w28_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w28_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w28_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w28_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w28_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w28_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w28_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w28_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w28_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w28_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w28_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w28_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w28_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w28_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_2
local.get $p0_1
local.get $p0_2
i32x4.add
local.get $p0_0
i32x4.sub
local.get $x0
local.get $w32_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w32_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w32_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w32_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w32_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w32_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w32_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w32_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w32_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w32_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w32_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w32_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w32_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w32_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w32_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w32_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w32_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w32_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w32_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w32_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w32_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w32_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w32_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w32_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w32_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w32_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w32_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w32_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w32_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w32_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w32_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w32_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=4(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_4
local.get $x0
local.get $w2_0_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_5
local.get $p0_4
local.get $x0
local.get $w29_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w29_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w29_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w29_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w29_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w29_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w29_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w29_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w29_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w29_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w29_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w29_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w29_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w29_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w29_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w29_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w29_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w29_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w29_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w29_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w29_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w29_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w29_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w29_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w29_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w29_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w29_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w29_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w29_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w29_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w29_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w29_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_6
local.get $p0_5
local.get $x0
local.get $w30_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w30_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w30_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w30_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w30_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w30_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w30_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w30_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w30_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w30_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w30_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w30_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w30_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w30_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w30_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w30_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w30_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w30_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w30_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w30_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w30_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w30_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w30_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w30_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w30_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w30_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w30_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w30_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w30_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w30_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w30_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w30_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_7
local.get $p0_0
local.get $p0_4
i32x4.add
local.set $p0_0
local.get $p0_1
local.get $p0_5
i32x4.add
local.set $p0_1
local.get $p0_2
local.get $p0_6
i32x4.add
local.set $p0_2
local.get $p0_3
local.get $p0_7
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=28(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w7_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w7_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w7_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w7_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w7_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w7_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w7_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w7_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w7_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w7_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w7_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w7_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w7_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w7_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w7_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w7_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w7_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w7_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w7_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w7_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w7_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w7_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w7_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w7_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w7_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w7_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w7_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w7_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w7_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w7_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w7_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w7_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_4
local.get $p0_4
local.get $x0
local.get $w11_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w11_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w11_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w11_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w11_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w11_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w11_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w11_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w11_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w11_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w11_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w11_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w11_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w11_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w11_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w11_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w11_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w11_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w11_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w11_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w11_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w11_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w11_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w11_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w11_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w11_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w11_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w11_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w11_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w11_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w11_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w11_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_5
local.get $x0
local.get $w14_0_0
i32x4.dot_i16x8_s
local.get $x1
local.get $w14_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w14_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w14_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w14_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w14_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w14_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w14_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w14_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w14_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w14_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w14_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w14_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w14_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w14_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w14_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w14_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w14_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w14_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w14_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w14_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w14_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w14_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w14_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w14_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w14_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w14_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w14_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w14_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w14_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w14_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w14_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_6
local.get $p0_6
local.get $x0
local.get $w18_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w18_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w18_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w18_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w18_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w18_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w18_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w18_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w18_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w18_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w18_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w18_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w18_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w18_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w18_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w18_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w18_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w18_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w18_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w18_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w18_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w18_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w18_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w18_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w18_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w18_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w18_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w18_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w18_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w18_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w18_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w18_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_7
local.get $p0_0
local.get $p0_4
i32x4.add
local.set $p0_0
local.get $p0_1
local.get $p0_5
i32x4.add
local.set $p0_1
local.get $p0_2
local.get $p0_6
i32x4.add
local.set $p0_2
local.get $p0_3
local.get $p0_7
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=32(local.get $q))(local.get $qoff)))
local.get $p0_0
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w8_0_0
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w8_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w8_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w8_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w8_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w8_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w8_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w8_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w8_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w8_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w8_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w8_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w8_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w8_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w8_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w8_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w8_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w8_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w8_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w8_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w8_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w8_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w8_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w8_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w8_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w8_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w8_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w8_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w8_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w8_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w8_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w8_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_0
local.get $p0_1
local.get $x0
local.get $w9_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w9_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w9_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w9_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w9_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w9_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w9_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w9_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w9_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w9_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w9_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w9_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w9_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w9_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w9_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w9_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w9_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w9_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w9_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w9_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w9_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w9_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w9_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w9_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w9_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w9_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w9_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w9_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w9_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w9_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w9_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w9_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_1
local.get $p0_2
local.get $x0
local.get $w15_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w15_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w15_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w15_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w15_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w15_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w15_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w15_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w15_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w15_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w15_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w15_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w15_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w15_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w15_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w15_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w15_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w15_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w15_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w15_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w15_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w15_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w15_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w15_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w15_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w15_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w15_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w15_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w15_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w15_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w15_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w15_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_2
local.get $p0_3
local.get $x0
local.get $w16_0_0
i32x4.dot_i16x8_s
i32x4.add
local.get $x1
local.get $w16_0_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2
local.get $w16_0_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3
local.get $w16_0_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4
local.get $w16_0_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5
local.get $w16_0_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6
local.get $w16_0_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x7
local.get $w16_0_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x8
local.get $w16_0_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x9
local.get $w16_0_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x10
local.get $w16_0_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x11
local.get $w16_0_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x12
local.get $w16_0_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x13
local.get $w16_0_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x14
local.get $w16_0_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x15
local.get $w16_0_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x16
local.get $w16_0_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x17
local.get $w16_0_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x18
local.get $w16_0_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x19
local.get $w16_0_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x20
local.get $w16_0_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x21
local.get $w16_0_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x22
local.get $w16_0_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x23
local.get $w16_0_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x24
local.get $w16_0_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x25
local.get $w16_0_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x26
local.get $w16_0_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x27
local.get $w16_0_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x28
local.get $w16_0_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x29
local.get $w16_0_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x30
local.get $w16_0_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x31
local.get $w16_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_3
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_0
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_1
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_2
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $p0_3
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
)(else
(local.set $qoff(i32.add(i32.shr_u(i32.mul(local.get $t)(local.get $cols))(i32.const 3))(i32.shr_u(local.get $start)(i32.const 1))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 0))(local.get $n))(then(local.set $sx0(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 0))(local.get $input_stride))(i32.const 2)))))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 1))(local.get $n))(then(local.set $sx1(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 1))(local.get $input_stride))(i32.const 2)))))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 2))(local.get $n))(then(local.set $sx2(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 2))(local.get $input_stride))(i32.const 2)))))))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 3))(local.get $n))(then(local.set $sx3(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 3))(local.get $input_stride))(i32.const 2)))))))
(local.set $qp(i32.add(i32.load offset=0(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_0
(local.set $qp(i32.add(i32.load offset=4(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_1
(local.set $qp(i32.add(i32.load offset=8(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_2
(local.set $qp(i32.add(i32.load offset=12(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w3_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w3_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w3_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w3_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w3_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w3_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w3_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w3_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w3_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w3_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w3_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w3_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w3_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w3_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w3_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w3_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w3_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w3_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w3_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w3_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w3_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w3_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w3_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w3_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w3_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w3_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w3_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w3_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w3_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w3_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w3_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w3_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_3
(local.set $qp(i32.add(i32.load offset=16(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w4_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_4
(local.set $qp(i32.add(i32.load offset=20(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w5_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w5_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w5_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w5_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w5_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w5_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w5_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w5_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w5_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w5_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w5_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w5_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w5_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w5_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w5_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w5_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w5_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w5_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w5_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w5_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w5_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w5_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w5_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w5_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w5_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w5_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w5_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w5_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w5_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w5_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w5_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w5_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_5
(local.set $qp(i32.add(i32.load offset=24(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w6_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w6_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w6_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w6_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w6_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w6_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w6_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w6_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w6_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w6_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w6_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w6_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w6_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w6_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w6_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w6_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w6_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w6_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w6_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w6_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w6_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w6_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w6_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w6_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w6_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w6_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w6_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w6_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w6_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w6_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w6_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w6_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_6
(local.set $qp(i32.add(i32.load offset=28(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w7_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w7_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w7_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w7_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w7_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w7_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w7_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w7_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w7_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w7_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w7_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w7_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w7_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w7_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w7_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w7_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w7_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w7_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w7_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w7_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w7_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w7_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w7_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w7_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w7_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w7_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w7_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w7_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w7_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w7_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w7_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w7_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_7
(local.set $qp(i32.add(i32.load offset=32(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w8_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w8_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w8_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w8_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w8_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w8_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w8_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w8_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w8_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w8_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w8_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w8_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w8_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w8_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w8_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w8_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w8_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w8_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w8_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w8_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w8_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w8_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w8_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w8_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w8_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w8_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w8_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w8_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w8_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w8_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w8_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w8_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_8
(local.set $qp(i32.add(i32.load offset=36(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w9_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w9_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w9_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w9_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w9_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w9_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w9_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w9_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w9_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w9_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w9_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w9_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w9_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w9_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w9_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w9_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w9_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w9_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w9_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w9_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w9_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w9_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w9_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w9_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w9_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w9_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w9_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w9_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w9_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w9_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w9_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w9_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_9
(local.set $qp(i32.add(i32.load offset=40(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w10_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w10_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w10_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w10_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w10_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w10_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w10_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w10_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w10_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w10_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w10_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w10_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w10_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w10_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w10_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w10_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w10_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w10_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w10_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w10_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w10_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w10_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w10_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w10_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w10_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w10_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w10_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w10_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w10_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w10_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w10_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w10_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_10
(local.set $qp(i32.add(i32.load offset=44(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w11_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w11_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w11_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w11_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w11_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w11_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w11_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w11_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w11_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w11_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w11_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w11_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w11_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w11_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w11_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w11_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w11_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w11_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w11_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w11_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w11_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w11_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w11_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w11_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w11_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w11_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w11_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w11_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w11_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w11_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w11_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w11_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_11
(local.set $qp(i32.add(i32.load offset=48(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w12_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w12_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w12_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w12_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w12_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w12_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w12_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w12_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w12_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w12_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w12_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w12_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w12_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w12_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w12_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w12_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w12_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w12_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w12_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w12_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w12_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w12_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w12_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w12_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w12_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w12_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w12_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w12_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w12_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w12_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w12_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w12_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_12
(local.set $qp(i32.add(i32.load offset=52(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w13_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w13_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w13_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w13_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w13_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w13_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w13_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w13_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w13_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w13_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w13_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w13_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w13_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w13_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w13_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w13_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w13_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w13_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w13_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w13_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w13_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w13_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w13_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w13_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w13_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w13_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w13_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w13_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w13_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w13_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w13_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w13_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_13
(local.set $qp(i32.add(i32.load offset=56(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w14_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w14_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w14_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w14_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w14_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w14_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w14_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w14_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w14_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w14_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w14_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w14_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w14_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w14_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w14_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w14_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w14_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w14_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w14_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w14_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w14_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w14_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w14_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w14_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w14_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w14_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w14_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w14_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w14_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w14_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w14_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w14_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_14
(local.set $qp(i32.add(i32.load offset=60(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w15_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w15_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w15_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w15_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w15_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w15_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w15_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w15_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w15_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w15_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w15_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w15_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w15_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w15_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w15_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w15_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w15_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w15_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w15_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w15_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w15_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w15_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w15_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w15_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w15_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w15_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w15_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w15_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w15_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w15_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w15_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w15_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_15
(local.set $qp(i32.add(i32.load offset=64(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w16_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w16_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w16_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w16_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w16_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w16_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w16_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w16_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w16_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w16_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w16_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w16_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w16_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w16_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w16_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w16_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w16_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w16_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w16_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w16_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w16_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w16_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w16_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w16_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w16_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w16_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w16_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w16_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w16_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w16_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w16_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w16_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_16
(local.set $qp(i32.add(i32.load offset=68(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w17_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w17_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w17_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w17_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w17_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w17_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w17_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w17_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w17_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w17_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w17_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w17_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w17_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w17_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w17_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w17_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w17_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w17_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w17_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w17_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w17_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w17_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w17_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w17_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w17_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w17_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w17_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w17_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w17_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w17_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w17_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w17_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_17
(local.set $qp(i32.add(i32.load offset=72(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w18_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w18_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w18_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w18_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w18_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w18_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w18_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w18_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w18_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w18_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w18_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w18_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w18_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w18_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w18_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w18_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w18_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w18_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w18_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w18_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w18_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w18_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w18_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w18_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w18_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w18_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w18_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w18_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w18_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w18_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w18_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w18_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_18
(local.set $qp(i32.add(i32.load offset=76(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w19_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w19_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w19_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w19_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w19_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w19_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w19_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w19_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w19_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w19_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w19_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w19_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w19_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w19_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w19_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w19_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w19_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w19_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w19_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w19_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w19_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w19_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w19_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w19_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w19_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w19_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w19_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w19_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w19_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w19_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w19_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w19_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_19
(local.set $qp(i32.add(i32.load offset=80(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w20_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w20_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w20_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w20_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w20_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w20_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w20_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w20_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w20_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w20_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w20_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w20_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w20_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w20_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w20_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w20_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w20_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w20_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w20_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w20_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w20_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w20_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w20_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w20_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w20_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w20_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w20_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w20_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w20_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w20_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w20_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w20_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_20
(local.set $qp(i32.add(i32.load offset=84(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w21_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w21_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w21_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w21_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w21_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w21_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w21_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w21_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w21_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w21_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w21_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w21_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w21_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w21_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w21_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w21_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w21_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w21_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w21_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w21_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w21_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w21_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w21_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w21_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w21_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w21_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w21_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w21_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w21_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w21_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w21_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w21_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_21
(local.set $qp(i32.add(i32.load offset=88(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w22_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w22_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w22_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w22_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w22_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w22_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w22_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w22_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w22_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w22_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w22_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w22_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w22_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w22_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w22_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w22_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w22_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w22_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w22_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w22_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w22_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w22_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w22_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w22_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w22_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w22_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w22_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w22_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w22_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w22_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w22_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w22_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_22
(local.set $qp(i32.add(i32.load offset=92(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w23_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w23_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w23_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w23_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w23_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w23_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w23_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w23_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w23_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w23_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w23_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w23_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w23_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w23_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w23_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w23_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w23_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w23_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w23_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w23_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w23_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w23_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w23_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w23_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w23_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w23_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w23_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w23_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w23_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w23_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w23_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w23_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_23
(local.set $qp(i32.add(i32.load offset=96(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w24_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w24_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w24_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w24_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w24_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w24_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w24_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w24_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w24_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w24_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w24_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w24_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w24_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w24_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w24_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w24_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w24_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w24_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w24_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w24_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w24_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w24_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w24_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w24_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w24_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w24_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w24_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w24_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w24_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w24_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w24_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w24_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_24
(local.set $qp(i32.add(i32.load offset=100(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w25_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w25_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w25_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w25_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w25_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w25_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w25_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w25_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w25_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w25_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w25_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w25_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w25_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w25_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w25_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w25_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w25_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w25_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w25_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w25_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w25_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w25_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w25_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w25_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w25_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w25_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w25_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w25_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w25_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w25_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w25_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w25_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_25
(local.set $qp(i32.add(i32.load offset=104(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w26_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w26_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w26_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w26_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w26_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w26_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w26_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w26_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w26_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w26_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w26_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w26_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w26_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w26_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w26_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w26_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w26_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w26_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w26_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w26_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w26_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w26_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w26_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w26_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w26_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w26_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w26_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w26_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w26_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w26_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w26_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w26_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_26
(local.set $qp(i32.add(i32.load offset=108(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w27_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w27_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w27_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w27_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w27_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w27_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w27_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w27_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w27_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w27_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w27_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w27_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w27_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w27_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w27_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w27_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w27_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w27_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w27_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w27_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w27_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w27_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w27_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w27_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w27_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w27_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w27_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w27_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w27_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w27_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w27_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w27_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_27
(local.set $qp(i32.add(i32.load offset=112(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w28_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w28_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w28_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w28_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w28_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w28_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w28_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w28_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w28_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w28_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w28_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w28_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w28_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w28_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w28_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w28_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w28_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w28_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w28_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w28_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w28_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w28_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w28_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w28_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w28_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w28_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w28_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w28_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w28_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w28_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w28_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w28_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_28
(local.set $qp(i32.add(i32.load offset=116(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w29_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w29_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w29_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w29_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w29_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w29_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w29_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w29_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w29_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w29_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w29_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w29_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w29_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w29_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w29_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w29_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w29_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w29_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w29_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w29_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w29_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w29_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w29_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w29_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w29_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w29_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w29_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w29_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w29_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w29_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w29_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w29_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_29
(local.set $qp(i32.add(i32.load offset=120(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w30_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w30_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w30_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w30_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w30_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w30_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w30_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w30_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w30_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w30_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w30_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w30_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w30_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w30_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w30_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w30_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w30_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w30_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w30_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w30_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w30_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w30_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w30_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w30_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w30_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w30_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w30_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w30_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w30_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w30_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w30_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w30_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_30
(local.set $qp(i32.add(i32.load offset=124(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w31_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w31_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w31_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w31_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w31_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w31_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w31_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w31_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w31_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w31_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w31_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w31_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w31_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w31_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w31_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w31_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w31_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w31_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w31_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w31_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w31_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w31_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w31_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w31_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w31_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w31_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w31_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w31_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w31_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w31_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w31_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w31_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_31
(local.set $qp(i32.add(i32.load offset=128(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w32_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w32_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w32_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w32_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w32_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w32_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w32_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w32_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w32_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w32_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w32_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w32_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w32_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w32_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w32_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w32_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w32_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w32_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w32_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w32_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w32_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w32_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w32_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w32_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w32_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w32_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w32_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w32_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w32_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w32_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w32_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w32_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_32
(local.set $qp(i32.add(i32.load offset=132(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w33_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w33_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w33_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w33_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w33_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w33_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w33_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w33_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w33_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w33_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w33_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w33_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w33_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w33_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w33_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w33_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w33_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w33_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w33_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w33_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w33_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w33_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w33_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w33_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w33_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w33_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w33_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w33_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w33_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w33_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w33_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w33_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_33
(local.set $qp(i32.add(i32.load offset=136(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w34_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w34_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w34_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w34_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w34_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w34_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w34_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w34_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w34_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w34_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w34_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w34_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w34_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w34_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w34_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w34_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w34_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w34_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w34_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w34_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w34_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w34_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w34_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w34_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w34_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w34_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w34_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w34_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w34_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w34_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w34_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w34_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_34
(local.set $qp(i32.add(i32.load offset=140(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w35_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w35_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w35_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w35_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w35_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w35_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w35_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w35_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w35_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w35_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w35_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w35_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w35_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w35_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w35_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w35_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w35_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w35_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w35_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w35_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w35_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w35_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w35_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w35_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w35_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w35_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w35_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w35_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w35_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w35_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w35_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w35_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_35
(local.set $qp(i32.add(i32.load offset=144(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w36_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w36_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w36_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w36_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w36_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w36_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w36_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w36_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w36_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w36_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w36_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w36_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w36_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w36_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w36_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w36_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w36_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w36_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w36_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w36_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w36_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w36_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w36_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w36_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w36_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w36_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w36_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w36_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w36_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w36_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w36_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w36_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_36
(local.set $qp(i32.add(i32.load offset=148(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w37_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w37_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w37_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w37_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w37_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w37_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w37_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w37_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w37_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w37_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w37_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w37_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w37_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w37_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w37_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w37_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w37_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w37_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w37_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w37_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w37_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w37_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w37_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w37_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w37_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w37_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w37_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w37_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w37_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w37_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w37_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w37_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_37
(local.set $qp(i32.add(i32.load offset=152(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w38_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w38_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w38_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w38_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w38_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w38_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w38_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w38_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w38_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w38_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w38_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w38_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w38_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w38_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w38_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w38_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w38_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w38_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w38_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w38_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w38_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w38_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w38_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w38_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w38_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w38_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w38_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w38_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w38_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w38_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w38_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w38_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_38
(local.set $qp(i32.add(i32.load offset=156(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w39_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w39_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w39_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w39_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w39_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w39_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w39_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w39_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w39_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w39_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w39_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w39_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w39_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w39_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w39_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w39_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w39_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w39_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w39_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w39_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w39_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w39_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w39_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w39_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w39_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w39_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w39_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w39_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w39_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w39_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w39_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w39_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_39
(local.set $qp(i32.add(i32.load offset=160(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w40_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w40_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w40_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w40_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w40_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w40_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w40_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w40_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w40_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w40_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w40_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w40_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w40_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w40_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w40_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w40_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w40_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w40_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w40_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w40_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w40_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w40_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w40_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w40_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w40_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w40_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w40_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w40_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w40_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w40_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w40_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w40_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_40
(local.set $qp(i32.add(i32.load offset=164(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w41_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w41_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w41_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w41_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w41_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w41_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w41_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w41_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w41_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w41_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w41_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w41_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w41_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w41_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w41_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w41_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w41_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w41_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w41_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w41_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w41_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w41_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w41_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w41_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w41_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w41_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w41_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w41_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w41_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w41_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w41_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w41_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_41
(local.set $qp(i32.add(i32.load offset=168(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w42_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w42_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w42_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w42_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w42_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w42_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w42_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w42_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w42_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w42_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w42_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w42_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w42_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w42_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w42_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w42_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w42_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w42_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w42_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w42_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w42_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w42_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w42_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w42_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w42_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w42_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w42_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w42_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w42_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w42_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w42_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w42_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_42
(local.set $qp(i32.add(i32.load offset=172(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w43_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w43_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w43_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w43_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w43_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w43_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w43_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w43_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w43_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w43_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w43_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w43_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w43_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w43_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w43_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w43_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w43_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w43_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w43_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w43_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w43_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w43_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w43_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w43_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w43_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w43_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w43_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w43_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w43_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w43_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w43_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w43_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_43
(local.set $qp(i32.add(i32.load offset=176(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w44_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w44_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w44_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w44_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w44_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w44_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w44_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w44_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w44_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w44_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w44_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w44_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w44_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w44_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w44_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w44_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w44_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w44_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w44_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w44_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w44_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w44_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w44_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w44_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w44_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w44_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w44_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w44_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w44_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w44_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w44_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w44_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_44
(local.set $qp(i32.add(i32.load offset=180(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w45_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w45_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w45_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w45_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w45_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w45_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w45_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w45_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w45_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w45_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w45_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w45_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w45_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w45_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w45_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w45_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w45_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w45_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w45_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w45_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w45_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w45_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w45_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w45_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w45_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w45_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w45_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w45_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w45_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w45_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w45_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w45_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_45
(local.set $qp(i32.add(i32.load offset=184(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w46_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w46_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w46_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w46_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w46_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w46_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w46_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w46_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w46_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w46_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w46_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w46_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w46_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w46_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w46_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w46_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w46_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w46_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w46_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w46_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w46_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w46_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w46_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w46_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w46_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w46_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w46_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w46_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w46_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w46_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w46_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w46_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_46
(local.set $qp(i32.add(i32.load offset=188(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w47_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w47_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w47_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w47_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w47_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w47_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w47_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w47_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w47_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w47_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w47_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w47_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w47_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w47_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w47_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w47_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w47_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w47_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w47_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w47_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w47_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w47_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w47_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w47_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w47_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w47_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w47_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w47_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w47_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w47_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w47_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w47_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_47
(local.set $qp(i32.add(i32.load offset=192(local.get $q))(local.get $qoff)))
(local.tee $x0(v128.load32_splat offset=0(local.get $qp)))
local.get $w48_0_0
i32x4.dot_i16x8_s
(local.tee $x1(v128.load32_splat offset=4(local.get $qp)))
local.get $w48_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2(v128.load32_splat offset=8(local.get $qp)))
local.get $w48_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3(v128.load32_splat offset=12(local.get $qp)))
local.get $w48_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4(v128.load32_splat offset=16(local.get $qp)))
local.get $w48_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5(v128.load32_splat offset=20(local.get $qp)))
local.get $w48_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6(v128.load32_splat offset=24(local.get $qp)))
local.get $w48_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x7(v128.load32_splat offset=28(local.get $qp)))
local.get $w48_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x8(v128.load32_splat offset=32(local.get $qp)))
local.get $w48_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x9(v128.load32_splat offset=36(local.get $qp)))
local.get $w48_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x10(v128.load32_splat offset=40(local.get $qp)))
local.get $w48_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x11(v128.load32_splat offset=44(local.get $qp)))
local.get $w48_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x12(v128.load32_splat offset=48(local.get $qp)))
local.get $w48_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x13(v128.load32_splat offset=52(local.get $qp)))
local.get $w48_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x14(v128.load32_splat offset=56(local.get $qp)))
local.get $w48_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x15(v128.load32_splat offset=60(local.get $qp)))
local.get $w48_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x16(v128.load32_splat offset=64(local.get $qp)))
local.get $w48_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x17(v128.load32_splat offset=68(local.get $qp)))
local.get $w48_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x18(v128.load32_splat offset=72(local.get $qp)))
local.get $w48_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x19(v128.load32_splat offset=76(local.get $qp)))
local.get $w48_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x20(v128.load32_splat offset=80(local.get $qp)))
local.get $w48_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x21(v128.load32_splat offset=84(local.get $qp)))
local.get $w48_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x22(v128.load32_splat offset=88(local.get $qp)))
local.get $w48_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x23(v128.load32_splat offset=92(local.get $qp)))
local.get $w48_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x24(v128.load32_splat offset=96(local.get $qp)))
local.get $w48_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x25(v128.load32_splat offset=100(local.get $qp)))
local.get $w48_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x26(v128.load32_splat offset=104(local.get $qp)))
local.get $w48_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x27(v128.load32_splat offset=108(local.get $qp)))
local.get $w48_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x28(v128.load32_splat offset=112(local.get $qp)))
local.get $w48_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x29(v128.load32_splat offset=116(local.get $qp)))
local.get $w48_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x30(v128.load32_splat offset=120(local.get $qp)))
local.get $w48_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x31(v128.load32_splat offset=124(local.get $qp)))
local.get $w48_0_31
i32x4.dot_i16x8_s
i32x4.add
local.set $p0_48
local.get $p0_0
local.get $p0_1
i32x4.add
local.set $pc49
local.get $p0_0
local.get $p0_5
i32x4.add
local.set $pc50
local.get $pc50
local.get $p0_6
i32x4.add
local.set $pc51
local.get $pc50
local.get $p0_4
i32x4.add
local.get $p0_2
i32x4.add
local.set $pc52
local.get $pc51
local.get $p0_3
i32x4.sub
local.set $pc53
local.get $pc51
local.get $p0_4
i32x4.add
local.set $pc54
local.get $p0_7
local.get $p0_12
i32x4.add
local.set $pc55
local.get $pc55
local.get $p0_13
i32x4.add
local.set $pc56
local.get $p0_14
local.get $p0_19
i32x4.add
local.set $pc57
local.get $pc57
local.get $p0_20
i32x4.add
local.set $pc58
local.get $p0_21
local.get $p0_26
i32x4.add
local.set $pc59
local.get $pc59
local.get $p0_27
i32x4.add
local.set $pc60
local.get $p0_28
local.get $p0_29
i32x4.add
local.set $pc61
local.get $p0_28
local.get $p0_33
i32x4.add
local.set $pc62
local.get $pc62
local.get $p0_34
i32x4.add
local.set $pc63
local.get $pc62
local.get $p0_32
i32x4.add
local.get $p0_30
i32x4.add
local.set $pc64
local.get $pc63
local.get $p0_31
i32x4.sub
local.set $pc65
local.get $pc63
local.get $p0_32
i32x4.add
local.set $pc66
local.get $p0_35
local.get $p0_40
i32x4.add
local.set $pc67
local.get $pc67
local.get $p0_41
i32x4.add
local.set $pc68
local.get $p0_42
local.get $p0_47
i32x4.add
local.set $pc69
local.get $pc69
local.get $p0_48
i32x4.add
local.set $pc70
local.get $pc49
local.get $p0_7
local.get $p0_8
i32x4.add
i32x4.add
local.set $pc71
local.get $pc52
local.get $pc55
local.get $p0_11
i32x4.add
local.get $p0_9
i32x4.add
i32x4.add
local.set $pc72
local.get $pc53
local.get $pc56
local.get $p0_10
i32x4.sub
i32x4.add
local.set $pc73
local.get $pc54
local.get $pc56
local.get $p0_11
i32x4.add
i32x4.add
local.set $pc74
local.get $pc49
local.get $p0_35
local.get $p0_36
i32x4.add
i32x4.add
local.set $pc75
local.get $pc52
local.get $pc67
local.get $p0_39
i32x4.add
local.get $p0_37
i32x4.add
i32x4.add
local.set $pc76
local.get $pc53
local.get $pc68
local.get $p0_38
i32x4.sub
i32x4.add
local.set $pc77
local.get $pc54
local.get $pc68
local.get $p0_39
i32x4.add
i32x4.add
local.set $pc78
local.get $pc75
local.get $p0_42
local.get $p0_43
i32x4.add
i32x4.add
local.set $pc79
local.get $pc76
local.get $pc69
local.get $p0_46
i32x4.add
local.get $p0_44
i32x4.add
i32x4.add
local.set $pc80
local.get $pc77
local.get $pc70
local.get $p0_45
i32x4.sub
i32x4.add
local.set $pc81
local.get $pc78
local.get $pc70
local.get $p0_46
i32x4.add
i32x4.add
local.set $pc82
local.get $pc75
local.get $pc61
i32x4.add
local.get $p0_14
local.get $p0_15
i32x4.add
i32x4.add
local.set $pc83
local.get $pc76
local.get $pc64
i32x4.add
local.get $pc57
local.get $p0_18
i32x4.add
local.get $p0_16
i32x4.add
i32x4.add
local.set $pc84
local.get $pc77
local.get $pc65
i32x4.add
local.get $pc58
local.get $p0_17
i32x4.sub
i32x4.add
local.set $pc85
local.get $pc78
local.get $pc66
i32x4.add
local.get $pc58
local.get $p0_18
i32x4.add
i32x4.add
local.set $pc86
local.get $pc79
local.get $p0_21
local.get $p0_22
i32x4.add
i32x4.sub
local.set $pc87
local.get $pc80
local.get $pc59
local.get $p0_25
i32x4.add
local.get $p0_23
i32x4.add
i32x4.sub
local.set $pc88
local.get $pc81
local.get $pc60
local.get $p0_24
i32x4.sub
i32x4.sub
local.set $pc89
local.get $pc82
local.get $pc60
local.get $p0_25
i32x4.add
i32x4.sub
local.set $pc90
local.get $pc79
local.get $pc61
i32x4.add
local.set $pc91
local.get $pc80
local.get $pc64
i32x4.add
local.set $pc92
local.get $pc81
local.get $pc65
i32x4.add
local.set $pc93
local.get $pc82
local.get $pc66
i32x4.add
local.set $pc94
(if(i32.lt_u(i32.add(local.get $t)(i32.const 0))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 0))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc71
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc72
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc83
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc84
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 1))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 1))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc73
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc74
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc85
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc86
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 2))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 2))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc87
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc88
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc91
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc92
f32x4.convert_i32x4_s
local.get $sx2
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 3))(local.get $n))(then
(local.set $yp(i32.add(local.get $sums)(i32.mul(i32.add(local.get $t)(i32.const 3))(local.get $output_bytes))))
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc89
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc90
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc93
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
v128.const i32x4 0 0 0 0
local.get $pc94
f32x4.convert_i32x4_s
local.get $sx3
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
))
(local.set $t(i32.add(local.get $t)(i32.const 4)))
br $tokens
))
))
