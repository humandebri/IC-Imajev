(module(func(export "__imajev_win7_32_accumulate")(param $q i32)(param $w i32)(param $cols i32)(param $start i32)(param $sx i32)(param $stride i32)(param $sw i32)(param $sums i32)(param $n i32)
(local $input_stride i32)(local $output_bytes i32)(local $t i32)(local $qp i32)(local $qo i32)(local $keep i32)(local $yp i32)(local $yp1 i32)(local $sx0 v128)(local $sx1 v128)
(local $bp0 i32)(local $wp0 i32)
(local $bp1 i32)(local $wp1 i32)
(local $bp2 i32)(local $wp2 i32)
(local $bp3 i32)(local $wp3 i32)
(local $pc0 v128)
(local $pc1 v128)
(local $pc2 v128)
(local $pc3 v128)
(local $pc4 v128)
(local $pc5 v128)
(local $pc6 v128)
(local $pc7 v128)
(local $pc8 v128)
(local $pc9 v128)
(local $pc10 v128)
(local $pc11 v128)
(local $pc12 v128)
(local $x0_0 v128)
(local $x0_1 v128)
(local $x0_2 v128)
(local $x0_3 v128)
(local $x0_4 v128)
(local $x0_5 v128)
(local $x0_6 v128)
(local $x0_7 v128)
(local $x0_8 v128)
(local $x0_9 v128)
(local $x0_10 v128)
(local $x0_11 v128)
(local $x0_12 v128)
(local $x0_13 v128)
(local $x0_14 v128)
(local $x0_15 v128)
(local $x0_16 v128)
(local $x0_17 v128)
(local $x0_18 v128)
(local $x0_19 v128)
(local $x0_20 v128)
(local $x0_21 v128)
(local $x0_22 v128)
(local $x0_23 v128)
(local $x0_24 v128)
(local $x0_25 v128)
(local $x0_26 v128)
(local $x0_27 v128)
(local $x0_28 v128)
(local $x0_29 v128)
(local $x0_30 v128)
(local $x0_31 v128)
(local $x0_32 v128)
(local $x0_33 v128)
(local $x0_34 v128)
(local $x0_35 v128)
(local $x0_36 v128)
(local $x0_37 v128)
(local $x0_38 v128)
(local $x0_39 v128)
(local $x0_40 v128)
(local $x0_41 v128)
(local $x0_42 v128)
(local $x0_43 v128)
(local $x0_44 v128)
(local $x0_45 v128)
(local $x0_46 v128)
(local $x0_47 v128)
(local $x0_48 v128)
(local $x0_49 v128)
(local $x0_50 v128)
(local $x0_51 v128)
(local $x0_52 v128)
(local $x0_53 v128)
(local $x0_54 v128)
(local $x0_55 v128)
(local $x0_56 v128)
(local $x0_57 v128)
(local $x0_58 v128)
(local $x0_59 v128)
(local $x0_60 v128)
(local $x0_61 v128)
(local $x0_62 v128)
(local $x0_63 v128)
(local $w0_0_0 v128)
(local $w0_0_1 v128)
(local $w0_0_2 v128)
(local $w0_0_3 v128)
(local $w0_0_4 v128)
(local $w0_0_5 v128)
(local $w0_0_6 v128)
(local $w0_0_7 v128)
(local $w0_0_8 v128)
(local $w0_0_9 v128)
(local $w0_0_10 v128)
(local $w0_0_11 v128)
(local $w0_0_12 v128)
(local $w0_0_13 v128)
(local $w0_0_14 v128)
(local $w0_0_15 v128)
(local $w0_0_16 v128)
(local $w0_0_17 v128)
(local $w0_0_18 v128)
(local $w0_0_19 v128)
(local $w0_0_20 v128)
(local $w0_0_21 v128)
(local $w0_0_22 v128)
(local $w0_0_23 v128)
(local $w0_0_24 v128)
(local $w0_0_25 v128)
(local $w0_0_26 v128)
(local $w0_0_27 v128)
(local $w0_0_28 v128)
(local $w0_0_29 v128)
(local $w0_0_30 v128)
(local $w0_0_31 v128)
(local $w0_0_32 v128)
(local $w0_0_33 v128)
(local $w0_0_34 v128)
(local $w0_0_35 v128)
(local $w0_0_36 v128)
(local $w0_0_37 v128)
(local $w0_0_38 v128)
(local $w0_0_39 v128)
(local $w0_0_40 v128)
(local $w0_0_41 v128)
(local $w0_0_42 v128)
(local $w0_0_43 v128)
(local $w0_0_44 v128)
(local $w0_0_45 v128)
(local $w0_0_46 v128)
(local $w0_0_47 v128)
(local $w0_0_48 v128)
(local $w0_0_49 v128)
(local $w0_0_50 v128)
(local $w0_0_51 v128)
(local $w0_0_52 v128)
(local $w0_0_53 v128)
(local $w0_0_54 v128)
(local $w0_0_55 v128)
(local $w0_0_56 v128)
(local $w0_0_57 v128)
(local $w0_0_58 v128)
(local $w0_0_59 v128)
(local $w0_0_60 v128)
(local $w0_0_61 v128)
(local $w0_0_62 v128)
(local $w0_0_63 v128)
(local $w0_1_0 v128)
(local $w0_1_1 v128)
(local $w0_1_2 v128)
(local $w0_1_3 v128)
(local $w0_1_4 v128)
(local $w0_1_5 v128)
(local $w0_1_6 v128)
(local $w0_1_7 v128)
(local $w0_1_8 v128)
(local $w0_1_9 v128)
(local $w0_1_10 v128)
(local $w0_1_11 v128)
(local $w0_1_12 v128)
(local $w0_1_13 v128)
(local $w0_1_14 v128)
(local $w0_1_15 v128)
(local $w0_1_16 v128)
(local $w0_1_17 v128)
(local $w0_1_18 v128)
(local $w0_1_19 v128)
(local $w0_1_20 v128)
(local $w0_1_21 v128)
(local $w0_1_22 v128)
(local $w0_1_23 v128)
(local $w0_1_24 v128)
(local $w0_1_25 v128)
(local $w0_1_26 v128)
(local $w0_1_27 v128)
(local $w0_1_28 v128)
(local $w0_1_29 v128)
(local $w0_1_30 v128)
(local $w0_1_31 v128)
(local $w0_1_32 v128)
(local $w0_1_33 v128)
(local $w0_1_34 v128)
(local $w0_1_35 v128)
(local $w0_1_36 v128)
(local $w0_1_37 v128)
(local $w0_1_38 v128)
(local $w0_1_39 v128)
(local $w0_1_40 v128)
(local $w0_1_41 v128)
(local $w0_1_42 v128)
(local $w0_1_43 v128)
(local $w0_1_44 v128)
(local $w0_1_45 v128)
(local $w0_1_46 v128)
(local $w0_1_47 v128)
(local $w0_1_48 v128)
(local $w0_1_49 v128)
(local $w0_1_50 v128)
(local $w0_1_51 v128)
(local $w0_1_52 v128)
(local $w0_1_53 v128)
(local $w0_1_54 v128)
(local $w0_1_55 v128)
(local $w0_1_56 v128)
(local $w0_1_57 v128)
(local $w0_1_58 v128)
(local $w0_1_59 v128)
(local $w0_1_60 v128)
(local $w0_1_61 v128)
(local $w0_1_62 v128)
(local $w0_1_63 v128)
(local $w0_2_0 v128)
(local $w0_2_1 v128)
(local $w0_2_2 v128)
(local $w0_2_3 v128)
(local $w0_2_4 v128)
(local $w0_2_5 v128)
(local $w0_2_6 v128)
(local $w0_2_7 v128)
(local $w0_2_8 v128)
(local $w0_2_9 v128)
(local $w0_2_10 v128)
(local $w0_2_11 v128)
(local $w0_2_12 v128)
(local $w0_2_13 v128)
(local $w0_2_14 v128)
(local $w0_2_15 v128)
(local $w0_2_16 v128)
(local $w0_2_17 v128)
(local $w0_2_18 v128)
(local $w0_2_19 v128)
(local $w0_2_20 v128)
(local $w0_2_21 v128)
(local $w0_2_22 v128)
(local $w0_2_23 v128)
(local $w0_2_24 v128)
(local $w0_2_25 v128)
(local $w0_2_26 v128)
(local $w0_2_27 v128)
(local $w0_2_28 v128)
(local $w0_2_29 v128)
(local $w0_2_30 v128)
(local $w0_2_31 v128)
(local $w0_2_32 v128)
(local $w0_2_33 v128)
(local $w0_2_34 v128)
(local $w0_2_35 v128)
(local $w0_2_36 v128)
(local $w0_2_37 v128)
(local $w0_2_38 v128)
(local $w0_2_39 v128)
(local $w0_2_40 v128)
(local $w0_2_41 v128)
(local $w0_2_42 v128)
(local $w0_2_43 v128)
(local $w0_2_44 v128)
(local $w0_2_45 v128)
(local $w0_2_46 v128)
(local $w0_2_47 v128)
(local $w0_2_48 v128)
(local $w0_2_49 v128)
(local $w0_2_50 v128)
(local $w0_2_51 v128)
(local $w0_2_52 v128)
(local $w0_2_53 v128)
(local $w0_2_54 v128)
(local $w0_2_55 v128)
(local $w0_2_56 v128)
(local $w0_2_57 v128)
(local $w0_2_58 v128)
(local $w0_2_59 v128)
(local $w0_2_60 v128)
(local $w0_2_61 v128)
(local $w0_2_62 v128)
(local $w0_2_63 v128)
(local $w0_3_0 v128)
(local $w0_3_1 v128)
(local $w0_3_2 v128)
(local $w0_3_3 v128)
(local $w0_3_4 v128)
(local $w0_3_5 v128)
(local $w0_3_6 v128)
(local $w0_3_7 v128)
(local $w0_3_8 v128)
(local $w0_3_9 v128)
(local $w0_3_10 v128)
(local $w0_3_11 v128)
(local $w0_3_12 v128)
(local $w0_3_13 v128)
(local $w0_3_14 v128)
(local $w0_3_15 v128)
(local $w0_3_16 v128)
(local $w0_3_17 v128)
(local $w0_3_18 v128)
(local $w0_3_19 v128)
(local $w0_3_20 v128)
(local $w0_3_21 v128)
(local $w0_3_22 v128)
(local $w0_3_23 v128)
(local $w0_3_24 v128)
(local $w0_3_25 v128)
(local $w0_3_26 v128)
(local $w0_3_27 v128)
(local $w0_3_28 v128)
(local $w0_3_29 v128)
(local $w0_3_30 v128)
(local $w0_3_31 v128)
(local $w0_3_32 v128)
(local $w0_3_33 v128)
(local $w0_3_34 v128)
(local $w0_3_35 v128)
(local $w0_3_36 v128)
(local $w0_3_37 v128)
(local $w0_3_38 v128)
(local $w0_3_39 v128)
(local $w0_3_40 v128)
(local $w0_3_41 v128)
(local $w0_3_42 v128)
(local $w0_3_43 v128)
(local $w0_3_44 v128)
(local $w0_3_45 v128)
(local $w0_3_46 v128)
(local $w0_3_47 v128)
(local $w0_3_48 v128)
(local $w0_3_49 v128)
(local $w0_3_50 v128)
(local $w0_3_51 v128)
(local $w0_3_52 v128)
(local $w0_3_53 v128)
(local $w0_3_54 v128)
(local $w0_3_55 v128)
(local $w0_3_56 v128)
(local $w0_3_57 v128)
(local $w0_3_58 v128)
(local $w0_3_59 v128)
(local $w0_3_60 v128)
(local $w0_3_61 v128)
(local $w0_3_62 v128)
(local $w0_3_63 v128)
(local $x1_0 v128)
(local $x1_1 v128)
(local $x1_2 v128)
(local $x1_3 v128)
(local $x1_4 v128)
(local $x1_5 v128)
(local $x1_6 v128)
(local $x1_7 v128)
(local $x1_8 v128)
(local $x1_9 v128)
(local $x1_10 v128)
(local $x1_11 v128)
(local $x1_12 v128)
(local $x1_13 v128)
(local $x1_14 v128)
(local $x1_15 v128)
(local $x1_16 v128)
(local $x1_17 v128)
(local $x1_18 v128)
(local $x1_19 v128)
(local $x1_20 v128)
(local $x1_21 v128)
(local $x1_22 v128)
(local $x1_23 v128)
(local $x1_24 v128)
(local $x1_25 v128)
(local $x1_26 v128)
(local $x1_27 v128)
(local $x1_28 v128)
(local $x1_29 v128)
(local $x1_30 v128)
(local $x1_31 v128)
(local $x1_32 v128)
(local $x1_33 v128)
(local $x1_34 v128)
(local $x1_35 v128)
(local $x1_36 v128)
(local $x1_37 v128)
(local $x1_38 v128)
(local $x1_39 v128)
(local $x1_40 v128)
(local $x1_41 v128)
(local $x1_42 v128)
(local $x1_43 v128)
(local $x1_44 v128)
(local $x1_45 v128)
(local $x1_46 v128)
(local $x1_47 v128)
(local $x1_48 v128)
(local $x1_49 v128)
(local $x1_50 v128)
(local $x1_51 v128)
(local $x1_52 v128)
(local $x1_53 v128)
(local $x1_54 v128)
(local $x1_55 v128)
(local $x1_56 v128)
(local $x1_57 v128)
(local $x1_58 v128)
(local $x1_59 v128)
(local $x1_60 v128)
(local $x1_61 v128)
(local $x1_62 v128)
(local $x1_63 v128)
(local $w1_0_0 v128)
(local $w1_0_1 v128)
(local $w1_0_2 v128)
(local $w1_0_3 v128)
(local $w1_0_4 v128)
(local $w1_0_5 v128)
(local $w1_0_6 v128)
(local $w1_0_7 v128)
(local $w1_0_8 v128)
(local $w1_0_9 v128)
(local $w1_0_10 v128)
(local $w1_0_11 v128)
(local $w1_0_12 v128)
(local $w1_0_13 v128)
(local $w1_0_14 v128)
(local $w1_0_15 v128)
(local $w1_0_16 v128)
(local $w1_0_17 v128)
(local $w1_0_18 v128)
(local $w1_0_19 v128)
(local $w1_0_20 v128)
(local $w1_0_21 v128)
(local $w1_0_22 v128)
(local $w1_0_23 v128)
(local $w1_0_24 v128)
(local $w1_0_25 v128)
(local $w1_0_26 v128)
(local $w1_0_27 v128)
(local $w1_0_28 v128)
(local $w1_0_29 v128)
(local $w1_0_30 v128)
(local $w1_0_31 v128)
(local $w1_0_32 v128)
(local $w1_0_33 v128)
(local $w1_0_34 v128)
(local $w1_0_35 v128)
(local $w1_0_36 v128)
(local $w1_0_37 v128)
(local $w1_0_38 v128)
(local $w1_0_39 v128)
(local $w1_0_40 v128)
(local $w1_0_41 v128)
(local $w1_0_42 v128)
(local $w1_0_43 v128)
(local $w1_0_44 v128)
(local $w1_0_45 v128)
(local $w1_0_46 v128)
(local $w1_0_47 v128)
(local $w1_0_48 v128)
(local $w1_0_49 v128)
(local $w1_0_50 v128)
(local $w1_0_51 v128)
(local $w1_0_52 v128)
(local $w1_0_53 v128)
(local $w1_0_54 v128)
(local $w1_0_55 v128)
(local $w1_0_56 v128)
(local $w1_0_57 v128)
(local $w1_0_58 v128)
(local $w1_0_59 v128)
(local $w1_0_60 v128)
(local $w1_0_61 v128)
(local $w1_0_62 v128)
(local $w1_0_63 v128)
(local $w1_1_0 v128)
(local $w1_1_1 v128)
(local $w1_1_2 v128)
(local $w1_1_3 v128)
(local $w1_1_4 v128)
(local $w1_1_5 v128)
(local $w1_1_6 v128)
(local $w1_1_7 v128)
(local $w1_1_8 v128)
(local $w1_1_9 v128)
(local $w1_1_10 v128)
(local $w1_1_11 v128)
(local $w1_1_12 v128)
(local $w1_1_13 v128)
(local $w1_1_14 v128)
(local $w1_1_15 v128)
(local $w1_1_16 v128)
(local $w1_1_17 v128)
(local $w1_1_18 v128)
(local $w1_1_19 v128)
(local $w1_1_20 v128)
(local $w1_1_21 v128)
(local $w1_1_22 v128)
(local $w1_1_23 v128)
(local $w1_1_24 v128)
(local $w1_1_25 v128)
(local $w1_1_26 v128)
(local $w1_1_27 v128)
(local $w1_1_28 v128)
(local $w1_1_29 v128)
(local $w1_1_30 v128)
(local $w1_1_31 v128)
(local $w1_1_32 v128)
(local $w1_1_33 v128)
(local $w1_1_34 v128)
(local $w1_1_35 v128)
(local $w1_1_36 v128)
(local $w1_1_37 v128)
(local $w1_1_38 v128)
(local $w1_1_39 v128)
(local $w1_1_40 v128)
(local $w1_1_41 v128)
(local $w1_1_42 v128)
(local $w1_1_43 v128)
(local $w1_1_44 v128)
(local $w1_1_45 v128)
(local $w1_1_46 v128)
(local $w1_1_47 v128)
(local $w1_1_48 v128)
(local $w1_1_49 v128)
(local $w1_1_50 v128)
(local $w1_1_51 v128)
(local $w1_1_52 v128)
(local $w1_1_53 v128)
(local $w1_1_54 v128)
(local $w1_1_55 v128)
(local $w1_1_56 v128)
(local $w1_1_57 v128)
(local $w1_1_58 v128)
(local $w1_1_59 v128)
(local $w1_1_60 v128)
(local $w1_1_61 v128)
(local $w1_1_62 v128)
(local $w1_1_63 v128)
(local $w1_2_0 v128)
(local $w1_2_1 v128)
(local $w1_2_2 v128)
(local $w1_2_3 v128)
(local $w1_2_4 v128)
(local $w1_2_5 v128)
(local $w1_2_6 v128)
(local $w1_2_7 v128)
(local $w1_2_8 v128)
(local $w1_2_9 v128)
(local $w1_2_10 v128)
(local $w1_2_11 v128)
(local $w1_2_12 v128)
(local $w1_2_13 v128)
(local $w1_2_14 v128)
(local $w1_2_15 v128)
(local $w1_2_16 v128)
(local $w1_2_17 v128)
(local $w1_2_18 v128)
(local $w1_2_19 v128)
(local $w1_2_20 v128)
(local $w1_2_21 v128)
(local $w1_2_22 v128)
(local $w1_2_23 v128)
(local $w1_2_24 v128)
(local $w1_2_25 v128)
(local $w1_2_26 v128)
(local $w1_2_27 v128)
(local $w1_2_28 v128)
(local $w1_2_29 v128)
(local $w1_2_30 v128)
(local $w1_2_31 v128)
(local $w1_2_32 v128)
(local $w1_2_33 v128)
(local $w1_2_34 v128)
(local $w1_2_35 v128)
(local $w1_2_36 v128)
(local $w1_2_37 v128)
(local $w1_2_38 v128)
(local $w1_2_39 v128)
(local $w1_2_40 v128)
(local $w1_2_41 v128)
(local $w1_2_42 v128)
(local $w1_2_43 v128)
(local $w1_2_44 v128)
(local $w1_2_45 v128)
(local $w1_2_46 v128)
(local $w1_2_47 v128)
(local $w1_2_48 v128)
(local $w1_2_49 v128)
(local $w1_2_50 v128)
(local $w1_2_51 v128)
(local $w1_2_52 v128)
(local $w1_2_53 v128)
(local $w1_2_54 v128)
(local $w1_2_55 v128)
(local $w1_2_56 v128)
(local $w1_2_57 v128)
(local $w1_2_58 v128)
(local $w1_2_59 v128)
(local $w1_2_60 v128)
(local $w1_2_61 v128)
(local $w1_2_62 v128)
(local $w1_2_63 v128)
(local $w1_3_0 v128)
(local $w1_3_1 v128)
(local $w1_3_2 v128)
(local $w1_3_3 v128)
(local $w1_3_4 v128)
(local $w1_3_5 v128)
(local $w1_3_6 v128)
(local $w1_3_7 v128)
(local $w1_3_8 v128)
(local $w1_3_9 v128)
(local $w1_3_10 v128)
(local $w1_3_11 v128)
(local $w1_3_12 v128)
(local $w1_3_13 v128)
(local $w1_3_14 v128)
(local $w1_3_15 v128)
(local $w1_3_16 v128)
(local $w1_3_17 v128)
(local $w1_3_18 v128)
(local $w1_3_19 v128)
(local $w1_3_20 v128)
(local $w1_3_21 v128)
(local $w1_3_22 v128)
(local $w1_3_23 v128)
(local $w1_3_24 v128)
(local $w1_3_25 v128)
(local $w1_3_26 v128)
(local $w1_3_27 v128)
(local $w1_3_28 v128)
(local $w1_3_29 v128)
(local $w1_3_30 v128)
(local $w1_3_31 v128)
(local $w1_3_32 v128)
(local $w1_3_33 v128)
(local $w1_3_34 v128)
(local $w1_3_35 v128)
(local $w1_3_36 v128)
(local $w1_3_37 v128)
(local $w1_3_38 v128)
(local $w1_3_39 v128)
(local $w1_3_40 v128)
(local $w1_3_41 v128)
(local $w1_3_42 v128)
(local $w1_3_43 v128)
(local $w1_3_44 v128)
(local $w1_3_45 v128)
(local $w1_3_46 v128)
(local $w1_3_47 v128)
(local $w1_3_48 v128)
(local $w1_3_49 v128)
(local $w1_3_50 v128)
(local $w1_3_51 v128)
(local $w1_3_52 v128)
(local $w1_3_53 v128)
(local $w1_3_54 v128)
(local $w1_3_55 v128)
(local $w1_3_56 v128)
(local $w1_3_57 v128)
(local $w1_3_58 v128)
(local $w1_3_59 v128)
(local $w1_3_60 v128)
(local $w1_3_61 v128)
(local $w1_3_62 v128)
(local $w1_3_63 v128)
(local $x2_0 v128)
(local $x2_1 v128)
(local $x2_2 v128)
(local $x2_3 v128)
(local $x2_4 v128)
(local $x2_5 v128)
(local $x2_6 v128)
(local $x2_7 v128)
(local $x2_8 v128)
(local $x2_9 v128)
(local $x2_10 v128)
(local $x2_11 v128)
(local $x2_12 v128)
(local $x2_13 v128)
(local $x2_14 v128)
(local $x2_15 v128)
(local $x2_16 v128)
(local $x2_17 v128)
(local $x2_18 v128)
(local $x2_19 v128)
(local $x2_20 v128)
(local $x2_21 v128)
(local $x2_22 v128)
(local $x2_23 v128)
(local $x2_24 v128)
(local $x2_25 v128)
(local $x2_26 v128)
(local $x2_27 v128)
(local $x2_28 v128)
(local $x2_29 v128)
(local $x2_30 v128)
(local $x2_31 v128)
(local $x2_32 v128)
(local $x2_33 v128)
(local $x2_34 v128)
(local $x2_35 v128)
(local $x2_36 v128)
(local $x2_37 v128)
(local $x2_38 v128)
(local $x2_39 v128)
(local $x2_40 v128)
(local $x2_41 v128)
(local $x2_42 v128)
(local $x2_43 v128)
(local $x2_44 v128)
(local $x2_45 v128)
(local $x2_46 v128)
(local $x2_47 v128)
(local $x2_48 v128)
(local $x2_49 v128)
(local $x2_50 v128)
(local $x2_51 v128)
(local $x2_52 v128)
(local $x2_53 v128)
(local $x2_54 v128)
(local $x2_55 v128)
(local $x2_56 v128)
(local $x2_57 v128)
(local $x2_58 v128)
(local $x2_59 v128)
(local $x2_60 v128)
(local $x2_61 v128)
(local $x2_62 v128)
(local $x2_63 v128)
(local $w2_0_0 v128)
(local $w2_0_1 v128)
(local $w2_0_2 v128)
(local $w2_0_3 v128)
(local $w2_0_4 v128)
(local $w2_0_5 v128)
(local $w2_0_6 v128)
(local $w2_0_7 v128)
(local $w2_0_8 v128)
(local $w2_0_9 v128)
(local $w2_0_10 v128)
(local $w2_0_11 v128)
(local $w2_0_12 v128)
(local $w2_0_13 v128)
(local $w2_0_14 v128)
(local $w2_0_15 v128)
(local $w2_0_16 v128)
(local $w2_0_17 v128)
(local $w2_0_18 v128)
(local $w2_0_19 v128)
(local $w2_0_20 v128)
(local $w2_0_21 v128)
(local $w2_0_22 v128)
(local $w2_0_23 v128)
(local $w2_0_24 v128)
(local $w2_0_25 v128)
(local $w2_0_26 v128)
(local $w2_0_27 v128)
(local $w2_0_28 v128)
(local $w2_0_29 v128)
(local $w2_0_30 v128)
(local $w2_0_31 v128)
(local $w2_0_32 v128)
(local $w2_0_33 v128)
(local $w2_0_34 v128)
(local $w2_0_35 v128)
(local $w2_0_36 v128)
(local $w2_0_37 v128)
(local $w2_0_38 v128)
(local $w2_0_39 v128)
(local $w2_0_40 v128)
(local $w2_0_41 v128)
(local $w2_0_42 v128)
(local $w2_0_43 v128)
(local $w2_0_44 v128)
(local $w2_0_45 v128)
(local $w2_0_46 v128)
(local $w2_0_47 v128)
(local $w2_0_48 v128)
(local $w2_0_49 v128)
(local $w2_0_50 v128)
(local $w2_0_51 v128)
(local $w2_0_52 v128)
(local $w2_0_53 v128)
(local $w2_0_54 v128)
(local $w2_0_55 v128)
(local $w2_0_56 v128)
(local $w2_0_57 v128)
(local $w2_0_58 v128)
(local $w2_0_59 v128)
(local $w2_0_60 v128)
(local $w2_0_61 v128)
(local $w2_0_62 v128)
(local $w2_0_63 v128)
(local $w2_1_0 v128)
(local $w2_1_1 v128)
(local $w2_1_2 v128)
(local $w2_1_3 v128)
(local $w2_1_4 v128)
(local $w2_1_5 v128)
(local $w2_1_6 v128)
(local $w2_1_7 v128)
(local $w2_1_8 v128)
(local $w2_1_9 v128)
(local $w2_1_10 v128)
(local $w2_1_11 v128)
(local $w2_1_12 v128)
(local $w2_1_13 v128)
(local $w2_1_14 v128)
(local $w2_1_15 v128)
(local $w2_1_16 v128)
(local $w2_1_17 v128)
(local $w2_1_18 v128)
(local $w2_1_19 v128)
(local $w2_1_20 v128)
(local $w2_1_21 v128)
(local $w2_1_22 v128)
(local $w2_1_23 v128)
(local $w2_1_24 v128)
(local $w2_1_25 v128)
(local $w2_1_26 v128)
(local $w2_1_27 v128)
(local $w2_1_28 v128)
(local $w2_1_29 v128)
(local $w2_1_30 v128)
(local $w2_1_31 v128)
(local $w2_1_32 v128)
(local $w2_1_33 v128)
(local $w2_1_34 v128)
(local $w2_1_35 v128)
(local $w2_1_36 v128)
(local $w2_1_37 v128)
(local $w2_1_38 v128)
(local $w2_1_39 v128)
(local $w2_1_40 v128)
(local $w2_1_41 v128)
(local $w2_1_42 v128)
(local $w2_1_43 v128)
(local $w2_1_44 v128)
(local $w2_1_45 v128)
(local $w2_1_46 v128)
(local $w2_1_47 v128)
(local $w2_1_48 v128)
(local $w2_1_49 v128)
(local $w2_1_50 v128)
(local $w2_1_51 v128)
(local $w2_1_52 v128)
(local $w2_1_53 v128)
(local $w2_1_54 v128)
(local $w2_1_55 v128)
(local $w2_1_56 v128)
(local $w2_1_57 v128)
(local $w2_1_58 v128)
(local $w2_1_59 v128)
(local $w2_1_60 v128)
(local $w2_1_61 v128)
(local $w2_1_62 v128)
(local $w2_1_63 v128)
(local $w2_2_0 v128)
(local $w2_2_1 v128)
(local $w2_2_2 v128)
(local $w2_2_3 v128)
(local $w2_2_4 v128)
(local $w2_2_5 v128)
(local $w2_2_6 v128)
(local $w2_2_7 v128)
(local $w2_2_8 v128)
(local $w2_2_9 v128)
(local $w2_2_10 v128)
(local $w2_2_11 v128)
(local $w2_2_12 v128)
(local $w2_2_13 v128)
(local $w2_2_14 v128)
(local $w2_2_15 v128)
(local $w2_2_16 v128)
(local $w2_2_17 v128)
(local $w2_2_18 v128)
(local $w2_2_19 v128)
(local $w2_2_20 v128)
(local $w2_2_21 v128)
(local $w2_2_22 v128)
(local $w2_2_23 v128)
(local $w2_2_24 v128)
(local $w2_2_25 v128)
(local $w2_2_26 v128)
(local $w2_2_27 v128)
(local $w2_2_28 v128)
(local $w2_2_29 v128)
(local $w2_2_30 v128)
(local $w2_2_31 v128)
(local $w2_2_32 v128)
(local $w2_2_33 v128)
(local $w2_2_34 v128)
(local $w2_2_35 v128)
(local $w2_2_36 v128)
(local $w2_2_37 v128)
(local $w2_2_38 v128)
(local $w2_2_39 v128)
(local $w2_2_40 v128)
(local $w2_2_41 v128)
(local $w2_2_42 v128)
(local $w2_2_43 v128)
(local $w2_2_44 v128)
(local $w2_2_45 v128)
(local $w2_2_46 v128)
(local $w2_2_47 v128)
(local $w2_2_48 v128)
(local $w2_2_49 v128)
(local $w2_2_50 v128)
(local $w2_2_51 v128)
(local $w2_2_52 v128)
(local $w2_2_53 v128)
(local $w2_2_54 v128)
(local $w2_2_55 v128)
(local $w2_2_56 v128)
(local $w2_2_57 v128)
(local $w2_2_58 v128)
(local $w2_2_59 v128)
(local $w2_2_60 v128)
(local $w2_2_61 v128)
(local $w2_2_62 v128)
(local $w2_2_63 v128)
(local $w2_3_0 v128)
(local $w2_3_1 v128)
(local $w2_3_2 v128)
(local $w2_3_3 v128)
(local $w2_3_4 v128)
(local $w2_3_5 v128)
(local $w2_3_6 v128)
(local $w2_3_7 v128)
(local $w2_3_8 v128)
(local $w2_3_9 v128)
(local $w2_3_10 v128)
(local $w2_3_11 v128)
(local $w2_3_12 v128)
(local $w2_3_13 v128)
(local $w2_3_14 v128)
(local $w2_3_15 v128)
(local $w2_3_16 v128)
(local $w2_3_17 v128)
(local $w2_3_18 v128)
(local $w2_3_19 v128)
(local $w2_3_20 v128)
(local $w2_3_21 v128)
(local $w2_3_22 v128)
(local $w2_3_23 v128)
(local $w2_3_24 v128)
(local $w2_3_25 v128)
(local $w2_3_26 v128)
(local $w2_3_27 v128)
(local $w2_3_28 v128)
(local $w2_3_29 v128)
(local $w2_3_30 v128)
(local $w2_3_31 v128)
(local $w2_3_32 v128)
(local $w2_3_33 v128)
(local $w2_3_34 v128)
(local $w2_3_35 v128)
(local $w2_3_36 v128)
(local $w2_3_37 v128)
(local $w2_3_38 v128)
(local $w2_3_39 v128)
(local $w2_3_40 v128)
(local $w2_3_41 v128)
(local $w2_3_42 v128)
(local $w2_3_43 v128)
(local $w2_3_44 v128)
(local $w2_3_45 v128)
(local $w2_3_46 v128)
(local $w2_3_47 v128)
(local $w2_3_48 v128)
(local $w2_3_49 v128)
(local $w2_3_50 v128)
(local $w2_3_51 v128)
(local $w2_3_52 v128)
(local $w2_3_53 v128)
(local $w2_3_54 v128)
(local $w2_3_55 v128)
(local $w2_3_56 v128)
(local $w2_3_57 v128)
(local $w2_3_58 v128)
(local $w2_3_59 v128)
(local $w2_3_60 v128)
(local $w2_3_61 v128)
(local $w2_3_62 v128)
(local $w2_3_63 v128)
(local $x3_0 v128)
(local $x3_1 v128)
(local $x3_2 v128)
(local $x3_3 v128)
(local $x3_4 v128)
(local $x3_5 v128)
(local $x3_6 v128)
(local $x3_7 v128)
(local $x3_8 v128)
(local $x3_9 v128)
(local $x3_10 v128)
(local $x3_11 v128)
(local $x3_12 v128)
(local $x3_13 v128)
(local $x3_14 v128)
(local $x3_15 v128)
(local $x3_16 v128)
(local $x3_17 v128)
(local $x3_18 v128)
(local $x3_19 v128)
(local $x3_20 v128)
(local $x3_21 v128)
(local $x3_22 v128)
(local $x3_23 v128)
(local $x3_24 v128)
(local $x3_25 v128)
(local $x3_26 v128)
(local $x3_27 v128)
(local $x3_28 v128)
(local $x3_29 v128)
(local $x3_30 v128)
(local $x3_31 v128)
(local $x3_32 v128)
(local $x3_33 v128)
(local $x3_34 v128)
(local $x3_35 v128)
(local $x3_36 v128)
(local $x3_37 v128)
(local $x3_38 v128)
(local $x3_39 v128)
(local $x3_40 v128)
(local $x3_41 v128)
(local $x3_42 v128)
(local $x3_43 v128)
(local $x3_44 v128)
(local $x3_45 v128)
(local $x3_46 v128)
(local $x3_47 v128)
(local $x3_48 v128)
(local $x3_49 v128)
(local $x3_50 v128)
(local $x3_51 v128)
(local $x3_52 v128)
(local $x3_53 v128)
(local $x3_54 v128)
(local $x3_55 v128)
(local $x3_56 v128)
(local $x3_57 v128)
(local $x3_58 v128)
(local $x3_59 v128)
(local $x3_60 v128)
(local $x3_61 v128)
(local $x3_62 v128)
(local $x3_63 v128)
(local $w3_0_0 v128)
(local $w3_0_1 v128)
(local $w3_0_2 v128)
(local $w3_0_3 v128)
(local $w3_0_4 v128)
(local $w3_0_5 v128)
(local $w3_0_6 v128)
(local $w3_0_7 v128)
(local $w3_0_8 v128)
(local $w3_0_9 v128)
(local $w3_0_10 v128)
(local $w3_0_11 v128)
(local $w3_0_12 v128)
(local $w3_0_13 v128)
(local $w3_0_14 v128)
(local $w3_0_15 v128)
(local $w3_0_16 v128)
(local $w3_0_17 v128)
(local $w3_0_18 v128)
(local $w3_0_19 v128)
(local $w3_0_20 v128)
(local $w3_0_21 v128)
(local $w3_0_22 v128)
(local $w3_0_23 v128)
(local $w3_0_24 v128)
(local $w3_0_25 v128)
(local $w3_0_26 v128)
(local $w3_0_27 v128)
(local $w3_0_28 v128)
(local $w3_0_29 v128)
(local $w3_0_30 v128)
(local $w3_0_31 v128)
(local $w3_0_32 v128)
(local $w3_0_33 v128)
(local $w3_0_34 v128)
(local $w3_0_35 v128)
(local $w3_0_36 v128)
(local $w3_0_37 v128)
(local $w3_0_38 v128)
(local $w3_0_39 v128)
(local $w3_0_40 v128)
(local $w3_0_41 v128)
(local $w3_0_42 v128)
(local $w3_0_43 v128)
(local $w3_0_44 v128)
(local $w3_0_45 v128)
(local $w3_0_46 v128)
(local $w3_0_47 v128)
(local $w3_0_48 v128)
(local $w3_0_49 v128)
(local $w3_0_50 v128)
(local $w3_0_51 v128)
(local $w3_0_52 v128)
(local $w3_0_53 v128)
(local $w3_0_54 v128)
(local $w3_0_55 v128)
(local $w3_0_56 v128)
(local $w3_0_57 v128)
(local $w3_0_58 v128)
(local $w3_0_59 v128)
(local $w3_0_60 v128)
(local $w3_0_61 v128)
(local $w3_0_62 v128)
(local $w3_0_63 v128)
(local $w3_1_0 v128)
(local $w3_1_1 v128)
(local $w3_1_2 v128)
(local $w3_1_3 v128)
(local $w3_1_4 v128)
(local $w3_1_5 v128)
(local $w3_1_6 v128)
(local $w3_1_7 v128)
(local $w3_1_8 v128)
(local $w3_1_9 v128)
(local $w3_1_10 v128)
(local $w3_1_11 v128)
(local $w3_1_12 v128)
(local $w3_1_13 v128)
(local $w3_1_14 v128)
(local $w3_1_15 v128)
(local $w3_1_16 v128)
(local $w3_1_17 v128)
(local $w3_1_18 v128)
(local $w3_1_19 v128)
(local $w3_1_20 v128)
(local $w3_1_21 v128)
(local $w3_1_22 v128)
(local $w3_1_23 v128)
(local $w3_1_24 v128)
(local $w3_1_25 v128)
(local $w3_1_26 v128)
(local $w3_1_27 v128)
(local $w3_1_28 v128)
(local $w3_1_29 v128)
(local $w3_1_30 v128)
(local $w3_1_31 v128)
(local $w3_1_32 v128)
(local $w3_1_33 v128)
(local $w3_1_34 v128)
(local $w3_1_35 v128)
(local $w3_1_36 v128)
(local $w3_1_37 v128)
(local $w3_1_38 v128)
(local $w3_1_39 v128)
(local $w3_1_40 v128)
(local $w3_1_41 v128)
(local $w3_1_42 v128)
(local $w3_1_43 v128)
(local $w3_1_44 v128)
(local $w3_1_45 v128)
(local $w3_1_46 v128)
(local $w3_1_47 v128)
(local $w3_1_48 v128)
(local $w3_1_49 v128)
(local $w3_1_50 v128)
(local $w3_1_51 v128)
(local $w3_1_52 v128)
(local $w3_1_53 v128)
(local $w3_1_54 v128)
(local $w3_1_55 v128)
(local $w3_1_56 v128)
(local $w3_1_57 v128)
(local $w3_1_58 v128)
(local $w3_1_59 v128)
(local $w3_1_60 v128)
(local $w3_1_61 v128)
(local $w3_1_62 v128)
(local $w3_1_63 v128)
(local $w3_2_0 v128)
(local $w3_2_1 v128)
(local $w3_2_2 v128)
(local $w3_2_3 v128)
(local $w3_2_4 v128)
(local $w3_2_5 v128)
(local $w3_2_6 v128)
(local $w3_2_7 v128)
(local $w3_2_8 v128)
(local $w3_2_9 v128)
(local $w3_2_10 v128)
(local $w3_2_11 v128)
(local $w3_2_12 v128)
(local $w3_2_13 v128)
(local $w3_2_14 v128)
(local $w3_2_15 v128)
(local $w3_2_16 v128)
(local $w3_2_17 v128)
(local $w3_2_18 v128)
(local $w3_2_19 v128)
(local $w3_2_20 v128)
(local $w3_2_21 v128)
(local $w3_2_22 v128)
(local $w3_2_23 v128)
(local $w3_2_24 v128)
(local $w3_2_25 v128)
(local $w3_2_26 v128)
(local $w3_2_27 v128)
(local $w3_2_28 v128)
(local $w3_2_29 v128)
(local $w3_2_30 v128)
(local $w3_2_31 v128)
(local $w3_2_32 v128)
(local $w3_2_33 v128)
(local $w3_2_34 v128)
(local $w3_2_35 v128)
(local $w3_2_36 v128)
(local $w3_2_37 v128)
(local $w3_2_38 v128)
(local $w3_2_39 v128)
(local $w3_2_40 v128)
(local $w3_2_41 v128)
(local $w3_2_42 v128)
(local $w3_2_43 v128)
(local $w3_2_44 v128)
(local $w3_2_45 v128)
(local $w3_2_46 v128)
(local $w3_2_47 v128)
(local $w3_2_48 v128)
(local $w3_2_49 v128)
(local $w3_2_50 v128)
(local $w3_2_51 v128)
(local $w3_2_52 v128)
(local $w3_2_53 v128)
(local $w3_2_54 v128)
(local $w3_2_55 v128)
(local $w3_2_56 v128)
(local $w3_2_57 v128)
(local $w3_2_58 v128)
(local $w3_2_59 v128)
(local $w3_2_60 v128)
(local $w3_2_61 v128)
(local $w3_2_62 v128)
(local $w3_2_63 v128)
(local $w3_3_0 v128)
(local $w3_3_1 v128)
(local $w3_3_2 v128)
(local $w3_3_3 v128)
(local $w3_3_4 v128)
(local $w3_3_5 v128)
(local $w3_3_6 v128)
(local $w3_3_7 v128)
(local $w3_3_8 v128)
(local $w3_3_9 v128)
(local $w3_3_10 v128)
(local $w3_3_11 v128)
(local $w3_3_12 v128)
(local $w3_3_13 v128)
(local $w3_3_14 v128)
(local $w3_3_15 v128)
(local $w3_3_16 v128)
(local $w3_3_17 v128)
(local $w3_3_18 v128)
(local $w3_3_19 v128)
(local $w3_3_20 v128)
(local $w3_3_21 v128)
(local $w3_3_22 v128)
(local $w3_3_23 v128)
(local $w3_3_24 v128)
(local $w3_3_25 v128)
(local $w3_3_26 v128)
(local $w3_3_27 v128)
(local $w3_3_28 v128)
(local $w3_3_29 v128)
(local $w3_3_30 v128)
(local $w3_3_31 v128)
(local $w3_3_32 v128)
(local $w3_3_33 v128)
(local $w3_3_34 v128)
(local $w3_3_35 v128)
(local $w3_3_36 v128)
(local $w3_3_37 v128)
(local $w3_3_38 v128)
(local $w3_3_39 v128)
(local $w3_3_40 v128)
(local $w3_3_41 v128)
(local $w3_3_42 v128)
(local $w3_3_43 v128)
(local $w3_3_44 v128)
(local $w3_3_45 v128)
(local $w3_3_46 v128)
(local $w3_3_47 v128)
(local $w3_3_48 v128)
(local $w3_3_49 v128)
(local $w3_3_50 v128)
(local $w3_3_51 v128)
(local $w3_3_52 v128)
(local $w3_3_53 v128)
(local $w3_3_54 v128)
(local $w3_3_55 v128)
(local $w3_3_56 v128)
(local $w3_3_57 v128)
(local $w3_3_58 v128)
(local $w3_3_59 v128)
(local $w3_3_60 v128)
(local $w3_3_61 v128)
(local $w3_3_62 v128)
(local $w3_3_63 v128)
(local $x4_0 v128)
(local $x4_1 v128)
(local $x4_2 v128)
(local $x4_3 v128)
(local $x4_4 v128)
(local $x4_5 v128)
(local $x4_6 v128)
(local $x4_7 v128)
(local $x4_8 v128)
(local $x4_9 v128)
(local $x4_10 v128)
(local $x4_11 v128)
(local $x4_12 v128)
(local $x4_13 v128)
(local $x4_14 v128)
(local $x4_15 v128)
(local $x4_16 v128)
(local $x4_17 v128)
(local $x4_18 v128)
(local $x4_19 v128)
(local $x4_20 v128)
(local $x4_21 v128)
(local $x4_22 v128)
(local $x4_23 v128)
(local $x4_24 v128)
(local $x4_25 v128)
(local $x4_26 v128)
(local $x4_27 v128)
(local $x4_28 v128)
(local $x4_29 v128)
(local $x4_30 v128)
(local $x4_31 v128)
(local $x4_32 v128)
(local $x4_33 v128)
(local $x4_34 v128)
(local $x4_35 v128)
(local $x4_36 v128)
(local $x4_37 v128)
(local $x4_38 v128)
(local $x4_39 v128)
(local $x4_40 v128)
(local $x4_41 v128)
(local $x4_42 v128)
(local $x4_43 v128)
(local $x4_44 v128)
(local $x4_45 v128)
(local $x4_46 v128)
(local $x4_47 v128)
(local $x4_48 v128)
(local $x4_49 v128)
(local $x4_50 v128)
(local $x4_51 v128)
(local $x4_52 v128)
(local $x4_53 v128)
(local $x4_54 v128)
(local $x4_55 v128)
(local $x4_56 v128)
(local $x4_57 v128)
(local $x4_58 v128)
(local $x4_59 v128)
(local $x4_60 v128)
(local $x4_61 v128)
(local $x4_62 v128)
(local $x4_63 v128)
(local $w4_0_0 v128)
(local $w4_0_1 v128)
(local $w4_0_2 v128)
(local $w4_0_3 v128)
(local $w4_0_4 v128)
(local $w4_0_5 v128)
(local $w4_0_6 v128)
(local $w4_0_7 v128)
(local $w4_0_8 v128)
(local $w4_0_9 v128)
(local $w4_0_10 v128)
(local $w4_0_11 v128)
(local $w4_0_12 v128)
(local $w4_0_13 v128)
(local $w4_0_14 v128)
(local $w4_0_15 v128)
(local $w4_0_16 v128)
(local $w4_0_17 v128)
(local $w4_0_18 v128)
(local $w4_0_19 v128)
(local $w4_0_20 v128)
(local $w4_0_21 v128)
(local $w4_0_22 v128)
(local $w4_0_23 v128)
(local $w4_0_24 v128)
(local $w4_0_25 v128)
(local $w4_0_26 v128)
(local $w4_0_27 v128)
(local $w4_0_28 v128)
(local $w4_0_29 v128)
(local $w4_0_30 v128)
(local $w4_0_31 v128)
(local $w4_0_32 v128)
(local $w4_0_33 v128)
(local $w4_0_34 v128)
(local $w4_0_35 v128)
(local $w4_0_36 v128)
(local $w4_0_37 v128)
(local $w4_0_38 v128)
(local $w4_0_39 v128)
(local $w4_0_40 v128)
(local $w4_0_41 v128)
(local $w4_0_42 v128)
(local $w4_0_43 v128)
(local $w4_0_44 v128)
(local $w4_0_45 v128)
(local $w4_0_46 v128)
(local $w4_0_47 v128)
(local $w4_0_48 v128)
(local $w4_0_49 v128)
(local $w4_0_50 v128)
(local $w4_0_51 v128)
(local $w4_0_52 v128)
(local $w4_0_53 v128)
(local $w4_0_54 v128)
(local $w4_0_55 v128)
(local $w4_0_56 v128)
(local $w4_0_57 v128)
(local $w4_0_58 v128)
(local $w4_0_59 v128)
(local $w4_0_60 v128)
(local $w4_0_61 v128)
(local $w4_0_62 v128)
(local $w4_0_63 v128)
(local $w4_1_0 v128)
(local $w4_1_1 v128)
(local $w4_1_2 v128)
(local $w4_1_3 v128)
(local $w4_1_4 v128)
(local $w4_1_5 v128)
(local $w4_1_6 v128)
(local $w4_1_7 v128)
(local $w4_1_8 v128)
(local $w4_1_9 v128)
(local $w4_1_10 v128)
(local $w4_1_11 v128)
(local $w4_1_12 v128)
(local $w4_1_13 v128)
(local $w4_1_14 v128)
(local $w4_1_15 v128)
(local $w4_1_16 v128)
(local $w4_1_17 v128)
(local $w4_1_18 v128)
(local $w4_1_19 v128)
(local $w4_1_20 v128)
(local $w4_1_21 v128)
(local $w4_1_22 v128)
(local $w4_1_23 v128)
(local $w4_1_24 v128)
(local $w4_1_25 v128)
(local $w4_1_26 v128)
(local $w4_1_27 v128)
(local $w4_1_28 v128)
(local $w4_1_29 v128)
(local $w4_1_30 v128)
(local $w4_1_31 v128)
(local $w4_1_32 v128)
(local $w4_1_33 v128)
(local $w4_1_34 v128)
(local $w4_1_35 v128)
(local $w4_1_36 v128)
(local $w4_1_37 v128)
(local $w4_1_38 v128)
(local $w4_1_39 v128)
(local $w4_1_40 v128)
(local $w4_1_41 v128)
(local $w4_1_42 v128)
(local $w4_1_43 v128)
(local $w4_1_44 v128)
(local $w4_1_45 v128)
(local $w4_1_46 v128)
(local $w4_1_47 v128)
(local $w4_1_48 v128)
(local $w4_1_49 v128)
(local $w4_1_50 v128)
(local $w4_1_51 v128)
(local $w4_1_52 v128)
(local $w4_1_53 v128)
(local $w4_1_54 v128)
(local $w4_1_55 v128)
(local $w4_1_56 v128)
(local $w4_1_57 v128)
(local $w4_1_58 v128)
(local $w4_1_59 v128)
(local $w4_1_60 v128)
(local $w4_1_61 v128)
(local $w4_1_62 v128)
(local $w4_1_63 v128)
(local $w4_2_0 v128)
(local $w4_2_1 v128)
(local $w4_2_2 v128)
(local $w4_2_3 v128)
(local $w4_2_4 v128)
(local $w4_2_5 v128)
(local $w4_2_6 v128)
(local $w4_2_7 v128)
(local $w4_2_8 v128)
(local $w4_2_9 v128)
(local $w4_2_10 v128)
(local $w4_2_11 v128)
(local $w4_2_12 v128)
(local $w4_2_13 v128)
(local $w4_2_14 v128)
(local $w4_2_15 v128)
(local $w4_2_16 v128)
(local $w4_2_17 v128)
(local $w4_2_18 v128)
(local $w4_2_19 v128)
(local $w4_2_20 v128)
(local $w4_2_21 v128)
(local $w4_2_22 v128)
(local $w4_2_23 v128)
(local $w4_2_24 v128)
(local $w4_2_25 v128)
(local $w4_2_26 v128)
(local $w4_2_27 v128)
(local $w4_2_28 v128)
(local $w4_2_29 v128)
(local $w4_2_30 v128)
(local $w4_2_31 v128)
(local $w4_2_32 v128)
(local $w4_2_33 v128)
(local $w4_2_34 v128)
(local $w4_2_35 v128)
(local $w4_2_36 v128)
(local $w4_2_37 v128)
(local $w4_2_38 v128)
(local $w4_2_39 v128)
(local $w4_2_40 v128)
(local $w4_2_41 v128)
(local $w4_2_42 v128)
(local $w4_2_43 v128)
(local $w4_2_44 v128)
(local $w4_2_45 v128)
(local $w4_2_46 v128)
(local $w4_2_47 v128)
(local $w4_2_48 v128)
(local $w4_2_49 v128)
(local $w4_2_50 v128)
(local $w4_2_51 v128)
(local $w4_2_52 v128)
(local $w4_2_53 v128)
(local $w4_2_54 v128)
(local $w4_2_55 v128)
(local $w4_2_56 v128)
(local $w4_2_57 v128)
(local $w4_2_58 v128)
(local $w4_2_59 v128)
(local $w4_2_60 v128)
(local $w4_2_61 v128)
(local $w4_2_62 v128)
(local $w4_2_63 v128)
(local $w4_3_0 v128)
(local $w4_3_1 v128)
(local $w4_3_2 v128)
(local $w4_3_3 v128)
(local $w4_3_4 v128)
(local $w4_3_5 v128)
(local $w4_3_6 v128)
(local $w4_3_7 v128)
(local $w4_3_8 v128)
(local $w4_3_9 v128)
(local $w4_3_10 v128)
(local $w4_3_11 v128)
(local $w4_3_12 v128)
(local $w4_3_13 v128)
(local $w4_3_14 v128)
(local $w4_3_15 v128)
(local $w4_3_16 v128)
(local $w4_3_17 v128)
(local $w4_3_18 v128)
(local $w4_3_19 v128)
(local $w4_3_20 v128)
(local $w4_3_21 v128)
(local $w4_3_22 v128)
(local $w4_3_23 v128)
(local $w4_3_24 v128)
(local $w4_3_25 v128)
(local $w4_3_26 v128)
(local $w4_3_27 v128)
(local $w4_3_28 v128)
(local $w4_3_29 v128)
(local $w4_3_30 v128)
(local $w4_3_31 v128)
(local $w4_3_32 v128)
(local $w4_3_33 v128)
(local $w4_3_34 v128)
(local $w4_3_35 v128)
(local $w4_3_36 v128)
(local $w4_3_37 v128)
(local $w4_3_38 v128)
(local $w4_3_39 v128)
(local $w4_3_40 v128)
(local $w4_3_41 v128)
(local $w4_3_42 v128)
(local $w4_3_43 v128)
(local $w4_3_44 v128)
(local $w4_3_45 v128)
(local $w4_3_46 v128)
(local $w4_3_47 v128)
(local $w4_3_48 v128)
(local $w4_3_49 v128)
(local $w4_3_50 v128)
(local $w4_3_51 v128)
(local $w4_3_52 v128)
(local $w4_3_53 v128)
(local $w4_3_54 v128)
(local $w4_3_55 v128)
(local $w4_3_56 v128)
(local $w4_3_57 v128)
(local $w4_3_58 v128)
(local $w4_3_59 v128)
(local $w4_3_60 v128)
(local $w4_3_61 v128)
(local $w4_3_62 v128)
(local $w4_3_63 v128)
(local $x5_0 v128)
(local $x5_1 v128)
(local $x5_2 v128)
(local $x5_3 v128)
(local $x5_4 v128)
(local $x5_5 v128)
(local $x5_6 v128)
(local $x5_7 v128)
(local $x5_8 v128)
(local $x5_9 v128)
(local $x5_10 v128)
(local $x5_11 v128)
(local $x5_12 v128)
(local $x5_13 v128)
(local $x5_14 v128)
(local $x5_15 v128)
(local $x5_16 v128)
(local $x5_17 v128)
(local $x5_18 v128)
(local $x5_19 v128)
(local $x5_20 v128)
(local $x5_21 v128)
(local $x5_22 v128)
(local $x5_23 v128)
(local $x5_24 v128)
(local $x5_25 v128)
(local $x5_26 v128)
(local $x5_27 v128)
(local $x5_28 v128)
(local $x5_29 v128)
(local $x5_30 v128)
(local $x5_31 v128)
(local $x5_32 v128)
(local $x5_33 v128)
(local $x5_34 v128)
(local $x5_35 v128)
(local $x5_36 v128)
(local $x5_37 v128)
(local $x5_38 v128)
(local $x5_39 v128)
(local $x5_40 v128)
(local $x5_41 v128)
(local $x5_42 v128)
(local $x5_43 v128)
(local $x5_44 v128)
(local $x5_45 v128)
(local $x5_46 v128)
(local $x5_47 v128)
(local $x5_48 v128)
(local $x5_49 v128)
(local $x5_50 v128)
(local $x5_51 v128)
(local $x5_52 v128)
(local $x5_53 v128)
(local $x5_54 v128)
(local $x5_55 v128)
(local $x5_56 v128)
(local $x5_57 v128)
(local $x5_58 v128)
(local $x5_59 v128)
(local $x5_60 v128)
(local $x5_61 v128)
(local $x5_62 v128)
(local $x5_63 v128)
(local $w5_0_0 v128)
(local $w5_0_1 v128)
(local $w5_0_2 v128)
(local $w5_0_3 v128)
(local $w5_0_4 v128)
(local $w5_0_5 v128)
(local $w5_0_6 v128)
(local $w5_0_7 v128)
(local $w5_0_8 v128)
(local $w5_0_9 v128)
(local $w5_0_10 v128)
(local $w5_0_11 v128)
(local $w5_0_12 v128)
(local $w5_0_13 v128)
(local $w5_0_14 v128)
(local $w5_0_15 v128)
(local $w5_0_16 v128)
(local $w5_0_17 v128)
(local $w5_0_18 v128)
(local $w5_0_19 v128)
(local $w5_0_20 v128)
(local $w5_0_21 v128)
(local $w5_0_22 v128)
(local $w5_0_23 v128)
(local $w5_0_24 v128)
(local $w5_0_25 v128)
(local $w5_0_26 v128)
(local $w5_0_27 v128)
(local $w5_0_28 v128)
(local $w5_0_29 v128)
(local $w5_0_30 v128)
(local $w5_0_31 v128)
(local $w5_0_32 v128)
(local $w5_0_33 v128)
(local $w5_0_34 v128)
(local $w5_0_35 v128)
(local $w5_0_36 v128)
(local $w5_0_37 v128)
(local $w5_0_38 v128)
(local $w5_0_39 v128)
(local $w5_0_40 v128)
(local $w5_0_41 v128)
(local $w5_0_42 v128)
(local $w5_0_43 v128)
(local $w5_0_44 v128)
(local $w5_0_45 v128)
(local $w5_0_46 v128)
(local $w5_0_47 v128)
(local $w5_0_48 v128)
(local $w5_0_49 v128)
(local $w5_0_50 v128)
(local $w5_0_51 v128)
(local $w5_0_52 v128)
(local $w5_0_53 v128)
(local $w5_0_54 v128)
(local $w5_0_55 v128)
(local $w5_0_56 v128)
(local $w5_0_57 v128)
(local $w5_0_58 v128)
(local $w5_0_59 v128)
(local $w5_0_60 v128)
(local $w5_0_61 v128)
(local $w5_0_62 v128)
(local $w5_0_63 v128)
(local $w5_1_0 v128)
(local $w5_1_1 v128)
(local $w5_1_2 v128)
(local $w5_1_3 v128)
(local $w5_1_4 v128)
(local $w5_1_5 v128)
(local $w5_1_6 v128)
(local $w5_1_7 v128)
(local $w5_1_8 v128)
(local $w5_1_9 v128)
(local $w5_1_10 v128)
(local $w5_1_11 v128)
(local $w5_1_12 v128)
(local $w5_1_13 v128)
(local $w5_1_14 v128)
(local $w5_1_15 v128)
(local $w5_1_16 v128)
(local $w5_1_17 v128)
(local $w5_1_18 v128)
(local $w5_1_19 v128)
(local $w5_1_20 v128)
(local $w5_1_21 v128)
(local $w5_1_22 v128)
(local $w5_1_23 v128)
(local $w5_1_24 v128)
(local $w5_1_25 v128)
(local $w5_1_26 v128)
(local $w5_1_27 v128)
(local $w5_1_28 v128)
(local $w5_1_29 v128)
(local $w5_1_30 v128)
(local $w5_1_31 v128)
(local $w5_1_32 v128)
(local $w5_1_33 v128)
(local $w5_1_34 v128)
(local $w5_1_35 v128)
(local $w5_1_36 v128)
(local $w5_1_37 v128)
(local $w5_1_38 v128)
(local $w5_1_39 v128)
(local $w5_1_40 v128)
(local $w5_1_41 v128)
(local $w5_1_42 v128)
(local $w5_1_43 v128)
(local $w5_1_44 v128)
(local $w5_1_45 v128)
(local $w5_1_46 v128)
(local $w5_1_47 v128)
(local $w5_1_48 v128)
(local $w5_1_49 v128)
(local $w5_1_50 v128)
(local $w5_1_51 v128)
(local $w5_1_52 v128)
(local $w5_1_53 v128)
(local $w5_1_54 v128)
(local $w5_1_55 v128)
(local $w5_1_56 v128)
(local $w5_1_57 v128)
(local $w5_1_58 v128)
(local $w5_1_59 v128)
(local $w5_1_60 v128)
(local $w5_1_61 v128)
(local $w5_1_62 v128)
(local $w5_1_63 v128)
(local $w5_2_0 v128)
(local $w5_2_1 v128)
(local $w5_2_2 v128)
(local $w5_2_3 v128)
(local $w5_2_4 v128)
(local $w5_2_5 v128)
(local $w5_2_6 v128)
(local $w5_2_7 v128)
(local $w5_2_8 v128)
(local $w5_2_9 v128)
(local $w5_2_10 v128)
(local $w5_2_11 v128)
(local $w5_2_12 v128)
(local $w5_2_13 v128)
(local $w5_2_14 v128)
(local $w5_2_15 v128)
(local $w5_2_16 v128)
(local $w5_2_17 v128)
(local $w5_2_18 v128)
(local $w5_2_19 v128)
(local $w5_2_20 v128)
(local $w5_2_21 v128)
(local $w5_2_22 v128)
(local $w5_2_23 v128)
(local $w5_2_24 v128)
(local $w5_2_25 v128)
(local $w5_2_26 v128)
(local $w5_2_27 v128)
(local $w5_2_28 v128)
(local $w5_2_29 v128)
(local $w5_2_30 v128)
(local $w5_2_31 v128)
(local $w5_2_32 v128)
(local $w5_2_33 v128)
(local $w5_2_34 v128)
(local $w5_2_35 v128)
(local $w5_2_36 v128)
(local $w5_2_37 v128)
(local $w5_2_38 v128)
(local $w5_2_39 v128)
(local $w5_2_40 v128)
(local $w5_2_41 v128)
(local $w5_2_42 v128)
(local $w5_2_43 v128)
(local $w5_2_44 v128)
(local $w5_2_45 v128)
(local $w5_2_46 v128)
(local $w5_2_47 v128)
(local $w5_2_48 v128)
(local $w5_2_49 v128)
(local $w5_2_50 v128)
(local $w5_2_51 v128)
(local $w5_2_52 v128)
(local $w5_2_53 v128)
(local $w5_2_54 v128)
(local $w5_2_55 v128)
(local $w5_2_56 v128)
(local $w5_2_57 v128)
(local $w5_2_58 v128)
(local $w5_2_59 v128)
(local $w5_2_60 v128)
(local $w5_2_61 v128)
(local $w5_2_62 v128)
(local $w5_2_63 v128)
(local $w5_3_0 v128)
(local $w5_3_1 v128)
(local $w5_3_2 v128)
(local $w5_3_3 v128)
(local $w5_3_4 v128)
(local $w5_3_5 v128)
(local $w5_3_6 v128)
(local $w5_3_7 v128)
(local $w5_3_8 v128)
(local $w5_3_9 v128)
(local $w5_3_10 v128)
(local $w5_3_11 v128)
(local $w5_3_12 v128)
(local $w5_3_13 v128)
(local $w5_3_14 v128)
(local $w5_3_15 v128)
(local $w5_3_16 v128)
(local $w5_3_17 v128)
(local $w5_3_18 v128)
(local $w5_3_19 v128)
(local $w5_3_20 v128)
(local $w5_3_21 v128)
(local $w5_3_22 v128)
(local $w5_3_23 v128)
(local $w5_3_24 v128)
(local $w5_3_25 v128)
(local $w5_3_26 v128)
(local $w5_3_27 v128)
(local $w5_3_28 v128)
(local $w5_3_29 v128)
(local $w5_3_30 v128)
(local $w5_3_31 v128)
(local $w5_3_32 v128)
(local $w5_3_33 v128)
(local $w5_3_34 v128)
(local $w5_3_35 v128)
(local $w5_3_36 v128)
(local $w5_3_37 v128)
(local $w5_3_38 v128)
(local $w5_3_39 v128)
(local $w5_3_40 v128)
(local $w5_3_41 v128)
(local $w5_3_42 v128)
(local $w5_3_43 v128)
(local $w5_3_44 v128)
(local $w5_3_45 v128)
(local $w5_3_46 v128)
(local $w5_3_47 v128)
(local $w5_3_48 v128)
(local $w5_3_49 v128)
(local $w5_3_50 v128)
(local $w5_3_51 v128)
(local $w5_3_52 v128)
(local $w5_3_53 v128)
(local $w5_3_54 v128)
(local $w5_3_55 v128)
(local $w5_3_56 v128)
(local $w5_3_57 v128)
(local $w5_3_58 v128)
(local $w5_3_59 v128)
(local $w5_3_60 v128)
(local $w5_3_61 v128)
(local $w5_3_62 v128)
(local $w5_3_63 v128)
(local $x6_0 v128)
(local $x6_1 v128)
(local $x6_2 v128)
(local $x6_3 v128)
(local $x6_4 v128)
(local $x6_5 v128)
(local $x6_6 v128)
(local $x6_7 v128)
(local $x6_8 v128)
(local $x6_9 v128)
(local $x6_10 v128)
(local $x6_11 v128)
(local $x6_12 v128)
(local $x6_13 v128)
(local $x6_14 v128)
(local $x6_15 v128)
(local $x6_16 v128)
(local $x6_17 v128)
(local $x6_18 v128)
(local $x6_19 v128)
(local $x6_20 v128)
(local $x6_21 v128)
(local $x6_22 v128)
(local $x6_23 v128)
(local $x6_24 v128)
(local $x6_25 v128)
(local $x6_26 v128)
(local $x6_27 v128)
(local $x6_28 v128)
(local $x6_29 v128)
(local $x6_30 v128)
(local $x6_31 v128)
(local $x6_32 v128)
(local $x6_33 v128)
(local $x6_34 v128)
(local $x6_35 v128)
(local $x6_36 v128)
(local $x6_37 v128)
(local $x6_38 v128)
(local $x6_39 v128)
(local $x6_40 v128)
(local $x6_41 v128)
(local $x6_42 v128)
(local $x6_43 v128)
(local $x6_44 v128)
(local $x6_45 v128)
(local $x6_46 v128)
(local $x6_47 v128)
(local $x6_48 v128)
(local $x6_49 v128)
(local $x6_50 v128)
(local $x6_51 v128)
(local $x6_52 v128)
(local $x6_53 v128)
(local $x6_54 v128)
(local $x6_55 v128)
(local $x6_56 v128)
(local $x6_57 v128)
(local $x6_58 v128)
(local $x6_59 v128)
(local $x6_60 v128)
(local $x6_61 v128)
(local $x6_62 v128)
(local $x6_63 v128)
(local $w6_0_0 v128)
(local $w6_0_1 v128)
(local $w6_0_2 v128)
(local $w6_0_3 v128)
(local $w6_0_4 v128)
(local $w6_0_5 v128)
(local $w6_0_6 v128)
(local $w6_0_7 v128)
(local $w6_0_8 v128)
(local $w6_0_9 v128)
(local $w6_0_10 v128)
(local $w6_0_11 v128)
(local $w6_0_12 v128)
(local $w6_0_13 v128)
(local $w6_0_14 v128)
(local $w6_0_15 v128)
(local $w6_0_16 v128)
(local $w6_0_17 v128)
(local $w6_0_18 v128)
(local $w6_0_19 v128)
(local $w6_0_20 v128)
(local $w6_0_21 v128)
(local $w6_0_22 v128)
(local $w6_0_23 v128)
(local $w6_0_24 v128)
(local $w6_0_25 v128)
(local $w6_0_26 v128)
(local $w6_0_27 v128)
(local $w6_0_28 v128)
(local $w6_0_29 v128)
(local $w6_0_30 v128)
(local $w6_0_31 v128)
(local $w6_0_32 v128)
(local $w6_0_33 v128)
(local $w6_0_34 v128)
(local $w6_0_35 v128)
(local $w6_0_36 v128)
(local $w6_0_37 v128)
(local $w6_0_38 v128)
(local $w6_0_39 v128)
(local $w6_0_40 v128)
(local $w6_0_41 v128)
(local $w6_0_42 v128)
(local $w6_0_43 v128)
(local $w6_0_44 v128)
(local $w6_0_45 v128)
(local $w6_0_46 v128)
(local $w6_0_47 v128)
(local $w6_0_48 v128)
(local $w6_0_49 v128)
(local $w6_0_50 v128)
(local $w6_0_51 v128)
(local $w6_0_52 v128)
(local $w6_0_53 v128)
(local $w6_0_54 v128)
(local $w6_0_55 v128)
(local $w6_0_56 v128)
(local $w6_0_57 v128)
(local $w6_0_58 v128)
(local $w6_0_59 v128)
(local $w6_0_60 v128)
(local $w6_0_61 v128)
(local $w6_0_62 v128)
(local $w6_0_63 v128)
(local $w6_1_0 v128)
(local $w6_1_1 v128)
(local $w6_1_2 v128)
(local $w6_1_3 v128)
(local $w6_1_4 v128)
(local $w6_1_5 v128)
(local $w6_1_6 v128)
(local $w6_1_7 v128)
(local $w6_1_8 v128)
(local $w6_1_9 v128)
(local $w6_1_10 v128)
(local $w6_1_11 v128)
(local $w6_1_12 v128)
(local $w6_1_13 v128)
(local $w6_1_14 v128)
(local $w6_1_15 v128)
(local $w6_1_16 v128)
(local $w6_1_17 v128)
(local $w6_1_18 v128)
(local $w6_1_19 v128)
(local $w6_1_20 v128)
(local $w6_1_21 v128)
(local $w6_1_22 v128)
(local $w6_1_23 v128)
(local $w6_1_24 v128)
(local $w6_1_25 v128)
(local $w6_1_26 v128)
(local $w6_1_27 v128)
(local $w6_1_28 v128)
(local $w6_1_29 v128)
(local $w6_1_30 v128)
(local $w6_1_31 v128)
(local $w6_1_32 v128)
(local $w6_1_33 v128)
(local $w6_1_34 v128)
(local $w6_1_35 v128)
(local $w6_1_36 v128)
(local $w6_1_37 v128)
(local $w6_1_38 v128)
(local $w6_1_39 v128)
(local $w6_1_40 v128)
(local $w6_1_41 v128)
(local $w6_1_42 v128)
(local $w6_1_43 v128)
(local $w6_1_44 v128)
(local $w6_1_45 v128)
(local $w6_1_46 v128)
(local $w6_1_47 v128)
(local $w6_1_48 v128)
(local $w6_1_49 v128)
(local $w6_1_50 v128)
(local $w6_1_51 v128)
(local $w6_1_52 v128)
(local $w6_1_53 v128)
(local $w6_1_54 v128)
(local $w6_1_55 v128)
(local $w6_1_56 v128)
(local $w6_1_57 v128)
(local $w6_1_58 v128)
(local $w6_1_59 v128)
(local $w6_1_60 v128)
(local $w6_1_61 v128)
(local $w6_1_62 v128)
(local $w6_1_63 v128)
(local $w6_2_0 v128)
(local $w6_2_1 v128)
(local $w6_2_2 v128)
(local $w6_2_3 v128)
(local $w6_2_4 v128)
(local $w6_2_5 v128)
(local $w6_2_6 v128)
(local $w6_2_7 v128)
(local $w6_2_8 v128)
(local $w6_2_9 v128)
(local $w6_2_10 v128)
(local $w6_2_11 v128)
(local $w6_2_12 v128)
(local $w6_2_13 v128)
(local $w6_2_14 v128)
(local $w6_2_15 v128)
(local $w6_2_16 v128)
(local $w6_2_17 v128)
(local $w6_2_18 v128)
(local $w6_2_19 v128)
(local $w6_2_20 v128)
(local $w6_2_21 v128)
(local $w6_2_22 v128)
(local $w6_2_23 v128)
(local $w6_2_24 v128)
(local $w6_2_25 v128)
(local $w6_2_26 v128)
(local $w6_2_27 v128)
(local $w6_2_28 v128)
(local $w6_2_29 v128)
(local $w6_2_30 v128)
(local $w6_2_31 v128)
(local $w6_2_32 v128)
(local $w6_2_33 v128)
(local $w6_2_34 v128)
(local $w6_2_35 v128)
(local $w6_2_36 v128)
(local $w6_2_37 v128)
(local $w6_2_38 v128)
(local $w6_2_39 v128)
(local $w6_2_40 v128)
(local $w6_2_41 v128)
(local $w6_2_42 v128)
(local $w6_2_43 v128)
(local $w6_2_44 v128)
(local $w6_2_45 v128)
(local $w6_2_46 v128)
(local $w6_2_47 v128)
(local $w6_2_48 v128)
(local $w6_2_49 v128)
(local $w6_2_50 v128)
(local $w6_2_51 v128)
(local $w6_2_52 v128)
(local $w6_2_53 v128)
(local $w6_2_54 v128)
(local $w6_2_55 v128)
(local $w6_2_56 v128)
(local $w6_2_57 v128)
(local $w6_2_58 v128)
(local $w6_2_59 v128)
(local $w6_2_60 v128)
(local $w6_2_61 v128)
(local $w6_2_62 v128)
(local $w6_2_63 v128)
(local $w6_3_0 v128)
(local $w6_3_1 v128)
(local $w6_3_2 v128)
(local $w6_3_3 v128)
(local $w6_3_4 v128)
(local $w6_3_5 v128)
(local $w6_3_6 v128)
(local $w6_3_7 v128)
(local $w6_3_8 v128)
(local $w6_3_9 v128)
(local $w6_3_10 v128)
(local $w6_3_11 v128)
(local $w6_3_12 v128)
(local $w6_3_13 v128)
(local $w6_3_14 v128)
(local $w6_3_15 v128)
(local $w6_3_16 v128)
(local $w6_3_17 v128)
(local $w6_3_18 v128)
(local $w6_3_19 v128)
(local $w6_3_20 v128)
(local $w6_3_21 v128)
(local $w6_3_22 v128)
(local $w6_3_23 v128)
(local $w6_3_24 v128)
(local $w6_3_25 v128)
(local $w6_3_26 v128)
(local $w6_3_27 v128)
(local $w6_3_28 v128)
(local $w6_3_29 v128)
(local $w6_3_30 v128)
(local $w6_3_31 v128)
(local $w6_3_32 v128)
(local $w6_3_33 v128)
(local $w6_3_34 v128)
(local $w6_3_35 v128)
(local $w6_3_36 v128)
(local $w6_3_37 v128)
(local $w6_3_38 v128)
(local $w6_3_39 v128)
(local $w6_3_40 v128)
(local $w6_3_41 v128)
(local $w6_3_42 v128)
(local $w6_3_43 v128)
(local $w6_3_44 v128)
(local $w6_3_45 v128)
(local $w6_3_46 v128)
(local $w6_3_47 v128)
(local $w6_3_48 v128)
(local $w6_3_49 v128)
(local $w6_3_50 v128)
(local $w6_3_51 v128)
(local $w6_3_52 v128)
(local $w6_3_53 v128)
(local $w6_3_54 v128)
(local $w6_3_55 v128)
(local $w6_3_56 v128)
(local $w6_3_57 v128)
(local $w6_3_58 v128)
(local $w6_3_59 v128)
(local $w6_3_60 v128)
(local $w6_3_61 v128)
(local $w6_3_62 v128)
(local $w6_3_63 v128)
(local $sw0 v128)
(local $sw1 v128)
(local $sw2 v128)
(local $sw3 v128)
(local $sw4 v128)
(local $sw5 v128)
(local $sw6 v128)
(local $sw7 v128)
(local.set $input_stride(i32.shr_u(local.get $cols)(i32.const 8)))
(local.set $output_bytes(i32.shl(local.get $stride)(i32.const 2)))
(local.set $sw0(v128.load offset=0(local.get $sw)))
(local.set $sw1(v128.load offset=16(local.get $sw)))
(local.set $sw2(v128.load offset=32(local.get $sw)))
(local.set $sw3(v128.load offset=48(local.get $sw)))
(local.set $sw4(v128.load offset=64(local.get $sw)))
(local.set $sw5(v128.load offset=80(local.get $sw)))
(local.set $sw6(v128.load offset=96(local.get $sw)))
(local.set $sw7(v128.load offset=112(local.get $sw)))
(local.set $wp0(i32.add(i32.load offset=0(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp1(i32.add(i32.load offset=4(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp2(i32.add(i32.load offset=8(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(local.set $wp3(i32.add(i32.load offset=12(local.get $w))(i32.shl(local.get $start)(i32.const 1))))
(block $done
(br_if $done(i32.eqz(local.get $n)))
(local.set $qo(i32.add(i32.mul(i32.shr_u(local.get $t)(i32.const 1))(local.get $cols))(local.get $start)))
(local.set $keep(i32.lt_u(i32.add(local.get $t)(i32.const 1))(local.get $n)))
(local.set $yp(i32.add(local.get $sums)(i32.mul(local.get $t)(local.get $output_bytes))))
(local.set $yp1(i32.add(local.get $yp)(local.get $output_bytes)))
(local.set $sx0(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(local.get $t)(local.get $input_stride))(i32.const 2)))))
(if(local.get $keep)(then(local.set $sx1(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 1))(local.get $input_stride))(i32.const 2)))))))
(local.set $bp0(i32.add(local.get $wp0)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp1(i32.add(local.get $wp1)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp2(i32.add(local.get $wp2)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $bp3(i32.add(local.get $wp3)(i32.mul(local.get $cols)(i32.const 0))))
(local.set $qp(i32.add(i32.load offset=0(local.get $q))(local.get $qo)))
(local.tee $x0_0(v128.load32_splat offset=0(local.get $qp)))
(v128.load8x8_s offset=0(local.get $bp0))
local.tee $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x0_1(v128.load32_splat offset=4(local.get $qp)))
(v128.load8x8_s offset=8(local.get $bp0))
local.tee $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_2(v128.load32_splat offset=8(local.get $qp)))
(v128.load8x8_s offset=16(local.get $bp0))
local.tee $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_3(v128.load32_splat offset=12(local.get $qp)))
(v128.load8x8_s offset=24(local.get $bp0))
local.tee $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_4(v128.load32_splat offset=16(local.get $qp)))
(v128.load8x8_s offset=32(local.get $bp0))
local.tee $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_5(v128.load32_splat offset=20(local.get $qp)))
(v128.load8x8_s offset=40(local.get $bp0))
local.tee $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_6(v128.load32_splat offset=24(local.get $qp)))
(v128.load8x8_s offset=48(local.get $bp0))
local.tee $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_7(v128.load32_splat offset=28(local.get $qp)))
(v128.load8x8_s offset=56(local.get $bp0))
local.tee $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_8(v128.load32_splat offset=32(local.get $qp)))
(v128.load8x8_s offset=64(local.get $bp0))
local.tee $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_9(v128.load32_splat offset=36(local.get $qp)))
(v128.load8x8_s offset=72(local.get $bp0))
local.tee $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_10(v128.load32_splat offset=40(local.get $qp)))
(v128.load8x8_s offset=80(local.get $bp0))
local.tee $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_11(v128.load32_splat offset=44(local.get $qp)))
(v128.load8x8_s offset=88(local.get $bp0))
local.tee $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_12(v128.load32_splat offset=48(local.get $qp)))
(v128.load8x8_s offset=96(local.get $bp0))
local.tee $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_13(v128.load32_splat offset=52(local.get $qp)))
(v128.load8x8_s offset=104(local.get $bp0))
local.tee $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_14(v128.load32_splat offset=56(local.get $qp)))
(v128.load8x8_s offset=112(local.get $bp0))
local.tee $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_15(v128.load32_splat offset=60(local.get $qp)))
(v128.load8x8_s offset=120(local.get $bp0))
local.tee $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_16(v128.load32_splat offset=64(local.get $qp)))
(v128.load8x8_s offset=128(local.get $bp0))
local.tee $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_17(v128.load32_splat offset=68(local.get $qp)))
(v128.load8x8_s offset=136(local.get $bp0))
local.tee $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_18(v128.load32_splat offset=72(local.get $qp)))
(v128.load8x8_s offset=144(local.get $bp0))
local.tee $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_19(v128.load32_splat offset=76(local.get $qp)))
(v128.load8x8_s offset=152(local.get $bp0))
local.tee $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_20(v128.load32_splat offset=80(local.get $qp)))
(v128.load8x8_s offset=160(local.get $bp0))
local.tee $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_21(v128.load32_splat offset=84(local.get $qp)))
(v128.load8x8_s offset=168(local.get $bp0))
local.tee $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_22(v128.load32_splat offset=88(local.get $qp)))
(v128.load8x8_s offset=176(local.get $bp0))
local.tee $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_23(v128.load32_splat offset=92(local.get $qp)))
(v128.load8x8_s offset=184(local.get $bp0))
local.tee $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_24(v128.load32_splat offset=96(local.get $qp)))
(v128.load8x8_s offset=192(local.get $bp0))
local.tee $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_25(v128.load32_splat offset=100(local.get $qp)))
(v128.load8x8_s offset=200(local.get $bp0))
local.tee $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_26(v128.load32_splat offset=104(local.get $qp)))
(v128.load8x8_s offset=208(local.get $bp0))
local.tee $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_27(v128.load32_splat offset=108(local.get $qp)))
(v128.load8x8_s offset=216(local.get $bp0))
local.tee $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_28(v128.load32_splat offset=112(local.get $qp)))
(v128.load8x8_s offset=224(local.get $bp0))
local.tee $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_29(v128.load32_splat offset=116(local.get $qp)))
(v128.load8x8_s offset=232(local.get $bp0))
local.tee $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_30(v128.load32_splat offset=120(local.get $qp)))
(v128.load8x8_s offset=240(local.get $bp0))
local.tee $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_31(v128.load32_splat offset=124(local.get $qp)))
(v128.load8x8_s offset=248(local.get $bp0))
local.tee $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_32(v128.load32_splat offset=128(local.get $qp)))
(v128.load8x8_s offset=256(local.get $bp0))
local.tee $w0_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_33(v128.load32_splat offset=132(local.get $qp)))
(v128.load8x8_s offset=264(local.get $bp0))
local.tee $w0_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_34(v128.load32_splat offset=136(local.get $qp)))
(v128.load8x8_s offset=272(local.get $bp0))
local.tee $w0_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_35(v128.load32_splat offset=140(local.get $qp)))
(v128.load8x8_s offset=280(local.get $bp0))
local.tee $w0_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_36(v128.load32_splat offset=144(local.get $qp)))
(v128.load8x8_s offset=288(local.get $bp0))
local.tee $w0_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_37(v128.load32_splat offset=148(local.get $qp)))
(v128.load8x8_s offset=296(local.get $bp0))
local.tee $w0_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_38(v128.load32_splat offset=152(local.get $qp)))
(v128.load8x8_s offset=304(local.get $bp0))
local.tee $w0_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_39(v128.load32_splat offset=156(local.get $qp)))
(v128.load8x8_s offset=312(local.get $bp0))
local.tee $w0_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_40(v128.load32_splat offset=160(local.get $qp)))
(v128.load8x8_s offset=320(local.get $bp0))
local.tee $w0_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_41(v128.load32_splat offset=164(local.get $qp)))
(v128.load8x8_s offset=328(local.get $bp0))
local.tee $w0_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_42(v128.load32_splat offset=168(local.get $qp)))
(v128.load8x8_s offset=336(local.get $bp0))
local.tee $w0_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_43(v128.load32_splat offset=172(local.get $qp)))
(v128.load8x8_s offset=344(local.get $bp0))
local.tee $w0_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_44(v128.load32_splat offset=176(local.get $qp)))
(v128.load8x8_s offset=352(local.get $bp0))
local.tee $w0_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_45(v128.load32_splat offset=180(local.get $qp)))
(v128.load8x8_s offset=360(local.get $bp0))
local.tee $w0_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_46(v128.load32_splat offset=184(local.get $qp)))
(v128.load8x8_s offset=368(local.get $bp0))
local.tee $w0_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_47(v128.load32_splat offset=188(local.get $qp)))
(v128.load8x8_s offset=376(local.get $bp0))
local.tee $w0_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_48(v128.load32_splat offset=192(local.get $qp)))
(v128.load8x8_s offset=384(local.get $bp0))
local.tee $w0_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_49(v128.load32_splat offset=196(local.get $qp)))
(v128.load8x8_s offset=392(local.get $bp0))
local.tee $w0_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_50(v128.load32_splat offset=200(local.get $qp)))
(v128.load8x8_s offset=400(local.get $bp0))
local.tee $w0_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_51(v128.load32_splat offset=204(local.get $qp)))
(v128.load8x8_s offset=408(local.get $bp0))
local.tee $w0_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_52(v128.load32_splat offset=208(local.get $qp)))
(v128.load8x8_s offset=416(local.get $bp0))
local.tee $w0_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_53(v128.load32_splat offset=212(local.get $qp)))
(v128.load8x8_s offset=424(local.get $bp0))
local.tee $w0_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_54(v128.load32_splat offset=216(local.get $qp)))
(v128.load8x8_s offset=432(local.get $bp0))
local.tee $w0_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_55(v128.load32_splat offset=220(local.get $qp)))
(v128.load8x8_s offset=440(local.get $bp0))
local.tee $w0_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_56(v128.load32_splat offset=224(local.get $qp)))
(v128.load8x8_s offset=448(local.get $bp0))
local.tee $w0_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_57(v128.load32_splat offset=228(local.get $qp)))
(v128.load8x8_s offset=456(local.get $bp0))
local.tee $w0_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_58(v128.load32_splat offset=232(local.get $qp)))
(v128.load8x8_s offset=464(local.get $bp0))
local.tee $w0_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_59(v128.load32_splat offset=236(local.get $qp)))
(v128.load8x8_s offset=472(local.get $bp0))
local.tee $w0_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_60(v128.load32_splat offset=240(local.get $qp)))
(v128.load8x8_s offset=480(local.get $bp0))
local.tee $w0_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_61(v128.load32_splat offset=244(local.get $qp)))
(v128.load8x8_s offset=488(local.get $bp0))
local.tee $w0_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_62(v128.load32_splat offset=248(local.get $qp)))
(v128.load8x8_s offset=496(local.get $bp0))
local.tee $w0_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_63(v128.load32_splat offset=252(local.get $qp)))
(v128.load8x8_s offset=504(local.get $bp0))
local.tee $w0_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
(local.set $qp(i32.add(i32.load offset=4(local.get $q))(local.get $qo)))
(local.tee $x1_0(v128.load32_splat offset=0(local.get $qp)))
(v128.load8x8_s offset=0(local.get $bp1))
local.tee $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1_1(v128.load32_splat offset=4(local.get $qp)))
(v128.load8x8_s offset=8(local.get $bp1))
local.tee $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_2(v128.load32_splat offset=8(local.get $qp)))
(v128.load8x8_s offset=16(local.get $bp1))
local.tee $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_3(v128.load32_splat offset=12(local.get $qp)))
(v128.load8x8_s offset=24(local.get $bp1))
local.tee $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_4(v128.load32_splat offset=16(local.get $qp)))
(v128.load8x8_s offset=32(local.get $bp1))
local.tee $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_5(v128.load32_splat offset=20(local.get $qp)))
(v128.load8x8_s offset=40(local.get $bp1))
local.tee $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_6(v128.load32_splat offset=24(local.get $qp)))
(v128.load8x8_s offset=48(local.get $bp1))
local.tee $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_7(v128.load32_splat offset=28(local.get $qp)))
(v128.load8x8_s offset=56(local.get $bp1))
local.tee $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_8(v128.load32_splat offset=32(local.get $qp)))
(v128.load8x8_s offset=64(local.get $bp1))
local.tee $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_9(v128.load32_splat offset=36(local.get $qp)))
(v128.load8x8_s offset=72(local.get $bp1))
local.tee $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_10(v128.load32_splat offset=40(local.get $qp)))
(v128.load8x8_s offset=80(local.get $bp1))
local.tee $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_11(v128.load32_splat offset=44(local.get $qp)))
(v128.load8x8_s offset=88(local.get $bp1))
local.tee $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_12(v128.load32_splat offset=48(local.get $qp)))
(v128.load8x8_s offset=96(local.get $bp1))
local.tee $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_13(v128.load32_splat offset=52(local.get $qp)))
(v128.load8x8_s offset=104(local.get $bp1))
local.tee $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_14(v128.load32_splat offset=56(local.get $qp)))
(v128.load8x8_s offset=112(local.get $bp1))
local.tee $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_15(v128.load32_splat offset=60(local.get $qp)))
(v128.load8x8_s offset=120(local.get $bp1))
local.tee $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_16(v128.load32_splat offset=64(local.get $qp)))
(v128.load8x8_s offset=128(local.get $bp1))
local.tee $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_17(v128.load32_splat offset=68(local.get $qp)))
(v128.load8x8_s offset=136(local.get $bp1))
local.tee $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_18(v128.load32_splat offset=72(local.get $qp)))
(v128.load8x8_s offset=144(local.get $bp1))
local.tee $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_19(v128.load32_splat offset=76(local.get $qp)))
(v128.load8x8_s offset=152(local.get $bp1))
local.tee $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_20(v128.load32_splat offset=80(local.get $qp)))
(v128.load8x8_s offset=160(local.get $bp1))
local.tee $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_21(v128.load32_splat offset=84(local.get $qp)))
(v128.load8x8_s offset=168(local.get $bp1))
local.tee $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_22(v128.load32_splat offset=88(local.get $qp)))
(v128.load8x8_s offset=176(local.get $bp1))
local.tee $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_23(v128.load32_splat offset=92(local.get $qp)))
(v128.load8x8_s offset=184(local.get $bp1))
local.tee $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_24(v128.load32_splat offset=96(local.get $qp)))
(v128.load8x8_s offset=192(local.get $bp1))
local.tee $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_25(v128.load32_splat offset=100(local.get $qp)))
(v128.load8x8_s offset=200(local.get $bp1))
local.tee $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_26(v128.load32_splat offset=104(local.get $qp)))
(v128.load8x8_s offset=208(local.get $bp1))
local.tee $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_27(v128.load32_splat offset=108(local.get $qp)))
(v128.load8x8_s offset=216(local.get $bp1))
local.tee $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_28(v128.load32_splat offset=112(local.get $qp)))
(v128.load8x8_s offset=224(local.get $bp1))
local.tee $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_29(v128.load32_splat offset=116(local.get $qp)))
(v128.load8x8_s offset=232(local.get $bp1))
local.tee $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_30(v128.load32_splat offset=120(local.get $qp)))
(v128.load8x8_s offset=240(local.get $bp1))
local.tee $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_31(v128.load32_splat offset=124(local.get $qp)))
(v128.load8x8_s offset=248(local.get $bp1))
local.tee $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_32(v128.load32_splat offset=128(local.get $qp)))
(v128.load8x8_s offset=256(local.get $bp1))
local.tee $w1_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_33(v128.load32_splat offset=132(local.get $qp)))
(v128.load8x8_s offset=264(local.get $bp1))
local.tee $w1_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_34(v128.load32_splat offset=136(local.get $qp)))
(v128.load8x8_s offset=272(local.get $bp1))
local.tee $w1_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_35(v128.load32_splat offset=140(local.get $qp)))
(v128.load8x8_s offset=280(local.get $bp1))
local.tee $w1_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_36(v128.load32_splat offset=144(local.get $qp)))
(v128.load8x8_s offset=288(local.get $bp1))
local.tee $w1_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_37(v128.load32_splat offset=148(local.get $qp)))
(v128.load8x8_s offset=296(local.get $bp1))
local.tee $w1_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_38(v128.load32_splat offset=152(local.get $qp)))
(v128.load8x8_s offset=304(local.get $bp1))
local.tee $w1_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_39(v128.load32_splat offset=156(local.get $qp)))
(v128.load8x8_s offset=312(local.get $bp1))
local.tee $w1_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_40(v128.load32_splat offset=160(local.get $qp)))
(v128.load8x8_s offset=320(local.get $bp1))
local.tee $w1_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_41(v128.load32_splat offset=164(local.get $qp)))
(v128.load8x8_s offset=328(local.get $bp1))
local.tee $w1_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_42(v128.load32_splat offset=168(local.get $qp)))
(v128.load8x8_s offset=336(local.get $bp1))
local.tee $w1_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_43(v128.load32_splat offset=172(local.get $qp)))
(v128.load8x8_s offset=344(local.get $bp1))
local.tee $w1_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_44(v128.load32_splat offset=176(local.get $qp)))
(v128.load8x8_s offset=352(local.get $bp1))
local.tee $w1_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_45(v128.load32_splat offset=180(local.get $qp)))
(v128.load8x8_s offset=360(local.get $bp1))
local.tee $w1_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_46(v128.load32_splat offset=184(local.get $qp)))
(v128.load8x8_s offset=368(local.get $bp1))
local.tee $w1_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_47(v128.load32_splat offset=188(local.get $qp)))
(v128.load8x8_s offset=376(local.get $bp1))
local.tee $w1_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_48(v128.load32_splat offset=192(local.get $qp)))
(v128.load8x8_s offset=384(local.get $bp1))
local.tee $w1_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_49(v128.load32_splat offset=196(local.get $qp)))
(v128.load8x8_s offset=392(local.get $bp1))
local.tee $w1_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_50(v128.load32_splat offset=200(local.get $qp)))
(v128.load8x8_s offset=400(local.get $bp1))
local.tee $w1_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_51(v128.load32_splat offset=204(local.get $qp)))
(v128.load8x8_s offset=408(local.get $bp1))
local.tee $w1_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_52(v128.load32_splat offset=208(local.get $qp)))
(v128.load8x8_s offset=416(local.get $bp1))
local.tee $w1_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_53(v128.load32_splat offset=212(local.get $qp)))
(v128.load8x8_s offset=424(local.get $bp1))
local.tee $w1_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_54(v128.load32_splat offset=216(local.get $qp)))
(v128.load8x8_s offset=432(local.get $bp1))
local.tee $w1_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_55(v128.load32_splat offset=220(local.get $qp)))
(v128.load8x8_s offset=440(local.get $bp1))
local.tee $w1_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_56(v128.load32_splat offset=224(local.get $qp)))
(v128.load8x8_s offset=448(local.get $bp1))
local.tee $w1_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_57(v128.load32_splat offset=228(local.get $qp)))
(v128.load8x8_s offset=456(local.get $bp1))
local.tee $w1_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_58(v128.load32_splat offset=232(local.get $qp)))
(v128.load8x8_s offset=464(local.get $bp1))
local.tee $w1_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_59(v128.load32_splat offset=236(local.get $qp)))
(v128.load8x8_s offset=472(local.get $bp1))
local.tee $w1_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_60(v128.load32_splat offset=240(local.get $qp)))
(v128.load8x8_s offset=480(local.get $bp1))
local.tee $w1_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_61(v128.load32_splat offset=244(local.get $qp)))
(v128.load8x8_s offset=488(local.get $bp1))
local.tee $w1_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_62(v128.load32_splat offset=248(local.get $qp)))
(v128.load8x8_s offset=496(local.get $bp1))
local.tee $w1_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_63(v128.load32_splat offset=252(local.get $qp)))
(v128.load8x8_s offset=504(local.get $bp1))
local.tee $w1_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
(local.set $qp(i32.add(i32.load offset=8(local.get $q))(local.get $qo)))
(local.tee $x2_0(v128.load32_splat offset=0(local.get $qp)))
(v128.load8x8_s offset=0(local.get $bp3))
local.tee $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x2_1(v128.load32_splat offset=4(local.get $qp)))
(v128.load8x8_s offset=8(local.get $bp3))
local.tee $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_2(v128.load32_splat offset=8(local.get $qp)))
(v128.load8x8_s offset=16(local.get $bp3))
local.tee $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_3(v128.load32_splat offset=12(local.get $qp)))
(v128.load8x8_s offset=24(local.get $bp3))
local.tee $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_4(v128.load32_splat offset=16(local.get $qp)))
(v128.load8x8_s offset=32(local.get $bp3))
local.tee $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_5(v128.load32_splat offset=20(local.get $qp)))
(v128.load8x8_s offset=40(local.get $bp3))
local.tee $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_6(v128.load32_splat offset=24(local.get $qp)))
(v128.load8x8_s offset=48(local.get $bp3))
local.tee $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_7(v128.load32_splat offset=28(local.get $qp)))
(v128.load8x8_s offset=56(local.get $bp3))
local.tee $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_8(v128.load32_splat offset=32(local.get $qp)))
(v128.load8x8_s offset=64(local.get $bp3))
local.tee $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_9(v128.load32_splat offset=36(local.get $qp)))
(v128.load8x8_s offset=72(local.get $bp3))
local.tee $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_10(v128.load32_splat offset=40(local.get $qp)))
(v128.load8x8_s offset=80(local.get $bp3))
local.tee $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_11(v128.load32_splat offset=44(local.get $qp)))
(v128.load8x8_s offset=88(local.get $bp3))
local.tee $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_12(v128.load32_splat offset=48(local.get $qp)))
(v128.load8x8_s offset=96(local.get $bp3))
local.tee $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_13(v128.load32_splat offset=52(local.get $qp)))
(v128.load8x8_s offset=104(local.get $bp3))
local.tee $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_14(v128.load32_splat offset=56(local.get $qp)))
(v128.load8x8_s offset=112(local.get $bp3))
local.tee $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_15(v128.load32_splat offset=60(local.get $qp)))
(v128.load8x8_s offset=120(local.get $bp3))
local.tee $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_16(v128.load32_splat offset=64(local.get $qp)))
(v128.load8x8_s offset=128(local.get $bp3))
local.tee $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_17(v128.load32_splat offset=68(local.get $qp)))
(v128.load8x8_s offset=136(local.get $bp3))
local.tee $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_18(v128.load32_splat offset=72(local.get $qp)))
(v128.load8x8_s offset=144(local.get $bp3))
local.tee $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_19(v128.load32_splat offset=76(local.get $qp)))
(v128.load8x8_s offset=152(local.get $bp3))
local.tee $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_20(v128.load32_splat offset=80(local.get $qp)))
(v128.load8x8_s offset=160(local.get $bp3))
local.tee $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_21(v128.load32_splat offset=84(local.get $qp)))
(v128.load8x8_s offset=168(local.get $bp3))
local.tee $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_22(v128.load32_splat offset=88(local.get $qp)))
(v128.load8x8_s offset=176(local.get $bp3))
local.tee $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_23(v128.load32_splat offset=92(local.get $qp)))
(v128.load8x8_s offset=184(local.get $bp3))
local.tee $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_24(v128.load32_splat offset=96(local.get $qp)))
(v128.load8x8_s offset=192(local.get $bp3))
local.tee $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_25(v128.load32_splat offset=100(local.get $qp)))
(v128.load8x8_s offset=200(local.get $bp3))
local.tee $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_26(v128.load32_splat offset=104(local.get $qp)))
(v128.load8x8_s offset=208(local.get $bp3))
local.tee $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_27(v128.load32_splat offset=108(local.get $qp)))
(v128.load8x8_s offset=216(local.get $bp3))
local.tee $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_28(v128.load32_splat offset=112(local.get $qp)))
(v128.load8x8_s offset=224(local.get $bp3))
local.tee $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_29(v128.load32_splat offset=116(local.get $qp)))
(v128.load8x8_s offset=232(local.get $bp3))
local.tee $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_30(v128.load32_splat offset=120(local.get $qp)))
(v128.load8x8_s offset=240(local.get $bp3))
local.tee $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_31(v128.load32_splat offset=124(local.get $qp)))
(v128.load8x8_s offset=248(local.get $bp3))
local.tee $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_32(v128.load32_splat offset=128(local.get $qp)))
(v128.load8x8_s offset=256(local.get $bp3))
local.tee $w2_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_33(v128.load32_splat offset=132(local.get $qp)))
(v128.load8x8_s offset=264(local.get $bp3))
local.tee $w2_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_34(v128.load32_splat offset=136(local.get $qp)))
(v128.load8x8_s offset=272(local.get $bp3))
local.tee $w2_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_35(v128.load32_splat offset=140(local.get $qp)))
(v128.load8x8_s offset=280(local.get $bp3))
local.tee $w2_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_36(v128.load32_splat offset=144(local.get $qp)))
(v128.load8x8_s offset=288(local.get $bp3))
local.tee $w2_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_37(v128.load32_splat offset=148(local.get $qp)))
(v128.load8x8_s offset=296(local.get $bp3))
local.tee $w2_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_38(v128.load32_splat offset=152(local.get $qp)))
(v128.load8x8_s offset=304(local.get $bp3))
local.tee $w2_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_39(v128.load32_splat offset=156(local.get $qp)))
(v128.load8x8_s offset=312(local.get $bp3))
local.tee $w2_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_40(v128.load32_splat offset=160(local.get $qp)))
(v128.load8x8_s offset=320(local.get $bp3))
local.tee $w2_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_41(v128.load32_splat offset=164(local.get $qp)))
(v128.load8x8_s offset=328(local.get $bp3))
local.tee $w2_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_42(v128.load32_splat offset=168(local.get $qp)))
(v128.load8x8_s offset=336(local.get $bp3))
local.tee $w2_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_43(v128.load32_splat offset=172(local.get $qp)))
(v128.load8x8_s offset=344(local.get $bp3))
local.tee $w2_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_44(v128.load32_splat offset=176(local.get $qp)))
(v128.load8x8_s offset=352(local.get $bp3))
local.tee $w2_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_45(v128.load32_splat offset=180(local.get $qp)))
(v128.load8x8_s offset=360(local.get $bp3))
local.tee $w2_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_46(v128.load32_splat offset=184(local.get $qp)))
(v128.load8x8_s offset=368(local.get $bp3))
local.tee $w2_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_47(v128.load32_splat offset=188(local.get $qp)))
(v128.load8x8_s offset=376(local.get $bp3))
local.tee $w2_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_48(v128.load32_splat offset=192(local.get $qp)))
(v128.load8x8_s offset=384(local.get $bp3))
local.tee $w2_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_49(v128.load32_splat offset=196(local.get $qp)))
(v128.load8x8_s offset=392(local.get $bp3))
local.tee $w2_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_50(v128.load32_splat offset=200(local.get $qp)))
(v128.load8x8_s offset=400(local.get $bp3))
local.tee $w2_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_51(v128.load32_splat offset=204(local.get $qp)))
(v128.load8x8_s offset=408(local.get $bp3))
local.tee $w2_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_52(v128.load32_splat offset=208(local.get $qp)))
(v128.load8x8_s offset=416(local.get $bp3))
local.tee $w2_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_53(v128.load32_splat offset=212(local.get $qp)))
(v128.load8x8_s offset=424(local.get $bp3))
local.tee $w2_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_54(v128.load32_splat offset=216(local.get $qp)))
(v128.load8x8_s offset=432(local.get $bp3))
local.tee $w2_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_55(v128.load32_splat offset=220(local.get $qp)))
(v128.load8x8_s offset=440(local.get $bp3))
local.tee $w2_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_56(v128.load32_splat offset=224(local.get $qp)))
(v128.load8x8_s offset=448(local.get $bp3))
local.tee $w2_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_57(v128.load32_splat offset=228(local.get $qp)))
(v128.load8x8_s offset=456(local.get $bp3))
local.tee $w2_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_58(v128.load32_splat offset=232(local.get $qp)))
(v128.load8x8_s offset=464(local.get $bp3))
local.tee $w2_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_59(v128.load32_splat offset=236(local.get $qp)))
(v128.load8x8_s offset=472(local.get $bp3))
local.tee $w2_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_60(v128.load32_splat offset=240(local.get $qp)))
(v128.load8x8_s offset=480(local.get $bp3))
local.tee $w2_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_61(v128.load32_splat offset=244(local.get $qp)))
(v128.load8x8_s offset=488(local.get $bp3))
local.tee $w2_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_62(v128.load32_splat offset=248(local.get $qp)))
(v128.load8x8_s offset=496(local.get $bp3))
local.tee $w2_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_63(v128.load32_splat offset=252(local.get $qp)))
(v128.load8x8_s offset=504(local.get $bp3))
local.tee $w2_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
(local.set $qp(i32.add(i32.load offset=12(local.get $q))(local.get $qo)))
(local.tee $x3_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w2_0_0
(v128.load8x8_s offset=0(local.get $bp2))
local.get $w0_0_0
i16x8.sub
local.tee $w4_0_0
i16x8.sub
local.tee $w5_0_0
local.get $w1_0_0
i16x8.sub
local.tee $w3_0_0
i32x4.dot_i16x8_s
(local.tee $x3_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w2_0_1
(v128.load8x8_s offset=8(local.get $bp2))
local.get $w0_0_1
i16x8.sub
local.tee $w4_0_1
i16x8.sub
local.tee $w5_0_1
local.get $w1_0_1
i16x8.sub
local.tee $w3_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w2_0_2
(v128.load8x8_s offset=16(local.get $bp2))
local.get $w0_0_2
i16x8.sub
local.tee $w4_0_2
i16x8.sub
local.tee $w5_0_2
local.get $w1_0_2
i16x8.sub
local.tee $w3_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w2_0_3
(v128.load8x8_s offset=24(local.get $bp2))
local.get $w0_0_3
i16x8.sub
local.tee $w4_0_3
i16x8.sub
local.tee $w5_0_3
local.get $w1_0_3
i16x8.sub
local.tee $w3_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w2_0_4
(v128.load8x8_s offset=32(local.get $bp2))
local.get $w0_0_4
i16x8.sub
local.tee $w4_0_4
i16x8.sub
local.tee $w5_0_4
local.get $w1_0_4
i16x8.sub
local.tee $w3_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w2_0_5
(v128.load8x8_s offset=40(local.get $bp2))
local.get $w0_0_5
i16x8.sub
local.tee $w4_0_5
i16x8.sub
local.tee $w5_0_5
local.get $w1_0_5
i16x8.sub
local.tee $w3_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w2_0_6
(v128.load8x8_s offset=48(local.get $bp2))
local.get $w0_0_6
i16x8.sub
local.tee $w4_0_6
i16x8.sub
local.tee $w5_0_6
local.get $w1_0_6
i16x8.sub
local.tee $w3_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w2_0_7
(v128.load8x8_s offset=56(local.get $bp2))
local.get $w0_0_7
i16x8.sub
local.tee $w4_0_7
i16x8.sub
local.tee $w5_0_7
local.get $w1_0_7
i16x8.sub
local.tee $w3_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w2_0_8
(v128.load8x8_s offset=64(local.get $bp2))
local.get $w0_0_8
i16x8.sub
local.tee $w4_0_8
i16x8.sub
local.tee $w5_0_8
local.get $w1_0_8
i16x8.sub
local.tee $w3_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w2_0_9
(v128.load8x8_s offset=72(local.get $bp2))
local.get $w0_0_9
i16x8.sub
local.tee $w4_0_9
i16x8.sub
local.tee $w5_0_9
local.get $w1_0_9
i16x8.sub
local.tee $w3_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w2_0_10
(v128.load8x8_s offset=80(local.get $bp2))
local.get $w0_0_10
i16x8.sub
local.tee $w4_0_10
i16x8.sub
local.tee $w5_0_10
local.get $w1_0_10
i16x8.sub
local.tee $w3_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w2_0_11
(v128.load8x8_s offset=88(local.get $bp2))
local.get $w0_0_11
i16x8.sub
local.tee $w4_0_11
i16x8.sub
local.tee $w5_0_11
local.get $w1_0_11
i16x8.sub
local.tee $w3_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w2_0_12
(v128.load8x8_s offset=96(local.get $bp2))
local.get $w0_0_12
i16x8.sub
local.tee $w4_0_12
i16x8.sub
local.tee $w5_0_12
local.get $w1_0_12
i16x8.sub
local.tee $w3_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w2_0_13
(v128.load8x8_s offset=104(local.get $bp2))
local.get $w0_0_13
i16x8.sub
local.tee $w4_0_13
i16x8.sub
local.tee $w5_0_13
local.get $w1_0_13
i16x8.sub
local.tee $w3_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w2_0_14
(v128.load8x8_s offset=112(local.get $bp2))
local.get $w0_0_14
i16x8.sub
local.tee $w4_0_14
i16x8.sub
local.tee $w5_0_14
local.get $w1_0_14
i16x8.sub
local.tee $w3_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w2_0_15
(v128.load8x8_s offset=120(local.get $bp2))
local.get $w0_0_15
i16x8.sub
local.tee $w4_0_15
i16x8.sub
local.tee $w5_0_15
local.get $w1_0_15
i16x8.sub
local.tee $w3_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w2_0_16
(v128.load8x8_s offset=128(local.get $bp2))
local.get $w0_0_16
i16x8.sub
local.tee $w4_0_16
i16x8.sub
local.tee $w5_0_16
local.get $w1_0_16
i16x8.sub
local.tee $w3_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w2_0_17
(v128.load8x8_s offset=136(local.get $bp2))
local.get $w0_0_17
i16x8.sub
local.tee $w4_0_17
i16x8.sub
local.tee $w5_0_17
local.get $w1_0_17
i16x8.sub
local.tee $w3_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w2_0_18
(v128.load8x8_s offset=144(local.get $bp2))
local.get $w0_0_18
i16x8.sub
local.tee $w4_0_18
i16x8.sub
local.tee $w5_0_18
local.get $w1_0_18
i16x8.sub
local.tee $w3_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w2_0_19
(v128.load8x8_s offset=152(local.get $bp2))
local.get $w0_0_19
i16x8.sub
local.tee $w4_0_19
i16x8.sub
local.tee $w5_0_19
local.get $w1_0_19
i16x8.sub
local.tee $w3_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w2_0_20
(v128.load8x8_s offset=160(local.get $bp2))
local.get $w0_0_20
i16x8.sub
local.tee $w4_0_20
i16x8.sub
local.tee $w5_0_20
local.get $w1_0_20
i16x8.sub
local.tee $w3_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w2_0_21
(v128.load8x8_s offset=168(local.get $bp2))
local.get $w0_0_21
i16x8.sub
local.tee $w4_0_21
i16x8.sub
local.tee $w5_0_21
local.get $w1_0_21
i16x8.sub
local.tee $w3_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w2_0_22
(v128.load8x8_s offset=176(local.get $bp2))
local.get $w0_0_22
i16x8.sub
local.tee $w4_0_22
i16x8.sub
local.tee $w5_0_22
local.get $w1_0_22
i16x8.sub
local.tee $w3_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w2_0_23
(v128.load8x8_s offset=184(local.get $bp2))
local.get $w0_0_23
i16x8.sub
local.tee $w4_0_23
i16x8.sub
local.tee $w5_0_23
local.get $w1_0_23
i16x8.sub
local.tee $w3_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w2_0_24
(v128.load8x8_s offset=192(local.get $bp2))
local.get $w0_0_24
i16x8.sub
local.tee $w4_0_24
i16x8.sub
local.tee $w5_0_24
local.get $w1_0_24
i16x8.sub
local.tee $w3_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w2_0_25
(v128.load8x8_s offset=200(local.get $bp2))
local.get $w0_0_25
i16x8.sub
local.tee $w4_0_25
i16x8.sub
local.tee $w5_0_25
local.get $w1_0_25
i16x8.sub
local.tee $w3_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w2_0_26
(v128.load8x8_s offset=208(local.get $bp2))
local.get $w0_0_26
i16x8.sub
local.tee $w4_0_26
i16x8.sub
local.tee $w5_0_26
local.get $w1_0_26
i16x8.sub
local.tee $w3_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w2_0_27
(v128.load8x8_s offset=216(local.get $bp2))
local.get $w0_0_27
i16x8.sub
local.tee $w4_0_27
i16x8.sub
local.tee $w5_0_27
local.get $w1_0_27
i16x8.sub
local.tee $w3_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w2_0_28
(v128.load8x8_s offset=224(local.get $bp2))
local.get $w0_0_28
i16x8.sub
local.tee $w4_0_28
i16x8.sub
local.tee $w5_0_28
local.get $w1_0_28
i16x8.sub
local.tee $w3_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w2_0_29
(v128.load8x8_s offset=232(local.get $bp2))
local.get $w0_0_29
i16x8.sub
local.tee $w4_0_29
i16x8.sub
local.tee $w5_0_29
local.get $w1_0_29
i16x8.sub
local.tee $w3_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w2_0_30
(v128.load8x8_s offset=240(local.get $bp2))
local.get $w0_0_30
i16x8.sub
local.tee $w4_0_30
i16x8.sub
local.tee $w5_0_30
local.get $w1_0_30
i16x8.sub
local.tee $w3_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w2_0_31
(v128.load8x8_s offset=248(local.get $bp2))
local.get $w0_0_31
i16x8.sub
local.tee $w4_0_31
i16x8.sub
local.tee $w5_0_31
local.get $w1_0_31
i16x8.sub
local.tee $w3_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w2_0_32
(v128.load8x8_s offset=256(local.get $bp2))
local.get $w0_0_32
i16x8.sub
local.tee $w4_0_32
i16x8.sub
local.tee $w5_0_32
local.get $w1_0_32
i16x8.sub
local.tee $w3_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w2_0_33
(v128.load8x8_s offset=264(local.get $bp2))
local.get $w0_0_33
i16x8.sub
local.tee $w4_0_33
i16x8.sub
local.tee $w5_0_33
local.get $w1_0_33
i16x8.sub
local.tee $w3_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w2_0_34
(v128.load8x8_s offset=272(local.get $bp2))
local.get $w0_0_34
i16x8.sub
local.tee $w4_0_34
i16x8.sub
local.tee $w5_0_34
local.get $w1_0_34
i16x8.sub
local.tee $w3_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w2_0_35
(v128.load8x8_s offset=280(local.get $bp2))
local.get $w0_0_35
i16x8.sub
local.tee $w4_0_35
i16x8.sub
local.tee $w5_0_35
local.get $w1_0_35
i16x8.sub
local.tee $w3_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w2_0_36
(v128.load8x8_s offset=288(local.get $bp2))
local.get $w0_0_36
i16x8.sub
local.tee $w4_0_36
i16x8.sub
local.tee $w5_0_36
local.get $w1_0_36
i16x8.sub
local.tee $w3_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w2_0_37
(v128.load8x8_s offset=296(local.get $bp2))
local.get $w0_0_37
i16x8.sub
local.tee $w4_0_37
i16x8.sub
local.tee $w5_0_37
local.get $w1_0_37
i16x8.sub
local.tee $w3_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w2_0_38
(v128.load8x8_s offset=304(local.get $bp2))
local.get $w0_0_38
i16x8.sub
local.tee $w4_0_38
i16x8.sub
local.tee $w5_0_38
local.get $w1_0_38
i16x8.sub
local.tee $w3_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w2_0_39
(v128.load8x8_s offset=312(local.get $bp2))
local.get $w0_0_39
i16x8.sub
local.tee $w4_0_39
i16x8.sub
local.tee $w5_0_39
local.get $w1_0_39
i16x8.sub
local.tee $w3_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w2_0_40
(v128.load8x8_s offset=320(local.get $bp2))
local.get $w0_0_40
i16x8.sub
local.tee $w4_0_40
i16x8.sub
local.tee $w5_0_40
local.get $w1_0_40
i16x8.sub
local.tee $w3_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w2_0_41
(v128.load8x8_s offset=328(local.get $bp2))
local.get $w0_0_41
i16x8.sub
local.tee $w4_0_41
i16x8.sub
local.tee $w5_0_41
local.get $w1_0_41
i16x8.sub
local.tee $w3_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w2_0_42
(v128.load8x8_s offset=336(local.get $bp2))
local.get $w0_0_42
i16x8.sub
local.tee $w4_0_42
i16x8.sub
local.tee $w5_0_42
local.get $w1_0_42
i16x8.sub
local.tee $w3_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w2_0_43
(v128.load8x8_s offset=344(local.get $bp2))
local.get $w0_0_43
i16x8.sub
local.tee $w4_0_43
i16x8.sub
local.tee $w5_0_43
local.get $w1_0_43
i16x8.sub
local.tee $w3_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w2_0_44
(v128.load8x8_s offset=352(local.get $bp2))
local.get $w0_0_44
i16x8.sub
local.tee $w4_0_44
i16x8.sub
local.tee $w5_0_44
local.get $w1_0_44
i16x8.sub
local.tee $w3_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w2_0_45
(v128.load8x8_s offset=360(local.get $bp2))
local.get $w0_0_45
i16x8.sub
local.tee $w4_0_45
i16x8.sub
local.tee $w5_0_45
local.get $w1_0_45
i16x8.sub
local.tee $w3_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w2_0_46
(v128.load8x8_s offset=368(local.get $bp2))
local.get $w0_0_46
i16x8.sub
local.tee $w4_0_46
i16x8.sub
local.tee $w5_0_46
local.get $w1_0_46
i16x8.sub
local.tee $w3_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w2_0_47
(v128.load8x8_s offset=376(local.get $bp2))
local.get $w0_0_47
i16x8.sub
local.tee $w4_0_47
i16x8.sub
local.tee $w5_0_47
local.get $w1_0_47
i16x8.sub
local.tee $w3_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w2_0_48
(v128.load8x8_s offset=384(local.get $bp2))
local.get $w0_0_48
i16x8.sub
local.tee $w4_0_48
i16x8.sub
local.tee $w5_0_48
local.get $w1_0_48
i16x8.sub
local.tee $w3_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w2_0_49
(v128.load8x8_s offset=392(local.get $bp2))
local.get $w0_0_49
i16x8.sub
local.tee $w4_0_49
i16x8.sub
local.tee $w5_0_49
local.get $w1_0_49
i16x8.sub
local.tee $w3_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w2_0_50
(v128.load8x8_s offset=400(local.get $bp2))
local.get $w0_0_50
i16x8.sub
local.tee $w4_0_50
i16x8.sub
local.tee $w5_0_50
local.get $w1_0_50
i16x8.sub
local.tee $w3_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w2_0_51
(v128.load8x8_s offset=408(local.get $bp2))
local.get $w0_0_51
i16x8.sub
local.tee $w4_0_51
i16x8.sub
local.tee $w5_0_51
local.get $w1_0_51
i16x8.sub
local.tee $w3_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w2_0_52
(v128.load8x8_s offset=416(local.get $bp2))
local.get $w0_0_52
i16x8.sub
local.tee $w4_0_52
i16x8.sub
local.tee $w5_0_52
local.get $w1_0_52
i16x8.sub
local.tee $w3_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w2_0_53
(v128.load8x8_s offset=424(local.get $bp2))
local.get $w0_0_53
i16x8.sub
local.tee $w4_0_53
i16x8.sub
local.tee $w5_0_53
local.get $w1_0_53
i16x8.sub
local.tee $w3_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w2_0_54
(v128.load8x8_s offset=432(local.get $bp2))
local.get $w0_0_54
i16x8.sub
local.tee $w4_0_54
i16x8.sub
local.tee $w5_0_54
local.get $w1_0_54
i16x8.sub
local.tee $w3_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w2_0_55
(v128.load8x8_s offset=440(local.get $bp2))
local.get $w0_0_55
i16x8.sub
local.tee $w4_0_55
i16x8.sub
local.tee $w5_0_55
local.get $w1_0_55
i16x8.sub
local.tee $w3_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w2_0_56
(v128.load8x8_s offset=448(local.get $bp2))
local.get $w0_0_56
i16x8.sub
local.tee $w4_0_56
i16x8.sub
local.tee $w5_0_56
local.get $w1_0_56
i16x8.sub
local.tee $w3_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w2_0_57
(v128.load8x8_s offset=456(local.get $bp2))
local.get $w0_0_57
i16x8.sub
local.tee $w4_0_57
i16x8.sub
local.tee $w5_0_57
local.get $w1_0_57
i16x8.sub
local.tee $w3_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w2_0_58
(v128.load8x8_s offset=464(local.get $bp2))
local.get $w0_0_58
i16x8.sub
local.tee $w4_0_58
i16x8.sub
local.tee $w5_0_58
local.get $w1_0_58
i16x8.sub
local.tee $w3_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w2_0_59
(v128.load8x8_s offset=472(local.get $bp2))
local.get $w0_0_59
i16x8.sub
local.tee $w4_0_59
i16x8.sub
local.tee $w5_0_59
local.get $w1_0_59
i16x8.sub
local.tee $w3_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w2_0_60
(v128.load8x8_s offset=480(local.get $bp2))
local.get $w0_0_60
i16x8.sub
local.tee $w4_0_60
i16x8.sub
local.tee $w5_0_60
local.get $w1_0_60
i16x8.sub
local.tee $w3_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w2_0_61
(v128.load8x8_s offset=488(local.get $bp2))
local.get $w0_0_61
i16x8.sub
local.tee $w4_0_61
i16x8.sub
local.tee $w5_0_61
local.get $w1_0_61
i16x8.sub
local.tee $w3_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w2_0_62
(v128.load8x8_s offset=496(local.get $bp2))
local.get $w0_0_62
i16x8.sub
local.tee $w4_0_62
i16x8.sub
local.tee $w5_0_62
local.get $w1_0_62
i16x8.sub
local.tee $w3_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w2_0_63
(v128.load8x8_s offset=504(local.get $bp2))
local.get $w0_0_63
i16x8.sub
local.tee $w4_0_63
i16x8.sub
local.tee $w5_0_63
local.get $w1_0_63
i16x8.sub
local.tee $w3_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
(local.set $qp(i32.add(i32.load offset=16(local.get $q))(local.get $qo)))
(local.tee $x4_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w4_0_0
i32x4.dot_i16x8_s
(local.tee $x4_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w4_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w4_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w4_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w4_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w4_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w4_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w4_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w4_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w4_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w4_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w4_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w4_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w4_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w4_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w4_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w4_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w4_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w4_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w4_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w4_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w4_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w4_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w4_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w4_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w4_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w4_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w4_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w4_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w4_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w4_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w4_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w4_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
(local.set $qp(i32.add(i32.load offset=20(local.get $q))(local.get $qo)))
(local.tee $x5_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w5_0_0
i32x4.dot_i16x8_s
(local.tee $x5_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w5_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w5_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w5_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w5_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w5_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w5_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w5_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w5_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w5_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w5_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w5_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w5_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w5_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w5_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w5_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w5_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w5_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w5_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w5_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w5_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w5_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w5_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w5_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w5_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w5_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w5_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w5_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w5_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w5_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w5_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w5_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w5_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w5_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w5_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w5_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w5_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w5_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w5_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w5_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w5_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w5_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w5_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w5_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w5_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w5_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w5_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w5_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w5_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w5_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w5_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w5_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w5_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w5_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w5_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w5_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w5_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w5_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w5_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w5_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w5_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w5_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w5_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w5_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
(local.set $qp(i32.add(i32.load offset=24(local.get $q))(local.get $qo)))
(local.tee $x6_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w5_0_0
local.get $w0_0_0
i16x8.sub
local.tee $w6_0_0
i32x4.dot_i16x8_s
(local.tee $x6_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w5_0_1
local.get $w0_0_1
i16x8.sub
local.tee $w6_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w5_0_2
local.get $w0_0_2
i16x8.sub
local.tee $w6_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w5_0_3
local.get $w0_0_3
i16x8.sub
local.tee $w6_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w5_0_4
local.get $w0_0_4
i16x8.sub
local.tee $w6_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w5_0_5
local.get $w0_0_5
i16x8.sub
local.tee $w6_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w5_0_6
local.get $w0_0_6
i16x8.sub
local.tee $w6_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w5_0_7
local.get $w0_0_7
i16x8.sub
local.tee $w6_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w5_0_8
local.get $w0_0_8
i16x8.sub
local.tee $w6_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w5_0_9
local.get $w0_0_9
i16x8.sub
local.tee $w6_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w5_0_10
local.get $w0_0_10
i16x8.sub
local.tee $w6_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w5_0_11
local.get $w0_0_11
i16x8.sub
local.tee $w6_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w5_0_12
local.get $w0_0_12
i16x8.sub
local.tee $w6_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w5_0_13
local.get $w0_0_13
i16x8.sub
local.tee $w6_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w5_0_14
local.get $w0_0_14
i16x8.sub
local.tee $w6_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w5_0_15
local.get $w0_0_15
i16x8.sub
local.tee $w6_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w5_0_16
local.get $w0_0_16
i16x8.sub
local.tee $w6_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w5_0_17
local.get $w0_0_17
i16x8.sub
local.tee $w6_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w5_0_18
local.get $w0_0_18
i16x8.sub
local.tee $w6_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w5_0_19
local.get $w0_0_19
i16x8.sub
local.tee $w6_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w5_0_20
local.get $w0_0_20
i16x8.sub
local.tee $w6_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w5_0_21
local.get $w0_0_21
i16x8.sub
local.tee $w6_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w5_0_22
local.get $w0_0_22
i16x8.sub
local.tee $w6_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w5_0_23
local.get $w0_0_23
i16x8.sub
local.tee $w6_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w5_0_24
local.get $w0_0_24
i16x8.sub
local.tee $w6_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w5_0_25
local.get $w0_0_25
i16x8.sub
local.tee $w6_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w5_0_26
local.get $w0_0_26
i16x8.sub
local.tee $w6_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w5_0_27
local.get $w0_0_27
i16x8.sub
local.tee $w6_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w5_0_28
local.get $w0_0_28
i16x8.sub
local.tee $w6_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w5_0_29
local.get $w0_0_29
i16x8.sub
local.tee $w6_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w5_0_30
local.get $w0_0_30
i16x8.sub
local.tee $w6_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w5_0_31
local.get $w0_0_31
i16x8.sub
local.tee $w6_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w5_0_32
local.get $w0_0_32
i16x8.sub
local.tee $w6_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w5_0_33
local.get $w0_0_33
i16x8.sub
local.tee $w6_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w5_0_34
local.get $w0_0_34
i16x8.sub
local.tee $w6_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w5_0_35
local.get $w0_0_35
i16x8.sub
local.tee $w6_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w5_0_36
local.get $w0_0_36
i16x8.sub
local.tee $w6_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w5_0_37
local.get $w0_0_37
i16x8.sub
local.tee $w6_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w5_0_38
local.get $w0_0_38
i16x8.sub
local.tee $w6_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w5_0_39
local.get $w0_0_39
i16x8.sub
local.tee $w6_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w5_0_40
local.get $w0_0_40
i16x8.sub
local.tee $w6_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w5_0_41
local.get $w0_0_41
i16x8.sub
local.tee $w6_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w5_0_42
local.get $w0_0_42
i16x8.sub
local.tee $w6_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w5_0_43
local.get $w0_0_43
i16x8.sub
local.tee $w6_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w5_0_44
local.get $w0_0_44
i16x8.sub
local.tee $w6_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w5_0_45
local.get $w0_0_45
i16x8.sub
local.tee $w6_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w5_0_46
local.get $w0_0_46
i16x8.sub
local.tee $w6_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w5_0_47
local.get $w0_0_47
i16x8.sub
local.tee $w6_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w5_0_48
local.get $w0_0_48
i16x8.sub
local.tee $w6_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w5_0_49
local.get $w0_0_49
i16x8.sub
local.tee $w6_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w5_0_50
local.get $w0_0_50
i16x8.sub
local.tee $w6_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w5_0_51
local.get $w0_0_51
i16x8.sub
local.tee $w6_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w5_0_52
local.get $w0_0_52
i16x8.sub
local.tee $w6_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w5_0_53
local.get $w0_0_53
i16x8.sub
local.tee $w6_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w5_0_54
local.get $w0_0_54
i16x8.sub
local.tee $w6_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w5_0_55
local.get $w0_0_55
i16x8.sub
local.tee $w6_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w5_0_56
local.get $w0_0_56
i16x8.sub
local.tee $w6_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w5_0_57
local.get $w0_0_57
i16x8.sub
local.tee $w6_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w5_0_58
local.get $w0_0_58
i16x8.sub
local.tee $w6_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w5_0_59
local.get $w0_0_59
i16x8.sub
local.tee $w6_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w5_0_60
local.get $w0_0_60
i16x8.sub
local.tee $w6_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w5_0_61
local.get $w0_0_61
i16x8.sub
local.tee $w6_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w5_0_62
local.get $w0_0_62
i16x8.sub
local.tee $w6_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w5_0_63
local.get $w0_0_63
i16x8.sub
local.tee $w6_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=0
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
local.get $yp
v128.load offset=16
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
(if(local.get $keep)(then
local.get $yp1
local.get $yp1
v128.load offset=0
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp1
local.get $yp1
v128.load offset=16
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16
))
(local.set $bp0(i32.add(local.get $wp0)(i32.mul(local.get $cols)(i32.const 2))))
(local.set $bp1(i32.add(local.get $wp1)(i32.mul(local.get $cols)(i32.const 2))))
(local.set $bp2(i32.add(local.get $wp2)(i32.mul(local.get $cols)(i32.const 2))))
(local.set $bp3(i32.add(local.get $wp3)(i32.mul(local.get $cols)(i32.const 2))))
local.get $x0_0
(v128.load8x8_s offset=0(local.get $bp0))
local.tee $w0_1_0
i32x4.dot_i16x8_s
local.get $x0_1
(v128.load8x8_s offset=8(local.get $bp0))
local.tee $w0_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(v128.load8x8_s offset=16(local.get $bp0))
local.tee $w0_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(v128.load8x8_s offset=24(local.get $bp0))
local.tee $w0_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(v128.load8x8_s offset=32(local.get $bp0))
local.tee $w0_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(v128.load8x8_s offset=40(local.get $bp0))
local.tee $w0_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(v128.load8x8_s offset=48(local.get $bp0))
local.tee $w0_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(v128.load8x8_s offset=56(local.get $bp0))
local.tee $w0_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(v128.load8x8_s offset=64(local.get $bp0))
local.tee $w0_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(v128.load8x8_s offset=72(local.get $bp0))
local.tee $w0_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(v128.load8x8_s offset=80(local.get $bp0))
local.tee $w0_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(v128.load8x8_s offset=88(local.get $bp0))
local.tee $w0_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(v128.load8x8_s offset=96(local.get $bp0))
local.tee $w0_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(v128.load8x8_s offset=104(local.get $bp0))
local.tee $w0_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(v128.load8x8_s offset=112(local.get $bp0))
local.tee $w0_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(v128.load8x8_s offset=120(local.get $bp0))
local.tee $w0_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(v128.load8x8_s offset=128(local.get $bp0))
local.tee $w0_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(v128.load8x8_s offset=136(local.get $bp0))
local.tee $w0_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(v128.load8x8_s offset=144(local.get $bp0))
local.tee $w0_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(v128.load8x8_s offset=152(local.get $bp0))
local.tee $w0_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(v128.load8x8_s offset=160(local.get $bp0))
local.tee $w0_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(v128.load8x8_s offset=168(local.get $bp0))
local.tee $w0_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(v128.load8x8_s offset=176(local.get $bp0))
local.tee $w0_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(v128.load8x8_s offset=184(local.get $bp0))
local.tee $w0_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(v128.load8x8_s offset=192(local.get $bp0))
local.tee $w0_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(v128.load8x8_s offset=200(local.get $bp0))
local.tee $w0_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(v128.load8x8_s offset=208(local.get $bp0))
local.tee $w0_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(v128.load8x8_s offset=216(local.get $bp0))
local.tee $w0_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(v128.load8x8_s offset=224(local.get $bp0))
local.tee $w0_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(v128.load8x8_s offset=232(local.get $bp0))
local.tee $w0_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(v128.load8x8_s offset=240(local.get $bp0))
local.tee $w0_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(v128.load8x8_s offset=248(local.get $bp0))
local.tee $w0_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
(v128.load8x8_s offset=256(local.get $bp0))
local.tee $w0_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
(v128.load8x8_s offset=264(local.get $bp0))
local.tee $w0_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
(v128.load8x8_s offset=272(local.get $bp0))
local.tee $w0_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
(v128.load8x8_s offset=280(local.get $bp0))
local.tee $w0_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
(v128.load8x8_s offset=288(local.get $bp0))
local.tee $w0_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
(v128.load8x8_s offset=296(local.get $bp0))
local.tee $w0_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
(v128.load8x8_s offset=304(local.get $bp0))
local.tee $w0_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
(v128.load8x8_s offset=312(local.get $bp0))
local.tee $w0_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
(v128.load8x8_s offset=320(local.get $bp0))
local.tee $w0_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
(v128.load8x8_s offset=328(local.get $bp0))
local.tee $w0_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
(v128.load8x8_s offset=336(local.get $bp0))
local.tee $w0_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
(v128.load8x8_s offset=344(local.get $bp0))
local.tee $w0_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
(v128.load8x8_s offset=352(local.get $bp0))
local.tee $w0_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
(v128.load8x8_s offset=360(local.get $bp0))
local.tee $w0_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
(v128.load8x8_s offset=368(local.get $bp0))
local.tee $w0_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
(v128.load8x8_s offset=376(local.get $bp0))
local.tee $w0_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
(v128.load8x8_s offset=384(local.get $bp0))
local.tee $w0_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
(v128.load8x8_s offset=392(local.get $bp0))
local.tee $w0_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
(v128.load8x8_s offset=400(local.get $bp0))
local.tee $w0_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
(v128.load8x8_s offset=408(local.get $bp0))
local.tee $w0_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
(v128.load8x8_s offset=416(local.get $bp0))
local.tee $w0_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
(v128.load8x8_s offset=424(local.get $bp0))
local.tee $w0_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
(v128.load8x8_s offset=432(local.get $bp0))
local.tee $w0_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
(v128.load8x8_s offset=440(local.get $bp0))
local.tee $w0_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
(v128.load8x8_s offset=448(local.get $bp0))
local.tee $w0_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
(v128.load8x8_s offset=456(local.get $bp0))
local.tee $w0_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
(v128.load8x8_s offset=464(local.get $bp0))
local.tee $w0_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
(v128.load8x8_s offset=472(local.get $bp0))
local.tee $w0_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
(v128.load8x8_s offset=480(local.get $bp0))
local.tee $w0_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
(v128.load8x8_s offset=488(local.get $bp0))
local.tee $w0_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
(v128.load8x8_s offset=496(local.get $bp0))
local.tee $w0_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
(v128.load8x8_s offset=504(local.get $bp0))
local.tee $w0_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
(v128.load8x8_s offset=0(local.get $bp1))
local.tee $w1_1_0
i32x4.dot_i16x8_s
local.get $x1_1
(v128.load8x8_s offset=8(local.get $bp1))
local.tee $w1_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
(v128.load8x8_s offset=16(local.get $bp1))
local.tee $w1_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
(v128.load8x8_s offset=24(local.get $bp1))
local.tee $w1_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
(v128.load8x8_s offset=32(local.get $bp1))
local.tee $w1_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
(v128.load8x8_s offset=40(local.get $bp1))
local.tee $w1_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
(v128.load8x8_s offset=48(local.get $bp1))
local.tee $w1_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
(v128.load8x8_s offset=56(local.get $bp1))
local.tee $w1_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
(v128.load8x8_s offset=64(local.get $bp1))
local.tee $w1_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
(v128.load8x8_s offset=72(local.get $bp1))
local.tee $w1_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
(v128.load8x8_s offset=80(local.get $bp1))
local.tee $w1_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
(v128.load8x8_s offset=88(local.get $bp1))
local.tee $w1_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
(v128.load8x8_s offset=96(local.get $bp1))
local.tee $w1_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
(v128.load8x8_s offset=104(local.get $bp1))
local.tee $w1_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
(v128.load8x8_s offset=112(local.get $bp1))
local.tee $w1_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
(v128.load8x8_s offset=120(local.get $bp1))
local.tee $w1_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
(v128.load8x8_s offset=128(local.get $bp1))
local.tee $w1_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
(v128.load8x8_s offset=136(local.get $bp1))
local.tee $w1_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
(v128.load8x8_s offset=144(local.get $bp1))
local.tee $w1_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
(v128.load8x8_s offset=152(local.get $bp1))
local.tee $w1_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
(v128.load8x8_s offset=160(local.get $bp1))
local.tee $w1_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
(v128.load8x8_s offset=168(local.get $bp1))
local.tee $w1_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
(v128.load8x8_s offset=176(local.get $bp1))
local.tee $w1_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
(v128.load8x8_s offset=184(local.get $bp1))
local.tee $w1_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
(v128.load8x8_s offset=192(local.get $bp1))
local.tee $w1_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
(v128.load8x8_s offset=200(local.get $bp1))
local.tee $w1_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
(v128.load8x8_s offset=208(local.get $bp1))
local.tee $w1_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
(v128.load8x8_s offset=216(local.get $bp1))
local.tee $w1_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
(v128.load8x8_s offset=224(local.get $bp1))
local.tee $w1_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
(v128.load8x8_s offset=232(local.get $bp1))
local.tee $w1_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
(v128.load8x8_s offset=240(local.get $bp1))
local.tee $w1_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
(v128.load8x8_s offset=248(local.get $bp1))
local.tee $w1_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
(v128.load8x8_s offset=256(local.get $bp1))
local.tee $w1_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
(v128.load8x8_s offset=264(local.get $bp1))
local.tee $w1_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
(v128.load8x8_s offset=272(local.get $bp1))
local.tee $w1_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
(v128.load8x8_s offset=280(local.get $bp1))
local.tee $w1_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
(v128.load8x8_s offset=288(local.get $bp1))
local.tee $w1_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
(v128.load8x8_s offset=296(local.get $bp1))
local.tee $w1_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
(v128.load8x8_s offset=304(local.get $bp1))
local.tee $w1_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
(v128.load8x8_s offset=312(local.get $bp1))
local.tee $w1_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
(v128.load8x8_s offset=320(local.get $bp1))
local.tee $w1_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
(v128.load8x8_s offset=328(local.get $bp1))
local.tee $w1_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
(v128.load8x8_s offset=336(local.get $bp1))
local.tee $w1_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
(v128.load8x8_s offset=344(local.get $bp1))
local.tee $w1_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
(v128.load8x8_s offset=352(local.get $bp1))
local.tee $w1_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
(v128.load8x8_s offset=360(local.get $bp1))
local.tee $w1_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
(v128.load8x8_s offset=368(local.get $bp1))
local.tee $w1_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
(v128.load8x8_s offset=376(local.get $bp1))
local.tee $w1_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
(v128.load8x8_s offset=384(local.get $bp1))
local.tee $w1_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
(v128.load8x8_s offset=392(local.get $bp1))
local.tee $w1_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
(v128.load8x8_s offset=400(local.get $bp1))
local.tee $w1_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
(v128.load8x8_s offset=408(local.get $bp1))
local.tee $w1_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
(v128.load8x8_s offset=416(local.get $bp1))
local.tee $w1_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
(v128.load8x8_s offset=424(local.get $bp1))
local.tee $w1_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
(v128.load8x8_s offset=432(local.get $bp1))
local.tee $w1_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
(v128.load8x8_s offset=440(local.get $bp1))
local.tee $w1_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
(v128.load8x8_s offset=448(local.get $bp1))
local.tee $w1_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
(v128.load8x8_s offset=456(local.get $bp1))
local.tee $w1_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
(v128.load8x8_s offset=464(local.get $bp1))
local.tee $w1_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
(v128.load8x8_s offset=472(local.get $bp1))
local.tee $w1_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
(v128.load8x8_s offset=480(local.get $bp1))
local.tee $w1_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
(v128.load8x8_s offset=488(local.get $bp1))
local.tee $w1_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
(v128.load8x8_s offset=496(local.get $bp1))
local.tee $w1_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
(v128.load8x8_s offset=504(local.get $bp1))
local.tee $w1_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
(v128.load8x8_s offset=0(local.get $bp3))
local.tee $w2_1_0
i32x4.dot_i16x8_s
local.get $x2_1
(v128.load8x8_s offset=8(local.get $bp3))
local.tee $w2_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(v128.load8x8_s offset=16(local.get $bp3))
local.tee $w2_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(v128.load8x8_s offset=24(local.get $bp3))
local.tee $w2_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(v128.load8x8_s offset=32(local.get $bp3))
local.tee $w2_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(v128.load8x8_s offset=40(local.get $bp3))
local.tee $w2_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(v128.load8x8_s offset=48(local.get $bp3))
local.tee $w2_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(v128.load8x8_s offset=56(local.get $bp3))
local.tee $w2_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(v128.load8x8_s offset=64(local.get $bp3))
local.tee $w2_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(v128.load8x8_s offset=72(local.get $bp3))
local.tee $w2_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(v128.load8x8_s offset=80(local.get $bp3))
local.tee $w2_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(v128.load8x8_s offset=88(local.get $bp3))
local.tee $w2_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(v128.load8x8_s offset=96(local.get $bp3))
local.tee $w2_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(v128.load8x8_s offset=104(local.get $bp3))
local.tee $w2_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(v128.load8x8_s offset=112(local.get $bp3))
local.tee $w2_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(v128.load8x8_s offset=120(local.get $bp3))
local.tee $w2_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(v128.load8x8_s offset=128(local.get $bp3))
local.tee $w2_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(v128.load8x8_s offset=136(local.get $bp3))
local.tee $w2_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(v128.load8x8_s offset=144(local.get $bp3))
local.tee $w2_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(v128.load8x8_s offset=152(local.get $bp3))
local.tee $w2_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(v128.load8x8_s offset=160(local.get $bp3))
local.tee $w2_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(v128.load8x8_s offset=168(local.get $bp3))
local.tee $w2_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(v128.load8x8_s offset=176(local.get $bp3))
local.tee $w2_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(v128.load8x8_s offset=184(local.get $bp3))
local.tee $w2_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(v128.load8x8_s offset=192(local.get $bp3))
local.tee $w2_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(v128.load8x8_s offset=200(local.get $bp3))
local.tee $w2_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(v128.load8x8_s offset=208(local.get $bp3))
local.tee $w2_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(v128.load8x8_s offset=216(local.get $bp3))
local.tee $w2_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(v128.load8x8_s offset=224(local.get $bp3))
local.tee $w2_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(v128.load8x8_s offset=232(local.get $bp3))
local.tee $w2_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(v128.load8x8_s offset=240(local.get $bp3))
local.tee $w2_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(v128.load8x8_s offset=248(local.get $bp3))
local.tee $w2_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
(v128.load8x8_s offset=256(local.get $bp3))
local.tee $w2_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
(v128.load8x8_s offset=264(local.get $bp3))
local.tee $w2_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
(v128.load8x8_s offset=272(local.get $bp3))
local.tee $w2_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
(v128.load8x8_s offset=280(local.get $bp3))
local.tee $w2_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
(v128.load8x8_s offset=288(local.get $bp3))
local.tee $w2_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
(v128.load8x8_s offset=296(local.get $bp3))
local.tee $w2_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
(v128.load8x8_s offset=304(local.get $bp3))
local.tee $w2_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
(v128.load8x8_s offset=312(local.get $bp3))
local.tee $w2_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
(v128.load8x8_s offset=320(local.get $bp3))
local.tee $w2_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
(v128.load8x8_s offset=328(local.get $bp3))
local.tee $w2_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
(v128.load8x8_s offset=336(local.get $bp3))
local.tee $w2_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
(v128.load8x8_s offset=344(local.get $bp3))
local.tee $w2_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
(v128.load8x8_s offset=352(local.get $bp3))
local.tee $w2_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
(v128.load8x8_s offset=360(local.get $bp3))
local.tee $w2_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
(v128.load8x8_s offset=368(local.get $bp3))
local.tee $w2_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
(v128.load8x8_s offset=376(local.get $bp3))
local.tee $w2_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
(v128.load8x8_s offset=384(local.get $bp3))
local.tee $w2_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
(v128.load8x8_s offset=392(local.get $bp3))
local.tee $w2_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
(v128.load8x8_s offset=400(local.get $bp3))
local.tee $w2_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
(v128.load8x8_s offset=408(local.get $bp3))
local.tee $w2_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
(v128.load8x8_s offset=416(local.get $bp3))
local.tee $w2_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
(v128.load8x8_s offset=424(local.get $bp3))
local.tee $w2_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
(v128.load8x8_s offset=432(local.get $bp3))
local.tee $w2_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
(v128.load8x8_s offset=440(local.get $bp3))
local.tee $w2_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
(v128.load8x8_s offset=448(local.get $bp3))
local.tee $w2_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
(v128.load8x8_s offset=456(local.get $bp3))
local.tee $w2_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
(v128.load8x8_s offset=464(local.get $bp3))
local.tee $w2_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
(v128.load8x8_s offset=472(local.get $bp3))
local.tee $w2_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
(v128.load8x8_s offset=480(local.get $bp3))
local.tee $w2_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
(v128.load8x8_s offset=488(local.get $bp3))
local.tee $w2_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
(v128.load8x8_s offset=496(local.get $bp3))
local.tee $w2_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
(v128.load8x8_s offset=504(local.get $bp3))
local.tee $w2_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x3_0
local.get $w2_1_0
(v128.load8x8_s offset=0(local.get $bp2))
local.get $w0_1_0
i16x8.sub
local.tee $w4_1_0
i16x8.sub
local.tee $w5_1_0
local.get $w1_1_0
i16x8.sub
local.tee $w3_1_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w2_1_1
(v128.load8x8_s offset=8(local.get $bp2))
local.get $w0_1_1
i16x8.sub
local.tee $w4_1_1
i16x8.sub
local.tee $w5_1_1
local.get $w1_1_1
i16x8.sub
local.tee $w3_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w2_1_2
(v128.load8x8_s offset=16(local.get $bp2))
local.get $w0_1_2
i16x8.sub
local.tee $w4_1_2
i16x8.sub
local.tee $w5_1_2
local.get $w1_1_2
i16x8.sub
local.tee $w3_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w2_1_3
(v128.load8x8_s offset=24(local.get $bp2))
local.get $w0_1_3
i16x8.sub
local.tee $w4_1_3
i16x8.sub
local.tee $w5_1_3
local.get $w1_1_3
i16x8.sub
local.tee $w3_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w2_1_4
(v128.load8x8_s offset=32(local.get $bp2))
local.get $w0_1_4
i16x8.sub
local.tee $w4_1_4
i16x8.sub
local.tee $w5_1_4
local.get $w1_1_4
i16x8.sub
local.tee $w3_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w2_1_5
(v128.load8x8_s offset=40(local.get $bp2))
local.get $w0_1_5
i16x8.sub
local.tee $w4_1_5
i16x8.sub
local.tee $w5_1_5
local.get $w1_1_5
i16x8.sub
local.tee $w3_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w2_1_6
(v128.load8x8_s offset=48(local.get $bp2))
local.get $w0_1_6
i16x8.sub
local.tee $w4_1_6
i16x8.sub
local.tee $w5_1_6
local.get $w1_1_6
i16x8.sub
local.tee $w3_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w2_1_7
(v128.load8x8_s offset=56(local.get $bp2))
local.get $w0_1_7
i16x8.sub
local.tee $w4_1_7
i16x8.sub
local.tee $w5_1_7
local.get $w1_1_7
i16x8.sub
local.tee $w3_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w2_1_8
(v128.load8x8_s offset=64(local.get $bp2))
local.get $w0_1_8
i16x8.sub
local.tee $w4_1_8
i16x8.sub
local.tee $w5_1_8
local.get $w1_1_8
i16x8.sub
local.tee $w3_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w2_1_9
(v128.load8x8_s offset=72(local.get $bp2))
local.get $w0_1_9
i16x8.sub
local.tee $w4_1_9
i16x8.sub
local.tee $w5_1_9
local.get $w1_1_9
i16x8.sub
local.tee $w3_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w2_1_10
(v128.load8x8_s offset=80(local.get $bp2))
local.get $w0_1_10
i16x8.sub
local.tee $w4_1_10
i16x8.sub
local.tee $w5_1_10
local.get $w1_1_10
i16x8.sub
local.tee $w3_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w2_1_11
(v128.load8x8_s offset=88(local.get $bp2))
local.get $w0_1_11
i16x8.sub
local.tee $w4_1_11
i16x8.sub
local.tee $w5_1_11
local.get $w1_1_11
i16x8.sub
local.tee $w3_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w2_1_12
(v128.load8x8_s offset=96(local.get $bp2))
local.get $w0_1_12
i16x8.sub
local.tee $w4_1_12
i16x8.sub
local.tee $w5_1_12
local.get $w1_1_12
i16x8.sub
local.tee $w3_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w2_1_13
(v128.load8x8_s offset=104(local.get $bp2))
local.get $w0_1_13
i16x8.sub
local.tee $w4_1_13
i16x8.sub
local.tee $w5_1_13
local.get $w1_1_13
i16x8.sub
local.tee $w3_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w2_1_14
(v128.load8x8_s offset=112(local.get $bp2))
local.get $w0_1_14
i16x8.sub
local.tee $w4_1_14
i16x8.sub
local.tee $w5_1_14
local.get $w1_1_14
i16x8.sub
local.tee $w3_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w2_1_15
(v128.load8x8_s offset=120(local.get $bp2))
local.get $w0_1_15
i16x8.sub
local.tee $w4_1_15
i16x8.sub
local.tee $w5_1_15
local.get $w1_1_15
i16x8.sub
local.tee $w3_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w2_1_16
(v128.load8x8_s offset=128(local.get $bp2))
local.get $w0_1_16
i16x8.sub
local.tee $w4_1_16
i16x8.sub
local.tee $w5_1_16
local.get $w1_1_16
i16x8.sub
local.tee $w3_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w2_1_17
(v128.load8x8_s offset=136(local.get $bp2))
local.get $w0_1_17
i16x8.sub
local.tee $w4_1_17
i16x8.sub
local.tee $w5_1_17
local.get $w1_1_17
i16x8.sub
local.tee $w3_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w2_1_18
(v128.load8x8_s offset=144(local.get $bp2))
local.get $w0_1_18
i16x8.sub
local.tee $w4_1_18
i16x8.sub
local.tee $w5_1_18
local.get $w1_1_18
i16x8.sub
local.tee $w3_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w2_1_19
(v128.load8x8_s offset=152(local.get $bp2))
local.get $w0_1_19
i16x8.sub
local.tee $w4_1_19
i16x8.sub
local.tee $w5_1_19
local.get $w1_1_19
i16x8.sub
local.tee $w3_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w2_1_20
(v128.load8x8_s offset=160(local.get $bp2))
local.get $w0_1_20
i16x8.sub
local.tee $w4_1_20
i16x8.sub
local.tee $w5_1_20
local.get $w1_1_20
i16x8.sub
local.tee $w3_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w2_1_21
(v128.load8x8_s offset=168(local.get $bp2))
local.get $w0_1_21
i16x8.sub
local.tee $w4_1_21
i16x8.sub
local.tee $w5_1_21
local.get $w1_1_21
i16x8.sub
local.tee $w3_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w2_1_22
(v128.load8x8_s offset=176(local.get $bp2))
local.get $w0_1_22
i16x8.sub
local.tee $w4_1_22
i16x8.sub
local.tee $w5_1_22
local.get $w1_1_22
i16x8.sub
local.tee $w3_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w2_1_23
(v128.load8x8_s offset=184(local.get $bp2))
local.get $w0_1_23
i16x8.sub
local.tee $w4_1_23
i16x8.sub
local.tee $w5_1_23
local.get $w1_1_23
i16x8.sub
local.tee $w3_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w2_1_24
(v128.load8x8_s offset=192(local.get $bp2))
local.get $w0_1_24
i16x8.sub
local.tee $w4_1_24
i16x8.sub
local.tee $w5_1_24
local.get $w1_1_24
i16x8.sub
local.tee $w3_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w2_1_25
(v128.load8x8_s offset=200(local.get $bp2))
local.get $w0_1_25
i16x8.sub
local.tee $w4_1_25
i16x8.sub
local.tee $w5_1_25
local.get $w1_1_25
i16x8.sub
local.tee $w3_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w2_1_26
(v128.load8x8_s offset=208(local.get $bp2))
local.get $w0_1_26
i16x8.sub
local.tee $w4_1_26
i16x8.sub
local.tee $w5_1_26
local.get $w1_1_26
i16x8.sub
local.tee $w3_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w2_1_27
(v128.load8x8_s offset=216(local.get $bp2))
local.get $w0_1_27
i16x8.sub
local.tee $w4_1_27
i16x8.sub
local.tee $w5_1_27
local.get $w1_1_27
i16x8.sub
local.tee $w3_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w2_1_28
(v128.load8x8_s offset=224(local.get $bp2))
local.get $w0_1_28
i16x8.sub
local.tee $w4_1_28
i16x8.sub
local.tee $w5_1_28
local.get $w1_1_28
i16x8.sub
local.tee $w3_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w2_1_29
(v128.load8x8_s offset=232(local.get $bp2))
local.get $w0_1_29
i16x8.sub
local.tee $w4_1_29
i16x8.sub
local.tee $w5_1_29
local.get $w1_1_29
i16x8.sub
local.tee $w3_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w2_1_30
(v128.load8x8_s offset=240(local.get $bp2))
local.get $w0_1_30
i16x8.sub
local.tee $w4_1_30
i16x8.sub
local.tee $w5_1_30
local.get $w1_1_30
i16x8.sub
local.tee $w3_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w2_1_31
(v128.load8x8_s offset=248(local.get $bp2))
local.get $w0_1_31
i16x8.sub
local.tee $w4_1_31
i16x8.sub
local.tee $w5_1_31
local.get $w1_1_31
i16x8.sub
local.tee $w3_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_32
local.get $w2_1_32
(v128.load8x8_s offset=256(local.get $bp2))
local.get $w0_1_32
i16x8.sub
local.tee $w4_1_32
i16x8.sub
local.tee $w5_1_32
local.get $w1_1_32
i16x8.sub
local.tee $w3_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_33
local.get $w2_1_33
(v128.load8x8_s offset=264(local.get $bp2))
local.get $w0_1_33
i16x8.sub
local.tee $w4_1_33
i16x8.sub
local.tee $w5_1_33
local.get $w1_1_33
i16x8.sub
local.tee $w3_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_34
local.get $w2_1_34
(v128.load8x8_s offset=272(local.get $bp2))
local.get $w0_1_34
i16x8.sub
local.tee $w4_1_34
i16x8.sub
local.tee $w5_1_34
local.get $w1_1_34
i16x8.sub
local.tee $w3_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_35
local.get $w2_1_35
(v128.load8x8_s offset=280(local.get $bp2))
local.get $w0_1_35
i16x8.sub
local.tee $w4_1_35
i16x8.sub
local.tee $w5_1_35
local.get $w1_1_35
i16x8.sub
local.tee $w3_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_36
local.get $w2_1_36
(v128.load8x8_s offset=288(local.get $bp2))
local.get $w0_1_36
i16x8.sub
local.tee $w4_1_36
i16x8.sub
local.tee $w5_1_36
local.get $w1_1_36
i16x8.sub
local.tee $w3_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_37
local.get $w2_1_37
(v128.load8x8_s offset=296(local.get $bp2))
local.get $w0_1_37
i16x8.sub
local.tee $w4_1_37
i16x8.sub
local.tee $w5_1_37
local.get $w1_1_37
i16x8.sub
local.tee $w3_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_38
local.get $w2_1_38
(v128.load8x8_s offset=304(local.get $bp2))
local.get $w0_1_38
i16x8.sub
local.tee $w4_1_38
i16x8.sub
local.tee $w5_1_38
local.get $w1_1_38
i16x8.sub
local.tee $w3_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_39
local.get $w2_1_39
(v128.load8x8_s offset=312(local.get $bp2))
local.get $w0_1_39
i16x8.sub
local.tee $w4_1_39
i16x8.sub
local.tee $w5_1_39
local.get $w1_1_39
i16x8.sub
local.tee $w3_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_40
local.get $w2_1_40
(v128.load8x8_s offset=320(local.get $bp2))
local.get $w0_1_40
i16x8.sub
local.tee $w4_1_40
i16x8.sub
local.tee $w5_1_40
local.get $w1_1_40
i16x8.sub
local.tee $w3_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_41
local.get $w2_1_41
(v128.load8x8_s offset=328(local.get $bp2))
local.get $w0_1_41
i16x8.sub
local.tee $w4_1_41
i16x8.sub
local.tee $w5_1_41
local.get $w1_1_41
i16x8.sub
local.tee $w3_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_42
local.get $w2_1_42
(v128.load8x8_s offset=336(local.get $bp2))
local.get $w0_1_42
i16x8.sub
local.tee $w4_1_42
i16x8.sub
local.tee $w5_1_42
local.get $w1_1_42
i16x8.sub
local.tee $w3_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_43
local.get $w2_1_43
(v128.load8x8_s offset=344(local.get $bp2))
local.get $w0_1_43
i16x8.sub
local.tee $w4_1_43
i16x8.sub
local.tee $w5_1_43
local.get $w1_1_43
i16x8.sub
local.tee $w3_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_44
local.get $w2_1_44
(v128.load8x8_s offset=352(local.get $bp2))
local.get $w0_1_44
i16x8.sub
local.tee $w4_1_44
i16x8.sub
local.tee $w5_1_44
local.get $w1_1_44
i16x8.sub
local.tee $w3_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_45
local.get $w2_1_45
(v128.load8x8_s offset=360(local.get $bp2))
local.get $w0_1_45
i16x8.sub
local.tee $w4_1_45
i16x8.sub
local.tee $w5_1_45
local.get $w1_1_45
i16x8.sub
local.tee $w3_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_46
local.get $w2_1_46
(v128.load8x8_s offset=368(local.get $bp2))
local.get $w0_1_46
i16x8.sub
local.tee $w4_1_46
i16x8.sub
local.tee $w5_1_46
local.get $w1_1_46
i16x8.sub
local.tee $w3_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_47
local.get $w2_1_47
(v128.load8x8_s offset=376(local.get $bp2))
local.get $w0_1_47
i16x8.sub
local.tee $w4_1_47
i16x8.sub
local.tee $w5_1_47
local.get $w1_1_47
i16x8.sub
local.tee $w3_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_48
local.get $w2_1_48
(v128.load8x8_s offset=384(local.get $bp2))
local.get $w0_1_48
i16x8.sub
local.tee $w4_1_48
i16x8.sub
local.tee $w5_1_48
local.get $w1_1_48
i16x8.sub
local.tee $w3_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_49
local.get $w2_1_49
(v128.load8x8_s offset=392(local.get $bp2))
local.get $w0_1_49
i16x8.sub
local.tee $w4_1_49
i16x8.sub
local.tee $w5_1_49
local.get $w1_1_49
i16x8.sub
local.tee $w3_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_50
local.get $w2_1_50
(v128.load8x8_s offset=400(local.get $bp2))
local.get $w0_1_50
i16x8.sub
local.tee $w4_1_50
i16x8.sub
local.tee $w5_1_50
local.get $w1_1_50
i16x8.sub
local.tee $w3_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_51
local.get $w2_1_51
(v128.load8x8_s offset=408(local.get $bp2))
local.get $w0_1_51
i16x8.sub
local.tee $w4_1_51
i16x8.sub
local.tee $w5_1_51
local.get $w1_1_51
i16x8.sub
local.tee $w3_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_52
local.get $w2_1_52
(v128.load8x8_s offset=416(local.get $bp2))
local.get $w0_1_52
i16x8.sub
local.tee $w4_1_52
i16x8.sub
local.tee $w5_1_52
local.get $w1_1_52
i16x8.sub
local.tee $w3_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_53
local.get $w2_1_53
(v128.load8x8_s offset=424(local.get $bp2))
local.get $w0_1_53
i16x8.sub
local.tee $w4_1_53
i16x8.sub
local.tee $w5_1_53
local.get $w1_1_53
i16x8.sub
local.tee $w3_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_54
local.get $w2_1_54
(v128.load8x8_s offset=432(local.get $bp2))
local.get $w0_1_54
i16x8.sub
local.tee $w4_1_54
i16x8.sub
local.tee $w5_1_54
local.get $w1_1_54
i16x8.sub
local.tee $w3_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_55
local.get $w2_1_55
(v128.load8x8_s offset=440(local.get $bp2))
local.get $w0_1_55
i16x8.sub
local.tee $w4_1_55
i16x8.sub
local.tee $w5_1_55
local.get $w1_1_55
i16x8.sub
local.tee $w3_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_56
local.get $w2_1_56
(v128.load8x8_s offset=448(local.get $bp2))
local.get $w0_1_56
i16x8.sub
local.tee $w4_1_56
i16x8.sub
local.tee $w5_1_56
local.get $w1_1_56
i16x8.sub
local.tee $w3_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_57
local.get $w2_1_57
(v128.load8x8_s offset=456(local.get $bp2))
local.get $w0_1_57
i16x8.sub
local.tee $w4_1_57
i16x8.sub
local.tee $w5_1_57
local.get $w1_1_57
i16x8.sub
local.tee $w3_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_58
local.get $w2_1_58
(v128.load8x8_s offset=464(local.get $bp2))
local.get $w0_1_58
i16x8.sub
local.tee $w4_1_58
i16x8.sub
local.tee $w5_1_58
local.get $w1_1_58
i16x8.sub
local.tee $w3_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_59
local.get $w2_1_59
(v128.load8x8_s offset=472(local.get $bp2))
local.get $w0_1_59
i16x8.sub
local.tee $w4_1_59
i16x8.sub
local.tee $w5_1_59
local.get $w1_1_59
i16x8.sub
local.tee $w3_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_60
local.get $w2_1_60
(v128.load8x8_s offset=480(local.get $bp2))
local.get $w0_1_60
i16x8.sub
local.tee $w4_1_60
i16x8.sub
local.tee $w5_1_60
local.get $w1_1_60
i16x8.sub
local.tee $w3_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_61
local.get $w2_1_61
(v128.load8x8_s offset=488(local.get $bp2))
local.get $w0_1_61
i16x8.sub
local.tee $w4_1_61
i16x8.sub
local.tee $w5_1_61
local.get $w1_1_61
i16x8.sub
local.tee $w3_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_62
local.get $w2_1_62
(v128.load8x8_s offset=496(local.get $bp2))
local.get $w0_1_62
i16x8.sub
local.tee $w4_1_62
i16x8.sub
local.tee $w5_1_62
local.get $w1_1_62
i16x8.sub
local.tee $w3_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_63
local.get $w2_1_63
(v128.load8x8_s offset=504(local.get $bp2))
local.get $w0_1_63
i16x8.sub
local.tee $w4_1_63
i16x8.sub
local.tee $w5_1_63
local.get $w1_1_63
i16x8.sub
local.tee $w3_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
local.get $x4_0
local.get $w4_1_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_32
local.get $w4_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_33
local.get $w4_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_34
local.get $w4_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_35
local.get $w4_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_36
local.get $w4_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_37
local.get $w4_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_38
local.get $w4_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_39
local.get $w4_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_40
local.get $w4_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_41
local.get $w4_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_42
local.get $w4_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_43
local.get $w4_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_44
local.get $w4_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_45
local.get $w4_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_46
local.get $w4_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_47
local.get $w4_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_48
local.get $w4_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_49
local.get $w4_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_50
local.get $w4_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_51
local.get $w4_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_52
local.get $w4_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_53
local.get $w4_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_54
local.get $w4_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_55
local.get $w4_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_56
local.get $w4_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_57
local.get $w4_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_58
local.get $w4_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_59
local.get $w4_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_60
local.get $w4_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_61
local.get $w4_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_62
local.get $w4_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_63
local.get $w4_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
local.get $x5_0
local.get $w5_1_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $x6_0
local.get $w5_1_0
local.get $w0_1_0
i16x8.sub
local.tee $w6_1_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w5_1_1
local.get $w0_1_1
i16x8.sub
local.tee $w6_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w5_1_2
local.get $w0_1_2
i16x8.sub
local.tee $w6_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w5_1_3
local.get $w0_1_3
i16x8.sub
local.tee $w6_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w5_1_4
local.get $w0_1_4
i16x8.sub
local.tee $w6_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w5_1_5
local.get $w0_1_5
i16x8.sub
local.tee $w6_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w5_1_6
local.get $w0_1_6
i16x8.sub
local.tee $w6_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w5_1_7
local.get $w0_1_7
i16x8.sub
local.tee $w6_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w5_1_8
local.get $w0_1_8
i16x8.sub
local.tee $w6_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w5_1_9
local.get $w0_1_9
i16x8.sub
local.tee $w6_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w5_1_10
local.get $w0_1_10
i16x8.sub
local.tee $w6_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w5_1_11
local.get $w0_1_11
i16x8.sub
local.tee $w6_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w5_1_12
local.get $w0_1_12
i16x8.sub
local.tee $w6_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w5_1_13
local.get $w0_1_13
i16x8.sub
local.tee $w6_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w5_1_14
local.get $w0_1_14
i16x8.sub
local.tee $w6_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w5_1_15
local.get $w0_1_15
i16x8.sub
local.tee $w6_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w5_1_16
local.get $w0_1_16
i16x8.sub
local.tee $w6_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w5_1_17
local.get $w0_1_17
i16x8.sub
local.tee $w6_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w5_1_18
local.get $w0_1_18
i16x8.sub
local.tee $w6_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w5_1_19
local.get $w0_1_19
i16x8.sub
local.tee $w6_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w5_1_20
local.get $w0_1_20
i16x8.sub
local.tee $w6_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w5_1_21
local.get $w0_1_21
i16x8.sub
local.tee $w6_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w5_1_22
local.get $w0_1_22
i16x8.sub
local.tee $w6_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w5_1_23
local.get $w0_1_23
i16x8.sub
local.tee $w6_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w5_1_24
local.get $w0_1_24
i16x8.sub
local.tee $w6_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w5_1_25
local.get $w0_1_25
i16x8.sub
local.tee $w6_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w5_1_26
local.get $w0_1_26
i16x8.sub
local.tee $w6_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w5_1_27
local.get $w0_1_27
i16x8.sub
local.tee $w6_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w5_1_28
local.get $w0_1_28
i16x8.sub
local.tee $w6_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w5_1_29
local.get $w0_1_29
i16x8.sub
local.tee $w6_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w5_1_30
local.get $w0_1_30
i16x8.sub
local.tee $w6_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w5_1_31
local.get $w0_1_31
i16x8.sub
local.tee $w6_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_32
local.get $w5_1_32
local.get $w0_1_32
i16x8.sub
local.tee $w6_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_33
local.get $w5_1_33
local.get $w0_1_33
i16x8.sub
local.tee $w6_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_34
local.get $w5_1_34
local.get $w0_1_34
i16x8.sub
local.tee $w6_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_35
local.get $w5_1_35
local.get $w0_1_35
i16x8.sub
local.tee $w6_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_36
local.get $w5_1_36
local.get $w0_1_36
i16x8.sub
local.tee $w6_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_37
local.get $w5_1_37
local.get $w0_1_37
i16x8.sub
local.tee $w6_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_38
local.get $w5_1_38
local.get $w0_1_38
i16x8.sub
local.tee $w6_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_39
local.get $w5_1_39
local.get $w0_1_39
i16x8.sub
local.tee $w6_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_40
local.get $w5_1_40
local.get $w0_1_40
i16x8.sub
local.tee $w6_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_41
local.get $w5_1_41
local.get $w0_1_41
i16x8.sub
local.tee $w6_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_42
local.get $w5_1_42
local.get $w0_1_42
i16x8.sub
local.tee $w6_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_43
local.get $w5_1_43
local.get $w0_1_43
i16x8.sub
local.tee $w6_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_44
local.get $w5_1_44
local.get $w0_1_44
i16x8.sub
local.tee $w6_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_45
local.get $w5_1_45
local.get $w0_1_45
i16x8.sub
local.tee $w6_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_46
local.get $w5_1_46
local.get $w0_1_46
i16x8.sub
local.tee $w6_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_47
local.get $w5_1_47
local.get $w0_1_47
i16x8.sub
local.tee $w6_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_48
local.get $w5_1_48
local.get $w0_1_48
i16x8.sub
local.tee $w6_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_49
local.get $w5_1_49
local.get $w0_1_49
i16x8.sub
local.tee $w6_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_50
local.get $w5_1_50
local.get $w0_1_50
i16x8.sub
local.tee $w6_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_51
local.get $w5_1_51
local.get $w0_1_51
i16x8.sub
local.tee $w6_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_52
local.get $w5_1_52
local.get $w0_1_52
i16x8.sub
local.tee $w6_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_53
local.get $w5_1_53
local.get $w0_1_53
i16x8.sub
local.tee $w6_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_54
local.get $w5_1_54
local.get $w0_1_54
i16x8.sub
local.tee $w6_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_55
local.get $w5_1_55
local.get $w0_1_55
i16x8.sub
local.tee $w6_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_56
local.get $w5_1_56
local.get $w0_1_56
i16x8.sub
local.tee $w6_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_57
local.get $w5_1_57
local.get $w0_1_57
i16x8.sub
local.tee $w6_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_58
local.get $w5_1_58
local.get $w0_1_58
i16x8.sub
local.tee $w6_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_59
local.get $w5_1_59
local.get $w0_1_59
i16x8.sub
local.tee $w6_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_60
local.get $w5_1_60
local.get $w0_1_60
i16x8.sub
local.tee $w6_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_61
local.get $w5_1_61
local.get $w0_1_61
i16x8.sub
local.tee $w6_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_62
local.get $w5_1_62
local.get $w0_1_62
i16x8.sub
local.tee $w6_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_63
local.get $w5_1_63
local.get $w0_1_63
i16x8.sub
local.tee $w6_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=32
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
local.get $yp
v128.load offset=48
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
(if(local.get $keep)(then
local.get $yp1
local.get $yp1
v128.load offset=32
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp1
local.get $yp1
v128.load offset=48
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48
))
(local.set $bp0(i32.add(local.get $wp0)(i32.mul(local.get $cols)(i32.const 4))))
(local.set $bp1(i32.add(local.get $wp1)(i32.mul(local.get $cols)(i32.const 4))))
(local.set $bp2(i32.add(local.get $wp2)(i32.mul(local.get $cols)(i32.const 4))))
(local.set $bp3(i32.add(local.get $wp3)(i32.mul(local.get $cols)(i32.const 4))))
local.get $x0_0
(v128.load8x8_s offset=0(local.get $bp0))
local.tee $w0_2_0
i32x4.dot_i16x8_s
local.get $x0_1
(v128.load8x8_s offset=8(local.get $bp0))
local.tee $w0_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(v128.load8x8_s offset=16(local.get $bp0))
local.tee $w0_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(v128.load8x8_s offset=24(local.get $bp0))
local.tee $w0_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(v128.load8x8_s offset=32(local.get $bp0))
local.tee $w0_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(v128.load8x8_s offset=40(local.get $bp0))
local.tee $w0_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(v128.load8x8_s offset=48(local.get $bp0))
local.tee $w0_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(v128.load8x8_s offset=56(local.get $bp0))
local.tee $w0_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(v128.load8x8_s offset=64(local.get $bp0))
local.tee $w0_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(v128.load8x8_s offset=72(local.get $bp0))
local.tee $w0_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(v128.load8x8_s offset=80(local.get $bp0))
local.tee $w0_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(v128.load8x8_s offset=88(local.get $bp0))
local.tee $w0_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(v128.load8x8_s offset=96(local.get $bp0))
local.tee $w0_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(v128.load8x8_s offset=104(local.get $bp0))
local.tee $w0_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(v128.load8x8_s offset=112(local.get $bp0))
local.tee $w0_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(v128.load8x8_s offset=120(local.get $bp0))
local.tee $w0_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(v128.load8x8_s offset=128(local.get $bp0))
local.tee $w0_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(v128.load8x8_s offset=136(local.get $bp0))
local.tee $w0_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(v128.load8x8_s offset=144(local.get $bp0))
local.tee $w0_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(v128.load8x8_s offset=152(local.get $bp0))
local.tee $w0_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(v128.load8x8_s offset=160(local.get $bp0))
local.tee $w0_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(v128.load8x8_s offset=168(local.get $bp0))
local.tee $w0_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(v128.load8x8_s offset=176(local.get $bp0))
local.tee $w0_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(v128.load8x8_s offset=184(local.get $bp0))
local.tee $w0_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(v128.load8x8_s offset=192(local.get $bp0))
local.tee $w0_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(v128.load8x8_s offset=200(local.get $bp0))
local.tee $w0_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(v128.load8x8_s offset=208(local.get $bp0))
local.tee $w0_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(v128.load8x8_s offset=216(local.get $bp0))
local.tee $w0_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(v128.load8x8_s offset=224(local.get $bp0))
local.tee $w0_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(v128.load8x8_s offset=232(local.get $bp0))
local.tee $w0_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(v128.load8x8_s offset=240(local.get $bp0))
local.tee $w0_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(v128.load8x8_s offset=248(local.get $bp0))
local.tee $w0_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
(v128.load8x8_s offset=256(local.get $bp0))
local.tee $w0_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
(v128.load8x8_s offset=264(local.get $bp0))
local.tee $w0_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
(v128.load8x8_s offset=272(local.get $bp0))
local.tee $w0_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
(v128.load8x8_s offset=280(local.get $bp0))
local.tee $w0_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
(v128.load8x8_s offset=288(local.get $bp0))
local.tee $w0_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
(v128.load8x8_s offset=296(local.get $bp0))
local.tee $w0_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
(v128.load8x8_s offset=304(local.get $bp0))
local.tee $w0_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
(v128.load8x8_s offset=312(local.get $bp0))
local.tee $w0_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
(v128.load8x8_s offset=320(local.get $bp0))
local.tee $w0_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
(v128.load8x8_s offset=328(local.get $bp0))
local.tee $w0_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
(v128.load8x8_s offset=336(local.get $bp0))
local.tee $w0_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
(v128.load8x8_s offset=344(local.get $bp0))
local.tee $w0_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
(v128.load8x8_s offset=352(local.get $bp0))
local.tee $w0_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
(v128.load8x8_s offset=360(local.get $bp0))
local.tee $w0_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
(v128.load8x8_s offset=368(local.get $bp0))
local.tee $w0_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
(v128.load8x8_s offset=376(local.get $bp0))
local.tee $w0_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
(v128.load8x8_s offset=384(local.get $bp0))
local.tee $w0_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
(v128.load8x8_s offset=392(local.get $bp0))
local.tee $w0_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
(v128.load8x8_s offset=400(local.get $bp0))
local.tee $w0_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
(v128.load8x8_s offset=408(local.get $bp0))
local.tee $w0_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
(v128.load8x8_s offset=416(local.get $bp0))
local.tee $w0_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
(v128.load8x8_s offset=424(local.get $bp0))
local.tee $w0_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
(v128.load8x8_s offset=432(local.get $bp0))
local.tee $w0_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
(v128.load8x8_s offset=440(local.get $bp0))
local.tee $w0_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
(v128.load8x8_s offset=448(local.get $bp0))
local.tee $w0_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
(v128.load8x8_s offset=456(local.get $bp0))
local.tee $w0_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
(v128.load8x8_s offset=464(local.get $bp0))
local.tee $w0_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
(v128.load8x8_s offset=472(local.get $bp0))
local.tee $w0_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
(v128.load8x8_s offset=480(local.get $bp0))
local.tee $w0_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
(v128.load8x8_s offset=488(local.get $bp0))
local.tee $w0_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
(v128.load8x8_s offset=496(local.get $bp0))
local.tee $w0_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
(v128.load8x8_s offset=504(local.get $bp0))
local.tee $w0_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
(v128.load8x8_s offset=0(local.get $bp1))
local.tee $w1_2_0
i32x4.dot_i16x8_s
local.get $x1_1
(v128.load8x8_s offset=8(local.get $bp1))
local.tee $w1_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
(v128.load8x8_s offset=16(local.get $bp1))
local.tee $w1_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
(v128.load8x8_s offset=24(local.get $bp1))
local.tee $w1_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
(v128.load8x8_s offset=32(local.get $bp1))
local.tee $w1_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
(v128.load8x8_s offset=40(local.get $bp1))
local.tee $w1_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
(v128.load8x8_s offset=48(local.get $bp1))
local.tee $w1_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
(v128.load8x8_s offset=56(local.get $bp1))
local.tee $w1_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
(v128.load8x8_s offset=64(local.get $bp1))
local.tee $w1_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
(v128.load8x8_s offset=72(local.get $bp1))
local.tee $w1_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
(v128.load8x8_s offset=80(local.get $bp1))
local.tee $w1_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
(v128.load8x8_s offset=88(local.get $bp1))
local.tee $w1_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
(v128.load8x8_s offset=96(local.get $bp1))
local.tee $w1_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
(v128.load8x8_s offset=104(local.get $bp1))
local.tee $w1_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
(v128.load8x8_s offset=112(local.get $bp1))
local.tee $w1_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
(v128.load8x8_s offset=120(local.get $bp1))
local.tee $w1_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
(v128.load8x8_s offset=128(local.get $bp1))
local.tee $w1_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
(v128.load8x8_s offset=136(local.get $bp1))
local.tee $w1_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
(v128.load8x8_s offset=144(local.get $bp1))
local.tee $w1_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
(v128.load8x8_s offset=152(local.get $bp1))
local.tee $w1_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
(v128.load8x8_s offset=160(local.get $bp1))
local.tee $w1_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
(v128.load8x8_s offset=168(local.get $bp1))
local.tee $w1_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
(v128.load8x8_s offset=176(local.get $bp1))
local.tee $w1_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
(v128.load8x8_s offset=184(local.get $bp1))
local.tee $w1_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
(v128.load8x8_s offset=192(local.get $bp1))
local.tee $w1_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
(v128.load8x8_s offset=200(local.get $bp1))
local.tee $w1_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
(v128.load8x8_s offset=208(local.get $bp1))
local.tee $w1_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
(v128.load8x8_s offset=216(local.get $bp1))
local.tee $w1_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
(v128.load8x8_s offset=224(local.get $bp1))
local.tee $w1_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
(v128.load8x8_s offset=232(local.get $bp1))
local.tee $w1_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
(v128.load8x8_s offset=240(local.get $bp1))
local.tee $w1_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
(v128.load8x8_s offset=248(local.get $bp1))
local.tee $w1_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
(v128.load8x8_s offset=256(local.get $bp1))
local.tee $w1_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
(v128.load8x8_s offset=264(local.get $bp1))
local.tee $w1_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
(v128.load8x8_s offset=272(local.get $bp1))
local.tee $w1_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
(v128.load8x8_s offset=280(local.get $bp1))
local.tee $w1_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
(v128.load8x8_s offset=288(local.get $bp1))
local.tee $w1_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
(v128.load8x8_s offset=296(local.get $bp1))
local.tee $w1_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
(v128.load8x8_s offset=304(local.get $bp1))
local.tee $w1_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
(v128.load8x8_s offset=312(local.get $bp1))
local.tee $w1_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
(v128.load8x8_s offset=320(local.get $bp1))
local.tee $w1_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
(v128.load8x8_s offset=328(local.get $bp1))
local.tee $w1_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
(v128.load8x8_s offset=336(local.get $bp1))
local.tee $w1_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
(v128.load8x8_s offset=344(local.get $bp1))
local.tee $w1_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
(v128.load8x8_s offset=352(local.get $bp1))
local.tee $w1_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
(v128.load8x8_s offset=360(local.get $bp1))
local.tee $w1_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
(v128.load8x8_s offset=368(local.get $bp1))
local.tee $w1_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
(v128.load8x8_s offset=376(local.get $bp1))
local.tee $w1_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
(v128.load8x8_s offset=384(local.get $bp1))
local.tee $w1_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
(v128.load8x8_s offset=392(local.get $bp1))
local.tee $w1_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
(v128.load8x8_s offset=400(local.get $bp1))
local.tee $w1_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
(v128.load8x8_s offset=408(local.get $bp1))
local.tee $w1_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
(v128.load8x8_s offset=416(local.get $bp1))
local.tee $w1_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
(v128.load8x8_s offset=424(local.get $bp1))
local.tee $w1_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
(v128.load8x8_s offset=432(local.get $bp1))
local.tee $w1_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
(v128.load8x8_s offset=440(local.get $bp1))
local.tee $w1_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
(v128.load8x8_s offset=448(local.get $bp1))
local.tee $w1_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
(v128.load8x8_s offset=456(local.get $bp1))
local.tee $w1_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
(v128.load8x8_s offset=464(local.get $bp1))
local.tee $w1_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
(v128.load8x8_s offset=472(local.get $bp1))
local.tee $w1_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
(v128.load8x8_s offset=480(local.get $bp1))
local.tee $w1_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
(v128.load8x8_s offset=488(local.get $bp1))
local.tee $w1_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
(v128.load8x8_s offset=496(local.get $bp1))
local.tee $w1_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
(v128.load8x8_s offset=504(local.get $bp1))
local.tee $w1_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
(v128.load8x8_s offset=0(local.get $bp3))
local.tee $w2_2_0
i32x4.dot_i16x8_s
local.get $x2_1
(v128.load8x8_s offset=8(local.get $bp3))
local.tee $w2_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(v128.load8x8_s offset=16(local.get $bp3))
local.tee $w2_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(v128.load8x8_s offset=24(local.get $bp3))
local.tee $w2_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(v128.load8x8_s offset=32(local.get $bp3))
local.tee $w2_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(v128.load8x8_s offset=40(local.get $bp3))
local.tee $w2_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(v128.load8x8_s offset=48(local.get $bp3))
local.tee $w2_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(v128.load8x8_s offset=56(local.get $bp3))
local.tee $w2_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(v128.load8x8_s offset=64(local.get $bp3))
local.tee $w2_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(v128.load8x8_s offset=72(local.get $bp3))
local.tee $w2_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(v128.load8x8_s offset=80(local.get $bp3))
local.tee $w2_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(v128.load8x8_s offset=88(local.get $bp3))
local.tee $w2_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(v128.load8x8_s offset=96(local.get $bp3))
local.tee $w2_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(v128.load8x8_s offset=104(local.get $bp3))
local.tee $w2_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(v128.load8x8_s offset=112(local.get $bp3))
local.tee $w2_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(v128.load8x8_s offset=120(local.get $bp3))
local.tee $w2_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(v128.load8x8_s offset=128(local.get $bp3))
local.tee $w2_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(v128.load8x8_s offset=136(local.get $bp3))
local.tee $w2_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(v128.load8x8_s offset=144(local.get $bp3))
local.tee $w2_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(v128.load8x8_s offset=152(local.get $bp3))
local.tee $w2_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(v128.load8x8_s offset=160(local.get $bp3))
local.tee $w2_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(v128.load8x8_s offset=168(local.get $bp3))
local.tee $w2_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(v128.load8x8_s offset=176(local.get $bp3))
local.tee $w2_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(v128.load8x8_s offset=184(local.get $bp3))
local.tee $w2_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(v128.load8x8_s offset=192(local.get $bp3))
local.tee $w2_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(v128.load8x8_s offset=200(local.get $bp3))
local.tee $w2_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(v128.load8x8_s offset=208(local.get $bp3))
local.tee $w2_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(v128.load8x8_s offset=216(local.get $bp3))
local.tee $w2_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(v128.load8x8_s offset=224(local.get $bp3))
local.tee $w2_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(v128.load8x8_s offset=232(local.get $bp3))
local.tee $w2_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(v128.load8x8_s offset=240(local.get $bp3))
local.tee $w2_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(v128.load8x8_s offset=248(local.get $bp3))
local.tee $w2_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
(v128.load8x8_s offset=256(local.get $bp3))
local.tee $w2_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
(v128.load8x8_s offset=264(local.get $bp3))
local.tee $w2_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
(v128.load8x8_s offset=272(local.get $bp3))
local.tee $w2_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
(v128.load8x8_s offset=280(local.get $bp3))
local.tee $w2_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
(v128.load8x8_s offset=288(local.get $bp3))
local.tee $w2_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
(v128.load8x8_s offset=296(local.get $bp3))
local.tee $w2_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
(v128.load8x8_s offset=304(local.get $bp3))
local.tee $w2_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
(v128.load8x8_s offset=312(local.get $bp3))
local.tee $w2_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
(v128.load8x8_s offset=320(local.get $bp3))
local.tee $w2_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
(v128.load8x8_s offset=328(local.get $bp3))
local.tee $w2_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
(v128.load8x8_s offset=336(local.get $bp3))
local.tee $w2_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
(v128.load8x8_s offset=344(local.get $bp3))
local.tee $w2_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
(v128.load8x8_s offset=352(local.get $bp3))
local.tee $w2_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
(v128.load8x8_s offset=360(local.get $bp3))
local.tee $w2_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
(v128.load8x8_s offset=368(local.get $bp3))
local.tee $w2_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
(v128.load8x8_s offset=376(local.get $bp3))
local.tee $w2_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
(v128.load8x8_s offset=384(local.get $bp3))
local.tee $w2_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
(v128.load8x8_s offset=392(local.get $bp3))
local.tee $w2_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
(v128.load8x8_s offset=400(local.get $bp3))
local.tee $w2_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
(v128.load8x8_s offset=408(local.get $bp3))
local.tee $w2_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
(v128.load8x8_s offset=416(local.get $bp3))
local.tee $w2_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
(v128.load8x8_s offset=424(local.get $bp3))
local.tee $w2_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
(v128.load8x8_s offset=432(local.get $bp3))
local.tee $w2_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
(v128.load8x8_s offset=440(local.get $bp3))
local.tee $w2_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
(v128.load8x8_s offset=448(local.get $bp3))
local.tee $w2_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
(v128.load8x8_s offset=456(local.get $bp3))
local.tee $w2_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
(v128.load8x8_s offset=464(local.get $bp3))
local.tee $w2_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
(v128.load8x8_s offset=472(local.get $bp3))
local.tee $w2_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
(v128.load8x8_s offset=480(local.get $bp3))
local.tee $w2_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
(v128.load8x8_s offset=488(local.get $bp3))
local.tee $w2_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
(v128.load8x8_s offset=496(local.get $bp3))
local.tee $w2_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
(v128.load8x8_s offset=504(local.get $bp3))
local.tee $w2_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x3_0
local.get $w2_2_0
(v128.load8x8_s offset=0(local.get $bp2))
local.get $w0_2_0
i16x8.sub
local.tee $w4_2_0
i16x8.sub
local.tee $w5_2_0
local.get $w1_2_0
i16x8.sub
local.tee $w3_2_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w2_2_1
(v128.load8x8_s offset=8(local.get $bp2))
local.get $w0_2_1
i16x8.sub
local.tee $w4_2_1
i16x8.sub
local.tee $w5_2_1
local.get $w1_2_1
i16x8.sub
local.tee $w3_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w2_2_2
(v128.load8x8_s offset=16(local.get $bp2))
local.get $w0_2_2
i16x8.sub
local.tee $w4_2_2
i16x8.sub
local.tee $w5_2_2
local.get $w1_2_2
i16x8.sub
local.tee $w3_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w2_2_3
(v128.load8x8_s offset=24(local.get $bp2))
local.get $w0_2_3
i16x8.sub
local.tee $w4_2_3
i16x8.sub
local.tee $w5_2_3
local.get $w1_2_3
i16x8.sub
local.tee $w3_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w2_2_4
(v128.load8x8_s offset=32(local.get $bp2))
local.get $w0_2_4
i16x8.sub
local.tee $w4_2_4
i16x8.sub
local.tee $w5_2_4
local.get $w1_2_4
i16x8.sub
local.tee $w3_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w2_2_5
(v128.load8x8_s offset=40(local.get $bp2))
local.get $w0_2_5
i16x8.sub
local.tee $w4_2_5
i16x8.sub
local.tee $w5_2_5
local.get $w1_2_5
i16x8.sub
local.tee $w3_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w2_2_6
(v128.load8x8_s offset=48(local.get $bp2))
local.get $w0_2_6
i16x8.sub
local.tee $w4_2_6
i16x8.sub
local.tee $w5_2_6
local.get $w1_2_6
i16x8.sub
local.tee $w3_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w2_2_7
(v128.load8x8_s offset=56(local.get $bp2))
local.get $w0_2_7
i16x8.sub
local.tee $w4_2_7
i16x8.sub
local.tee $w5_2_7
local.get $w1_2_7
i16x8.sub
local.tee $w3_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w2_2_8
(v128.load8x8_s offset=64(local.get $bp2))
local.get $w0_2_8
i16x8.sub
local.tee $w4_2_8
i16x8.sub
local.tee $w5_2_8
local.get $w1_2_8
i16x8.sub
local.tee $w3_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w2_2_9
(v128.load8x8_s offset=72(local.get $bp2))
local.get $w0_2_9
i16x8.sub
local.tee $w4_2_9
i16x8.sub
local.tee $w5_2_9
local.get $w1_2_9
i16x8.sub
local.tee $w3_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w2_2_10
(v128.load8x8_s offset=80(local.get $bp2))
local.get $w0_2_10
i16x8.sub
local.tee $w4_2_10
i16x8.sub
local.tee $w5_2_10
local.get $w1_2_10
i16x8.sub
local.tee $w3_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w2_2_11
(v128.load8x8_s offset=88(local.get $bp2))
local.get $w0_2_11
i16x8.sub
local.tee $w4_2_11
i16x8.sub
local.tee $w5_2_11
local.get $w1_2_11
i16x8.sub
local.tee $w3_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w2_2_12
(v128.load8x8_s offset=96(local.get $bp2))
local.get $w0_2_12
i16x8.sub
local.tee $w4_2_12
i16x8.sub
local.tee $w5_2_12
local.get $w1_2_12
i16x8.sub
local.tee $w3_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w2_2_13
(v128.load8x8_s offset=104(local.get $bp2))
local.get $w0_2_13
i16x8.sub
local.tee $w4_2_13
i16x8.sub
local.tee $w5_2_13
local.get $w1_2_13
i16x8.sub
local.tee $w3_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w2_2_14
(v128.load8x8_s offset=112(local.get $bp2))
local.get $w0_2_14
i16x8.sub
local.tee $w4_2_14
i16x8.sub
local.tee $w5_2_14
local.get $w1_2_14
i16x8.sub
local.tee $w3_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w2_2_15
(v128.load8x8_s offset=120(local.get $bp2))
local.get $w0_2_15
i16x8.sub
local.tee $w4_2_15
i16x8.sub
local.tee $w5_2_15
local.get $w1_2_15
i16x8.sub
local.tee $w3_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w2_2_16
(v128.load8x8_s offset=128(local.get $bp2))
local.get $w0_2_16
i16x8.sub
local.tee $w4_2_16
i16x8.sub
local.tee $w5_2_16
local.get $w1_2_16
i16x8.sub
local.tee $w3_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w2_2_17
(v128.load8x8_s offset=136(local.get $bp2))
local.get $w0_2_17
i16x8.sub
local.tee $w4_2_17
i16x8.sub
local.tee $w5_2_17
local.get $w1_2_17
i16x8.sub
local.tee $w3_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w2_2_18
(v128.load8x8_s offset=144(local.get $bp2))
local.get $w0_2_18
i16x8.sub
local.tee $w4_2_18
i16x8.sub
local.tee $w5_2_18
local.get $w1_2_18
i16x8.sub
local.tee $w3_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w2_2_19
(v128.load8x8_s offset=152(local.get $bp2))
local.get $w0_2_19
i16x8.sub
local.tee $w4_2_19
i16x8.sub
local.tee $w5_2_19
local.get $w1_2_19
i16x8.sub
local.tee $w3_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w2_2_20
(v128.load8x8_s offset=160(local.get $bp2))
local.get $w0_2_20
i16x8.sub
local.tee $w4_2_20
i16x8.sub
local.tee $w5_2_20
local.get $w1_2_20
i16x8.sub
local.tee $w3_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w2_2_21
(v128.load8x8_s offset=168(local.get $bp2))
local.get $w0_2_21
i16x8.sub
local.tee $w4_2_21
i16x8.sub
local.tee $w5_2_21
local.get $w1_2_21
i16x8.sub
local.tee $w3_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w2_2_22
(v128.load8x8_s offset=176(local.get $bp2))
local.get $w0_2_22
i16x8.sub
local.tee $w4_2_22
i16x8.sub
local.tee $w5_2_22
local.get $w1_2_22
i16x8.sub
local.tee $w3_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w2_2_23
(v128.load8x8_s offset=184(local.get $bp2))
local.get $w0_2_23
i16x8.sub
local.tee $w4_2_23
i16x8.sub
local.tee $w5_2_23
local.get $w1_2_23
i16x8.sub
local.tee $w3_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w2_2_24
(v128.load8x8_s offset=192(local.get $bp2))
local.get $w0_2_24
i16x8.sub
local.tee $w4_2_24
i16x8.sub
local.tee $w5_2_24
local.get $w1_2_24
i16x8.sub
local.tee $w3_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w2_2_25
(v128.load8x8_s offset=200(local.get $bp2))
local.get $w0_2_25
i16x8.sub
local.tee $w4_2_25
i16x8.sub
local.tee $w5_2_25
local.get $w1_2_25
i16x8.sub
local.tee $w3_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w2_2_26
(v128.load8x8_s offset=208(local.get $bp2))
local.get $w0_2_26
i16x8.sub
local.tee $w4_2_26
i16x8.sub
local.tee $w5_2_26
local.get $w1_2_26
i16x8.sub
local.tee $w3_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w2_2_27
(v128.load8x8_s offset=216(local.get $bp2))
local.get $w0_2_27
i16x8.sub
local.tee $w4_2_27
i16x8.sub
local.tee $w5_2_27
local.get $w1_2_27
i16x8.sub
local.tee $w3_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w2_2_28
(v128.load8x8_s offset=224(local.get $bp2))
local.get $w0_2_28
i16x8.sub
local.tee $w4_2_28
i16x8.sub
local.tee $w5_2_28
local.get $w1_2_28
i16x8.sub
local.tee $w3_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w2_2_29
(v128.load8x8_s offset=232(local.get $bp2))
local.get $w0_2_29
i16x8.sub
local.tee $w4_2_29
i16x8.sub
local.tee $w5_2_29
local.get $w1_2_29
i16x8.sub
local.tee $w3_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w2_2_30
(v128.load8x8_s offset=240(local.get $bp2))
local.get $w0_2_30
i16x8.sub
local.tee $w4_2_30
i16x8.sub
local.tee $w5_2_30
local.get $w1_2_30
i16x8.sub
local.tee $w3_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w2_2_31
(v128.load8x8_s offset=248(local.get $bp2))
local.get $w0_2_31
i16x8.sub
local.tee $w4_2_31
i16x8.sub
local.tee $w5_2_31
local.get $w1_2_31
i16x8.sub
local.tee $w3_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_32
local.get $w2_2_32
(v128.load8x8_s offset=256(local.get $bp2))
local.get $w0_2_32
i16x8.sub
local.tee $w4_2_32
i16x8.sub
local.tee $w5_2_32
local.get $w1_2_32
i16x8.sub
local.tee $w3_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_33
local.get $w2_2_33
(v128.load8x8_s offset=264(local.get $bp2))
local.get $w0_2_33
i16x8.sub
local.tee $w4_2_33
i16x8.sub
local.tee $w5_2_33
local.get $w1_2_33
i16x8.sub
local.tee $w3_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_34
local.get $w2_2_34
(v128.load8x8_s offset=272(local.get $bp2))
local.get $w0_2_34
i16x8.sub
local.tee $w4_2_34
i16x8.sub
local.tee $w5_2_34
local.get $w1_2_34
i16x8.sub
local.tee $w3_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_35
local.get $w2_2_35
(v128.load8x8_s offset=280(local.get $bp2))
local.get $w0_2_35
i16x8.sub
local.tee $w4_2_35
i16x8.sub
local.tee $w5_2_35
local.get $w1_2_35
i16x8.sub
local.tee $w3_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_36
local.get $w2_2_36
(v128.load8x8_s offset=288(local.get $bp2))
local.get $w0_2_36
i16x8.sub
local.tee $w4_2_36
i16x8.sub
local.tee $w5_2_36
local.get $w1_2_36
i16x8.sub
local.tee $w3_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_37
local.get $w2_2_37
(v128.load8x8_s offset=296(local.get $bp2))
local.get $w0_2_37
i16x8.sub
local.tee $w4_2_37
i16x8.sub
local.tee $w5_2_37
local.get $w1_2_37
i16x8.sub
local.tee $w3_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_38
local.get $w2_2_38
(v128.load8x8_s offset=304(local.get $bp2))
local.get $w0_2_38
i16x8.sub
local.tee $w4_2_38
i16x8.sub
local.tee $w5_2_38
local.get $w1_2_38
i16x8.sub
local.tee $w3_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_39
local.get $w2_2_39
(v128.load8x8_s offset=312(local.get $bp2))
local.get $w0_2_39
i16x8.sub
local.tee $w4_2_39
i16x8.sub
local.tee $w5_2_39
local.get $w1_2_39
i16x8.sub
local.tee $w3_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_40
local.get $w2_2_40
(v128.load8x8_s offset=320(local.get $bp2))
local.get $w0_2_40
i16x8.sub
local.tee $w4_2_40
i16x8.sub
local.tee $w5_2_40
local.get $w1_2_40
i16x8.sub
local.tee $w3_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_41
local.get $w2_2_41
(v128.load8x8_s offset=328(local.get $bp2))
local.get $w0_2_41
i16x8.sub
local.tee $w4_2_41
i16x8.sub
local.tee $w5_2_41
local.get $w1_2_41
i16x8.sub
local.tee $w3_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_42
local.get $w2_2_42
(v128.load8x8_s offset=336(local.get $bp2))
local.get $w0_2_42
i16x8.sub
local.tee $w4_2_42
i16x8.sub
local.tee $w5_2_42
local.get $w1_2_42
i16x8.sub
local.tee $w3_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_43
local.get $w2_2_43
(v128.load8x8_s offset=344(local.get $bp2))
local.get $w0_2_43
i16x8.sub
local.tee $w4_2_43
i16x8.sub
local.tee $w5_2_43
local.get $w1_2_43
i16x8.sub
local.tee $w3_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_44
local.get $w2_2_44
(v128.load8x8_s offset=352(local.get $bp2))
local.get $w0_2_44
i16x8.sub
local.tee $w4_2_44
i16x8.sub
local.tee $w5_2_44
local.get $w1_2_44
i16x8.sub
local.tee $w3_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_45
local.get $w2_2_45
(v128.load8x8_s offset=360(local.get $bp2))
local.get $w0_2_45
i16x8.sub
local.tee $w4_2_45
i16x8.sub
local.tee $w5_2_45
local.get $w1_2_45
i16x8.sub
local.tee $w3_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_46
local.get $w2_2_46
(v128.load8x8_s offset=368(local.get $bp2))
local.get $w0_2_46
i16x8.sub
local.tee $w4_2_46
i16x8.sub
local.tee $w5_2_46
local.get $w1_2_46
i16x8.sub
local.tee $w3_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_47
local.get $w2_2_47
(v128.load8x8_s offset=376(local.get $bp2))
local.get $w0_2_47
i16x8.sub
local.tee $w4_2_47
i16x8.sub
local.tee $w5_2_47
local.get $w1_2_47
i16x8.sub
local.tee $w3_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_48
local.get $w2_2_48
(v128.load8x8_s offset=384(local.get $bp2))
local.get $w0_2_48
i16x8.sub
local.tee $w4_2_48
i16x8.sub
local.tee $w5_2_48
local.get $w1_2_48
i16x8.sub
local.tee $w3_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_49
local.get $w2_2_49
(v128.load8x8_s offset=392(local.get $bp2))
local.get $w0_2_49
i16x8.sub
local.tee $w4_2_49
i16x8.sub
local.tee $w5_2_49
local.get $w1_2_49
i16x8.sub
local.tee $w3_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_50
local.get $w2_2_50
(v128.load8x8_s offset=400(local.get $bp2))
local.get $w0_2_50
i16x8.sub
local.tee $w4_2_50
i16x8.sub
local.tee $w5_2_50
local.get $w1_2_50
i16x8.sub
local.tee $w3_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_51
local.get $w2_2_51
(v128.load8x8_s offset=408(local.get $bp2))
local.get $w0_2_51
i16x8.sub
local.tee $w4_2_51
i16x8.sub
local.tee $w5_2_51
local.get $w1_2_51
i16x8.sub
local.tee $w3_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_52
local.get $w2_2_52
(v128.load8x8_s offset=416(local.get $bp2))
local.get $w0_2_52
i16x8.sub
local.tee $w4_2_52
i16x8.sub
local.tee $w5_2_52
local.get $w1_2_52
i16x8.sub
local.tee $w3_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_53
local.get $w2_2_53
(v128.load8x8_s offset=424(local.get $bp2))
local.get $w0_2_53
i16x8.sub
local.tee $w4_2_53
i16x8.sub
local.tee $w5_2_53
local.get $w1_2_53
i16x8.sub
local.tee $w3_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_54
local.get $w2_2_54
(v128.load8x8_s offset=432(local.get $bp2))
local.get $w0_2_54
i16x8.sub
local.tee $w4_2_54
i16x8.sub
local.tee $w5_2_54
local.get $w1_2_54
i16x8.sub
local.tee $w3_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_55
local.get $w2_2_55
(v128.load8x8_s offset=440(local.get $bp2))
local.get $w0_2_55
i16x8.sub
local.tee $w4_2_55
i16x8.sub
local.tee $w5_2_55
local.get $w1_2_55
i16x8.sub
local.tee $w3_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_56
local.get $w2_2_56
(v128.load8x8_s offset=448(local.get $bp2))
local.get $w0_2_56
i16x8.sub
local.tee $w4_2_56
i16x8.sub
local.tee $w5_2_56
local.get $w1_2_56
i16x8.sub
local.tee $w3_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_57
local.get $w2_2_57
(v128.load8x8_s offset=456(local.get $bp2))
local.get $w0_2_57
i16x8.sub
local.tee $w4_2_57
i16x8.sub
local.tee $w5_2_57
local.get $w1_2_57
i16x8.sub
local.tee $w3_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_58
local.get $w2_2_58
(v128.load8x8_s offset=464(local.get $bp2))
local.get $w0_2_58
i16x8.sub
local.tee $w4_2_58
i16x8.sub
local.tee $w5_2_58
local.get $w1_2_58
i16x8.sub
local.tee $w3_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_59
local.get $w2_2_59
(v128.load8x8_s offset=472(local.get $bp2))
local.get $w0_2_59
i16x8.sub
local.tee $w4_2_59
i16x8.sub
local.tee $w5_2_59
local.get $w1_2_59
i16x8.sub
local.tee $w3_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_60
local.get $w2_2_60
(v128.load8x8_s offset=480(local.get $bp2))
local.get $w0_2_60
i16x8.sub
local.tee $w4_2_60
i16x8.sub
local.tee $w5_2_60
local.get $w1_2_60
i16x8.sub
local.tee $w3_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_61
local.get $w2_2_61
(v128.load8x8_s offset=488(local.get $bp2))
local.get $w0_2_61
i16x8.sub
local.tee $w4_2_61
i16x8.sub
local.tee $w5_2_61
local.get $w1_2_61
i16x8.sub
local.tee $w3_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_62
local.get $w2_2_62
(v128.load8x8_s offset=496(local.get $bp2))
local.get $w0_2_62
i16x8.sub
local.tee $w4_2_62
i16x8.sub
local.tee $w5_2_62
local.get $w1_2_62
i16x8.sub
local.tee $w3_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_63
local.get $w2_2_63
(v128.load8x8_s offset=504(local.get $bp2))
local.get $w0_2_63
i16x8.sub
local.tee $w4_2_63
i16x8.sub
local.tee $w5_2_63
local.get $w1_2_63
i16x8.sub
local.tee $w3_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
local.get $x4_0
local.get $w4_2_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_32
local.get $w4_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_33
local.get $w4_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_34
local.get $w4_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_35
local.get $w4_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_36
local.get $w4_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_37
local.get $w4_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_38
local.get $w4_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_39
local.get $w4_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_40
local.get $w4_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_41
local.get $w4_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_42
local.get $w4_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_43
local.get $w4_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_44
local.get $w4_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_45
local.get $w4_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_46
local.get $w4_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_47
local.get $w4_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_48
local.get $w4_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_49
local.get $w4_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_50
local.get $w4_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_51
local.get $w4_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_52
local.get $w4_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_53
local.get $w4_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_54
local.get $w4_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_55
local.get $w4_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_56
local.get $w4_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_57
local.get $w4_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_58
local.get $w4_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_59
local.get $w4_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_60
local.get $w4_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_61
local.get $w4_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_62
local.get $w4_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_63
local.get $w4_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
local.get $x5_0
local.get $w5_2_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $x6_0
local.get $w5_2_0
local.get $w0_2_0
i16x8.sub
local.tee $w6_2_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w5_2_1
local.get $w0_2_1
i16x8.sub
local.tee $w6_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w5_2_2
local.get $w0_2_2
i16x8.sub
local.tee $w6_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w5_2_3
local.get $w0_2_3
i16x8.sub
local.tee $w6_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w5_2_4
local.get $w0_2_4
i16x8.sub
local.tee $w6_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w5_2_5
local.get $w0_2_5
i16x8.sub
local.tee $w6_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w5_2_6
local.get $w0_2_6
i16x8.sub
local.tee $w6_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w5_2_7
local.get $w0_2_7
i16x8.sub
local.tee $w6_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w5_2_8
local.get $w0_2_8
i16x8.sub
local.tee $w6_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w5_2_9
local.get $w0_2_9
i16x8.sub
local.tee $w6_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w5_2_10
local.get $w0_2_10
i16x8.sub
local.tee $w6_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w5_2_11
local.get $w0_2_11
i16x8.sub
local.tee $w6_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w5_2_12
local.get $w0_2_12
i16x8.sub
local.tee $w6_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w5_2_13
local.get $w0_2_13
i16x8.sub
local.tee $w6_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w5_2_14
local.get $w0_2_14
i16x8.sub
local.tee $w6_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w5_2_15
local.get $w0_2_15
i16x8.sub
local.tee $w6_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w5_2_16
local.get $w0_2_16
i16x8.sub
local.tee $w6_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w5_2_17
local.get $w0_2_17
i16x8.sub
local.tee $w6_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w5_2_18
local.get $w0_2_18
i16x8.sub
local.tee $w6_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w5_2_19
local.get $w0_2_19
i16x8.sub
local.tee $w6_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w5_2_20
local.get $w0_2_20
i16x8.sub
local.tee $w6_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w5_2_21
local.get $w0_2_21
i16x8.sub
local.tee $w6_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w5_2_22
local.get $w0_2_22
i16x8.sub
local.tee $w6_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w5_2_23
local.get $w0_2_23
i16x8.sub
local.tee $w6_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w5_2_24
local.get $w0_2_24
i16x8.sub
local.tee $w6_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w5_2_25
local.get $w0_2_25
i16x8.sub
local.tee $w6_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w5_2_26
local.get $w0_2_26
i16x8.sub
local.tee $w6_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w5_2_27
local.get $w0_2_27
i16x8.sub
local.tee $w6_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w5_2_28
local.get $w0_2_28
i16x8.sub
local.tee $w6_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w5_2_29
local.get $w0_2_29
i16x8.sub
local.tee $w6_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w5_2_30
local.get $w0_2_30
i16x8.sub
local.tee $w6_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w5_2_31
local.get $w0_2_31
i16x8.sub
local.tee $w6_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_32
local.get $w5_2_32
local.get $w0_2_32
i16x8.sub
local.tee $w6_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_33
local.get $w5_2_33
local.get $w0_2_33
i16x8.sub
local.tee $w6_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_34
local.get $w5_2_34
local.get $w0_2_34
i16x8.sub
local.tee $w6_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_35
local.get $w5_2_35
local.get $w0_2_35
i16x8.sub
local.tee $w6_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_36
local.get $w5_2_36
local.get $w0_2_36
i16x8.sub
local.tee $w6_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_37
local.get $w5_2_37
local.get $w0_2_37
i16x8.sub
local.tee $w6_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_38
local.get $w5_2_38
local.get $w0_2_38
i16x8.sub
local.tee $w6_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_39
local.get $w5_2_39
local.get $w0_2_39
i16x8.sub
local.tee $w6_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_40
local.get $w5_2_40
local.get $w0_2_40
i16x8.sub
local.tee $w6_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_41
local.get $w5_2_41
local.get $w0_2_41
i16x8.sub
local.tee $w6_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_42
local.get $w5_2_42
local.get $w0_2_42
i16x8.sub
local.tee $w6_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_43
local.get $w5_2_43
local.get $w0_2_43
i16x8.sub
local.tee $w6_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_44
local.get $w5_2_44
local.get $w0_2_44
i16x8.sub
local.tee $w6_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_45
local.get $w5_2_45
local.get $w0_2_45
i16x8.sub
local.tee $w6_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_46
local.get $w5_2_46
local.get $w0_2_46
i16x8.sub
local.tee $w6_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_47
local.get $w5_2_47
local.get $w0_2_47
i16x8.sub
local.tee $w6_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_48
local.get $w5_2_48
local.get $w0_2_48
i16x8.sub
local.tee $w6_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_49
local.get $w5_2_49
local.get $w0_2_49
i16x8.sub
local.tee $w6_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_50
local.get $w5_2_50
local.get $w0_2_50
i16x8.sub
local.tee $w6_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_51
local.get $w5_2_51
local.get $w0_2_51
i16x8.sub
local.tee $w6_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_52
local.get $w5_2_52
local.get $w0_2_52
i16x8.sub
local.tee $w6_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_53
local.get $w5_2_53
local.get $w0_2_53
i16x8.sub
local.tee $w6_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_54
local.get $w5_2_54
local.get $w0_2_54
i16x8.sub
local.tee $w6_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_55
local.get $w5_2_55
local.get $w0_2_55
i16x8.sub
local.tee $w6_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_56
local.get $w5_2_56
local.get $w0_2_56
i16x8.sub
local.tee $w6_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_57
local.get $w5_2_57
local.get $w0_2_57
i16x8.sub
local.tee $w6_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_58
local.get $w5_2_58
local.get $w0_2_58
i16x8.sub
local.tee $w6_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_59
local.get $w5_2_59
local.get $w0_2_59
i16x8.sub
local.tee $w6_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_60
local.get $w5_2_60
local.get $w0_2_60
i16x8.sub
local.tee $w6_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_61
local.get $w5_2_61
local.get $w0_2_61
i16x8.sub
local.tee $w6_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_62
local.get $w5_2_62
local.get $w0_2_62
i16x8.sub
local.tee $w6_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_63
local.get $w5_2_63
local.get $w0_2_63
i16x8.sub
local.tee $w6_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=64
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp
local.get $yp
v128.load offset=80
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80
(if(local.get $keep)(then
local.get $yp1
local.get $yp1
v128.load offset=64
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp1
local.get $yp1
v128.load offset=80
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80
))
(local.set $bp0(i32.add(local.get $wp0)(i32.mul(local.get $cols)(i32.const 6))))
(local.set $bp1(i32.add(local.get $wp1)(i32.mul(local.get $cols)(i32.const 6))))
(local.set $bp2(i32.add(local.get $wp2)(i32.mul(local.get $cols)(i32.const 6))))
(local.set $bp3(i32.add(local.get $wp3)(i32.mul(local.get $cols)(i32.const 6))))
local.get $x0_0
(v128.load8x8_s offset=0(local.get $bp0))
local.tee $w0_3_0
i32x4.dot_i16x8_s
local.get $x0_1
(v128.load8x8_s offset=8(local.get $bp0))
local.tee $w0_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
(v128.load8x8_s offset=16(local.get $bp0))
local.tee $w0_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
(v128.load8x8_s offset=24(local.get $bp0))
local.tee $w0_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
(v128.load8x8_s offset=32(local.get $bp0))
local.tee $w0_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
(v128.load8x8_s offset=40(local.get $bp0))
local.tee $w0_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
(v128.load8x8_s offset=48(local.get $bp0))
local.tee $w0_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
(v128.load8x8_s offset=56(local.get $bp0))
local.tee $w0_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
(v128.load8x8_s offset=64(local.get $bp0))
local.tee $w0_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
(v128.load8x8_s offset=72(local.get $bp0))
local.tee $w0_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
(v128.load8x8_s offset=80(local.get $bp0))
local.tee $w0_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
(v128.load8x8_s offset=88(local.get $bp0))
local.tee $w0_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
(v128.load8x8_s offset=96(local.get $bp0))
local.tee $w0_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
(v128.load8x8_s offset=104(local.get $bp0))
local.tee $w0_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
(v128.load8x8_s offset=112(local.get $bp0))
local.tee $w0_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
(v128.load8x8_s offset=120(local.get $bp0))
local.tee $w0_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
(v128.load8x8_s offset=128(local.get $bp0))
local.tee $w0_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
(v128.load8x8_s offset=136(local.get $bp0))
local.tee $w0_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
(v128.load8x8_s offset=144(local.get $bp0))
local.tee $w0_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
(v128.load8x8_s offset=152(local.get $bp0))
local.tee $w0_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
(v128.load8x8_s offset=160(local.get $bp0))
local.tee $w0_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
(v128.load8x8_s offset=168(local.get $bp0))
local.tee $w0_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
(v128.load8x8_s offset=176(local.get $bp0))
local.tee $w0_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
(v128.load8x8_s offset=184(local.get $bp0))
local.tee $w0_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
(v128.load8x8_s offset=192(local.get $bp0))
local.tee $w0_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
(v128.load8x8_s offset=200(local.get $bp0))
local.tee $w0_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
(v128.load8x8_s offset=208(local.get $bp0))
local.tee $w0_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
(v128.load8x8_s offset=216(local.get $bp0))
local.tee $w0_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
(v128.load8x8_s offset=224(local.get $bp0))
local.tee $w0_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
(v128.load8x8_s offset=232(local.get $bp0))
local.tee $w0_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
(v128.load8x8_s offset=240(local.get $bp0))
local.tee $w0_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
(v128.load8x8_s offset=248(local.get $bp0))
local.tee $w0_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
(v128.load8x8_s offset=256(local.get $bp0))
local.tee $w0_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
(v128.load8x8_s offset=264(local.get $bp0))
local.tee $w0_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
(v128.load8x8_s offset=272(local.get $bp0))
local.tee $w0_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
(v128.load8x8_s offset=280(local.get $bp0))
local.tee $w0_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
(v128.load8x8_s offset=288(local.get $bp0))
local.tee $w0_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
(v128.load8x8_s offset=296(local.get $bp0))
local.tee $w0_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
(v128.load8x8_s offset=304(local.get $bp0))
local.tee $w0_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
(v128.load8x8_s offset=312(local.get $bp0))
local.tee $w0_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
(v128.load8x8_s offset=320(local.get $bp0))
local.tee $w0_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
(v128.load8x8_s offset=328(local.get $bp0))
local.tee $w0_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
(v128.load8x8_s offset=336(local.get $bp0))
local.tee $w0_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
(v128.load8x8_s offset=344(local.get $bp0))
local.tee $w0_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
(v128.load8x8_s offset=352(local.get $bp0))
local.tee $w0_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
(v128.load8x8_s offset=360(local.get $bp0))
local.tee $w0_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
(v128.load8x8_s offset=368(local.get $bp0))
local.tee $w0_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
(v128.load8x8_s offset=376(local.get $bp0))
local.tee $w0_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
(v128.load8x8_s offset=384(local.get $bp0))
local.tee $w0_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
(v128.load8x8_s offset=392(local.get $bp0))
local.tee $w0_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
(v128.load8x8_s offset=400(local.get $bp0))
local.tee $w0_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
(v128.load8x8_s offset=408(local.get $bp0))
local.tee $w0_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
(v128.load8x8_s offset=416(local.get $bp0))
local.tee $w0_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
(v128.load8x8_s offset=424(local.get $bp0))
local.tee $w0_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
(v128.load8x8_s offset=432(local.get $bp0))
local.tee $w0_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
(v128.load8x8_s offset=440(local.get $bp0))
local.tee $w0_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
(v128.load8x8_s offset=448(local.get $bp0))
local.tee $w0_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
(v128.load8x8_s offset=456(local.get $bp0))
local.tee $w0_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
(v128.load8x8_s offset=464(local.get $bp0))
local.tee $w0_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
(v128.load8x8_s offset=472(local.get $bp0))
local.tee $w0_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
(v128.load8x8_s offset=480(local.get $bp0))
local.tee $w0_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
(v128.load8x8_s offset=488(local.get $bp0))
local.tee $w0_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
(v128.load8x8_s offset=496(local.get $bp0))
local.tee $w0_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
(v128.load8x8_s offset=504(local.get $bp0))
local.tee $w0_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
(v128.load8x8_s offset=0(local.get $bp1))
local.tee $w1_3_0
i32x4.dot_i16x8_s
local.get $x1_1
(v128.load8x8_s offset=8(local.get $bp1))
local.tee $w1_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
(v128.load8x8_s offset=16(local.get $bp1))
local.tee $w1_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
(v128.load8x8_s offset=24(local.get $bp1))
local.tee $w1_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
(v128.load8x8_s offset=32(local.get $bp1))
local.tee $w1_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
(v128.load8x8_s offset=40(local.get $bp1))
local.tee $w1_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
(v128.load8x8_s offset=48(local.get $bp1))
local.tee $w1_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
(v128.load8x8_s offset=56(local.get $bp1))
local.tee $w1_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
(v128.load8x8_s offset=64(local.get $bp1))
local.tee $w1_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
(v128.load8x8_s offset=72(local.get $bp1))
local.tee $w1_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
(v128.load8x8_s offset=80(local.get $bp1))
local.tee $w1_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
(v128.load8x8_s offset=88(local.get $bp1))
local.tee $w1_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
(v128.load8x8_s offset=96(local.get $bp1))
local.tee $w1_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
(v128.load8x8_s offset=104(local.get $bp1))
local.tee $w1_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
(v128.load8x8_s offset=112(local.get $bp1))
local.tee $w1_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
(v128.load8x8_s offset=120(local.get $bp1))
local.tee $w1_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
(v128.load8x8_s offset=128(local.get $bp1))
local.tee $w1_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
(v128.load8x8_s offset=136(local.get $bp1))
local.tee $w1_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
(v128.load8x8_s offset=144(local.get $bp1))
local.tee $w1_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
(v128.load8x8_s offset=152(local.get $bp1))
local.tee $w1_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
(v128.load8x8_s offset=160(local.get $bp1))
local.tee $w1_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
(v128.load8x8_s offset=168(local.get $bp1))
local.tee $w1_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
(v128.load8x8_s offset=176(local.get $bp1))
local.tee $w1_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
(v128.load8x8_s offset=184(local.get $bp1))
local.tee $w1_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
(v128.load8x8_s offset=192(local.get $bp1))
local.tee $w1_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
(v128.load8x8_s offset=200(local.get $bp1))
local.tee $w1_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
(v128.load8x8_s offset=208(local.get $bp1))
local.tee $w1_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
(v128.load8x8_s offset=216(local.get $bp1))
local.tee $w1_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
(v128.load8x8_s offset=224(local.get $bp1))
local.tee $w1_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
(v128.load8x8_s offset=232(local.get $bp1))
local.tee $w1_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
(v128.load8x8_s offset=240(local.get $bp1))
local.tee $w1_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
(v128.load8x8_s offset=248(local.get $bp1))
local.tee $w1_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
(v128.load8x8_s offset=256(local.get $bp1))
local.tee $w1_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
(v128.load8x8_s offset=264(local.get $bp1))
local.tee $w1_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
(v128.load8x8_s offset=272(local.get $bp1))
local.tee $w1_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
(v128.load8x8_s offset=280(local.get $bp1))
local.tee $w1_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
(v128.load8x8_s offset=288(local.get $bp1))
local.tee $w1_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
(v128.load8x8_s offset=296(local.get $bp1))
local.tee $w1_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
(v128.load8x8_s offset=304(local.get $bp1))
local.tee $w1_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
(v128.load8x8_s offset=312(local.get $bp1))
local.tee $w1_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
(v128.load8x8_s offset=320(local.get $bp1))
local.tee $w1_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
(v128.load8x8_s offset=328(local.get $bp1))
local.tee $w1_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
(v128.load8x8_s offset=336(local.get $bp1))
local.tee $w1_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
(v128.load8x8_s offset=344(local.get $bp1))
local.tee $w1_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
(v128.load8x8_s offset=352(local.get $bp1))
local.tee $w1_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
(v128.load8x8_s offset=360(local.get $bp1))
local.tee $w1_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
(v128.load8x8_s offset=368(local.get $bp1))
local.tee $w1_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
(v128.load8x8_s offset=376(local.get $bp1))
local.tee $w1_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
(v128.load8x8_s offset=384(local.get $bp1))
local.tee $w1_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
(v128.load8x8_s offset=392(local.get $bp1))
local.tee $w1_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
(v128.load8x8_s offset=400(local.get $bp1))
local.tee $w1_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
(v128.load8x8_s offset=408(local.get $bp1))
local.tee $w1_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
(v128.load8x8_s offset=416(local.get $bp1))
local.tee $w1_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
(v128.load8x8_s offset=424(local.get $bp1))
local.tee $w1_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
(v128.load8x8_s offset=432(local.get $bp1))
local.tee $w1_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
(v128.load8x8_s offset=440(local.get $bp1))
local.tee $w1_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
(v128.load8x8_s offset=448(local.get $bp1))
local.tee $w1_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
(v128.load8x8_s offset=456(local.get $bp1))
local.tee $w1_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
(v128.load8x8_s offset=464(local.get $bp1))
local.tee $w1_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
(v128.load8x8_s offset=472(local.get $bp1))
local.tee $w1_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
(v128.load8x8_s offset=480(local.get $bp1))
local.tee $w1_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
(v128.load8x8_s offset=488(local.get $bp1))
local.tee $w1_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
(v128.load8x8_s offset=496(local.get $bp1))
local.tee $w1_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
(v128.load8x8_s offset=504(local.get $bp1))
local.tee $w1_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
(v128.load8x8_s offset=0(local.get $bp3))
local.tee $w2_3_0
i32x4.dot_i16x8_s
local.get $x2_1
(v128.load8x8_s offset=8(local.get $bp3))
local.tee $w2_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
(v128.load8x8_s offset=16(local.get $bp3))
local.tee $w2_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
(v128.load8x8_s offset=24(local.get $bp3))
local.tee $w2_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
(v128.load8x8_s offset=32(local.get $bp3))
local.tee $w2_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
(v128.load8x8_s offset=40(local.get $bp3))
local.tee $w2_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
(v128.load8x8_s offset=48(local.get $bp3))
local.tee $w2_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
(v128.load8x8_s offset=56(local.get $bp3))
local.tee $w2_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
(v128.load8x8_s offset=64(local.get $bp3))
local.tee $w2_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
(v128.load8x8_s offset=72(local.get $bp3))
local.tee $w2_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
(v128.load8x8_s offset=80(local.get $bp3))
local.tee $w2_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
(v128.load8x8_s offset=88(local.get $bp3))
local.tee $w2_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
(v128.load8x8_s offset=96(local.get $bp3))
local.tee $w2_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
(v128.load8x8_s offset=104(local.get $bp3))
local.tee $w2_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
(v128.load8x8_s offset=112(local.get $bp3))
local.tee $w2_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
(v128.load8x8_s offset=120(local.get $bp3))
local.tee $w2_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
(v128.load8x8_s offset=128(local.get $bp3))
local.tee $w2_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
(v128.load8x8_s offset=136(local.get $bp3))
local.tee $w2_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
(v128.load8x8_s offset=144(local.get $bp3))
local.tee $w2_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
(v128.load8x8_s offset=152(local.get $bp3))
local.tee $w2_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
(v128.load8x8_s offset=160(local.get $bp3))
local.tee $w2_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
(v128.load8x8_s offset=168(local.get $bp3))
local.tee $w2_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
(v128.load8x8_s offset=176(local.get $bp3))
local.tee $w2_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
(v128.load8x8_s offset=184(local.get $bp3))
local.tee $w2_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
(v128.load8x8_s offset=192(local.get $bp3))
local.tee $w2_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
(v128.load8x8_s offset=200(local.get $bp3))
local.tee $w2_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
(v128.load8x8_s offset=208(local.get $bp3))
local.tee $w2_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
(v128.load8x8_s offset=216(local.get $bp3))
local.tee $w2_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
(v128.load8x8_s offset=224(local.get $bp3))
local.tee $w2_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
(v128.load8x8_s offset=232(local.get $bp3))
local.tee $w2_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
(v128.load8x8_s offset=240(local.get $bp3))
local.tee $w2_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
(v128.load8x8_s offset=248(local.get $bp3))
local.tee $w2_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
(v128.load8x8_s offset=256(local.get $bp3))
local.tee $w2_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
(v128.load8x8_s offset=264(local.get $bp3))
local.tee $w2_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
(v128.load8x8_s offset=272(local.get $bp3))
local.tee $w2_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
(v128.load8x8_s offset=280(local.get $bp3))
local.tee $w2_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
(v128.load8x8_s offset=288(local.get $bp3))
local.tee $w2_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
(v128.load8x8_s offset=296(local.get $bp3))
local.tee $w2_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
(v128.load8x8_s offset=304(local.get $bp3))
local.tee $w2_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
(v128.load8x8_s offset=312(local.get $bp3))
local.tee $w2_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
(v128.load8x8_s offset=320(local.get $bp3))
local.tee $w2_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
(v128.load8x8_s offset=328(local.get $bp3))
local.tee $w2_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
(v128.load8x8_s offset=336(local.get $bp3))
local.tee $w2_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
(v128.load8x8_s offset=344(local.get $bp3))
local.tee $w2_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
(v128.load8x8_s offset=352(local.get $bp3))
local.tee $w2_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
(v128.load8x8_s offset=360(local.get $bp3))
local.tee $w2_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
(v128.load8x8_s offset=368(local.get $bp3))
local.tee $w2_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
(v128.load8x8_s offset=376(local.get $bp3))
local.tee $w2_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
(v128.load8x8_s offset=384(local.get $bp3))
local.tee $w2_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
(v128.load8x8_s offset=392(local.get $bp3))
local.tee $w2_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
(v128.load8x8_s offset=400(local.get $bp3))
local.tee $w2_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
(v128.load8x8_s offset=408(local.get $bp3))
local.tee $w2_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
(v128.load8x8_s offset=416(local.get $bp3))
local.tee $w2_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
(v128.load8x8_s offset=424(local.get $bp3))
local.tee $w2_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
(v128.load8x8_s offset=432(local.get $bp3))
local.tee $w2_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
(v128.load8x8_s offset=440(local.get $bp3))
local.tee $w2_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
(v128.load8x8_s offset=448(local.get $bp3))
local.tee $w2_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
(v128.load8x8_s offset=456(local.get $bp3))
local.tee $w2_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
(v128.load8x8_s offset=464(local.get $bp3))
local.tee $w2_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
(v128.load8x8_s offset=472(local.get $bp3))
local.tee $w2_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
(v128.load8x8_s offset=480(local.get $bp3))
local.tee $w2_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
(v128.load8x8_s offset=488(local.get $bp3))
local.tee $w2_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
(v128.load8x8_s offset=496(local.get $bp3))
local.tee $w2_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
(v128.load8x8_s offset=504(local.get $bp3))
local.tee $w2_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x3_0
local.get $w2_3_0
(v128.load8x8_s offset=0(local.get $bp2))
local.get $w0_3_0
i16x8.sub
local.tee $w4_3_0
i16x8.sub
local.tee $w5_3_0
local.get $w1_3_0
i16x8.sub
local.tee $w3_3_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w2_3_1
(v128.load8x8_s offset=8(local.get $bp2))
local.get $w0_3_1
i16x8.sub
local.tee $w4_3_1
i16x8.sub
local.tee $w5_3_1
local.get $w1_3_1
i16x8.sub
local.tee $w3_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w2_3_2
(v128.load8x8_s offset=16(local.get $bp2))
local.get $w0_3_2
i16x8.sub
local.tee $w4_3_2
i16x8.sub
local.tee $w5_3_2
local.get $w1_3_2
i16x8.sub
local.tee $w3_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w2_3_3
(v128.load8x8_s offset=24(local.get $bp2))
local.get $w0_3_3
i16x8.sub
local.tee $w4_3_3
i16x8.sub
local.tee $w5_3_3
local.get $w1_3_3
i16x8.sub
local.tee $w3_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w2_3_4
(v128.load8x8_s offset=32(local.get $bp2))
local.get $w0_3_4
i16x8.sub
local.tee $w4_3_4
i16x8.sub
local.tee $w5_3_4
local.get $w1_3_4
i16x8.sub
local.tee $w3_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w2_3_5
(v128.load8x8_s offset=40(local.get $bp2))
local.get $w0_3_5
i16x8.sub
local.tee $w4_3_5
i16x8.sub
local.tee $w5_3_5
local.get $w1_3_5
i16x8.sub
local.tee $w3_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w2_3_6
(v128.load8x8_s offset=48(local.get $bp2))
local.get $w0_3_6
i16x8.sub
local.tee $w4_3_6
i16x8.sub
local.tee $w5_3_6
local.get $w1_3_6
i16x8.sub
local.tee $w3_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w2_3_7
(v128.load8x8_s offset=56(local.get $bp2))
local.get $w0_3_7
i16x8.sub
local.tee $w4_3_7
i16x8.sub
local.tee $w5_3_7
local.get $w1_3_7
i16x8.sub
local.tee $w3_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w2_3_8
(v128.load8x8_s offset=64(local.get $bp2))
local.get $w0_3_8
i16x8.sub
local.tee $w4_3_8
i16x8.sub
local.tee $w5_3_8
local.get $w1_3_8
i16x8.sub
local.tee $w3_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w2_3_9
(v128.load8x8_s offset=72(local.get $bp2))
local.get $w0_3_9
i16x8.sub
local.tee $w4_3_9
i16x8.sub
local.tee $w5_3_9
local.get $w1_3_9
i16x8.sub
local.tee $w3_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w2_3_10
(v128.load8x8_s offset=80(local.get $bp2))
local.get $w0_3_10
i16x8.sub
local.tee $w4_3_10
i16x8.sub
local.tee $w5_3_10
local.get $w1_3_10
i16x8.sub
local.tee $w3_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w2_3_11
(v128.load8x8_s offset=88(local.get $bp2))
local.get $w0_3_11
i16x8.sub
local.tee $w4_3_11
i16x8.sub
local.tee $w5_3_11
local.get $w1_3_11
i16x8.sub
local.tee $w3_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w2_3_12
(v128.load8x8_s offset=96(local.get $bp2))
local.get $w0_3_12
i16x8.sub
local.tee $w4_3_12
i16x8.sub
local.tee $w5_3_12
local.get $w1_3_12
i16x8.sub
local.tee $w3_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w2_3_13
(v128.load8x8_s offset=104(local.get $bp2))
local.get $w0_3_13
i16x8.sub
local.tee $w4_3_13
i16x8.sub
local.tee $w5_3_13
local.get $w1_3_13
i16x8.sub
local.tee $w3_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w2_3_14
(v128.load8x8_s offset=112(local.get $bp2))
local.get $w0_3_14
i16x8.sub
local.tee $w4_3_14
i16x8.sub
local.tee $w5_3_14
local.get $w1_3_14
i16x8.sub
local.tee $w3_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w2_3_15
(v128.load8x8_s offset=120(local.get $bp2))
local.get $w0_3_15
i16x8.sub
local.tee $w4_3_15
i16x8.sub
local.tee $w5_3_15
local.get $w1_3_15
i16x8.sub
local.tee $w3_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w2_3_16
(v128.load8x8_s offset=128(local.get $bp2))
local.get $w0_3_16
i16x8.sub
local.tee $w4_3_16
i16x8.sub
local.tee $w5_3_16
local.get $w1_3_16
i16x8.sub
local.tee $w3_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w2_3_17
(v128.load8x8_s offset=136(local.get $bp2))
local.get $w0_3_17
i16x8.sub
local.tee $w4_3_17
i16x8.sub
local.tee $w5_3_17
local.get $w1_3_17
i16x8.sub
local.tee $w3_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w2_3_18
(v128.load8x8_s offset=144(local.get $bp2))
local.get $w0_3_18
i16x8.sub
local.tee $w4_3_18
i16x8.sub
local.tee $w5_3_18
local.get $w1_3_18
i16x8.sub
local.tee $w3_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w2_3_19
(v128.load8x8_s offset=152(local.get $bp2))
local.get $w0_3_19
i16x8.sub
local.tee $w4_3_19
i16x8.sub
local.tee $w5_3_19
local.get $w1_3_19
i16x8.sub
local.tee $w3_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w2_3_20
(v128.load8x8_s offset=160(local.get $bp2))
local.get $w0_3_20
i16x8.sub
local.tee $w4_3_20
i16x8.sub
local.tee $w5_3_20
local.get $w1_3_20
i16x8.sub
local.tee $w3_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w2_3_21
(v128.load8x8_s offset=168(local.get $bp2))
local.get $w0_3_21
i16x8.sub
local.tee $w4_3_21
i16x8.sub
local.tee $w5_3_21
local.get $w1_3_21
i16x8.sub
local.tee $w3_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w2_3_22
(v128.load8x8_s offset=176(local.get $bp2))
local.get $w0_3_22
i16x8.sub
local.tee $w4_3_22
i16x8.sub
local.tee $w5_3_22
local.get $w1_3_22
i16x8.sub
local.tee $w3_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w2_3_23
(v128.load8x8_s offset=184(local.get $bp2))
local.get $w0_3_23
i16x8.sub
local.tee $w4_3_23
i16x8.sub
local.tee $w5_3_23
local.get $w1_3_23
i16x8.sub
local.tee $w3_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w2_3_24
(v128.load8x8_s offset=192(local.get $bp2))
local.get $w0_3_24
i16x8.sub
local.tee $w4_3_24
i16x8.sub
local.tee $w5_3_24
local.get $w1_3_24
i16x8.sub
local.tee $w3_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w2_3_25
(v128.load8x8_s offset=200(local.get $bp2))
local.get $w0_3_25
i16x8.sub
local.tee $w4_3_25
i16x8.sub
local.tee $w5_3_25
local.get $w1_3_25
i16x8.sub
local.tee $w3_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w2_3_26
(v128.load8x8_s offset=208(local.get $bp2))
local.get $w0_3_26
i16x8.sub
local.tee $w4_3_26
i16x8.sub
local.tee $w5_3_26
local.get $w1_3_26
i16x8.sub
local.tee $w3_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w2_3_27
(v128.load8x8_s offset=216(local.get $bp2))
local.get $w0_3_27
i16x8.sub
local.tee $w4_3_27
i16x8.sub
local.tee $w5_3_27
local.get $w1_3_27
i16x8.sub
local.tee $w3_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w2_3_28
(v128.load8x8_s offset=224(local.get $bp2))
local.get $w0_3_28
i16x8.sub
local.tee $w4_3_28
i16x8.sub
local.tee $w5_3_28
local.get $w1_3_28
i16x8.sub
local.tee $w3_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w2_3_29
(v128.load8x8_s offset=232(local.get $bp2))
local.get $w0_3_29
i16x8.sub
local.tee $w4_3_29
i16x8.sub
local.tee $w5_3_29
local.get $w1_3_29
i16x8.sub
local.tee $w3_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w2_3_30
(v128.load8x8_s offset=240(local.get $bp2))
local.get $w0_3_30
i16x8.sub
local.tee $w4_3_30
i16x8.sub
local.tee $w5_3_30
local.get $w1_3_30
i16x8.sub
local.tee $w3_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w2_3_31
(v128.load8x8_s offset=248(local.get $bp2))
local.get $w0_3_31
i16x8.sub
local.tee $w4_3_31
i16x8.sub
local.tee $w5_3_31
local.get $w1_3_31
i16x8.sub
local.tee $w3_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_32
local.get $w2_3_32
(v128.load8x8_s offset=256(local.get $bp2))
local.get $w0_3_32
i16x8.sub
local.tee $w4_3_32
i16x8.sub
local.tee $w5_3_32
local.get $w1_3_32
i16x8.sub
local.tee $w3_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_33
local.get $w2_3_33
(v128.load8x8_s offset=264(local.get $bp2))
local.get $w0_3_33
i16x8.sub
local.tee $w4_3_33
i16x8.sub
local.tee $w5_3_33
local.get $w1_3_33
i16x8.sub
local.tee $w3_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_34
local.get $w2_3_34
(v128.load8x8_s offset=272(local.get $bp2))
local.get $w0_3_34
i16x8.sub
local.tee $w4_3_34
i16x8.sub
local.tee $w5_3_34
local.get $w1_3_34
i16x8.sub
local.tee $w3_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_35
local.get $w2_3_35
(v128.load8x8_s offset=280(local.get $bp2))
local.get $w0_3_35
i16x8.sub
local.tee $w4_3_35
i16x8.sub
local.tee $w5_3_35
local.get $w1_3_35
i16x8.sub
local.tee $w3_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_36
local.get $w2_3_36
(v128.load8x8_s offset=288(local.get $bp2))
local.get $w0_3_36
i16x8.sub
local.tee $w4_3_36
i16x8.sub
local.tee $w5_3_36
local.get $w1_3_36
i16x8.sub
local.tee $w3_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_37
local.get $w2_3_37
(v128.load8x8_s offset=296(local.get $bp2))
local.get $w0_3_37
i16x8.sub
local.tee $w4_3_37
i16x8.sub
local.tee $w5_3_37
local.get $w1_3_37
i16x8.sub
local.tee $w3_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_38
local.get $w2_3_38
(v128.load8x8_s offset=304(local.get $bp2))
local.get $w0_3_38
i16x8.sub
local.tee $w4_3_38
i16x8.sub
local.tee $w5_3_38
local.get $w1_3_38
i16x8.sub
local.tee $w3_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_39
local.get $w2_3_39
(v128.load8x8_s offset=312(local.get $bp2))
local.get $w0_3_39
i16x8.sub
local.tee $w4_3_39
i16x8.sub
local.tee $w5_3_39
local.get $w1_3_39
i16x8.sub
local.tee $w3_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_40
local.get $w2_3_40
(v128.load8x8_s offset=320(local.get $bp2))
local.get $w0_3_40
i16x8.sub
local.tee $w4_3_40
i16x8.sub
local.tee $w5_3_40
local.get $w1_3_40
i16x8.sub
local.tee $w3_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_41
local.get $w2_3_41
(v128.load8x8_s offset=328(local.get $bp2))
local.get $w0_3_41
i16x8.sub
local.tee $w4_3_41
i16x8.sub
local.tee $w5_3_41
local.get $w1_3_41
i16x8.sub
local.tee $w3_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_42
local.get $w2_3_42
(v128.load8x8_s offset=336(local.get $bp2))
local.get $w0_3_42
i16x8.sub
local.tee $w4_3_42
i16x8.sub
local.tee $w5_3_42
local.get $w1_3_42
i16x8.sub
local.tee $w3_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_43
local.get $w2_3_43
(v128.load8x8_s offset=344(local.get $bp2))
local.get $w0_3_43
i16x8.sub
local.tee $w4_3_43
i16x8.sub
local.tee $w5_3_43
local.get $w1_3_43
i16x8.sub
local.tee $w3_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_44
local.get $w2_3_44
(v128.load8x8_s offset=352(local.get $bp2))
local.get $w0_3_44
i16x8.sub
local.tee $w4_3_44
i16x8.sub
local.tee $w5_3_44
local.get $w1_3_44
i16x8.sub
local.tee $w3_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_45
local.get $w2_3_45
(v128.load8x8_s offset=360(local.get $bp2))
local.get $w0_3_45
i16x8.sub
local.tee $w4_3_45
i16x8.sub
local.tee $w5_3_45
local.get $w1_3_45
i16x8.sub
local.tee $w3_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_46
local.get $w2_3_46
(v128.load8x8_s offset=368(local.get $bp2))
local.get $w0_3_46
i16x8.sub
local.tee $w4_3_46
i16x8.sub
local.tee $w5_3_46
local.get $w1_3_46
i16x8.sub
local.tee $w3_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_47
local.get $w2_3_47
(v128.load8x8_s offset=376(local.get $bp2))
local.get $w0_3_47
i16x8.sub
local.tee $w4_3_47
i16x8.sub
local.tee $w5_3_47
local.get $w1_3_47
i16x8.sub
local.tee $w3_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_48
local.get $w2_3_48
(v128.load8x8_s offset=384(local.get $bp2))
local.get $w0_3_48
i16x8.sub
local.tee $w4_3_48
i16x8.sub
local.tee $w5_3_48
local.get $w1_3_48
i16x8.sub
local.tee $w3_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_49
local.get $w2_3_49
(v128.load8x8_s offset=392(local.get $bp2))
local.get $w0_3_49
i16x8.sub
local.tee $w4_3_49
i16x8.sub
local.tee $w5_3_49
local.get $w1_3_49
i16x8.sub
local.tee $w3_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_50
local.get $w2_3_50
(v128.load8x8_s offset=400(local.get $bp2))
local.get $w0_3_50
i16x8.sub
local.tee $w4_3_50
i16x8.sub
local.tee $w5_3_50
local.get $w1_3_50
i16x8.sub
local.tee $w3_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_51
local.get $w2_3_51
(v128.load8x8_s offset=408(local.get $bp2))
local.get $w0_3_51
i16x8.sub
local.tee $w4_3_51
i16x8.sub
local.tee $w5_3_51
local.get $w1_3_51
i16x8.sub
local.tee $w3_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_52
local.get $w2_3_52
(v128.load8x8_s offset=416(local.get $bp2))
local.get $w0_3_52
i16x8.sub
local.tee $w4_3_52
i16x8.sub
local.tee $w5_3_52
local.get $w1_3_52
i16x8.sub
local.tee $w3_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_53
local.get $w2_3_53
(v128.load8x8_s offset=424(local.get $bp2))
local.get $w0_3_53
i16x8.sub
local.tee $w4_3_53
i16x8.sub
local.tee $w5_3_53
local.get $w1_3_53
i16x8.sub
local.tee $w3_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_54
local.get $w2_3_54
(v128.load8x8_s offset=432(local.get $bp2))
local.get $w0_3_54
i16x8.sub
local.tee $w4_3_54
i16x8.sub
local.tee $w5_3_54
local.get $w1_3_54
i16x8.sub
local.tee $w3_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_55
local.get $w2_3_55
(v128.load8x8_s offset=440(local.get $bp2))
local.get $w0_3_55
i16x8.sub
local.tee $w4_3_55
i16x8.sub
local.tee $w5_3_55
local.get $w1_3_55
i16x8.sub
local.tee $w3_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_56
local.get $w2_3_56
(v128.load8x8_s offset=448(local.get $bp2))
local.get $w0_3_56
i16x8.sub
local.tee $w4_3_56
i16x8.sub
local.tee $w5_3_56
local.get $w1_3_56
i16x8.sub
local.tee $w3_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_57
local.get $w2_3_57
(v128.load8x8_s offset=456(local.get $bp2))
local.get $w0_3_57
i16x8.sub
local.tee $w4_3_57
i16x8.sub
local.tee $w5_3_57
local.get $w1_3_57
i16x8.sub
local.tee $w3_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_58
local.get $w2_3_58
(v128.load8x8_s offset=464(local.get $bp2))
local.get $w0_3_58
i16x8.sub
local.tee $w4_3_58
i16x8.sub
local.tee $w5_3_58
local.get $w1_3_58
i16x8.sub
local.tee $w3_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_59
local.get $w2_3_59
(v128.load8x8_s offset=472(local.get $bp2))
local.get $w0_3_59
i16x8.sub
local.tee $w4_3_59
i16x8.sub
local.tee $w5_3_59
local.get $w1_3_59
i16x8.sub
local.tee $w3_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_60
local.get $w2_3_60
(v128.load8x8_s offset=480(local.get $bp2))
local.get $w0_3_60
i16x8.sub
local.tee $w4_3_60
i16x8.sub
local.tee $w5_3_60
local.get $w1_3_60
i16x8.sub
local.tee $w3_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_61
local.get $w2_3_61
(v128.load8x8_s offset=488(local.get $bp2))
local.get $w0_3_61
i16x8.sub
local.tee $w4_3_61
i16x8.sub
local.tee $w5_3_61
local.get $w1_3_61
i16x8.sub
local.tee $w3_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_62
local.get $w2_3_62
(v128.load8x8_s offset=496(local.get $bp2))
local.get $w0_3_62
i16x8.sub
local.tee $w4_3_62
i16x8.sub
local.tee $w5_3_62
local.get $w1_3_62
i16x8.sub
local.tee $w3_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_63
local.get $w2_3_63
(v128.load8x8_s offset=504(local.get $bp2))
local.get $w0_3_63
i16x8.sub
local.tee $w4_3_63
i16x8.sub
local.tee $w5_3_63
local.get $w1_3_63
i16x8.sub
local.tee $w3_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
local.get $x4_0
local.get $w4_3_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_32
local.get $w4_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_33
local.get $w4_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_34
local.get $w4_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_35
local.get $w4_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_36
local.get $w4_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_37
local.get $w4_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_38
local.get $w4_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_39
local.get $w4_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_40
local.get $w4_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_41
local.get $w4_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_42
local.get $w4_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_43
local.get $w4_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_44
local.get $w4_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_45
local.get $w4_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_46
local.get $w4_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_47
local.get $w4_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_48
local.get $w4_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_49
local.get $w4_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_50
local.get $w4_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_51
local.get $w4_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_52
local.get $w4_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_53
local.get $w4_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_54
local.get $w4_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_55
local.get $w4_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_56
local.get $w4_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_57
local.get $w4_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_58
local.get $w4_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_59
local.get $w4_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_60
local.get $w4_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_61
local.get $w4_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_62
local.get $w4_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_63
local.get $w4_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
local.get $x5_0
local.get $w5_3_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $x6_0
local.get $w5_3_0
local.get $w0_3_0
i16x8.sub
local.tee $w6_3_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w5_3_1
local.get $w0_3_1
i16x8.sub
local.tee $w6_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w5_3_2
local.get $w0_3_2
i16x8.sub
local.tee $w6_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w5_3_3
local.get $w0_3_3
i16x8.sub
local.tee $w6_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w5_3_4
local.get $w0_3_4
i16x8.sub
local.tee $w6_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w5_3_5
local.get $w0_3_5
i16x8.sub
local.tee $w6_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w5_3_6
local.get $w0_3_6
i16x8.sub
local.tee $w6_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w5_3_7
local.get $w0_3_7
i16x8.sub
local.tee $w6_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w5_3_8
local.get $w0_3_8
i16x8.sub
local.tee $w6_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w5_3_9
local.get $w0_3_9
i16x8.sub
local.tee $w6_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w5_3_10
local.get $w0_3_10
i16x8.sub
local.tee $w6_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w5_3_11
local.get $w0_3_11
i16x8.sub
local.tee $w6_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w5_3_12
local.get $w0_3_12
i16x8.sub
local.tee $w6_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w5_3_13
local.get $w0_3_13
i16x8.sub
local.tee $w6_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w5_3_14
local.get $w0_3_14
i16x8.sub
local.tee $w6_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w5_3_15
local.get $w0_3_15
i16x8.sub
local.tee $w6_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w5_3_16
local.get $w0_3_16
i16x8.sub
local.tee $w6_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w5_3_17
local.get $w0_3_17
i16x8.sub
local.tee $w6_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w5_3_18
local.get $w0_3_18
i16x8.sub
local.tee $w6_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w5_3_19
local.get $w0_3_19
i16x8.sub
local.tee $w6_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w5_3_20
local.get $w0_3_20
i16x8.sub
local.tee $w6_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w5_3_21
local.get $w0_3_21
i16x8.sub
local.tee $w6_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w5_3_22
local.get $w0_3_22
i16x8.sub
local.tee $w6_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w5_3_23
local.get $w0_3_23
i16x8.sub
local.tee $w6_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w5_3_24
local.get $w0_3_24
i16x8.sub
local.tee $w6_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w5_3_25
local.get $w0_3_25
i16x8.sub
local.tee $w6_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w5_3_26
local.get $w0_3_26
i16x8.sub
local.tee $w6_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w5_3_27
local.get $w0_3_27
i16x8.sub
local.tee $w6_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w5_3_28
local.get $w0_3_28
i16x8.sub
local.tee $w6_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w5_3_29
local.get $w0_3_29
i16x8.sub
local.tee $w6_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w5_3_30
local.get $w0_3_30
i16x8.sub
local.tee $w6_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w5_3_31
local.get $w0_3_31
i16x8.sub
local.tee $w6_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_32
local.get $w5_3_32
local.get $w0_3_32
i16x8.sub
local.tee $w6_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_33
local.get $w5_3_33
local.get $w0_3_33
i16x8.sub
local.tee $w6_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_34
local.get $w5_3_34
local.get $w0_3_34
i16x8.sub
local.tee $w6_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_35
local.get $w5_3_35
local.get $w0_3_35
i16x8.sub
local.tee $w6_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_36
local.get $w5_3_36
local.get $w0_3_36
i16x8.sub
local.tee $w6_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_37
local.get $w5_3_37
local.get $w0_3_37
i16x8.sub
local.tee $w6_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_38
local.get $w5_3_38
local.get $w0_3_38
i16x8.sub
local.tee $w6_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_39
local.get $w5_3_39
local.get $w0_3_39
i16x8.sub
local.tee $w6_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_40
local.get $w5_3_40
local.get $w0_3_40
i16x8.sub
local.tee $w6_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_41
local.get $w5_3_41
local.get $w0_3_41
i16x8.sub
local.tee $w6_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_42
local.get $w5_3_42
local.get $w0_3_42
i16x8.sub
local.tee $w6_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_43
local.get $w5_3_43
local.get $w0_3_43
i16x8.sub
local.tee $w6_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_44
local.get $w5_3_44
local.get $w0_3_44
i16x8.sub
local.tee $w6_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_45
local.get $w5_3_45
local.get $w0_3_45
i16x8.sub
local.tee $w6_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_46
local.get $w5_3_46
local.get $w0_3_46
i16x8.sub
local.tee $w6_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_47
local.get $w5_3_47
local.get $w0_3_47
i16x8.sub
local.tee $w6_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_48
local.get $w5_3_48
local.get $w0_3_48
i16x8.sub
local.tee $w6_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_49
local.get $w5_3_49
local.get $w0_3_49
i16x8.sub
local.tee $w6_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_50
local.get $w5_3_50
local.get $w0_3_50
i16x8.sub
local.tee $w6_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_51
local.get $w5_3_51
local.get $w0_3_51
i16x8.sub
local.tee $w6_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_52
local.get $w5_3_52
local.get $w0_3_52
i16x8.sub
local.tee $w6_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_53
local.get $w5_3_53
local.get $w0_3_53
i16x8.sub
local.tee $w6_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_54
local.get $w5_3_54
local.get $w0_3_54
i16x8.sub
local.tee $w6_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_55
local.get $w5_3_55
local.get $w0_3_55
i16x8.sub
local.tee $w6_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_56
local.get $w5_3_56
local.get $w0_3_56
i16x8.sub
local.tee $w6_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_57
local.get $w5_3_57
local.get $w0_3_57
i16x8.sub
local.tee $w6_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_58
local.get $w5_3_58
local.get $w0_3_58
i16x8.sub
local.tee $w6_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_59
local.get $w5_3_59
local.get $w0_3_59
i16x8.sub
local.tee $w6_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_60
local.get $w5_3_60
local.get $w0_3_60
i16x8.sub
local.tee $w6_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_61
local.get $w5_3_61
local.get $w0_3_61
i16x8.sub
local.tee $w6_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_62
local.get $w5_3_62
local.get $w0_3_62
i16x8.sub
local.tee $w6_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_63
local.get $w5_3_63
local.get $w0_3_63
i16x8.sub
local.tee $w6_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=96
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp
local.get $yp
v128.load offset=112
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112
(if(local.get $keep)(then
local.get $yp1
local.get $yp1
v128.load offset=96
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp1
local.get $yp1
v128.load offset=112
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112
))
(local.set $t(i32.const 2))
(loop $tokens
(br_if $done(i32.ge_u(local.get $t)(local.get $n)))
(if(i32.lt_u(i32.add(local.get $t)(i32.const 1))(local.get $n))(then
(local.set $qo(i32.add(i32.mul(i32.shr_u(local.get $t)(i32.const 1))(local.get $cols))(local.get $start)))
(local.set $yp(i32.add(local.get $sums)(i32.mul(local.get $t)(local.get $output_bytes))))
(local.set $yp1(i32.add(local.get $yp)(local.get $output_bytes)))
(local.set $sx0(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(local.get $t)(local.get $input_stride))(i32.const 2)))))
(local.set $sx1(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(i32.add(local.get $t)(i32.const 1))(local.get $input_stride))(i32.const 2)))))
(local.set $qp(i32.add(i32.load offset=0(local.get $q))(local.get $qo)))
(local.tee $x0_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x0_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w0_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w0_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w0_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w0_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w0_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w0_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w0_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w0_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w0_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w0_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w0_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w0_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w0_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w0_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w0_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w0_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w0_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w0_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w0_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w0_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w0_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w0_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w0_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w0_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w0_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w0_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w0_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w0_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w0_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w0_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w0_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w0_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
(local.set $qp(i32.add(i32.load offset=4(local.get $q))(local.get $qo)))
(local.tee $x1_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w1_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w1_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w1_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w1_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w1_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w1_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w1_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w1_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w1_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w1_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w1_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w1_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w1_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w1_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w1_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w1_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w1_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w1_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w1_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w1_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w1_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w1_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w1_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w1_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w1_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w1_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w1_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w1_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w1_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w1_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w1_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w1_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
(local.set $qp(i32.add(i32.load offset=8(local.get $q))(local.get $qo)))
(local.tee $x2_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x2_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w2_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w2_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w2_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w2_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w2_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w2_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w2_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w2_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w2_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w2_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w2_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w2_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w2_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w2_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w2_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w2_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w2_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w2_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w2_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w2_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w2_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w2_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w2_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w2_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w2_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w2_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w2_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w2_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w2_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w2_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w2_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w2_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
(local.set $qp(i32.add(i32.load offset=12(local.get $q))(local.get $qo)))
(local.tee $x3_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w3_0_0
i32x4.dot_i16x8_s
(local.tee $x3_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w3_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w3_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w3_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w3_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w3_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w3_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w3_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w3_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w3_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w3_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w3_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w3_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w3_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w3_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w3_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w3_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w3_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w3_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w3_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w3_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w3_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w3_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w3_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w3_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w3_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w3_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w3_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w3_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w3_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w3_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w3_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w3_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w3_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w3_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w3_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w3_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w3_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w3_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w3_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w3_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w3_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w3_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w3_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w3_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w3_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w3_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w3_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w3_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w3_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w3_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w3_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w3_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w3_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w3_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w3_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w3_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w3_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w3_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w3_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w3_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w3_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w3_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x3_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w3_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
(local.set $qp(i32.add(i32.load offset=16(local.get $q))(local.get $qo)))
(local.tee $x4_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w4_0_0
i32x4.dot_i16x8_s
(local.tee $x4_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w4_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w4_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w4_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w4_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w4_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w4_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w4_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w4_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w4_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w4_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w4_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w4_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w4_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w4_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w4_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w4_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w4_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w4_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w4_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w4_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w4_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w4_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w4_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w4_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w4_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w4_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w4_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w4_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w4_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w4_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w4_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w4_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w4_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w4_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w4_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w4_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w4_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w4_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w4_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w4_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w4_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w4_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w4_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w4_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w4_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w4_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w4_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w4_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w4_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w4_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w4_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w4_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w4_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w4_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w4_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w4_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w4_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w4_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w4_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w4_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w4_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w4_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x4_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w4_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
(local.set $qp(i32.add(i32.load offset=20(local.get $q))(local.get $qo)))
(local.tee $x5_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w5_0_0
i32x4.dot_i16x8_s
(local.tee $x5_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w5_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w5_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w5_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w5_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w5_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w5_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w5_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w5_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w5_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w5_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w5_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w5_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w5_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w5_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w5_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w5_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w5_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w5_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w5_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w5_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w5_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w5_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w5_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w5_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w5_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w5_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w5_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w5_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w5_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w5_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w5_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w5_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w5_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w5_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w5_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w5_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w5_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w5_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w5_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w5_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w5_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w5_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w5_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w5_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w5_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w5_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w5_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w5_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w5_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w5_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w5_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w5_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w5_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w5_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w5_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w5_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w5_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w5_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w5_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w5_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w5_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w5_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w5_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
(local.set $qp(i32.add(i32.load offset=24(local.get $q))(local.get $qo)))
(local.tee $x6_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w6_0_0
i32x4.dot_i16x8_s
(local.tee $x6_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w6_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w6_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w6_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w6_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w6_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w6_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w6_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w6_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w6_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w6_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w6_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w6_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w6_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w6_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w6_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w6_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w6_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w6_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w6_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w6_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w6_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w6_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w6_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w6_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w6_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w6_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w6_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w6_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w6_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w6_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w6_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w6_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w6_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w6_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w6_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w6_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w6_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w6_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w6_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w6_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w6_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w6_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w6_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w6_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w6_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w6_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w6_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w6_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w6_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w6_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w6_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w6_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w6_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w6_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w6_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w6_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w6_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w6_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w6_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w6_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w6_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w6_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x6_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w6_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=0
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
local.get $yp
v128.load offset=16
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16

local.get $yp1
local.get $yp1
v128.load offset=0
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp1
local.get $yp1
v128.load offset=16
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16

local.get $x0_0
local.get $w0_1_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
local.get $w0_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
local.get $w0_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
local.get $w0_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
local.get $w0_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
local.get $w0_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
local.get $w0_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
local.get $w0_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
local.get $w0_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
local.get $w0_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
local.get $w0_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
local.get $w0_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
local.get $w0_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
local.get $w0_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
local.get $w0_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
local.get $w0_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
local.get $w0_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
local.get $w0_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
local.get $w0_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
local.get $w0_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
local.get $w0_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
local.get $w0_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
local.get $w0_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
local.get $w0_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
local.get $w0_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
local.get $w0_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
local.get $w0_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
local.get $w0_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
local.get $w0_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
local.get $w0_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
local.get $w0_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
local.get $w0_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
local.get $w0_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
local.get $w1_1_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
local.get $w1_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
local.get $w1_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
local.get $w1_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
local.get $w1_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
local.get $w1_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
local.get $w1_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
local.get $w1_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
local.get $w1_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
local.get $w1_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
local.get $w1_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
local.get $w1_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
local.get $w1_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
local.get $w1_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
local.get $w1_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
local.get $w1_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
local.get $w1_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
local.get $w1_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
local.get $w1_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
local.get $w1_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
local.get $w1_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
local.get $w1_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
local.get $w1_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
local.get $w1_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
local.get $w1_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
local.get $w1_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
local.get $w1_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
local.get $w1_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
local.get $w1_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
local.get $w1_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
local.get $w1_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
local.get $w1_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
local.get $w1_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
local.get $w2_1_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
local.get $w2_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
local.get $w2_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
local.get $w2_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
local.get $w2_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
local.get $w2_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
local.get $w2_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
local.get $w2_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
local.get $w2_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
local.get $w2_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
local.get $w2_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
local.get $w2_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
local.get $w2_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
local.get $w2_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
local.get $w2_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
local.get $w2_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
local.get $w2_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
local.get $w2_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
local.get $w2_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
local.get $w2_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
local.get $w2_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
local.get $w2_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
local.get $w2_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
local.get $w2_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
local.get $w2_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
local.get $w2_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
local.get $w2_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
local.get $w2_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
local.get $w2_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
local.get $w2_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
local.get $w2_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
local.get $w2_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
local.get $w2_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x3_0
local.get $w3_1_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_32
local.get $w3_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_33
local.get $w3_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_34
local.get $w3_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_35
local.get $w3_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_36
local.get $w3_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_37
local.get $w3_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_38
local.get $w3_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_39
local.get $w3_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_40
local.get $w3_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_41
local.get $w3_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_42
local.get $w3_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_43
local.get $w3_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_44
local.get $w3_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_45
local.get $w3_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_46
local.get $w3_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_47
local.get $w3_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_48
local.get $w3_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_49
local.get $w3_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_50
local.get $w3_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_51
local.get $w3_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_52
local.get $w3_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_53
local.get $w3_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_54
local.get $w3_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_55
local.get $w3_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_56
local.get $w3_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_57
local.get $w3_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_58
local.get $w3_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_59
local.get $w3_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_60
local.get $w3_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_61
local.get $w3_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_62
local.get $w3_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_63
local.get $w3_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
local.get $x4_0
local.get $w4_1_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_32
local.get $w4_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_33
local.get $w4_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_34
local.get $w4_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_35
local.get $w4_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_36
local.get $w4_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_37
local.get $w4_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_38
local.get $w4_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_39
local.get $w4_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_40
local.get $w4_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_41
local.get $w4_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_42
local.get $w4_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_43
local.get $w4_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_44
local.get $w4_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_45
local.get $w4_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_46
local.get $w4_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_47
local.get $w4_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_48
local.get $w4_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_49
local.get $w4_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_50
local.get $w4_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_51
local.get $w4_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_52
local.get $w4_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_53
local.get $w4_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_54
local.get $w4_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_55
local.get $w4_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_56
local.get $w4_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_57
local.get $w4_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_58
local.get $w4_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_59
local.get $w4_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_60
local.get $w4_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_61
local.get $w4_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_62
local.get $w4_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_63
local.get $w4_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
local.get $x5_0
local.get $w5_1_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $x6_0
local.get $w6_1_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_32
local.get $w6_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_33
local.get $w6_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_34
local.get $w6_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_35
local.get $w6_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_36
local.get $w6_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_37
local.get $w6_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_38
local.get $w6_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_39
local.get $w6_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_40
local.get $w6_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_41
local.get $w6_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_42
local.get $w6_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_43
local.get $w6_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_44
local.get $w6_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_45
local.get $w6_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_46
local.get $w6_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_47
local.get $w6_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_48
local.get $w6_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_49
local.get $w6_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_50
local.get $w6_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_51
local.get $w6_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_52
local.get $w6_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_53
local.get $w6_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_54
local.get $w6_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_55
local.get $w6_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_56
local.get $w6_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_57
local.get $w6_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_58
local.get $w6_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_59
local.get $w6_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_60
local.get $w6_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_61
local.get $w6_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_62
local.get $w6_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_63
local.get $w6_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=32
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
local.get $yp
v128.load offset=48
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48

local.get $yp1
local.get $yp1
v128.load offset=32
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp1
local.get $yp1
v128.load offset=48
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48

local.get $x0_0
local.get $w0_2_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
local.get $w0_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
local.get $w0_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
local.get $w0_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
local.get $w0_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
local.get $w0_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
local.get $w0_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
local.get $w0_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
local.get $w0_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
local.get $w0_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
local.get $w0_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
local.get $w0_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
local.get $w0_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
local.get $w0_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
local.get $w0_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
local.get $w0_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
local.get $w0_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
local.get $w0_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
local.get $w0_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
local.get $w0_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
local.get $w0_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
local.get $w0_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
local.get $w0_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
local.get $w0_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
local.get $w0_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
local.get $w0_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
local.get $w0_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
local.get $w0_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
local.get $w0_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
local.get $w0_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
local.get $w0_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
local.get $w0_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
local.get $w0_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
local.get $w1_2_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
local.get $w1_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
local.get $w1_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
local.get $w1_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
local.get $w1_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
local.get $w1_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
local.get $w1_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
local.get $w1_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
local.get $w1_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
local.get $w1_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
local.get $w1_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
local.get $w1_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
local.get $w1_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
local.get $w1_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
local.get $w1_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
local.get $w1_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
local.get $w1_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
local.get $w1_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
local.get $w1_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
local.get $w1_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
local.get $w1_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
local.get $w1_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
local.get $w1_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
local.get $w1_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
local.get $w1_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
local.get $w1_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
local.get $w1_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
local.get $w1_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
local.get $w1_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
local.get $w1_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
local.get $w1_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
local.get $w1_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
local.get $w1_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
local.get $w2_2_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
local.get $w2_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
local.get $w2_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
local.get $w2_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
local.get $w2_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
local.get $w2_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
local.get $w2_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
local.get $w2_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
local.get $w2_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
local.get $w2_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
local.get $w2_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
local.get $w2_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
local.get $w2_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
local.get $w2_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
local.get $w2_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
local.get $w2_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
local.get $w2_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
local.get $w2_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
local.get $w2_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
local.get $w2_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
local.get $w2_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
local.get $w2_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
local.get $w2_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
local.get $w2_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
local.get $w2_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
local.get $w2_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
local.get $w2_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
local.get $w2_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
local.get $w2_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
local.get $w2_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
local.get $w2_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
local.get $w2_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
local.get $w2_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x3_0
local.get $w3_2_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_32
local.get $w3_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_33
local.get $w3_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_34
local.get $w3_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_35
local.get $w3_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_36
local.get $w3_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_37
local.get $w3_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_38
local.get $w3_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_39
local.get $w3_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_40
local.get $w3_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_41
local.get $w3_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_42
local.get $w3_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_43
local.get $w3_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_44
local.get $w3_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_45
local.get $w3_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_46
local.get $w3_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_47
local.get $w3_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_48
local.get $w3_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_49
local.get $w3_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_50
local.get $w3_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_51
local.get $w3_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_52
local.get $w3_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_53
local.get $w3_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_54
local.get $w3_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_55
local.get $w3_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_56
local.get $w3_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_57
local.get $w3_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_58
local.get $w3_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_59
local.get $w3_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_60
local.get $w3_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_61
local.get $w3_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_62
local.get $w3_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_63
local.get $w3_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
local.get $x4_0
local.get $w4_2_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_32
local.get $w4_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_33
local.get $w4_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_34
local.get $w4_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_35
local.get $w4_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_36
local.get $w4_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_37
local.get $w4_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_38
local.get $w4_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_39
local.get $w4_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_40
local.get $w4_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_41
local.get $w4_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_42
local.get $w4_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_43
local.get $w4_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_44
local.get $w4_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_45
local.get $w4_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_46
local.get $w4_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_47
local.get $w4_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_48
local.get $w4_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_49
local.get $w4_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_50
local.get $w4_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_51
local.get $w4_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_52
local.get $w4_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_53
local.get $w4_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_54
local.get $w4_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_55
local.get $w4_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_56
local.get $w4_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_57
local.get $w4_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_58
local.get $w4_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_59
local.get $w4_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_60
local.get $w4_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_61
local.get $w4_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_62
local.get $w4_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_63
local.get $w4_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
local.get $x5_0
local.get $w5_2_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $x6_0
local.get $w6_2_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_32
local.get $w6_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_33
local.get $w6_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_34
local.get $w6_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_35
local.get $w6_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_36
local.get $w6_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_37
local.get $w6_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_38
local.get $w6_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_39
local.get $w6_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_40
local.get $w6_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_41
local.get $w6_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_42
local.get $w6_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_43
local.get $w6_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_44
local.get $w6_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_45
local.get $w6_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_46
local.get $w6_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_47
local.get $w6_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_48
local.get $w6_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_49
local.get $w6_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_50
local.get $w6_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_51
local.get $w6_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_52
local.get $w6_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_53
local.get $w6_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_54
local.get $w6_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_55
local.get $w6_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_56
local.get $w6_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_57
local.get $w6_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_58
local.get $w6_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_59
local.get $w6_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_60
local.get $w6_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_61
local.get $w6_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_62
local.get $w6_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_63
local.get $w6_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=64
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp
local.get $yp
v128.load offset=80
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80

local.get $yp1
local.get $yp1
v128.load offset=64
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp1
local.get $yp1
v128.load offset=80
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80

local.get $x0_0
local.get $w0_3_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
local.get $w0_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
local.get $w0_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
local.get $w0_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
local.get $w0_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
local.get $w0_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
local.get $w0_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
local.get $w0_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
local.get $w0_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
local.get $w0_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
local.get $w0_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
local.get $w0_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
local.get $w0_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
local.get $w0_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
local.get $w0_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
local.get $w0_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
local.get $w0_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
local.get $w0_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
local.get $w0_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
local.get $w0_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
local.get $w0_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
local.get $w0_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
local.get $w0_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
local.get $w0_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
local.get $w0_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
local.get $w0_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
local.get $w0_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
local.get $w0_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
local.get $w0_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
local.get $w0_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
local.get $w0_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
local.get $w0_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
local.get $w0_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
local.get $w1_3_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
local.get $w1_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
local.get $w1_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
local.get $w1_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
local.get $w1_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
local.get $w1_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
local.get $w1_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
local.get $w1_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
local.get $w1_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
local.get $w1_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
local.get $w1_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
local.get $w1_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
local.get $w1_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
local.get $w1_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
local.get $w1_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
local.get $w1_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
local.get $w1_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
local.get $w1_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
local.get $w1_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
local.get $w1_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
local.get $w1_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
local.get $w1_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
local.get $w1_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
local.get $w1_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
local.get $w1_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
local.get $w1_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
local.get $w1_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
local.get $w1_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
local.get $w1_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
local.get $w1_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
local.get $w1_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
local.get $w1_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
local.get $w1_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
local.get $w2_3_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
local.get $w2_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
local.get $w2_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
local.get $w2_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
local.get $w2_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
local.get $w2_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
local.get $w2_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
local.get $w2_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
local.get $w2_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
local.get $w2_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
local.get $w2_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
local.get $w2_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
local.get $w2_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
local.get $w2_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
local.get $w2_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
local.get $w2_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
local.get $w2_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
local.get $w2_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
local.get $w2_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
local.get $w2_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
local.get $w2_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
local.get $w2_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
local.get $w2_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
local.get $w2_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
local.get $w2_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
local.get $w2_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
local.get $w2_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
local.get $w2_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
local.get $w2_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
local.get $w2_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
local.get $w2_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
local.get $w2_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
local.get $w2_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x3_0
local.get $w3_3_0
i32x4.dot_i16x8_s
local.get $x3_1
local.get $w3_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_2
local.get $w3_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_3
local.get $w3_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_4
local.get $w3_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_5
local.get $w3_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_6
local.get $w3_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_7
local.get $w3_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_8
local.get $w3_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_9
local.get $w3_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_10
local.get $w3_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_11
local.get $w3_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_12
local.get $w3_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_13
local.get $w3_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_14
local.get $w3_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_15
local.get $w3_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_16
local.get $w3_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_17
local.get $w3_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_18
local.get $w3_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_19
local.get $w3_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_20
local.get $w3_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_21
local.get $w3_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_22
local.get $w3_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_23
local.get $w3_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_24
local.get $w3_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_25
local.get $w3_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_26
local.get $w3_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_27
local.get $w3_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_28
local.get $w3_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_29
local.get $w3_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_30
local.get $w3_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_31
local.get $w3_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_32
local.get $w3_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_33
local.get $w3_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_34
local.get $w3_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_35
local.get $w3_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_36
local.get $w3_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_37
local.get $w3_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_38
local.get $w3_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_39
local.get $w3_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_40
local.get $w3_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_41
local.get $w3_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_42
local.get $w3_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_43
local.get $w3_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_44
local.get $w3_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_45
local.get $w3_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_46
local.get $w3_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_47
local.get $w3_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_48
local.get $w3_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_49
local.get $w3_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_50
local.get $w3_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_51
local.get $w3_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_52
local.get $w3_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_53
local.get $w3_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_54
local.get $w3_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_55
local.get $w3_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_56
local.get $w3_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_57
local.get $w3_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_58
local.get $w3_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_59
local.get $w3_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_60
local.get $w3_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_61
local.get $w3_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_62
local.get $w3_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x3_63
local.get $w3_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc3
local.get $x4_0
local.get $w4_3_0
i32x4.dot_i16x8_s
local.get $x4_1
local.get $w4_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_2
local.get $w4_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_3
local.get $w4_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_4
local.get $w4_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_5
local.get $w4_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_6
local.get $w4_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_7
local.get $w4_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_8
local.get $w4_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_9
local.get $w4_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_10
local.get $w4_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_11
local.get $w4_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_12
local.get $w4_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_13
local.get $w4_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_14
local.get $w4_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_15
local.get $w4_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_16
local.get $w4_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_17
local.get $w4_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_18
local.get $w4_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_19
local.get $w4_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_20
local.get $w4_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_21
local.get $w4_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_22
local.get $w4_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_23
local.get $w4_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_24
local.get $w4_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_25
local.get $w4_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_26
local.get $w4_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_27
local.get $w4_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_28
local.get $w4_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_29
local.get $w4_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_30
local.get $w4_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_31
local.get $w4_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_32
local.get $w4_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_33
local.get $w4_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_34
local.get $w4_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_35
local.get $w4_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_36
local.get $w4_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_37
local.get $w4_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_38
local.get $w4_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_39
local.get $w4_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_40
local.get $w4_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_41
local.get $w4_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_42
local.get $w4_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_43
local.get $w4_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_44
local.get $w4_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_45
local.get $w4_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_46
local.get $w4_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_47
local.get $w4_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_48
local.get $w4_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_49
local.get $w4_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_50
local.get $w4_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_51
local.get $w4_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_52
local.get $w4_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_53
local.get $w4_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_54
local.get $w4_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_55
local.get $w4_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_56
local.get $w4_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_57
local.get $w4_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_58
local.get $w4_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_59
local.get $w4_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_60
local.get $w4_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_61
local.get $w4_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_62
local.get $w4_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x4_63
local.get $w4_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc4
local.get $x5_0
local.get $w5_3_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $x6_0
local.get $w6_3_0
i32x4.dot_i16x8_s
local.get $x6_1
local.get $w6_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_2
local.get $w6_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_3
local.get $w6_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_4
local.get $w6_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_5
local.get $w6_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_6
local.get $w6_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_7
local.get $w6_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_8
local.get $w6_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_9
local.get $w6_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_10
local.get $w6_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_11
local.get $w6_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_12
local.get $w6_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_13
local.get $w6_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_14
local.get $w6_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_15
local.get $w6_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_16
local.get $w6_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_17
local.get $w6_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_18
local.get $w6_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_19
local.get $w6_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_20
local.get $w6_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_21
local.get $w6_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_22
local.get $w6_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_23
local.get $w6_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_24
local.get $w6_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_25
local.get $w6_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_26
local.get $w6_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_27
local.get $w6_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_28
local.get $w6_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_29
local.get $w6_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_30
local.get $w6_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_31
local.get $w6_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_32
local.get $w6_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_33
local.get $w6_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_34
local.get $w6_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_35
local.get $w6_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_36
local.get $w6_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_37
local.get $w6_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_38
local.get $w6_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_39
local.get $w6_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_40
local.get $w6_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_41
local.get $w6_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_42
local.get $w6_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_43
local.get $w6_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_44
local.get $w6_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_45
local.get $w6_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_46
local.get $w6_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_47
local.get $w6_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_48
local.get $w6_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_49
local.get $w6_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_50
local.get $w6_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_51
local.get $w6_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_52
local.get $w6_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_53
local.get $w6_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_54
local.get $w6_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_55
local.get $w6_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_56
local.get $w6_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_57
local.get $w6_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_58
local.get $w6_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_59
local.get $w6_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_60
local.get $w6_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_61
local.get $w6_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_62
local.get $w6_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x6_63
local.get $w6_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc6
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.set $pc8
local.get $pc8
local.get $pc6
i32x4.add
local.set $pc9
local.get $pc8
local.get $pc4
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $pc9
local.get $pc3
i32x4.sub
local.set $pc11
local.get $pc9
local.get $pc4
i32x4.add
local.set $pc12
local.get $yp
local.get $yp
v128.load offset=96
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp
local.get $yp
v128.load offset=112
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112

local.get $yp1
local.get $yp1
v128.load offset=96
local.get $pc11
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp1
local.get $yp1
v128.load offset=112
local.get $pc12
f32x4.convert_i32x4_s
local.get $sx1
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112

)(else
(local.set $qo(i32.add(i32.mul(i32.shr_u(local.get $t)(i32.const 1))(local.get $cols))(local.get $start)))
(local.set $yp(i32.add(local.get $sums)(i32.mul(local.get $t)(local.get $output_bytes))))
(local.set $sx0(v128.load32_splat(i32.add(local.get $sx)(i32.shl(i32.mul(local.get $t)(local.get $input_stride))(i32.const 2)))))

(local.set $qp(i32.add(i32.load offset=0(local.get $q))(local.get $qo)))
(local.tee $x0_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w0_0_0
i32x4.dot_i16x8_s
(local.tee $x0_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w0_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w0_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w0_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w0_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w0_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w0_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w0_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w0_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w0_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w0_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w0_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w0_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w0_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w0_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w0_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w0_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w0_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w0_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w0_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w0_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w0_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w0_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w0_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w0_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w0_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w0_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w0_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w0_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w0_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w0_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w0_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w0_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w0_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w0_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w0_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w0_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w0_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w0_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w0_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w0_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w0_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w0_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w0_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w0_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w0_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w0_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w0_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w0_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w0_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w0_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w0_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w0_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w0_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w0_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w0_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w0_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w0_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w0_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w0_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w0_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w0_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w0_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x0_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w0_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
(local.set $qp(i32.add(i32.load offset=4(local.get $q))(local.get $qo)))
(local.tee $x1_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w1_0_0
i32x4.dot_i16x8_s
(local.tee $x1_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w1_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w1_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w1_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w1_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w1_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w1_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w1_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w1_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w1_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w1_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w1_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w1_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w1_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w1_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w1_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w1_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w1_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w1_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w1_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w1_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w1_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w1_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w1_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w1_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w1_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w1_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w1_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w1_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w1_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w1_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w1_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w1_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w1_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w1_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w1_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w1_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w1_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w1_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w1_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w1_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w1_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w1_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w1_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w1_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w1_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w1_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w1_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w1_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w1_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w1_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w1_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w1_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w1_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w1_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w1_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w1_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w1_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w1_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w1_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w1_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w1_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w1_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x1_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w1_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
(local.set $qp(i32.add(i32.load offset=8(local.get $q))(local.get $qo)))
(local.tee $x2_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w2_0_0
i32x4.dot_i16x8_s
(local.tee $x2_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w2_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w2_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w2_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w2_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w2_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w2_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w2_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w2_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w2_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w2_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w2_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w2_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w2_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w2_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w2_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w2_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w2_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w2_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w2_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w2_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w2_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w2_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w2_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w2_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w2_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w2_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w2_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w2_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w2_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w2_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w2_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w2_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w2_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w2_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w2_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w2_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w2_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w2_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w2_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w2_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w2_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w2_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w2_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w2_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w2_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w2_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w2_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w2_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w2_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w2_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w2_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w2_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w2_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w2_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w2_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w2_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w2_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w2_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w2_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w2_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w2_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w2_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x2_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w2_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
(local.set $qp(i32.add(i32.load offset=20(local.get $q))(local.get $qo)))
(local.tee $x5_0(v128.load32_splat offset=0(local.get $qp)))
local.get $w5_0_0
i32x4.dot_i16x8_s
(local.tee $x5_1(v128.load32_splat offset=4(local.get $qp)))
local.get $w5_0_1
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_2(v128.load32_splat offset=8(local.get $qp)))
local.get $w5_0_2
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_3(v128.load32_splat offset=12(local.get $qp)))
local.get $w5_0_3
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_4(v128.load32_splat offset=16(local.get $qp)))
local.get $w5_0_4
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_5(v128.load32_splat offset=20(local.get $qp)))
local.get $w5_0_5
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_6(v128.load32_splat offset=24(local.get $qp)))
local.get $w5_0_6
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_7(v128.load32_splat offset=28(local.get $qp)))
local.get $w5_0_7
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_8(v128.load32_splat offset=32(local.get $qp)))
local.get $w5_0_8
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_9(v128.load32_splat offset=36(local.get $qp)))
local.get $w5_0_9
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_10(v128.load32_splat offset=40(local.get $qp)))
local.get $w5_0_10
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_11(v128.load32_splat offset=44(local.get $qp)))
local.get $w5_0_11
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_12(v128.load32_splat offset=48(local.get $qp)))
local.get $w5_0_12
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_13(v128.load32_splat offset=52(local.get $qp)))
local.get $w5_0_13
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_14(v128.load32_splat offset=56(local.get $qp)))
local.get $w5_0_14
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_15(v128.load32_splat offset=60(local.get $qp)))
local.get $w5_0_15
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_16(v128.load32_splat offset=64(local.get $qp)))
local.get $w5_0_16
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_17(v128.load32_splat offset=68(local.get $qp)))
local.get $w5_0_17
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_18(v128.load32_splat offset=72(local.get $qp)))
local.get $w5_0_18
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_19(v128.load32_splat offset=76(local.get $qp)))
local.get $w5_0_19
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_20(v128.load32_splat offset=80(local.get $qp)))
local.get $w5_0_20
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_21(v128.load32_splat offset=84(local.get $qp)))
local.get $w5_0_21
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_22(v128.load32_splat offset=88(local.get $qp)))
local.get $w5_0_22
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_23(v128.load32_splat offset=92(local.get $qp)))
local.get $w5_0_23
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_24(v128.load32_splat offset=96(local.get $qp)))
local.get $w5_0_24
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_25(v128.load32_splat offset=100(local.get $qp)))
local.get $w5_0_25
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_26(v128.load32_splat offset=104(local.get $qp)))
local.get $w5_0_26
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_27(v128.load32_splat offset=108(local.get $qp)))
local.get $w5_0_27
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_28(v128.load32_splat offset=112(local.get $qp)))
local.get $w5_0_28
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_29(v128.load32_splat offset=116(local.get $qp)))
local.get $w5_0_29
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_30(v128.load32_splat offset=120(local.get $qp)))
local.get $w5_0_30
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_31(v128.load32_splat offset=124(local.get $qp)))
local.get $w5_0_31
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_32(v128.load32_splat offset=128(local.get $qp)))
local.get $w5_0_32
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_33(v128.load32_splat offset=132(local.get $qp)))
local.get $w5_0_33
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_34(v128.load32_splat offset=136(local.get $qp)))
local.get $w5_0_34
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_35(v128.load32_splat offset=140(local.get $qp)))
local.get $w5_0_35
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_36(v128.load32_splat offset=144(local.get $qp)))
local.get $w5_0_36
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_37(v128.load32_splat offset=148(local.get $qp)))
local.get $w5_0_37
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_38(v128.load32_splat offset=152(local.get $qp)))
local.get $w5_0_38
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_39(v128.load32_splat offset=156(local.get $qp)))
local.get $w5_0_39
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_40(v128.load32_splat offset=160(local.get $qp)))
local.get $w5_0_40
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_41(v128.load32_splat offset=164(local.get $qp)))
local.get $w5_0_41
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_42(v128.load32_splat offset=168(local.get $qp)))
local.get $w5_0_42
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_43(v128.load32_splat offset=172(local.get $qp)))
local.get $w5_0_43
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_44(v128.load32_splat offset=176(local.get $qp)))
local.get $w5_0_44
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_45(v128.load32_splat offset=180(local.get $qp)))
local.get $w5_0_45
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_46(v128.load32_splat offset=184(local.get $qp)))
local.get $w5_0_46
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_47(v128.load32_splat offset=188(local.get $qp)))
local.get $w5_0_47
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_48(v128.load32_splat offset=192(local.get $qp)))
local.get $w5_0_48
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_49(v128.load32_splat offset=196(local.get $qp)))
local.get $w5_0_49
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_50(v128.load32_splat offset=200(local.get $qp)))
local.get $w5_0_50
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_51(v128.load32_splat offset=204(local.get $qp)))
local.get $w5_0_51
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_52(v128.load32_splat offset=208(local.get $qp)))
local.get $w5_0_52
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_53(v128.load32_splat offset=212(local.get $qp)))
local.get $w5_0_53
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_54(v128.load32_splat offset=216(local.get $qp)))
local.get $w5_0_54
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_55(v128.load32_splat offset=220(local.get $qp)))
local.get $w5_0_55
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_56(v128.load32_splat offset=224(local.get $qp)))
local.get $w5_0_56
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_57(v128.load32_splat offset=228(local.get $qp)))
local.get $w5_0_57
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_58(v128.load32_splat offset=232(local.get $qp)))
local.get $w5_0_58
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_59(v128.load32_splat offset=236(local.get $qp)))
local.get $w5_0_59
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_60(v128.load32_splat offset=240(local.get $qp)))
local.get $w5_0_60
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_61(v128.load32_splat offset=244(local.get $qp)))
local.get $w5_0_61
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_62(v128.load32_splat offset=248(local.get $qp)))
local.get $w5_0_62
i32x4.dot_i16x8_s
i32x4.add
(local.tee $x5_63(v128.load32_splat offset=252(local.get $qp)))
local.get $w5_0_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $yp
local.get $yp
v128.load offset=0
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
local.get $yp
v128.load offset=16
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw1
f32x4.mul
f32x4.add
v128.store offset=16

local.get $x0_0
local.get $w0_1_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
local.get $w0_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
local.get $w0_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
local.get $w0_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
local.get $w0_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
local.get $w0_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
local.get $w0_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
local.get $w0_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
local.get $w0_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
local.get $w0_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
local.get $w0_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
local.get $w0_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
local.get $w0_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
local.get $w0_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
local.get $w0_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
local.get $w0_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
local.get $w0_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
local.get $w0_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
local.get $w0_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
local.get $w0_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
local.get $w0_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
local.get $w0_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
local.get $w0_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
local.get $w0_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
local.get $w0_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
local.get $w0_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
local.get $w0_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
local.get $w0_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
local.get $w0_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
local.get $w0_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
local.get $w0_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
local.get $w0_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
local.get $w0_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
local.get $w1_1_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
local.get $w1_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
local.get $w1_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
local.get $w1_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
local.get $w1_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
local.get $w1_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
local.get $w1_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
local.get $w1_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
local.get $w1_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
local.get $w1_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
local.get $w1_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
local.get $w1_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
local.get $w1_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
local.get $w1_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
local.get $w1_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
local.get $w1_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
local.get $w1_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
local.get $w1_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
local.get $w1_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
local.get $w1_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
local.get $w1_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
local.get $w1_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
local.get $w1_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
local.get $w1_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
local.get $w1_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
local.get $w1_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
local.get $w1_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
local.get $w1_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
local.get $w1_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
local.get $w1_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
local.get $w1_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
local.get $w1_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
local.get $w1_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
local.get $w2_1_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
local.get $w2_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
local.get $w2_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
local.get $w2_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
local.get $w2_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
local.get $w2_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
local.get $w2_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
local.get $w2_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
local.get $w2_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
local.get $w2_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
local.get $w2_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
local.get $w2_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
local.get $w2_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
local.get $w2_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
local.get $w2_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
local.get $w2_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
local.get $w2_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
local.get $w2_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
local.get $w2_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
local.get $w2_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
local.get $w2_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
local.get $w2_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
local.get $w2_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
local.get $w2_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
local.get $w2_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
local.get $w2_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
local.get $w2_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
local.get $w2_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
local.get $w2_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
local.get $w2_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
local.get $w2_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
local.get $w2_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
local.get $w2_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x5_0
local.get $w5_1_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_1_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_1_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_1_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_1_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_1_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_1_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_1_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_1_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_1_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_1_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_1_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_1_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_1_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_1_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_1_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_1_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_1_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_1_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_1_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_1_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_1_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_1_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_1_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_1_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_1_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_1_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_1_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_1_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_1_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_1_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_1_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_1_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_1_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_1_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_1_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_1_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_1_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_1_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_1_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_1_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_1_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_1_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_1_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_1_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_1_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_1_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_1_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_1_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_1_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_1_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_1_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_1_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_1_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_1_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_1_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_1_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_1_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_1_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_1_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_1_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_1_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_1_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_1_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $yp
local.get $yp
v128.load offset=32
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
local.get $yp
v128.load offset=48
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw3
f32x4.mul
f32x4.add
v128.store offset=48

local.get $x0_0
local.get $w0_2_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
local.get $w0_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
local.get $w0_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
local.get $w0_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
local.get $w0_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
local.get $w0_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
local.get $w0_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
local.get $w0_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
local.get $w0_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
local.get $w0_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
local.get $w0_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
local.get $w0_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
local.get $w0_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
local.get $w0_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
local.get $w0_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
local.get $w0_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
local.get $w0_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
local.get $w0_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
local.get $w0_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
local.get $w0_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
local.get $w0_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
local.get $w0_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
local.get $w0_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
local.get $w0_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
local.get $w0_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
local.get $w0_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
local.get $w0_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
local.get $w0_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
local.get $w0_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
local.get $w0_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
local.get $w0_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
local.get $w0_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
local.get $w0_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
local.get $w1_2_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
local.get $w1_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
local.get $w1_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
local.get $w1_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
local.get $w1_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
local.get $w1_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
local.get $w1_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
local.get $w1_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
local.get $w1_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
local.get $w1_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
local.get $w1_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
local.get $w1_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
local.get $w1_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
local.get $w1_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
local.get $w1_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
local.get $w1_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
local.get $w1_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
local.get $w1_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
local.get $w1_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
local.get $w1_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
local.get $w1_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
local.get $w1_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
local.get $w1_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
local.get $w1_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
local.get $w1_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
local.get $w1_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
local.get $w1_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
local.get $w1_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
local.get $w1_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
local.get $w1_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
local.get $w1_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
local.get $w1_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
local.get $w1_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
local.get $w2_2_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
local.get $w2_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
local.get $w2_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
local.get $w2_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
local.get $w2_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
local.get $w2_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
local.get $w2_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
local.get $w2_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
local.get $w2_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
local.get $w2_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
local.get $w2_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
local.get $w2_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
local.get $w2_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
local.get $w2_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
local.get $w2_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
local.get $w2_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
local.get $w2_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
local.get $w2_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
local.get $w2_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
local.get $w2_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
local.get $w2_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
local.get $w2_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
local.get $w2_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
local.get $w2_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
local.get $w2_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
local.get $w2_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
local.get $w2_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
local.get $w2_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
local.get $w2_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
local.get $w2_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
local.get $w2_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
local.get $w2_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
local.get $w2_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x5_0
local.get $w5_2_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_2_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_2_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_2_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_2_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_2_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_2_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_2_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_2_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_2_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_2_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_2_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_2_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_2_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_2_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_2_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_2_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_2_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_2_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_2_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_2_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_2_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_2_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_2_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_2_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_2_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_2_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_2_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_2_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_2_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_2_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_2_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_2_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_2_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_2_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_2_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_2_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_2_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_2_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_2_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_2_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_2_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_2_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_2_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_2_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_2_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_2_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_2_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_2_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_2_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_2_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_2_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_2_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_2_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_2_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_2_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_2_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_2_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_2_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_2_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_2_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_2_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_2_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_2_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $yp
local.get $yp
v128.load offset=64
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw4
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp
local.get $yp
v128.load offset=80
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw5
f32x4.mul
f32x4.add
v128.store offset=80

local.get $x0_0
local.get $w0_3_0
i32x4.dot_i16x8_s
local.get $x0_1
local.get $w0_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_2
local.get $w0_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_3
local.get $w0_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_4
local.get $w0_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_5
local.get $w0_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_6
local.get $w0_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_7
local.get $w0_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_8
local.get $w0_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_9
local.get $w0_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_10
local.get $w0_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_11
local.get $w0_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_12
local.get $w0_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_13
local.get $w0_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_14
local.get $w0_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_15
local.get $w0_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_16
local.get $w0_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_17
local.get $w0_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_18
local.get $w0_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_19
local.get $w0_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_20
local.get $w0_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_21
local.get $w0_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_22
local.get $w0_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_23
local.get $w0_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_24
local.get $w0_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_25
local.get $w0_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_26
local.get $w0_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_27
local.get $w0_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_28
local.get $w0_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_29
local.get $w0_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_30
local.get $w0_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_31
local.get $w0_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_32
local.get $w0_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_33
local.get $w0_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_34
local.get $w0_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_35
local.get $w0_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_36
local.get $w0_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_37
local.get $w0_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_38
local.get $w0_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_39
local.get $w0_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_40
local.get $w0_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_41
local.get $w0_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_42
local.get $w0_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_43
local.get $w0_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_44
local.get $w0_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_45
local.get $w0_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_46
local.get $w0_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_47
local.get $w0_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_48
local.get $w0_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_49
local.get $w0_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_50
local.get $w0_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_51
local.get $w0_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_52
local.get $w0_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_53
local.get $w0_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_54
local.get $w0_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_55
local.get $w0_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_56
local.get $w0_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_57
local.get $w0_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_58
local.get $w0_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_59
local.get $w0_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_60
local.get $w0_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_61
local.get $w0_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_62
local.get $w0_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x0_63
local.get $w0_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc0
local.get $x1_0
local.get $w1_3_0
i32x4.dot_i16x8_s
local.get $x1_1
local.get $w1_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_2
local.get $w1_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_3
local.get $w1_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_4
local.get $w1_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_5
local.get $w1_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_6
local.get $w1_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_7
local.get $w1_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_8
local.get $w1_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_9
local.get $w1_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_10
local.get $w1_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_11
local.get $w1_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_12
local.get $w1_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_13
local.get $w1_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_14
local.get $w1_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_15
local.get $w1_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_16
local.get $w1_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_17
local.get $w1_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_18
local.get $w1_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_19
local.get $w1_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_20
local.get $w1_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_21
local.get $w1_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_22
local.get $w1_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_23
local.get $w1_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_24
local.get $w1_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_25
local.get $w1_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_26
local.get $w1_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_27
local.get $w1_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_28
local.get $w1_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_29
local.get $w1_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_30
local.get $w1_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_31
local.get $w1_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_32
local.get $w1_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_33
local.get $w1_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_34
local.get $w1_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_35
local.get $w1_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_36
local.get $w1_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_37
local.get $w1_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_38
local.get $w1_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_39
local.get $w1_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_40
local.get $w1_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_41
local.get $w1_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_42
local.get $w1_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_43
local.get $w1_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_44
local.get $w1_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_45
local.get $w1_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_46
local.get $w1_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_47
local.get $w1_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_48
local.get $w1_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_49
local.get $w1_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_50
local.get $w1_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_51
local.get $w1_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_52
local.get $w1_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_53
local.get $w1_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_54
local.get $w1_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_55
local.get $w1_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_56
local.get $w1_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_57
local.get $w1_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_58
local.get $w1_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_59
local.get $w1_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_60
local.get $w1_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_61
local.get $w1_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_62
local.get $w1_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x1_63
local.get $w1_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc1
local.get $x2_0
local.get $w2_3_0
i32x4.dot_i16x8_s
local.get $x2_1
local.get $w2_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_2
local.get $w2_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_3
local.get $w2_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_4
local.get $w2_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_5
local.get $w2_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_6
local.get $w2_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_7
local.get $w2_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_8
local.get $w2_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_9
local.get $w2_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_10
local.get $w2_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_11
local.get $w2_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_12
local.get $w2_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_13
local.get $w2_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_14
local.get $w2_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_15
local.get $w2_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_16
local.get $w2_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_17
local.get $w2_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_18
local.get $w2_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_19
local.get $w2_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_20
local.get $w2_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_21
local.get $w2_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_22
local.get $w2_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_23
local.get $w2_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_24
local.get $w2_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_25
local.get $w2_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_26
local.get $w2_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_27
local.get $w2_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_28
local.get $w2_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_29
local.get $w2_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_30
local.get $w2_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_31
local.get $w2_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_32
local.get $w2_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_33
local.get $w2_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_34
local.get $w2_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_35
local.get $w2_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_36
local.get $w2_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_37
local.get $w2_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_38
local.get $w2_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_39
local.get $w2_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_40
local.get $w2_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_41
local.get $w2_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_42
local.get $w2_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_43
local.get $w2_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_44
local.get $w2_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_45
local.get $w2_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_46
local.get $w2_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_47
local.get $w2_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_48
local.get $w2_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_49
local.get $w2_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_50
local.get $w2_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_51
local.get $w2_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_52
local.get $w2_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_53
local.get $w2_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_54
local.get $w2_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_55
local.get $w2_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_56
local.get $w2_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_57
local.get $w2_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_58
local.get $w2_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_59
local.get $w2_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_60
local.get $w2_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_61
local.get $w2_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_62
local.get $w2_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x2_63
local.get $w2_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc2
local.get $x5_0
local.get $w5_3_0
i32x4.dot_i16x8_s
local.get $x5_1
local.get $w5_3_1
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_2
local.get $w5_3_2
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_3
local.get $w5_3_3
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_4
local.get $w5_3_4
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_5
local.get $w5_3_5
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_6
local.get $w5_3_6
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_7
local.get $w5_3_7
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_8
local.get $w5_3_8
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_9
local.get $w5_3_9
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_10
local.get $w5_3_10
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_11
local.get $w5_3_11
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_12
local.get $w5_3_12
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_13
local.get $w5_3_13
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_14
local.get $w5_3_14
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_15
local.get $w5_3_15
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_16
local.get $w5_3_16
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_17
local.get $w5_3_17
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_18
local.get $w5_3_18
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_19
local.get $w5_3_19
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_20
local.get $w5_3_20
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_21
local.get $w5_3_21
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_22
local.get $w5_3_22
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_23
local.get $w5_3_23
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_24
local.get $w5_3_24
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_25
local.get $w5_3_25
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_26
local.get $w5_3_26
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_27
local.get $w5_3_27
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_28
local.get $w5_3_28
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_29
local.get $w5_3_29
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_30
local.get $w5_3_30
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_31
local.get $w5_3_31
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_32
local.get $w5_3_32
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_33
local.get $w5_3_33
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_34
local.get $w5_3_34
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_35
local.get $w5_3_35
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_36
local.get $w5_3_36
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_37
local.get $w5_3_37
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_38
local.get $w5_3_38
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_39
local.get $w5_3_39
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_40
local.get $w5_3_40
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_41
local.get $w5_3_41
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_42
local.get $w5_3_42
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_43
local.get $w5_3_43
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_44
local.get $w5_3_44
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_45
local.get $w5_3_45
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_46
local.get $w5_3_46
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_47
local.get $w5_3_47
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_48
local.get $w5_3_48
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_49
local.get $w5_3_49
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_50
local.get $w5_3_50
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_51
local.get $w5_3_51
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_52
local.get $w5_3_52
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_53
local.get $w5_3_53
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_54
local.get $w5_3_54
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_55
local.get $w5_3_55
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_56
local.get $w5_3_56
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_57
local.get $w5_3_57
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_58
local.get $w5_3_58
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_59
local.get $w5_3_59
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_60
local.get $w5_3_60
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_61
local.get $w5_3_61
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_62
local.get $w5_3_62
i32x4.dot_i16x8_s
i32x4.add
local.get $x5_63
local.get $w5_3_63
i32x4.dot_i16x8_s
i32x4.add
local.set $pc5
local.get $pc0
local.get $pc1
i32x4.add
local.set $pc7
local.get $pc0
local.get $pc5
i32x4.add
local.get $pc2
i32x4.add
local.set $pc10
local.get $yp
local.get $yp
v128.load offset=96
local.get $pc7
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw6
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp
local.get $yp
v128.load offset=112
local.get $pc10
f32x4.convert_i32x4_s
local.get $sx0
f32x4.mul
local.get $sw7
f32x4.mul
f32x4.add
v128.store offset=112

))
(local.set $t(i32.add(local.get $t)(i32.const 2)))
br $tokens
))
))
