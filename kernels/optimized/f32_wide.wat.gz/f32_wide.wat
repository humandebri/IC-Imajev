(module (func (export "__imajev_f32_wide") (param $q i32) (param $w i32) (param $cols i32) (param $start i32) (param $sx i32) (param $stride i32) (param $sw i32) (param $sums i32) (param $n i32)
(local $t i32) (local $qp i32) (local $yp i32)
(local $wp0 i32)
(local $wp1 i32)
(local $x0 v128)
(local $x1 v128)
(local $x2 v128)
(local $x3 v128)
(local $x4 v128)
(local $x5 v128)
(local $x6 v128)
(local $x7 v128)
(local $x8 v128)
(local $x9 v128)
(local $x10 v128)
(local $x11 v128)
(local $x12 v128)
(local $x13 v128)
(local $x14 v128)
(local $x15 v128)
(local $x16 v128)
(local $x17 v128)
(local $x18 v128)
(local $x19 v128)
(local $x20 v128)
(local $x21 v128)
(local $x22 v128)
(local $x23 v128)
(local $x24 v128)
(local $x25 v128)
(local $x26 v128)
(local $x27 v128)
(local $x28 v128)
(local $x29 v128)
(local $x30 v128)
(local $x31 v128)
(local $x32 v128)
(local $x33 v128)
(local $x34 v128)
(local $x35 v128)
(local $x36 v128)
(local $x37 v128)
(local $x38 v128)
(local $x39 v128)
(local $x40 v128)
(local $x41 v128)
(local $x42 v128)
(local $x43 v128)
(local $x44 v128)
(local $x45 v128)
(local $x46 v128)
(local $x47 v128)
(local $x48 v128)
(local $x49 v128)
(local $x50 v128)
(local $x51 v128)
(local $x52 v128)
(local $x53 v128)
(local $x54 v128)
(local $x55 v128)
(local $x56 v128)
(local $x57 v128)
(local $x58 v128)
(local $x59 v128)
(local $x60 v128)
(local $x61 v128)
(local $x62 v128)
(local $x63 v128)
(local $w0_0 v128)
(local $w0_1 v128)
(local $w0_2 v128)
(local $w0_3 v128)
(local $w0_4 v128)
(local $w0_5 v128)
(local $w0_6 v128)
(local $w0_7 v128)
(local $w0_8 v128)
(local $w0_9 v128)
(local $w0_10 v128)
(local $w0_11 v128)
(local $w0_12 v128)
(local $w0_13 v128)
(local $w0_14 v128)
(local $w0_15 v128)
(local $w1_0 v128)
(local $w1_1 v128)
(local $w1_2 v128)
(local $w1_3 v128)
(local $w1_4 v128)
(local $w1_5 v128)
(local $w1_6 v128)
(local $w1_7 v128)
(local $w1_8 v128)
(local $w1_9 v128)
(local $w1_10 v128)
(local $w1_11 v128)
(local $w1_12 v128)
(local $w1_13 v128)
(local $w1_14 v128)
(local $w1_15 v128)
(local $w2_0 v128)
(local $w2_1 v128)
(local $w2_2 v128)
(local $w2_3 v128)
(local $w2_4 v128)
(local $w2_5 v128)
(local $w2_6 v128)
(local $w2_7 v128)
(local $w2_8 v128)
(local $w2_9 v128)
(local $w2_10 v128)
(local $w2_11 v128)
(local $w2_12 v128)
(local $w2_13 v128)
(local $w2_14 v128)
(local $w2_15 v128)
(local $w3_0 v128)
(local $w3_1 v128)
(local $w3_2 v128)
(local $w3_3 v128)
(local $w3_4 v128)
(local $w3_5 v128)
(local $w3_6 v128)
(local $w3_7 v128)
(local $w3_8 v128)
(local $w3_9 v128)
(local $w3_10 v128)
(local $w3_11 v128)
(local $w3_12 v128)
(local $w3_13 v128)
(local $w3_14 v128)
(local $w3_15 v128)
(local $w4_0 v128)
(local $w4_1 v128)
(local $w4_2 v128)
(local $w4_3 v128)
(local $w4_4 v128)
(local $w4_5 v128)
(local $w4_6 v128)
(local $w4_7 v128)
(local $w4_8 v128)
(local $w4_9 v128)
(local $w4_10 v128)
(local $w4_11 v128)
(local $w4_12 v128)
(local $w4_13 v128)
(local $w4_14 v128)
(local $w4_15 v128)
(local $w5_0 v128)
(local $w5_1 v128)
(local $w5_2 v128)
(local $w5_3 v128)
(local $w5_4 v128)
(local $w5_5 v128)
(local $w5_6 v128)
(local $w5_7 v128)
(local $w5_8 v128)
(local $w5_9 v128)
(local $w5_10 v128)
(local $w5_11 v128)
(local $w5_12 v128)
(local $w5_13 v128)
(local $w5_14 v128)
(local $w5_15 v128)
(local $w6_0 v128)
(local $w6_1 v128)
(local $w6_2 v128)
(local $w6_3 v128)
(local $w6_4 v128)
(local $w6_5 v128)
(local $w6_6 v128)
(local $w6_7 v128)
(local $w6_8 v128)
(local $w6_9 v128)
(local $w6_10 v128)
(local $w6_11 v128)
(local $w6_12 v128)
(local $w6_13 v128)
(local $w6_14 v128)
(local $w6_15 v128)
(local $w7_0 v128)
(local $w7_1 v128)
(local $w7_2 v128)
(local $w7_3 v128)
(local $w7_4 v128)
(local $w7_5 v128)
(local $w7_6 v128)
(local $w7_7 v128)
(local $w7_8 v128)
(local $w7_9 v128)
(local $w7_10 v128)
(local $w7_11 v128)
(local $w7_12 v128)
(local $w7_13 v128)
(local $w7_14 v128)
(local $w7_15 v128)
(local $w8_0 v128)
(local $w8_1 v128)
(local $w8_2 v128)
(local $w8_3 v128)
(local $w8_4 v128)
(local $w8_5 v128)
(local $w8_6 v128)
(local $w8_7 v128)
(local $w8_8 v128)
(local $w8_9 v128)
(local $w8_10 v128)
(local $w8_11 v128)
(local $w8_12 v128)
(local $w8_13 v128)
(local $w8_14 v128)
(local $w8_15 v128)
(local $w9_0 v128)
(local $w9_1 v128)
(local $w9_2 v128)
(local $w9_3 v128)
(local $w9_4 v128)
(local $w9_5 v128)
(local $w9_6 v128)
(local $w9_7 v128)
(local $w9_8 v128)
(local $w9_9 v128)
(local $w9_10 v128)
(local $w9_11 v128)
(local $w9_12 v128)
(local $w9_13 v128)
(local $w9_14 v128)
(local $w9_15 v128)
(local $w10_0 v128)
(local $w10_1 v128)
(local $w10_2 v128)
(local $w10_3 v128)
(local $w10_4 v128)
(local $w10_5 v128)
(local $w10_6 v128)
(local $w10_7 v128)
(local $w10_8 v128)
(local $w10_9 v128)
(local $w10_10 v128)
(local $w10_11 v128)
(local $w10_12 v128)
(local $w10_13 v128)
(local $w10_14 v128)
(local $w10_15 v128)
(local $w11_0 v128)
(local $w11_1 v128)
(local $w11_2 v128)
(local $w11_3 v128)
(local $w11_4 v128)
(local $w11_5 v128)
(local $w11_6 v128)
(local $w11_7 v128)
(local $w11_8 v128)
(local $w11_9 v128)
(local $w11_10 v128)
(local $w11_11 v128)
(local $w11_12 v128)
(local $w11_13 v128)
(local $w11_14 v128)
(local $w11_15 v128)
(local $w12_0 v128)
(local $w12_1 v128)
(local $w12_2 v128)
(local $w12_3 v128)
(local $w12_4 v128)
(local $w12_5 v128)
(local $w12_6 v128)
(local $w12_7 v128)
(local $w12_8 v128)
(local $w12_9 v128)
(local $w12_10 v128)
(local $w12_11 v128)
(local $w12_12 v128)
(local $w12_13 v128)
(local $w12_14 v128)
(local $w12_15 v128)
(local $w13_0 v128)
(local $w13_1 v128)
(local $w13_2 v128)
(local $w13_3 v128)
(local $w13_4 v128)
(local $w13_5 v128)
(local $w13_6 v128)
(local $w13_7 v128)
(local $w13_8 v128)
(local $w13_9 v128)
(local $w13_10 v128)
(local $w13_11 v128)
(local $w13_12 v128)
(local $w13_13 v128)
(local $w13_14 v128)
(local $w13_15 v128)
(local $w14_0 v128)
(local $w14_1 v128)
(local $w14_2 v128)
(local $w14_3 v128)
(local $w14_4 v128)
(local $w14_5 v128)
(local $w14_6 v128)
(local $w14_7 v128)
(local $w14_8 v128)
(local $w14_9 v128)
(local $w14_10 v128)
(local $w14_11 v128)
(local $w14_12 v128)
(local $w14_13 v128)
(local $w14_14 v128)
(local $w14_15 v128)
(local $w15_0 v128)
(local $w15_1 v128)
(local $w15_2 v128)
(local $w15_3 v128)
(local $w15_4 v128)
(local $w15_5 v128)
(local $w15_6 v128)
(local $w15_7 v128)
(local $w15_8 v128)
(local $w15_9 v128)
(local $w15_10 v128)
(local $w15_11 v128)
(local $w15_12 v128)
(local $w15_13 v128)
(local $w15_14 v128)
(local $w15_15 v128)
(local $w16_0 v128)
(local $w16_1 v128)
(local $w16_2 v128)
(local $w16_3 v128)
(local $w16_4 v128)
(local $w16_5 v128)
(local $w16_6 v128)
(local $w16_7 v128)
(local $w16_8 v128)
(local $w16_9 v128)
(local $w16_10 v128)
(local $w16_11 v128)
(local $w16_12 v128)
(local $w16_13 v128)
(local $w16_14 v128)
(local $w16_15 v128)
(local $w17_0 v128)
(local $w17_1 v128)
(local $w17_2 v128)
(local $w17_3 v128)
(local $w17_4 v128)
(local $w17_5 v128)
(local $w17_6 v128)
(local $w17_7 v128)
(local $w17_8 v128)
(local $w17_9 v128)
(local $w17_10 v128)
(local $w17_11 v128)
(local $w17_12 v128)
(local $w17_13 v128)
(local $w17_14 v128)
(local $w17_15 v128)
(local $w18_0 v128)
(local $w18_1 v128)
(local $w18_2 v128)
(local $w18_3 v128)
(local $w18_4 v128)
(local $w18_5 v128)
(local $w18_6 v128)
(local $w18_7 v128)
(local $w18_8 v128)
(local $w18_9 v128)
(local $w18_10 v128)
(local $w18_11 v128)
(local $w18_12 v128)
(local $w18_13 v128)
(local $w18_14 v128)
(local $w18_15 v128)
(local $w19_0 v128)
(local $w19_1 v128)
(local $w19_2 v128)
(local $w19_3 v128)
(local $w19_4 v128)
(local $w19_5 v128)
(local $w19_6 v128)
(local $w19_7 v128)
(local $w19_8 v128)
(local $w19_9 v128)
(local $w19_10 v128)
(local $w19_11 v128)
(local $w19_12 v128)
(local $w19_13 v128)
(local $w19_14 v128)
(local $w19_15 v128)
(local $w20_0 v128)
(local $w20_1 v128)
(local $w20_2 v128)
(local $w20_3 v128)
(local $w20_4 v128)
(local $w20_5 v128)
(local $w20_6 v128)
(local $w20_7 v128)
(local $w20_8 v128)
(local $w20_9 v128)
(local $w20_10 v128)
(local $w20_11 v128)
(local $w20_12 v128)
(local $w20_13 v128)
(local $w20_14 v128)
(local $w20_15 v128)
(local $w21_0 v128)
(local $w21_1 v128)
(local $w21_2 v128)
(local $w21_3 v128)
(local $w21_4 v128)
(local $w21_5 v128)
(local $w21_6 v128)
(local $w21_7 v128)
(local $w21_8 v128)
(local $w21_9 v128)
(local $w21_10 v128)
(local $w21_11 v128)
(local $w21_12 v128)
(local $w21_13 v128)
(local $w21_14 v128)
(local $w21_15 v128)
(local $w22_0 v128)
(local $w22_1 v128)
(local $w22_2 v128)
(local $w22_3 v128)
(local $w22_4 v128)
(local $w22_5 v128)
(local $w22_6 v128)
(local $w22_7 v128)
(local $w22_8 v128)
(local $w22_9 v128)
(local $w22_10 v128)
(local $w22_11 v128)
(local $w22_12 v128)
(local $w22_13 v128)
(local $w22_14 v128)
(local $w22_15 v128)
(local $w23_0 v128)
(local $w23_1 v128)
(local $w23_2 v128)
(local $w23_3 v128)
(local $w23_4 v128)
(local $w23_5 v128)
(local $w23_6 v128)
(local $w23_7 v128)
(local $w23_8 v128)
(local $w23_9 v128)
(local $w23_10 v128)
(local $w23_11 v128)
(local $w23_12 v128)
(local $w23_13 v128)
(local $w23_14 v128)
(local $w23_15 v128)
(local $w24_0 v128)
(local $w24_1 v128)
(local $w24_2 v128)
(local $w24_3 v128)
(local $w24_4 v128)
(local $w24_5 v128)
(local $w24_6 v128)
(local $w24_7 v128)
(local $w24_8 v128)
(local $w24_9 v128)
(local $w24_10 v128)
(local $w24_11 v128)
(local $w24_12 v128)
(local $w24_13 v128)
(local $w24_14 v128)
(local $w24_15 v128)
(local $w25_0 v128)
(local $w25_1 v128)
(local $w25_2 v128)
(local $w25_3 v128)
(local $w25_4 v128)
(local $w25_5 v128)
(local $w25_6 v128)
(local $w25_7 v128)
(local $w25_8 v128)
(local $w25_9 v128)
(local $w25_10 v128)
(local $w25_11 v128)
(local $w25_12 v128)
(local $w25_13 v128)
(local $w25_14 v128)
(local $w25_15 v128)
(local $w26_0 v128)
(local $w26_1 v128)
(local $w26_2 v128)
(local $w26_3 v128)
(local $w26_4 v128)
(local $w26_5 v128)
(local $w26_6 v128)
(local $w26_7 v128)
(local $w26_8 v128)
(local $w26_9 v128)
(local $w26_10 v128)
(local $w26_11 v128)
(local $w26_12 v128)
(local $w26_13 v128)
(local $w26_14 v128)
(local $w26_15 v128)
(local $w27_0 v128)
(local $w27_1 v128)
(local $w27_2 v128)
(local $w27_3 v128)
(local $w27_4 v128)
(local $w27_5 v128)
(local $w27_6 v128)
(local $w27_7 v128)
(local $w27_8 v128)
(local $w27_9 v128)
(local $w27_10 v128)
(local $w27_11 v128)
(local $w27_12 v128)
(local $w27_13 v128)
(local $w27_14 v128)
(local $w27_15 v128)
(local $w28_0 v128)
(local $w28_1 v128)
(local $w28_2 v128)
(local $w28_3 v128)
(local $w28_4 v128)
(local $w28_5 v128)
(local $w28_6 v128)
(local $w28_7 v128)
(local $w28_8 v128)
(local $w28_9 v128)
(local $w28_10 v128)
(local $w28_11 v128)
(local $w28_12 v128)
(local $w28_13 v128)
(local $w28_14 v128)
(local $w28_15 v128)
(local $w29_0 v128)
(local $w29_1 v128)
(local $w29_2 v128)
(local $w29_3 v128)
(local $w29_4 v128)
(local $w29_5 v128)
(local $w29_6 v128)
(local $w29_7 v128)
(local $w29_8 v128)
(local $w29_9 v128)
(local $w29_10 v128)
(local $w29_11 v128)
(local $w29_12 v128)
(local $w29_13 v128)
(local $w29_14 v128)
(local $w29_15 v128)
(local $w30_0 v128)
(local $w30_1 v128)
(local $w30_2 v128)
(local $w30_3 v128)
(local $w30_4 v128)
(local $w30_5 v128)
(local $w30_6 v128)
(local $w30_7 v128)
(local $w30_8 v128)
(local $w30_9 v128)
(local $w30_10 v128)
(local $w30_11 v128)
(local $w30_12 v128)
(local $w30_13 v128)
(local $w30_14 v128)
(local $w30_15 v128)
(local $w31_0 v128)
(local $w31_1 v128)
(local $w31_2 v128)
(local $w31_3 v128)
(local $w31_4 v128)
(local $w31_5 v128)
(local $w31_6 v128)
(local $w31_7 v128)
(local $w31_8 v128)
(local $w31_9 v128)
(local $w31_10 v128)
(local $w31_11 v128)
(local $w31_12 v128)
(local $w31_13 v128)
(local $w31_14 v128)
(local $w31_15 v128)
(local $w32_0 v128)
(local $w32_1 v128)
(local $w32_2 v128)
(local $w32_3 v128)
(local $w32_4 v128)
(local $w32_5 v128)
(local $w32_6 v128)
(local $w32_7 v128)
(local $w32_8 v128)
(local $w32_9 v128)
(local $w32_10 v128)
(local $w32_11 v128)
(local $w32_12 v128)
(local $w32_13 v128)
(local $w32_14 v128)
(local $w32_15 v128)
(local $w33_0 v128)
(local $w33_1 v128)
(local $w33_2 v128)
(local $w33_3 v128)
(local $w33_4 v128)
(local $w33_5 v128)
(local $w33_6 v128)
(local $w33_7 v128)
(local $w33_8 v128)
(local $w33_9 v128)
(local $w33_10 v128)
(local $w33_11 v128)
(local $w33_12 v128)
(local $w33_13 v128)
(local $w33_14 v128)
(local $w33_15 v128)
(local $w34_0 v128)
(local $w34_1 v128)
(local $w34_2 v128)
(local $w34_3 v128)
(local $w34_4 v128)
(local $w34_5 v128)
(local $w34_6 v128)
(local $w34_7 v128)
(local $w34_8 v128)
(local $w34_9 v128)
(local $w34_10 v128)
(local $w34_11 v128)
(local $w34_12 v128)
(local $w34_13 v128)
(local $w34_14 v128)
(local $w34_15 v128)
(local $w35_0 v128)
(local $w35_1 v128)
(local $w35_2 v128)
(local $w35_3 v128)
(local $w35_4 v128)
(local $w35_5 v128)
(local $w35_6 v128)
(local $w35_7 v128)
(local $w35_8 v128)
(local $w35_9 v128)
(local $w35_10 v128)
(local $w35_11 v128)
(local $w35_12 v128)
(local $w35_13 v128)
(local $w35_14 v128)
(local $w35_15 v128)
(local $w36_0 v128)
(local $w36_1 v128)
(local $w36_2 v128)
(local $w36_3 v128)
(local $w36_4 v128)
(local $w36_5 v128)
(local $w36_6 v128)
(local $w36_7 v128)
(local $w36_8 v128)
(local $w36_9 v128)
(local $w36_10 v128)
(local $w36_11 v128)
(local $w36_12 v128)
(local $w36_13 v128)
(local $w36_14 v128)
(local $w36_15 v128)
(local $w37_0 v128)
(local $w37_1 v128)
(local $w37_2 v128)
(local $w37_3 v128)
(local $w37_4 v128)
(local $w37_5 v128)
(local $w37_6 v128)
(local $w37_7 v128)
(local $w37_8 v128)
(local $w37_9 v128)
(local $w37_10 v128)
(local $w37_11 v128)
(local $w37_12 v128)
(local $w37_13 v128)
(local $w37_14 v128)
(local $w37_15 v128)
(local $w38_0 v128)
(local $w38_1 v128)
(local $w38_2 v128)
(local $w38_3 v128)
(local $w38_4 v128)
(local $w38_5 v128)
(local $w38_6 v128)
(local $w38_7 v128)
(local $w38_8 v128)
(local $w38_9 v128)
(local $w38_10 v128)
(local $w38_11 v128)
(local $w38_12 v128)
(local $w38_13 v128)
(local $w38_14 v128)
(local $w38_15 v128)
(local $w39_0 v128)
(local $w39_1 v128)
(local $w39_2 v128)
(local $w39_3 v128)
(local $w39_4 v128)
(local $w39_5 v128)
(local $w39_6 v128)
(local $w39_7 v128)
(local $w39_8 v128)
(local $w39_9 v128)
(local $w39_10 v128)
(local $w39_11 v128)
(local $w39_12 v128)
(local $w39_13 v128)
(local $w39_14 v128)
(local $w39_15 v128)
(local $w40_0 v128)
(local $w40_1 v128)
(local $w40_2 v128)
(local $w40_3 v128)
(local $w40_4 v128)
(local $w40_5 v128)
(local $w40_6 v128)
(local $w40_7 v128)
(local $w40_8 v128)
(local $w40_9 v128)
(local $w40_10 v128)
(local $w40_11 v128)
(local $w40_12 v128)
(local $w40_13 v128)
(local $w40_14 v128)
(local $w40_15 v128)
(local $w41_0 v128)
(local $w41_1 v128)
(local $w41_2 v128)
(local $w41_3 v128)
(local $w41_4 v128)
(local $w41_5 v128)
(local $w41_6 v128)
(local $w41_7 v128)
(local $w41_8 v128)
(local $w41_9 v128)
(local $w41_10 v128)
(local $w41_11 v128)
(local $w41_12 v128)
(local $w41_13 v128)
(local $w41_14 v128)
(local $w41_15 v128)
(local $w42_0 v128)
(local $w42_1 v128)
(local $w42_2 v128)
(local $w42_3 v128)
(local $w42_4 v128)
(local $w42_5 v128)
(local $w42_6 v128)
(local $w42_7 v128)
(local $w42_8 v128)
(local $w42_9 v128)
(local $w42_10 v128)
(local $w42_11 v128)
(local $w42_12 v128)
(local $w42_13 v128)
(local $w42_14 v128)
(local $w42_15 v128)
(local $w43_0 v128)
(local $w43_1 v128)
(local $w43_2 v128)
(local $w43_3 v128)
(local $w43_4 v128)
(local $w43_5 v128)
(local $w43_6 v128)
(local $w43_7 v128)
(local $w43_8 v128)
(local $w43_9 v128)
(local $w43_10 v128)
(local $w43_11 v128)
(local $w43_12 v128)
(local $w43_13 v128)
(local $w43_14 v128)
(local $w43_15 v128)
(local $w44_0 v128)
(local $w44_1 v128)
(local $w44_2 v128)
(local $w44_3 v128)
(local $w44_4 v128)
(local $w44_5 v128)
(local $w44_6 v128)
(local $w44_7 v128)
(local $w44_8 v128)
(local $w44_9 v128)
(local $w44_10 v128)
(local $w44_11 v128)
(local $w44_12 v128)
(local $w44_13 v128)
(local $w44_14 v128)
(local $w44_15 v128)
(local $w45_0 v128)
(local $w45_1 v128)
(local $w45_2 v128)
(local $w45_3 v128)
(local $w45_4 v128)
(local $w45_5 v128)
(local $w45_6 v128)
(local $w45_7 v128)
(local $w45_8 v128)
(local $w45_9 v128)
(local $w45_10 v128)
(local $w45_11 v128)
(local $w45_12 v128)
(local $w45_13 v128)
(local $w45_14 v128)
(local $w45_15 v128)
(local $w46_0 v128)
(local $w46_1 v128)
(local $w46_2 v128)
(local $w46_3 v128)
(local $w46_4 v128)
(local $w46_5 v128)
(local $w46_6 v128)
(local $w46_7 v128)
(local $w46_8 v128)
(local $w46_9 v128)
(local $w46_10 v128)
(local $w46_11 v128)
(local $w46_12 v128)
(local $w46_13 v128)
(local $w46_14 v128)
(local $w46_15 v128)
(local $w47_0 v128)
(local $w47_1 v128)
(local $w47_2 v128)
(local $w47_3 v128)
(local $w47_4 v128)
(local $w47_5 v128)
(local $w47_6 v128)
(local $w47_7 v128)
(local $w47_8 v128)
(local $w47_9 v128)
(local $w47_10 v128)
(local $w47_11 v128)
(local $w47_12 v128)
(local $w47_13 v128)
(local $w47_14 v128)
(local $w47_15 v128)
(local $w48_0 v128)
(local $w48_1 v128)
(local $w48_2 v128)
(local $w48_3 v128)
(local $w48_4 v128)
(local $w48_5 v128)
(local $w48_6 v128)
(local $w48_7 v128)
(local $w48_8 v128)
(local $w48_9 v128)
(local $w48_10 v128)
(local $w48_11 v128)
(local $w48_12 v128)
(local $w48_13 v128)
(local $w48_14 v128)
(local $w48_15 v128)
(local $w49_0 v128)
(local $w49_1 v128)
(local $w49_2 v128)
(local $w49_3 v128)
(local $w49_4 v128)
(local $w49_5 v128)
(local $w49_6 v128)
(local $w49_7 v128)
(local $w49_8 v128)
(local $w49_9 v128)
(local $w49_10 v128)
(local $w49_11 v128)
(local $w49_12 v128)
(local $w49_13 v128)
(local $w49_14 v128)
(local $w49_15 v128)
(local $w50_0 v128)
(local $w50_1 v128)
(local $w50_2 v128)
(local $w50_3 v128)
(local $w50_4 v128)
(local $w50_5 v128)
(local $w50_6 v128)
(local $w50_7 v128)
(local $w50_8 v128)
(local $w50_9 v128)
(local $w50_10 v128)
(local $w50_11 v128)
(local $w50_12 v128)
(local $w50_13 v128)
(local $w50_14 v128)
(local $w50_15 v128)
(local $w51_0 v128)
(local $w51_1 v128)
(local $w51_2 v128)
(local $w51_3 v128)
(local $w51_4 v128)
(local $w51_5 v128)
(local $w51_6 v128)
(local $w51_7 v128)
(local $w51_8 v128)
(local $w51_9 v128)
(local $w51_10 v128)
(local $w51_11 v128)
(local $w51_12 v128)
(local $w51_13 v128)
(local $w51_14 v128)
(local $w51_15 v128)
(local $w52_0 v128)
(local $w52_1 v128)
(local $w52_2 v128)
(local $w52_3 v128)
(local $w52_4 v128)
(local $w52_5 v128)
(local $w52_6 v128)
(local $w52_7 v128)
(local $w52_8 v128)
(local $w52_9 v128)
(local $w52_10 v128)
(local $w52_11 v128)
(local $w52_12 v128)
(local $w52_13 v128)
(local $w52_14 v128)
(local $w52_15 v128)
(local $w53_0 v128)
(local $w53_1 v128)
(local $w53_2 v128)
(local $w53_3 v128)
(local $w53_4 v128)
(local $w53_5 v128)
(local $w53_6 v128)
(local $w53_7 v128)
(local $w53_8 v128)
(local $w53_9 v128)
(local $w53_10 v128)
(local $w53_11 v128)
(local $w53_12 v128)
(local $w53_13 v128)
(local $w53_14 v128)
(local $w53_15 v128)
(local $w54_0 v128)
(local $w54_1 v128)
(local $w54_2 v128)
(local $w54_3 v128)
(local $w54_4 v128)
(local $w54_5 v128)
(local $w54_6 v128)
(local $w54_7 v128)
(local $w54_8 v128)
(local $w54_9 v128)
(local $w54_10 v128)
(local $w54_11 v128)
(local $w54_12 v128)
(local $w54_13 v128)
(local $w54_14 v128)
(local $w54_15 v128)
(local $w55_0 v128)
(local $w55_1 v128)
(local $w55_2 v128)
(local $w55_3 v128)
(local $w55_4 v128)
(local $w55_5 v128)
(local $w55_6 v128)
(local $w55_7 v128)
(local $w55_8 v128)
(local $w55_9 v128)
(local $w55_10 v128)
(local $w55_11 v128)
(local $w55_12 v128)
(local $w55_13 v128)
(local $w55_14 v128)
(local $w55_15 v128)
(local $w56_0 v128)
(local $w56_1 v128)
(local $w56_2 v128)
(local $w56_3 v128)
(local $w56_4 v128)
(local $w56_5 v128)
(local $w56_6 v128)
(local $w56_7 v128)
(local $w56_8 v128)
(local $w56_9 v128)
(local $w56_10 v128)
(local $w56_11 v128)
(local $w56_12 v128)
(local $w56_13 v128)
(local $w56_14 v128)
(local $w56_15 v128)
(local $w57_0 v128)
(local $w57_1 v128)
(local $w57_2 v128)
(local $w57_3 v128)
(local $w57_4 v128)
(local $w57_5 v128)
(local $w57_6 v128)
(local $w57_7 v128)
(local $w57_8 v128)
(local $w57_9 v128)
(local $w57_10 v128)
(local $w57_11 v128)
(local $w57_12 v128)
(local $w57_13 v128)
(local $w57_14 v128)
(local $w57_15 v128)
(local $w58_0 v128)
(local $w58_1 v128)
(local $w58_2 v128)
(local $w58_3 v128)
(local $w58_4 v128)
(local $w58_5 v128)
(local $w58_6 v128)
(local $w58_7 v128)
(local $w58_8 v128)
(local $w58_9 v128)
(local $w58_10 v128)
(local $w58_11 v128)
(local $w58_12 v128)
(local $w58_13 v128)
(local $w58_14 v128)
(local $w58_15 v128)
(local $w59_0 v128)
(local $w59_1 v128)
(local $w59_2 v128)
(local $w59_3 v128)
(local $w59_4 v128)
(local $w59_5 v128)
(local $w59_6 v128)
(local $w59_7 v128)
(local $w59_8 v128)
(local $w59_9 v128)
(local $w59_10 v128)
(local $w59_11 v128)
(local $w59_12 v128)
(local $w59_13 v128)
(local $w59_14 v128)
(local $w59_15 v128)
(local $w60_0 v128)
(local $w60_1 v128)
(local $w60_2 v128)
(local $w60_3 v128)
(local $w60_4 v128)
(local $w60_5 v128)
(local $w60_6 v128)
(local $w60_7 v128)
(local $w60_8 v128)
(local $w60_9 v128)
(local $w60_10 v128)
(local $w60_11 v128)
(local $w60_12 v128)
(local $w60_13 v128)
(local $w60_14 v128)
(local $w60_15 v128)
(local $w61_0 v128)
(local $w61_1 v128)
(local $w61_2 v128)
(local $w61_3 v128)
(local $w61_4 v128)
(local $w61_5 v128)
(local $w61_6 v128)
(local $w61_7 v128)
(local $w61_8 v128)
(local $w61_9 v128)
(local $w61_10 v128)
(local $w61_11 v128)
(local $w61_12 v128)
(local $w61_13 v128)
(local $w61_14 v128)
(local $w61_15 v128)
(local $w62_0 v128)
(local $w62_1 v128)
(local $w62_2 v128)
(local $w62_3 v128)
(local $w62_4 v128)
(local $w62_5 v128)
(local $w62_6 v128)
(local $w62_7 v128)
(local $w62_8 v128)
(local $w62_9 v128)
(local $w62_10 v128)
(local $w62_11 v128)
(local $w62_12 v128)
(local $w62_13 v128)
(local $w62_14 v128)
(local $w62_15 v128)
(local $w63_0 v128)
(local $w63_1 v128)
(local $w63_2 v128)
(local $w63_3 v128)
(local $w63_4 v128)
(local $w63_5 v128)
(local $w63_6 v128)
(local $w63_7 v128)
(local $w63_8 v128)
(local $w63_9 v128)
(local $w63_10 v128)
(local $w63_11 v128)
(local $w63_12 v128)
(local $w63_13 v128)
(local $w63_14 v128)
(local $w63_15 v128)
(local.set $t (i32.const 0))
(block $done (br_if $done (i32.eqz (local.get $n)))
(local.set $wp0 (i32.add (local.get $w) (i32.shl (i32.add (local.get $start) (i32.mul (local.get $cols) (i32.const 0))) (i32.const 7))))
(local.set $wp1 (i32.add (local.get $w) (i32.shl (i32.add (local.get $start) (i32.mul (local.get $cols) (i32.const 1))) (i32.const 7))))
(local.set $qp (i32.add (local.get $q) (i32.shl (i32.add (i32.mul (local.get $t) (local.get $cols)) (local.get $start)) (i32.const 2))))
(local.set $yp (i32.add (local.get $sums) (i32.shl (i32.mul (local.get $t) (local.get $stride)) (i32.const 2))))
(local.set $x0 (v128.load32_splat offset=0 (local.get $qp)))
(local.set $x1 (v128.load32_splat offset=4 (local.get $qp)))
(local.set $x2 (v128.load32_splat offset=8 (local.get $qp)))
(local.set $x3 (v128.load32_splat offset=12 (local.get $qp)))
(local.set $x4 (v128.load32_splat offset=16 (local.get $qp)))
(local.set $x5 (v128.load32_splat offset=20 (local.get $qp)))
(local.set $x6 (v128.load32_splat offset=24 (local.get $qp)))
(local.set $x7 (v128.load32_splat offset=28 (local.get $qp)))
(local.set $x8 (v128.load32_splat offset=32 (local.get $qp)))
(local.set $x9 (v128.load32_splat offset=36 (local.get $qp)))
(local.set $x10 (v128.load32_splat offset=40 (local.get $qp)))
(local.set $x11 (v128.load32_splat offset=44 (local.get $qp)))
(local.set $x12 (v128.load32_splat offset=48 (local.get $qp)))
(local.set $x13 (v128.load32_splat offset=52 (local.get $qp)))
(local.set $x14 (v128.load32_splat offset=56 (local.get $qp)))
(local.set $x15 (v128.load32_splat offset=60 (local.get $qp)))
(local.set $x16 (v128.load32_splat offset=64 (local.get $qp)))
(local.set $x17 (v128.load32_splat offset=68 (local.get $qp)))
(local.set $x18 (v128.load32_splat offset=72 (local.get $qp)))
(local.set $x19 (v128.load32_splat offset=76 (local.get $qp)))
(local.set $x20 (v128.load32_splat offset=80 (local.get $qp)))
(local.set $x21 (v128.load32_splat offset=84 (local.get $qp)))
(local.set $x22 (v128.load32_splat offset=88 (local.get $qp)))
(local.set $x23 (v128.load32_splat offset=92 (local.get $qp)))
(local.set $x24 (v128.load32_splat offset=96 (local.get $qp)))
(local.set $x25 (v128.load32_splat offset=100 (local.get $qp)))
(local.set $x26 (v128.load32_splat offset=104 (local.get $qp)))
(local.set $x27 (v128.load32_splat offset=108 (local.get $qp)))
(local.set $x28 (v128.load32_splat offset=112 (local.get $qp)))
(local.set $x29 (v128.load32_splat offset=116 (local.get $qp)))
(local.set $x30 (v128.load32_splat offset=120 (local.get $qp)))
(local.set $x31 (v128.load32_splat offset=124 (local.get $qp)))
(local.set $x32 (v128.load32_splat offset=128 (local.get $qp)))
(local.set $x33 (v128.load32_splat offset=132 (local.get $qp)))
(local.set $x34 (v128.load32_splat offset=136 (local.get $qp)))
(local.set $x35 (v128.load32_splat offset=140 (local.get $qp)))
(local.set $x36 (v128.load32_splat offset=144 (local.get $qp)))
(local.set $x37 (v128.load32_splat offset=148 (local.get $qp)))
(local.set $x38 (v128.load32_splat offset=152 (local.get $qp)))
(local.set $x39 (v128.load32_splat offset=156 (local.get $qp)))
(local.set $x40 (v128.load32_splat offset=160 (local.get $qp)))
(local.set $x41 (v128.load32_splat offset=164 (local.get $qp)))
(local.set $x42 (v128.load32_splat offset=168 (local.get $qp)))
(local.set $x43 (v128.load32_splat offset=172 (local.get $qp)))
(local.set $x44 (v128.load32_splat offset=176 (local.get $qp)))
(local.set $x45 (v128.load32_splat offset=180 (local.get $qp)))
(local.set $x46 (v128.load32_splat offset=184 (local.get $qp)))
(local.set $x47 (v128.load32_splat offset=188 (local.get $qp)))
(local.set $x48 (v128.load32_splat offset=192 (local.get $qp)))
(local.set $x49 (v128.load32_splat offset=196 (local.get $qp)))
(local.set $x50 (v128.load32_splat offset=200 (local.get $qp)))
(local.set $x51 (v128.load32_splat offset=204 (local.get $qp)))
(local.set $x52 (v128.load32_splat offset=208 (local.get $qp)))
(local.set $x53 (v128.load32_splat offset=212 (local.get $qp)))
(local.set $x54 (v128.load32_splat offset=216 (local.get $qp)))
(local.set $x55 (v128.load32_splat offset=220 (local.get $qp)))
(local.set $x56 (v128.load32_splat offset=224 (local.get $qp)))
(local.set $x57 (v128.load32_splat offset=228 (local.get $qp)))
(local.set $x58 (v128.load32_splat offset=232 (local.get $qp)))
(local.set $x59 (v128.load32_splat offset=236 (local.get $qp)))
(local.set $x60 (v128.load32_splat offset=240 (local.get $qp)))
(local.set $x61 (v128.load32_splat offset=244 (local.get $qp)))
(local.set $x62 (v128.load32_splat offset=248 (local.get $qp)))
(local.set $x63 (v128.load32_splat offset=252 (local.get $qp)))
local.get $yp
local.get $yp
v128.load offset=0
local.get $x0
(local.tee $w0_0 (v128.load offset=0 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_0 (v128.load offset=128 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_0 (v128.load offset=256 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_0 (v128.load offset=384 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_0 (v128.load offset=512 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_0 (v128.load offset=640 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_0 (v128.load offset=768 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_0 (v128.load offset=896 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_0 (v128.load offset=1024 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_0 (v128.load offset=1152 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_0 (v128.load offset=1280 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_0 (v128.load offset=1408 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_0 (v128.load offset=1536 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_0 (v128.load offset=1664 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_0 (v128.load offset=1792 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_0 (v128.load offset=1920 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_0 (v128.load offset=2048 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_0 (v128.load offset=2176 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_0 (v128.load offset=2304 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_0 (v128.load offset=2432 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_0 (v128.load offset=2560 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_0 (v128.load offset=2688 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_0 (v128.load offset=2816 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_0 (v128.load offset=2944 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_0 (v128.load offset=3072 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_0 (v128.load offset=3200 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_0 (v128.load offset=3328 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_0 (v128.load offset=3456 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_0 (v128.load offset=3584 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_0 (v128.load offset=3712 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_0 (v128.load offset=3840 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_0 (v128.load offset=3968 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_0 (v128.load offset=4096 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_0 (v128.load offset=4224 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_0 (v128.load offset=4352 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_0 (v128.load offset=4480 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_0 (v128.load offset=4608 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_0 (v128.load offset=4736 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_0 (v128.load offset=4864 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_0 (v128.load offset=4992 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_0 (v128.load offset=5120 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_0 (v128.load offset=5248 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_0 (v128.load offset=5376 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_0 (v128.load offset=5504 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_0 (v128.load offset=5632 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_0 (v128.load offset=5760 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_0 (v128.load offset=5888 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_0 (v128.load offset=6016 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_0 (v128.load offset=6144 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_0 (v128.load offset=6272 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_0 (v128.load offset=6400 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_0 (v128.load offset=6528 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_0 (v128.load offset=6656 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_0 (v128.load offset=6784 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_0 (v128.load offset=6912 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_0 (v128.load offset=7040 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_0 (v128.load offset=7168 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_0 (v128.load offset=7296 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_0 (v128.load offset=7424 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_0 (v128.load offset=7552 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_0 (v128.load offset=7680 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_0 (v128.load offset=7808 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_0 (v128.load offset=7936 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_0 (v128.load offset=8064 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
local.get $yp
v128.load offset=16
local.get $x0
(local.tee $w0_1 (v128.load offset=16 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_1 (v128.load offset=144 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_1 (v128.load offset=272 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_1 (v128.load offset=400 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_1 (v128.load offset=528 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_1 (v128.load offset=656 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_1 (v128.load offset=784 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_1 (v128.load offset=912 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_1 (v128.load offset=1040 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_1 (v128.load offset=1168 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_1 (v128.load offset=1296 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_1 (v128.load offset=1424 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_1 (v128.load offset=1552 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_1 (v128.load offset=1680 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_1 (v128.load offset=1808 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_1 (v128.load offset=1936 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_1 (v128.load offset=2064 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_1 (v128.load offset=2192 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_1 (v128.load offset=2320 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_1 (v128.load offset=2448 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_1 (v128.load offset=2576 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_1 (v128.load offset=2704 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_1 (v128.load offset=2832 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_1 (v128.load offset=2960 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_1 (v128.load offset=3088 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_1 (v128.load offset=3216 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_1 (v128.load offset=3344 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_1 (v128.load offset=3472 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_1 (v128.load offset=3600 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_1 (v128.load offset=3728 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_1 (v128.load offset=3856 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_1 (v128.load offset=3984 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_1 (v128.load offset=4112 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_1 (v128.load offset=4240 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_1 (v128.load offset=4368 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_1 (v128.load offset=4496 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_1 (v128.load offset=4624 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_1 (v128.load offset=4752 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_1 (v128.load offset=4880 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_1 (v128.load offset=5008 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_1 (v128.load offset=5136 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_1 (v128.load offset=5264 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_1 (v128.load offset=5392 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_1 (v128.load offset=5520 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_1 (v128.load offset=5648 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_1 (v128.load offset=5776 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_1 (v128.load offset=5904 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_1 (v128.load offset=6032 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_1 (v128.load offset=6160 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_1 (v128.load offset=6288 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_1 (v128.load offset=6416 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_1 (v128.load offset=6544 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_1 (v128.load offset=6672 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_1 (v128.load offset=6800 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_1 (v128.load offset=6928 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_1 (v128.load offset=7056 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_1 (v128.load offset=7184 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_1 (v128.load offset=7312 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_1 (v128.load offset=7440 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_1 (v128.load offset=7568 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_1 (v128.load offset=7696 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_1 (v128.load offset=7824 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_1 (v128.load offset=7952 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_1 (v128.load offset=8080 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
local.get $yp
v128.load offset=32
local.get $x0
(local.tee $w0_2 (v128.load offset=32 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_2 (v128.load offset=160 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_2 (v128.load offset=288 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_2 (v128.load offset=416 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_2 (v128.load offset=544 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_2 (v128.load offset=672 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_2 (v128.load offset=800 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_2 (v128.load offset=928 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_2 (v128.load offset=1056 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_2 (v128.load offset=1184 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_2 (v128.load offset=1312 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_2 (v128.load offset=1440 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_2 (v128.load offset=1568 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_2 (v128.load offset=1696 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_2 (v128.load offset=1824 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_2 (v128.load offset=1952 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_2 (v128.load offset=2080 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_2 (v128.load offset=2208 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_2 (v128.load offset=2336 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_2 (v128.load offset=2464 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_2 (v128.load offset=2592 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_2 (v128.load offset=2720 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_2 (v128.load offset=2848 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_2 (v128.load offset=2976 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_2 (v128.load offset=3104 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_2 (v128.load offset=3232 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_2 (v128.load offset=3360 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_2 (v128.load offset=3488 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_2 (v128.load offset=3616 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_2 (v128.load offset=3744 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_2 (v128.load offset=3872 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_2 (v128.load offset=4000 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_2 (v128.load offset=4128 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_2 (v128.load offset=4256 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_2 (v128.load offset=4384 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_2 (v128.load offset=4512 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_2 (v128.load offset=4640 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_2 (v128.load offset=4768 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_2 (v128.load offset=4896 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_2 (v128.load offset=5024 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_2 (v128.load offset=5152 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_2 (v128.load offset=5280 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_2 (v128.load offset=5408 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_2 (v128.load offset=5536 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_2 (v128.load offset=5664 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_2 (v128.load offset=5792 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_2 (v128.load offset=5920 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_2 (v128.load offset=6048 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_2 (v128.load offset=6176 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_2 (v128.load offset=6304 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_2 (v128.load offset=6432 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_2 (v128.load offset=6560 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_2 (v128.load offset=6688 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_2 (v128.load offset=6816 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_2 (v128.load offset=6944 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_2 (v128.load offset=7072 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_2 (v128.load offset=7200 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_2 (v128.load offset=7328 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_2 (v128.load offset=7456 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_2 (v128.load offset=7584 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_2 (v128.load offset=7712 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_2 (v128.load offset=7840 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_2 (v128.load offset=7968 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_2 (v128.load offset=8096 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
local.get $yp
v128.load offset=48
local.get $x0
(local.tee $w0_3 (v128.load offset=48 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_3 (v128.load offset=176 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_3 (v128.load offset=304 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_3 (v128.load offset=432 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_3 (v128.load offset=560 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_3 (v128.load offset=688 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_3 (v128.load offset=816 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_3 (v128.load offset=944 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_3 (v128.load offset=1072 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_3 (v128.load offset=1200 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_3 (v128.load offset=1328 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_3 (v128.load offset=1456 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_3 (v128.load offset=1584 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_3 (v128.load offset=1712 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_3 (v128.load offset=1840 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_3 (v128.load offset=1968 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_3 (v128.load offset=2096 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_3 (v128.load offset=2224 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_3 (v128.load offset=2352 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_3 (v128.load offset=2480 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_3 (v128.load offset=2608 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_3 (v128.load offset=2736 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_3 (v128.load offset=2864 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_3 (v128.load offset=2992 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_3 (v128.load offset=3120 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_3 (v128.load offset=3248 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_3 (v128.load offset=3376 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_3 (v128.load offset=3504 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_3 (v128.load offset=3632 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_3 (v128.load offset=3760 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_3 (v128.load offset=3888 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_3 (v128.load offset=4016 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_3 (v128.load offset=4144 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_3 (v128.load offset=4272 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_3 (v128.load offset=4400 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_3 (v128.load offset=4528 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_3 (v128.load offset=4656 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_3 (v128.load offset=4784 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_3 (v128.load offset=4912 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_3 (v128.load offset=5040 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_3 (v128.load offset=5168 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_3 (v128.load offset=5296 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_3 (v128.load offset=5424 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_3 (v128.load offset=5552 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_3 (v128.load offset=5680 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_3 (v128.load offset=5808 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_3 (v128.load offset=5936 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_3 (v128.load offset=6064 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_3 (v128.load offset=6192 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_3 (v128.load offset=6320 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_3 (v128.load offset=6448 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_3 (v128.load offset=6576 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_3 (v128.load offset=6704 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_3 (v128.load offset=6832 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_3 (v128.load offset=6960 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_3 (v128.load offset=7088 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_3 (v128.load offset=7216 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_3 (v128.load offset=7344 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_3 (v128.load offset=7472 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_3 (v128.load offset=7600 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_3 (v128.load offset=7728 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_3 (v128.load offset=7856 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_3 (v128.load offset=7984 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_3 (v128.load offset=8112 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=48
local.get $yp
local.get $yp
v128.load offset=64
local.get $x0
(local.tee $w0_4 (v128.load offset=64 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_4 (v128.load offset=192 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_4 (v128.load offset=320 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_4 (v128.load offset=448 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_4 (v128.load offset=576 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_4 (v128.load offset=704 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_4 (v128.load offset=832 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_4 (v128.load offset=960 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_4 (v128.load offset=1088 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_4 (v128.load offset=1216 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_4 (v128.load offset=1344 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_4 (v128.load offset=1472 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_4 (v128.load offset=1600 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_4 (v128.load offset=1728 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_4 (v128.load offset=1856 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_4 (v128.load offset=1984 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_4 (v128.load offset=2112 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_4 (v128.load offset=2240 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_4 (v128.load offset=2368 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_4 (v128.load offset=2496 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_4 (v128.load offset=2624 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_4 (v128.load offset=2752 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_4 (v128.load offset=2880 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_4 (v128.load offset=3008 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_4 (v128.load offset=3136 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_4 (v128.load offset=3264 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_4 (v128.load offset=3392 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_4 (v128.load offset=3520 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_4 (v128.load offset=3648 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_4 (v128.load offset=3776 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_4 (v128.load offset=3904 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_4 (v128.load offset=4032 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_4 (v128.load offset=4160 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_4 (v128.load offset=4288 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_4 (v128.load offset=4416 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_4 (v128.load offset=4544 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_4 (v128.load offset=4672 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_4 (v128.load offset=4800 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_4 (v128.load offset=4928 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_4 (v128.load offset=5056 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_4 (v128.load offset=5184 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_4 (v128.load offset=5312 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_4 (v128.load offset=5440 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_4 (v128.load offset=5568 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_4 (v128.load offset=5696 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_4 (v128.load offset=5824 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_4 (v128.load offset=5952 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_4 (v128.load offset=6080 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_4 (v128.load offset=6208 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_4 (v128.load offset=6336 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_4 (v128.load offset=6464 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_4 (v128.load offset=6592 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_4 (v128.load offset=6720 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_4 (v128.load offset=6848 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_4 (v128.load offset=6976 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_4 (v128.load offset=7104 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_4 (v128.load offset=7232 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_4 (v128.load offset=7360 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_4 (v128.load offset=7488 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_4 (v128.load offset=7616 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_4 (v128.load offset=7744 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_4 (v128.load offset=7872 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_4 (v128.load offset=8000 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_4 (v128.load offset=8128 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp
local.get $yp
v128.load offset=80
local.get $x0
(local.tee $w0_5 (v128.load offset=80 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_5 (v128.load offset=208 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_5 (v128.load offset=336 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_5 (v128.load offset=464 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_5 (v128.load offset=592 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_5 (v128.load offset=720 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_5 (v128.load offset=848 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_5 (v128.load offset=976 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_5 (v128.load offset=1104 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_5 (v128.load offset=1232 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_5 (v128.load offset=1360 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_5 (v128.load offset=1488 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_5 (v128.load offset=1616 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_5 (v128.load offset=1744 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_5 (v128.load offset=1872 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_5 (v128.load offset=2000 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_5 (v128.load offset=2128 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_5 (v128.load offset=2256 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_5 (v128.load offset=2384 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_5 (v128.load offset=2512 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_5 (v128.load offset=2640 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_5 (v128.load offset=2768 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_5 (v128.load offset=2896 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_5 (v128.load offset=3024 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_5 (v128.load offset=3152 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_5 (v128.load offset=3280 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_5 (v128.load offset=3408 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_5 (v128.load offset=3536 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_5 (v128.load offset=3664 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_5 (v128.load offset=3792 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_5 (v128.load offset=3920 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_5 (v128.load offset=4048 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_5 (v128.load offset=4176 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_5 (v128.load offset=4304 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_5 (v128.load offset=4432 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_5 (v128.load offset=4560 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_5 (v128.load offset=4688 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_5 (v128.load offset=4816 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_5 (v128.load offset=4944 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_5 (v128.load offset=5072 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_5 (v128.load offset=5200 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_5 (v128.load offset=5328 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_5 (v128.load offset=5456 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_5 (v128.load offset=5584 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_5 (v128.load offset=5712 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_5 (v128.load offset=5840 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_5 (v128.load offset=5968 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_5 (v128.load offset=6096 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_5 (v128.load offset=6224 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_5 (v128.load offset=6352 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_5 (v128.load offset=6480 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_5 (v128.load offset=6608 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_5 (v128.load offset=6736 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_5 (v128.load offset=6864 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_5 (v128.load offset=6992 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_5 (v128.load offset=7120 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_5 (v128.load offset=7248 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_5 (v128.load offset=7376 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_5 (v128.load offset=7504 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_5 (v128.load offset=7632 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_5 (v128.load offset=7760 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_5 (v128.load offset=7888 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_5 (v128.load offset=8016 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_5 (v128.load offset=8144 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=80
local.get $yp
local.get $yp
v128.load offset=96
local.get $x0
(local.tee $w0_6 (v128.load offset=96 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_6 (v128.load offset=224 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_6 (v128.load offset=352 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_6 (v128.load offset=480 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_6 (v128.load offset=608 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_6 (v128.load offset=736 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_6 (v128.load offset=864 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_6 (v128.load offset=992 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_6 (v128.load offset=1120 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_6 (v128.load offset=1248 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_6 (v128.load offset=1376 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_6 (v128.load offset=1504 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_6 (v128.load offset=1632 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_6 (v128.load offset=1760 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_6 (v128.load offset=1888 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_6 (v128.load offset=2016 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_6 (v128.load offset=2144 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_6 (v128.load offset=2272 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_6 (v128.load offset=2400 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_6 (v128.load offset=2528 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_6 (v128.load offset=2656 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_6 (v128.load offset=2784 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_6 (v128.load offset=2912 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_6 (v128.load offset=3040 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_6 (v128.load offset=3168 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_6 (v128.load offset=3296 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_6 (v128.load offset=3424 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_6 (v128.load offset=3552 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_6 (v128.load offset=3680 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_6 (v128.load offset=3808 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_6 (v128.load offset=3936 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_6 (v128.load offset=4064 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_6 (v128.load offset=4192 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_6 (v128.load offset=4320 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_6 (v128.load offset=4448 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_6 (v128.load offset=4576 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_6 (v128.load offset=4704 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_6 (v128.load offset=4832 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_6 (v128.load offset=4960 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_6 (v128.load offset=5088 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_6 (v128.load offset=5216 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_6 (v128.load offset=5344 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_6 (v128.load offset=5472 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_6 (v128.load offset=5600 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_6 (v128.load offset=5728 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_6 (v128.load offset=5856 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_6 (v128.load offset=5984 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_6 (v128.load offset=6112 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_6 (v128.load offset=6240 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_6 (v128.load offset=6368 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_6 (v128.load offset=6496 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_6 (v128.load offset=6624 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_6 (v128.load offset=6752 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_6 (v128.load offset=6880 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_6 (v128.load offset=7008 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_6 (v128.load offset=7136 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_6 (v128.load offset=7264 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_6 (v128.load offset=7392 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_6 (v128.load offset=7520 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_6 (v128.load offset=7648 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_6 (v128.load offset=7776 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_6 (v128.load offset=7904 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_6 (v128.load offset=8032 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_6 (v128.load offset=8160 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp
local.get $yp
v128.load offset=112
local.get $x0
(local.tee $w0_7 (v128.load offset=112 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_7 (v128.load offset=240 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_7 (v128.load offset=368 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_7 (v128.load offset=496 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_7 (v128.load offset=624 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_7 (v128.load offset=752 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_7 (v128.load offset=880 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_7 (v128.load offset=1008 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_7 (v128.load offset=1136 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_7 (v128.load offset=1264 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_7 (v128.load offset=1392 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_7 (v128.load offset=1520 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_7 (v128.load offset=1648 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_7 (v128.load offset=1776 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_7 (v128.load offset=1904 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_7 (v128.load offset=2032 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_7 (v128.load offset=2160 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_7 (v128.load offset=2288 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_7 (v128.load offset=2416 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_7 (v128.load offset=2544 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_7 (v128.load offset=2672 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_7 (v128.load offset=2800 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_7 (v128.load offset=2928 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_7 (v128.load offset=3056 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_7 (v128.load offset=3184 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_7 (v128.load offset=3312 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_7 (v128.load offset=3440 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_7 (v128.load offset=3568 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_7 (v128.load offset=3696 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_7 (v128.load offset=3824 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_7 (v128.load offset=3952 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_7 (v128.load offset=4080 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_7 (v128.load offset=4208 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_7 (v128.load offset=4336 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_7 (v128.load offset=4464 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_7 (v128.load offset=4592 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_7 (v128.load offset=4720 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_7 (v128.load offset=4848 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_7 (v128.load offset=4976 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_7 (v128.load offset=5104 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_7 (v128.load offset=5232 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_7 (v128.load offset=5360 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_7 (v128.load offset=5488 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_7 (v128.load offset=5616 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_7 (v128.load offset=5744 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_7 (v128.load offset=5872 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_7 (v128.load offset=6000 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_7 (v128.load offset=6128 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_7 (v128.load offset=6256 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_7 (v128.load offset=6384 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_7 (v128.load offset=6512 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_7 (v128.load offset=6640 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_7 (v128.load offset=6768 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_7 (v128.load offset=6896 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_7 (v128.load offset=7024 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_7 (v128.load offset=7152 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_7 (v128.load offset=7280 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_7 (v128.load offset=7408 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_7 (v128.load offset=7536 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_7 (v128.load offset=7664 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_7 (v128.load offset=7792 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_7 (v128.load offset=7920 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_7 (v128.load offset=8048 (local.get $wp0)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_7 (v128.load offset=8176 (local.get $wp0)))
f32x4.mul
f32x4.add
v128.store offset=112
local.get $yp
local.get $yp
v128.load offset=128
local.get $x0
(local.tee $w0_8 (v128.load offset=0 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_8 (v128.load offset=128 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_8 (v128.load offset=256 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_8 (v128.load offset=384 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_8 (v128.load offset=512 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_8 (v128.load offset=640 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_8 (v128.load offset=768 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_8 (v128.load offset=896 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_8 (v128.load offset=1024 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_8 (v128.load offset=1152 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_8 (v128.load offset=1280 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_8 (v128.load offset=1408 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_8 (v128.load offset=1536 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_8 (v128.load offset=1664 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_8 (v128.load offset=1792 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_8 (v128.load offset=1920 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_8 (v128.load offset=2048 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_8 (v128.load offset=2176 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_8 (v128.load offset=2304 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_8 (v128.load offset=2432 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_8 (v128.load offset=2560 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_8 (v128.load offset=2688 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_8 (v128.load offset=2816 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_8 (v128.load offset=2944 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_8 (v128.load offset=3072 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_8 (v128.load offset=3200 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_8 (v128.load offset=3328 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_8 (v128.load offset=3456 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_8 (v128.load offset=3584 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_8 (v128.load offset=3712 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_8 (v128.load offset=3840 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_8 (v128.load offset=3968 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_8 (v128.load offset=4096 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_8 (v128.load offset=4224 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_8 (v128.load offset=4352 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_8 (v128.load offset=4480 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_8 (v128.load offset=4608 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_8 (v128.load offset=4736 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_8 (v128.load offset=4864 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_8 (v128.load offset=4992 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_8 (v128.load offset=5120 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_8 (v128.load offset=5248 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_8 (v128.load offset=5376 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_8 (v128.load offset=5504 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_8 (v128.load offset=5632 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_8 (v128.load offset=5760 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_8 (v128.load offset=5888 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_8 (v128.load offset=6016 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_8 (v128.load offset=6144 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_8 (v128.load offset=6272 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_8 (v128.load offset=6400 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_8 (v128.load offset=6528 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_8 (v128.load offset=6656 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_8 (v128.load offset=6784 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_8 (v128.load offset=6912 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_8 (v128.load offset=7040 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_8 (v128.load offset=7168 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_8 (v128.load offset=7296 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_8 (v128.load offset=7424 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_8 (v128.load offset=7552 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_8 (v128.load offset=7680 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_8 (v128.load offset=7808 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_8 (v128.load offset=7936 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_8 (v128.load offset=8064 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=128
local.get $yp
local.get $yp
v128.load offset=144
local.get $x0
(local.tee $w0_9 (v128.load offset=16 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_9 (v128.load offset=144 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_9 (v128.load offset=272 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_9 (v128.load offset=400 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_9 (v128.load offset=528 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_9 (v128.load offset=656 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_9 (v128.load offset=784 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_9 (v128.load offset=912 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_9 (v128.load offset=1040 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_9 (v128.load offset=1168 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_9 (v128.load offset=1296 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_9 (v128.load offset=1424 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_9 (v128.load offset=1552 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_9 (v128.load offset=1680 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_9 (v128.load offset=1808 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_9 (v128.load offset=1936 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_9 (v128.load offset=2064 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_9 (v128.load offset=2192 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_9 (v128.load offset=2320 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_9 (v128.load offset=2448 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_9 (v128.load offset=2576 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_9 (v128.load offset=2704 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_9 (v128.load offset=2832 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_9 (v128.load offset=2960 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_9 (v128.load offset=3088 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_9 (v128.load offset=3216 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_9 (v128.load offset=3344 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_9 (v128.load offset=3472 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_9 (v128.load offset=3600 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_9 (v128.load offset=3728 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_9 (v128.load offset=3856 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_9 (v128.load offset=3984 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_9 (v128.load offset=4112 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_9 (v128.load offset=4240 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_9 (v128.load offset=4368 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_9 (v128.load offset=4496 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_9 (v128.load offset=4624 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_9 (v128.load offset=4752 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_9 (v128.load offset=4880 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_9 (v128.load offset=5008 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_9 (v128.load offset=5136 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_9 (v128.load offset=5264 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_9 (v128.load offset=5392 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_9 (v128.load offset=5520 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_9 (v128.load offset=5648 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_9 (v128.load offset=5776 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_9 (v128.load offset=5904 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_9 (v128.load offset=6032 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_9 (v128.load offset=6160 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_9 (v128.load offset=6288 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_9 (v128.load offset=6416 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_9 (v128.load offset=6544 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_9 (v128.load offset=6672 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_9 (v128.load offset=6800 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_9 (v128.load offset=6928 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_9 (v128.load offset=7056 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_9 (v128.load offset=7184 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_9 (v128.load offset=7312 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_9 (v128.load offset=7440 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_9 (v128.load offset=7568 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_9 (v128.load offset=7696 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_9 (v128.load offset=7824 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_9 (v128.load offset=7952 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_9 (v128.load offset=8080 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=144
local.get $yp
local.get $yp
v128.load offset=160
local.get $x0
(local.tee $w0_10 (v128.load offset=32 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_10 (v128.load offset=160 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_10 (v128.load offset=288 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_10 (v128.load offset=416 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_10 (v128.load offset=544 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_10 (v128.load offset=672 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_10 (v128.load offset=800 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_10 (v128.load offset=928 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_10 (v128.load offset=1056 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_10 (v128.load offset=1184 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_10 (v128.load offset=1312 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_10 (v128.load offset=1440 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_10 (v128.load offset=1568 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_10 (v128.load offset=1696 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_10 (v128.load offset=1824 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_10 (v128.load offset=1952 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_10 (v128.load offset=2080 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_10 (v128.load offset=2208 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_10 (v128.load offset=2336 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_10 (v128.load offset=2464 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_10 (v128.load offset=2592 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_10 (v128.load offset=2720 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_10 (v128.load offset=2848 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_10 (v128.load offset=2976 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_10 (v128.load offset=3104 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_10 (v128.load offset=3232 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_10 (v128.load offset=3360 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_10 (v128.load offset=3488 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_10 (v128.load offset=3616 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_10 (v128.load offset=3744 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_10 (v128.load offset=3872 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_10 (v128.load offset=4000 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_10 (v128.load offset=4128 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_10 (v128.load offset=4256 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_10 (v128.load offset=4384 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_10 (v128.load offset=4512 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_10 (v128.load offset=4640 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_10 (v128.load offset=4768 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_10 (v128.load offset=4896 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_10 (v128.load offset=5024 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_10 (v128.load offset=5152 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_10 (v128.load offset=5280 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_10 (v128.load offset=5408 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_10 (v128.load offset=5536 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_10 (v128.load offset=5664 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_10 (v128.load offset=5792 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_10 (v128.load offset=5920 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_10 (v128.load offset=6048 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_10 (v128.load offset=6176 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_10 (v128.load offset=6304 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_10 (v128.load offset=6432 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_10 (v128.load offset=6560 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_10 (v128.load offset=6688 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_10 (v128.load offset=6816 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_10 (v128.load offset=6944 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_10 (v128.load offset=7072 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_10 (v128.load offset=7200 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_10 (v128.load offset=7328 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_10 (v128.load offset=7456 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_10 (v128.load offset=7584 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_10 (v128.load offset=7712 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_10 (v128.load offset=7840 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_10 (v128.load offset=7968 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_10 (v128.load offset=8096 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=160
local.get $yp
local.get $yp
v128.load offset=176
local.get $x0
(local.tee $w0_11 (v128.load offset=48 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_11 (v128.load offset=176 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_11 (v128.load offset=304 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_11 (v128.load offset=432 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_11 (v128.load offset=560 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_11 (v128.load offset=688 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_11 (v128.load offset=816 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_11 (v128.load offset=944 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_11 (v128.load offset=1072 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_11 (v128.load offset=1200 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_11 (v128.load offset=1328 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_11 (v128.load offset=1456 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_11 (v128.load offset=1584 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_11 (v128.load offset=1712 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_11 (v128.load offset=1840 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_11 (v128.load offset=1968 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_11 (v128.load offset=2096 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_11 (v128.load offset=2224 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_11 (v128.load offset=2352 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_11 (v128.load offset=2480 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_11 (v128.load offset=2608 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_11 (v128.load offset=2736 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_11 (v128.load offset=2864 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_11 (v128.load offset=2992 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_11 (v128.load offset=3120 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_11 (v128.load offset=3248 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_11 (v128.load offset=3376 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_11 (v128.load offset=3504 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_11 (v128.load offset=3632 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_11 (v128.load offset=3760 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_11 (v128.load offset=3888 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_11 (v128.load offset=4016 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_11 (v128.load offset=4144 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_11 (v128.load offset=4272 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_11 (v128.load offset=4400 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_11 (v128.load offset=4528 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_11 (v128.load offset=4656 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_11 (v128.load offset=4784 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_11 (v128.load offset=4912 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_11 (v128.load offset=5040 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_11 (v128.load offset=5168 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_11 (v128.load offset=5296 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_11 (v128.load offset=5424 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_11 (v128.load offset=5552 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_11 (v128.load offset=5680 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_11 (v128.load offset=5808 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_11 (v128.load offset=5936 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_11 (v128.load offset=6064 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_11 (v128.load offset=6192 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_11 (v128.load offset=6320 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_11 (v128.load offset=6448 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_11 (v128.load offset=6576 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_11 (v128.load offset=6704 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_11 (v128.load offset=6832 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_11 (v128.load offset=6960 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_11 (v128.load offset=7088 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_11 (v128.load offset=7216 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_11 (v128.load offset=7344 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_11 (v128.load offset=7472 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_11 (v128.load offset=7600 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_11 (v128.load offset=7728 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_11 (v128.load offset=7856 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_11 (v128.load offset=7984 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_11 (v128.load offset=8112 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=176
local.get $yp
local.get $yp
v128.load offset=192
local.get $x0
(local.tee $w0_12 (v128.load offset=64 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_12 (v128.load offset=192 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_12 (v128.load offset=320 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_12 (v128.load offset=448 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_12 (v128.load offset=576 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_12 (v128.load offset=704 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_12 (v128.load offset=832 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_12 (v128.load offset=960 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_12 (v128.load offset=1088 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_12 (v128.load offset=1216 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_12 (v128.load offset=1344 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_12 (v128.load offset=1472 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_12 (v128.load offset=1600 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_12 (v128.load offset=1728 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_12 (v128.load offset=1856 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_12 (v128.load offset=1984 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_12 (v128.load offset=2112 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_12 (v128.load offset=2240 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_12 (v128.load offset=2368 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_12 (v128.load offset=2496 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_12 (v128.load offset=2624 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_12 (v128.load offset=2752 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_12 (v128.load offset=2880 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_12 (v128.load offset=3008 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_12 (v128.load offset=3136 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_12 (v128.load offset=3264 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_12 (v128.load offset=3392 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_12 (v128.load offset=3520 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_12 (v128.load offset=3648 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_12 (v128.load offset=3776 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_12 (v128.load offset=3904 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_12 (v128.load offset=4032 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_12 (v128.load offset=4160 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_12 (v128.load offset=4288 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_12 (v128.load offset=4416 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_12 (v128.load offset=4544 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_12 (v128.load offset=4672 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_12 (v128.load offset=4800 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_12 (v128.load offset=4928 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_12 (v128.load offset=5056 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_12 (v128.load offset=5184 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_12 (v128.load offset=5312 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_12 (v128.load offset=5440 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_12 (v128.load offset=5568 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_12 (v128.load offset=5696 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_12 (v128.load offset=5824 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_12 (v128.load offset=5952 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_12 (v128.load offset=6080 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_12 (v128.load offset=6208 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_12 (v128.load offset=6336 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_12 (v128.load offset=6464 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_12 (v128.load offset=6592 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_12 (v128.load offset=6720 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_12 (v128.load offset=6848 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_12 (v128.load offset=6976 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_12 (v128.load offset=7104 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_12 (v128.load offset=7232 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_12 (v128.load offset=7360 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_12 (v128.load offset=7488 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_12 (v128.load offset=7616 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_12 (v128.load offset=7744 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_12 (v128.load offset=7872 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_12 (v128.load offset=8000 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_12 (v128.load offset=8128 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=192
local.get $yp
local.get $yp
v128.load offset=208
local.get $x0
(local.tee $w0_13 (v128.load offset=80 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_13 (v128.load offset=208 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_13 (v128.load offset=336 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_13 (v128.load offset=464 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_13 (v128.load offset=592 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_13 (v128.load offset=720 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_13 (v128.load offset=848 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_13 (v128.load offset=976 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_13 (v128.load offset=1104 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_13 (v128.load offset=1232 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_13 (v128.load offset=1360 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_13 (v128.load offset=1488 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_13 (v128.load offset=1616 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_13 (v128.load offset=1744 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_13 (v128.load offset=1872 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_13 (v128.load offset=2000 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_13 (v128.load offset=2128 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_13 (v128.load offset=2256 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_13 (v128.load offset=2384 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_13 (v128.load offset=2512 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_13 (v128.load offset=2640 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_13 (v128.load offset=2768 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_13 (v128.load offset=2896 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_13 (v128.load offset=3024 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_13 (v128.load offset=3152 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_13 (v128.load offset=3280 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_13 (v128.load offset=3408 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_13 (v128.load offset=3536 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_13 (v128.load offset=3664 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_13 (v128.load offset=3792 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_13 (v128.load offset=3920 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_13 (v128.load offset=4048 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_13 (v128.load offset=4176 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_13 (v128.load offset=4304 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_13 (v128.load offset=4432 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_13 (v128.load offset=4560 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_13 (v128.load offset=4688 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_13 (v128.load offset=4816 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_13 (v128.load offset=4944 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_13 (v128.load offset=5072 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_13 (v128.load offset=5200 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_13 (v128.load offset=5328 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_13 (v128.load offset=5456 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_13 (v128.load offset=5584 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_13 (v128.load offset=5712 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_13 (v128.load offset=5840 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_13 (v128.load offset=5968 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_13 (v128.load offset=6096 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_13 (v128.load offset=6224 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_13 (v128.load offset=6352 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_13 (v128.load offset=6480 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_13 (v128.load offset=6608 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_13 (v128.load offset=6736 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_13 (v128.load offset=6864 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_13 (v128.load offset=6992 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_13 (v128.load offset=7120 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_13 (v128.load offset=7248 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_13 (v128.load offset=7376 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_13 (v128.load offset=7504 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_13 (v128.load offset=7632 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_13 (v128.load offset=7760 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_13 (v128.load offset=7888 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_13 (v128.load offset=8016 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_13 (v128.load offset=8144 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=208
local.get $yp
local.get $yp
v128.load offset=224
local.get $x0
(local.tee $w0_14 (v128.load offset=96 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_14 (v128.load offset=224 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_14 (v128.load offset=352 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_14 (v128.load offset=480 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_14 (v128.load offset=608 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_14 (v128.load offset=736 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_14 (v128.load offset=864 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_14 (v128.load offset=992 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_14 (v128.load offset=1120 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_14 (v128.load offset=1248 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_14 (v128.load offset=1376 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_14 (v128.load offset=1504 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_14 (v128.load offset=1632 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_14 (v128.load offset=1760 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_14 (v128.load offset=1888 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_14 (v128.load offset=2016 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_14 (v128.load offset=2144 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_14 (v128.load offset=2272 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_14 (v128.load offset=2400 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_14 (v128.load offset=2528 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_14 (v128.load offset=2656 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_14 (v128.load offset=2784 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_14 (v128.load offset=2912 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_14 (v128.load offset=3040 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_14 (v128.load offset=3168 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_14 (v128.load offset=3296 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_14 (v128.load offset=3424 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_14 (v128.load offset=3552 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_14 (v128.load offset=3680 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_14 (v128.load offset=3808 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_14 (v128.load offset=3936 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_14 (v128.load offset=4064 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_14 (v128.load offset=4192 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_14 (v128.load offset=4320 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_14 (v128.load offset=4448 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_14 (v128.load offset=4576 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_14 (v128.load offset=4704 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_14 (v128.load offset=4832 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_14 (v128.load offset=4960 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_14 (v128.load offset=5088 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_14 (v128.load offset=5216 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_14 (v128.load offset=5344 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_14 (v128.load offset=5472 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_14 (v128.load offset=5600 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_14 (v128.load offset=5728 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_14 (v128.load offset=5856 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_14 (v128.load offset=5984 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_14 (v128.load offset=6112 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_14 (v128.load offset=6240 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_14 (v128.load offset=6368 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_14 (v128.load offset=6496 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_14 (v128.load offset=6624 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_14 (v128.load offset=6752 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_14 (v128.load offset=6880 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_14 (v128.load offset=7008 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_14 (v128.load offset=7136 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_14 (v128.load offset=7264 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_14 (v128.load offset=7392 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_14 (v128.load offset=7520 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_14 (v128.load offset=7648 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_14 (v128.load offset=7776 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_14 (v128.load offset=7904 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_14 (v128.load offset=8032 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_14 (v128.load offset=8160 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=224
local.get $yp
local.get $yp
v128.load offset=240
local.get $x0
(local.tee $w0_15 (v128.load offset=112 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x1
(local.tee $w1_15 (v128.load offset=240 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x2
(local.tee $w2_15 (v128.load offset=368 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x3
(local.tee $w3_15 (v128.load offset=496 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x4
(local.tee $w4_15 (v128.load offset=624 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x5
(local.tee $w5_15 (v128.load offset=752 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x6
(local.tee $w6_15 (v128.load offset=880 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x7
(local.tee $w7_15 (v128.load offset=1008 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x8
(local.tee $w8_15 (v128.load offset=1136 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x9
(local.tee $w9_15 (v128.load offset=1264 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x10
(local.tee $w10_15 (v128.load offset=1392 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x11
(local.tee $w11_15 (v128.load offset=1520 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x12
(local.tee $w12_15 (v128.load offset=1648 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x13
(local.tee $w13_15 (v128.load offset=1776 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x14
(local.tee $w14_15 (v128.load offset=1904 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x15
(local.tee $w15_15 (v128.load offset=2032 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x16
(local.tee $w16_15 (v128.load offset=2160 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x17
(local.tee $w17_15 (v128.load offset=2288 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x18
(local.tee $w18_15 (v128.load offset=2416 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x19
(local.tee $w19_15 (v128.load offset=2544 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x20
(local.tee $w20_15 (v128.load offset=2672 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x21
(local.tee $w21_15 (v128.load offset=2800 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x22
(local.tee $w22_15 (v128.load offset=2928 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x23
(local.tee $w23_15 (v128.load offset=3056 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x24
(local.tee $w24_15 (v128.load offset=3184 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x25
(local.tee $w25_15 (v128.load offset=3312 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x26
(local.tee $w26_15 (v128.load offset=3440 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x27
(local.tee $w27_15 (v128.load offset=3568 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x28
(local.tee $w28_15 (v128.load offset=3696 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x29
(local.tee $w29_15 (v128.load offset=3824 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x30
(local.tee $w30_15 (v128.load offset=3952 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x31
(local.tee $w31_15 (v128.load offset=4080 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x32
(local.tee $w32_15 (v128.load offset=4208 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x33
(local.tee $w33_15 (v128.load offset=4336 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x34
(local.tee $w34_15 (v128.load offset=4464 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x35
(local.tee $w35_15 (v128.load offset=4592 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x36
(local.tee $w36_15 (v128.load offset=4720 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x37
(local.tee $w37_15 (v128.load offset=4848 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x38
(local.tee $w38_15 (v128.load offset=4976 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x39
(local.tee $w39_15 (v128.load offset=5104 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x40
(local.tee $w40_15 (v128.load offset=5232 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x41
(local.tee $w41_15 (v128.load offset=5360 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x42
(local.tee $w42_15 (v128.load offset=5488 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x43
(local.tee $w43_15 (v128.load offset=5616 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x44
(local.tee $w44_15 (v128.load offset=5744 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x45
(local.tee $w45_15 (v128.load offset=5872 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x46
(local.tee $w46_15 (v128.load offset=6000 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x47
(local.tee $w47_15 (v128.load offset=6128 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x48
(local.tee $w48_15 (v128.load offset=6256 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x49
(local.tee $w49_15 (v128.load offset=6384 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x50
(local.tee $w50_15 (v128.load offset=6512 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x51
(local.tee $w51_15 (v128.load offset=6640 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x52
(local.tee $w52_15 (v128.load offset=6768 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x53
(local.tee $w53_15 (v128.load offset=6896 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x54
(local.tee $w54_15 (v128.load offset=7024 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x55
(local.tee $w55_15 (v128.load offset=7152 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x56
(local.tee $w56_15 (v128.load offset=7280 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x57
(local.tee $w57_15 (v128.load offset=7408 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x58
(local.tee $w58_15 (v128.load offset=7536 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x59
(local.tee $w59_15 (v128.load offset=7664 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x60
(local.tee $w60_15 (v128.load offset=7792 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x61
(local.tee $w61_15 (v128.load offset=7920 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x62
(local.tee $w62_15 (v128.load offset=8048 (local.get $wp1)))
f32x4.mul
f32x4.add
local.get $x63
(local.tee $w63_15 (v128.load offset=8176 (local.get $wp1)))
f32x4.mul
f32x4.add
v128.store offset=240
(local.set $t (i32.const 1))
(loop $tokens (br_if $done (i32.ge_u (local.get $t) (local.get $n)))
(local.set $qp (i32.add (local.get $q) (i32.shl (i32.add (i32.mul (local.get $t) (local.get $cols)) (local.get $start)) (i32.const 2))))
(local.set $yp (i32.add (local.get $sums) (i32.shl (i32.mul (local.get $t) (local.get $stride)) (i32.const 2))))
(local.set $x0 (v128.load32_splat offset=0 (local.get $qp)))
(local.set $x1 (v128.load32_splat offset=4 (local.get $qp)))
(local.set $x2 (v128.load32_splat offset=8 (local.get $qp)))
(local.set $x3 (v128.load32_splat offset=12 (local.get $qp)))
(local.set $x4 (v128.load32_splat offset=16 (local.get $qp)))
(local.set $x5 (v128.load32_splat offset=20 (local.get $qp)))
(local.set $x6 (v128.load32_splat offset=24 (local.get $qp)))
(local.set $x7 (v128.load32_splat offset=28 (local.get $qp)))
(local.set $x8 (v128.load32_splat offset=32 (local.get $qp)))
(local.set $x9 (v128.load32_splat offset=36 (local.get $qp)))
(local.set $x10 (v128.load32_splat offset=40 (local.get $qp)))
(local.set $x11 (v128.load32_splat offset=44 (local.get $qp)))
(local.set $x12 (v128.load32_splat offset=48 (local.get $qp)))
(local.set $x13 (v128.load32_splat offset=52 (local.get $qp)))
(local.set $x14 (v128.load32_splat offset=56 (local.get $qp)))
(local.set $x15 (v128.load32_splat offset=60 (local.get $qp)))
(local.set $x16 (v128.load32_splat offset=64 (local.get $qp)))
(local.set $x17 (v128.load32_splat offset=68 (local.get $qp)))
(local.set $x18 (v128.load32_splat offset=72 (local.get $qp)))
(local.set $x19 (v128.load32_splat offset=76 (local.get $qp)))
(local.set $x20 (v128.load32_splat offset=80 (local.get $qp)))
(local.set $x21 (v128.load32_splat offset=84 (local.get $qp)))
(local.set $x22 (v128.load32_splat offset=88 (local.get $qp)))
(local.set $x23 (v128.load32_splat offset=92 (local.get $qp)))
(local.set $x24 (v128.load32_splat offset=96 (local.get $qp)))
(local.set $x25 (v128.load32_splat offset=100 (local.get $qp)))
(local.set $x26 (v128.load32_splat offset=104 (local.get $qp)))
(local.set $x27 (v128.load32_splat offset=108 (local.get $qp)))
(local.set $x28 (v128.load32_splat offset=112 (local.get $qp)))
(local.set $x29 (v128.load32_splat offset=116 (local.get $qp)))
(local.set $x30 (v128.load32_splat offset=120 (local.get $qp)))
(local.set $x31 (v128.load32_splat offset=124 (local.get $qp)))
(local.set $x32 (v128.load32_splat offset=128 (local.get $qp)))
(local.set $x33 (v128.load32_splat offset=132 (local.get $qp)))
(local.set $x34 (v128.load32_splat offset=136 (local.get $qp)))
(local.set $x35 (v128.load32_splat offset=140 (local.get $qp)))
(local.set $x36 (v128.load32_splat offset=144 (local.get $qp)))
(local.set $x37 (v128.load32_splat offset=148 (local.get $qp)))
(local.set $x38 (v128.load32_splat offset=152 (local.get $qp)))
(local.set $x39 (v128.load32_splat offset=156 (local.get $qp)))
(local.set $x40 (v128.load32_splat offset=160 (local.get $qp)))
(local.set $x41 (v128.load32_splat offset=164 (local.get $qp)))
(local.set $x42 (v128.load32_splat offset=168 (local.get $qp)))
(local.set $x43 (v128.load32_splat offset=172 (local.get $qp)))
(local.set $x44 (v128.load32_splat offset=176 (local.get $qp)))
(local.set $x45 (v128.load32_splat offset=180 (local.get $qp)))
(local.set $x46 (v128.load32_splat offset=184 (local.get $qp)))
(local.set $x47 (v128.load32_splat offset=188 (local.get $qp)))
(local.set $x48 (v128.load32_splat offset=192 (local.get $qp)))
(local.set $x49 (v128.load32_splat offset=196 (local.get $qp)))
(local.set $x50 (v128.load32_splat offset=200 (local.get $qp)))
(local.set $x51 (v128.load32_splat offset=204 (local.get $qp)))
(local.set $x52 (v128.load32_splat offset=208 (local.get $qp)))
(local.set $x53 (v128.load32_splat offset=212 (local.get $qp)))
(local.set $x54 (v128.load32_splat offset=216 (local.get $qp)))
(local.set $x55 (v128.load32_splat offset=220 (local.get $qp)))
(local.set $x56 (v128.load32_splat offset=224 (local.get $qp)))
(local.set $x57 (v128.load32_splat offset=228 (local.get $qp)))
(local.set $x58 (v128.load32_splat offset=232 (local.get $qp)))
(local.set $x59 (v128.load32_splat offset=236 (local.get $qp)))
(local.set $x60 (v128.load32_splat offset=240 (local.get $qp)))
(local.set $x61 (v128.load32_splat offset=244 (local.get $qp)))
(local.set $x62 (v128.load32_splat offset=248 (local.get $qp)))
(local.set $x63 (v128.load32_splat offset=252 (local.get $qp)))
local.get $yp
local.get $yp
v128.load offset=0
local.get $x0
local.get $w0_0
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_0
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_0
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_0
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_0
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_0
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_0
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_0
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_0
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_0
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_0
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_0
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_0
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_0
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_0
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_0
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_0
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_0
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_0
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_0
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_0
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_0
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_0
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_0
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_0
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_0
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_0
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_0
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_0
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_0
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_0
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_0
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_0
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_0
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_0
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_0
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_0
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_0
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_0
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_0
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_0
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_0
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_0
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_0
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_0
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_0
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_0
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_0
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_0
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_0
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_0
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_0
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_0
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_0
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_0
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_0
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_0
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_0
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_0
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_0
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_0
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_0
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_0
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_0
f32x4.mul
f32x4.add
v128.store offset=0
local.get $yp
local.get $yp
v128.load offset=16
local.get $x0
local.get $w0_1
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_1
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_1
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_1
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_1
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_1
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_1
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_1
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_1
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_1
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_1
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_1
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_1
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_1
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_1
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_1
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_1
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_1
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_1
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_1
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_1
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_1
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_1
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_1
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_1
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_1
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_1
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_1
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_1
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_1
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_1
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_1
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_1
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_1
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_1
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_1
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_1
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_1
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_1
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_1
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_1
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_1
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_1
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_1
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_1
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_1
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_1
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_1
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_1
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_1
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_1
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_1
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_1
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_1
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_1
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_1
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_1
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_1
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_1
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_1
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_1
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_1
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_1
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_1
f32x4.mul
f32x4.add
v128.store offset=16
local.get $yp
local.get $yp
v128.load offset=32
local.get $x0
local.get $w0_2
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_2
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_2
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_2
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_2
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_2
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_2
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_2
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_2
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_2
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_2
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_2
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_2
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_2
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_2
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_2
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_2
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_2
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_2
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_2
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_2
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_2
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_2
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_2
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_2
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_2
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_2
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_2
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_2
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_2
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_2
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_2
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_2
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_2
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_2
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_2
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_2
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_2
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_2
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_2
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_2
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_2
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_2
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_2
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_2
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_2
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_2
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_2
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_2
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_2
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_2
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_2
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_2
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_2
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_2
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_2
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_2
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_2
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_2
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_2
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_2
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_2
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_2
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_2
f32x4.mul
f32x4.add
v128.store offset=32
local.get $yp
local.get $yp
v128.load offset=48
local.get $x0
local.get $w0_3
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_3
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_3
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_3
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_3
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_3
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_3
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_3
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_3
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_3
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_3
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_3
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_3
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_3
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_3
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_3
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_3
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_3
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_3
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_3
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_3
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_3
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_3
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_3
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_3
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_3
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_3
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_3
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_3
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_3
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_3
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_3
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_3
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_3
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_3
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_3
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_3
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_3
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_3
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_3
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_3
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_3
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_3
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_3
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_3
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_3
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_3
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_3
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_3
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_3
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_3
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_3
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_3
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_3
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_3
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_3
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_3
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_3
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_3
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_3
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_3
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_3
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_3
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_3
f32x4.mul
f32x4.add
v128.store offset=48
local.get $yp
local.get $yp
v128.load offset=64
local.get $x0
local.get $w0_4
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_4
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_4
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_4
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_4
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_4
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_4
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_4
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_4
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_4
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_4
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_4
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_4
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_4
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_4
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_4
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_4
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_4
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_4
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_4
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_4
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_4
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_4
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_4
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_4
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_4
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_4
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_4
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_4
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_4
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_4
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_4
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_4
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_4
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_4
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_4
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_4
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_4
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_4
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_4
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_4
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_4
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_4
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_4
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_4
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_4
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_4
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_4
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_4
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_4
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_4
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_4
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_4
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_4
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_4
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_4
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_4
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_4
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_4
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_4
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_4
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_4
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_4
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_4
f32x4.mul
f32x4.add
v128.store offset=64
local.get $yp
local.get $yp
v128.load offset=80
local.get $x0
local.get $w0_5
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_5
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_5
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_5
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_5
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_5
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_5
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_5
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_5
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_5
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_5
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_5
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_5
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_5
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_5
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_5
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_5
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_5
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_5
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_5
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_5
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_5
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_5
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_5
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_5
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_5
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_5
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_5
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_5
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_5
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_5
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_5
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_5
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_5
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_5
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_5
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_5
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_5
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_5
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_5
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_5
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_5
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_5
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_5
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_5
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_5
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_5
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_5
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_5
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_5
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_5
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_5
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_5
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_5
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_5
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_5
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_5
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_5
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_5
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_5
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_5
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_5
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_5
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_5
f32x4.mul
f32x4.add
v128.store offset=80
local.get $yp
local.get $yp
v128.load offset=96
local.get $x0
local.get $w0_6
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_6
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_6
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_6
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_6
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_6
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_6
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_6
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_6
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_6
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_6
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_6
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_6
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_6
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_6
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_6
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_6
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_6
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_6
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_6
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_6
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_6
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_6
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_6
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_6
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_6
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_6
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_6
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_6
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_6
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_6
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_6
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_6
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_6
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_6
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_6
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_6
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_6
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_6
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_6
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_6
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_6
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_6
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_6
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_6
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_6
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_6
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_6
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_6
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_6
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_6
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_6
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_6
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_6
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_6
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_6
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_6
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_6
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_6
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_6
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_6
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_6
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_6
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_6
f32x4.mul
f32x4.add
v128.store offset=96
local.get $yp
local.get $yp
v128.load offset=112
local.get $x0
local.get $w0_7
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_7
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_7
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_7
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_7
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_7
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_7
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_7
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_7
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_7
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_7
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_7
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_7
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_7
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_7
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_7
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_7
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_7
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_7
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_7
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_7
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_7
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_7
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_7
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_7
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_7
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_7
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_7
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_7
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_7
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_7
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_7
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_7
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_7
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_7
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_7
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_7
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_7
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_7
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_7
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_7
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_7
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_7
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_7
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_7
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_7
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_7
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_7
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_7
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_7
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_7
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_7
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_7
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_7
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_7
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_7
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_7
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_7
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_7
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_7
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_7
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_7
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_7
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_7
f32x4.mul
f32x4.add
v128.store offset=112
local.get $yp
local.get $yp
v128.load offset=128
local.get $x0
local.get $w0_8
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_8
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_8
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_8
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_8
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_8
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_8
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_8
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_8
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_8
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_8
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_8
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_8
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_8
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_8
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_8
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_8
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_8
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_8
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_8
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_8
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_8
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_8
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_8
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_8
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_8
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_8
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_8
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_8
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_8
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_8
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_8
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_8
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_8
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_8
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_8
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_8
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_8
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_8
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_8
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_8
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_8
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_8
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_8
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_8
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_8
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_8
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_8
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_8
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_8
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_8
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_8
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_8
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_8
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_8
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_8
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_8
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_8
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_8
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_8
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_8
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_8
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_8
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_8
f32x4.mul
f32x4.add
v128.store offset=128
local.get $yp
local.get $yp
v128.load offset=144
local.get $x0
local.get $w0_9
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_9
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_9
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_9
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_9
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_9
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_9
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_9
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_9
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_9
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_9
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_9
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_9
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_9
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_9
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_9
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_9
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_9
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_9
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_9
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_9
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_9
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_9
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_9
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_9
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_9
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_9
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_9
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_9
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_9
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_9
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_9
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_9
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_9
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_9
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_9
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_9
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_9
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_9
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_9
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_9
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_9
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_9
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_9
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_9
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_9
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_9
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_9
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_9
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_9
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_9
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_9
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_9
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_9
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_9
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_9
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_9
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_9
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_9
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_9
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_9
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_9
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_9
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_9
f32x4.mul
f32x4.add
v128.store offset=144
local.get $yp
local.get $yp
v128.load offset=160
local.get $x0
local.get $w0_10
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_10
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_10
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_10
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_10
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_10
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_10
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_10
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_10
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_10
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_10
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_10
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_10
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_10
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_10
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_10
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_10
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_10
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_10
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_10
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_10
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_10
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_10
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_10
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_10
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_10
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_10
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_10
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_10
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_10
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_10
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_10
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_10
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_10
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_10
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_10
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_10
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_10
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_10
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_10
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_10
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_10
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_10
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_10
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_10
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_10
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_10
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_10
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_10
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_10
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_10
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_10
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_10
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_10
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_10
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_10
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_10
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_10
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_10
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_10
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_10
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_10
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_10
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_10
f32x4.mul
f32x4.add
v128.store offset=160
local.get $yp
local.get $yp
v128.load offset=176
local.get $x0
local.get $w0_11
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_11
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_11
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_11
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_11
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_11
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_11
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_11
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_11
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_11
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_11
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_11
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_11
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_11
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_11
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_11
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_11
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_11
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_11
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_11
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_11
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_11
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_11
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_11
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_11
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_11
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_11
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_11
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_11
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_11
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_11
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_11
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_11
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_11
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_11
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_11
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_11
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_11
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_11
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_11
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_11
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_11
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_11
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_11
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_11
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_11
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_11
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_11
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_11
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_11
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_11
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_11
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_11
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_11
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_11
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_11
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_11
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_11
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_11
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_11
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_11
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_11
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_11
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_11
f32x4.mul
f32x4.add
v128.store offset=176
local.get $yp
local.get $yp
v128.load offset=192
local.get $x0
local.get $w0_12
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_12
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_12
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_12
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_12
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_12
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_12
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_12
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_12
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_12
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_12
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_12
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_12
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_12
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_12
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_12
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_12
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_12
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_12
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_12
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_12
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_12
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_12
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_12
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_12
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_12
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_12
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_12
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_12
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_12
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_12
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_12
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_12
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_12
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_12
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_12
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_12
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_12
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_12
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_12
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_12
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_12
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_12
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_12
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_12
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_12
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_12
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_12
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_12
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_12
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_12
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_12
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_12
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_12
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_12
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_12
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_12
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_12
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_12
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_12
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_12
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_12
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_12
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_12
f32x4.mul
f32x4.add
v128.store offset=192
local.get $yp
local.get $yp
v128.load offset=208
local.get $x0
local.get $w0_13
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_13
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_13
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_13
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_13
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_13
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_13
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_13
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_13
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_13
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_13
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_13
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_13
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_13
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_13
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_13
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_13
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_13
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_13
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_13
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_13
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_13
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_13
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_13
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_13
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_13
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_13
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_13
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_13
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_13
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_13
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_13
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_13
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_13
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_13
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_13
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_13
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_13
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_13
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_13
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_13
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_13
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_13
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_13
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_13
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_13
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_13
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_13
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_13
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_13
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_13
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_13
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_13
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_13
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_13
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_13
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_13
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_13
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_13
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_13
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_13
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_13
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_13
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_13
f32x4.mul
f32x4.add
v128.store offset=208
local.get $yp
local.get $yp
v128.load offset=224
local.get $x0
local.get $w0_14
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_14
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_14
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_14
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_14
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_14
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_14
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_14
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_14
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_14
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_14
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_14
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_14
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_14
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_14
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_14
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_14
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_14
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_14
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_14
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_14
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_14
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_14
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_14
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_14
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_14
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_14
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_14
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_14
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_14
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_14
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_14
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_14
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_14
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_14
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_14
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_14
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_14
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_14
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_14
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_14
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_14
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_14
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_14
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_14
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_14
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_14
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_14
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_14
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_14
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_14
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_14
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_14
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_14
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_14
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_14
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_14
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_14
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_14
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_14
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_14
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_14
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_14
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_14
f32x4.mul
f32x4.add
v128.store offset=224
local.get $yp
local.get $yp
v128.load offset=240
local.get $x0
local.get $w0_15
f32x4.mul
f32x4.add
local.get $x1
local.get $w1_15
f32x4.mul
f32x4.add
local.get $x2
local.get $w2_15
f32x4.mul
f32x4.add
local.get $x3
local.get $w3_15
f32x4.mul
f32x4.add
local.get $x4
local.get $w4_15
f32x4.mul
f32x4.add
local.get $x5
local.get $w5_15
f32x4.mul
f32x4.add
local.get $x6
local.get $w6_15
f32x4.mul
f32x4.add
local.get $x7
local.get $w7_15
f32x4.mul
f32x4.add
local.get $x8
local.get $w8_15
f32x4.mul
f32x4.add
local.get $x9
local.get $w9_15
f32x4.mul
f32x4.add
local.get $x10
local.get $w10_15
f32x4.mul
f32x4.add
local.get $x11
local.get $w11_15
f32x4.mul
f32x4.add
local.get $x12
local.get $w12_15
f32x4.mul
f32x4.add
local.get $x13
local.get $w13_15
f32x4.mul
f32x4.add
local.get $x14
local.get $w14_15
f32x4.mul
f32x4.add
local.get $x15
local.get $w15_15
f32x4.mul
f32x4.add
local.get $x16
local.get $w16_15
f32x4.mul
f32x4.add
local.get $x17
local.get $w17_15
f32x4.mul
f32x4.add
local.get $x18
local.get $w18_15
f32x4.mul
f32x4.add
local.get $x19
local.get $w19_15
f32x4.mul
f32x4.add
local.get $x20
local.get $w20_15
f32x4.mul
f32x4.add
local.get $x21
local.get $w21_15
f32x4.mul
f32x4.add
local.get $x22
local.get $w22_15
f32x4.mul
f32x4.add
local.get $x23
local.get $w23_15
f32x4.mul
f32x4.add
local.get $x24
local.get $w24_15
f32x4.mul
f32x4.add
local.get $x25
local.get $w25_15
f32x4.mul
f32x4.add
local.get $x26
local.get $w26_15
f32x4.mul
f32x4.add
local.get $x27
local.get $w27_15
f32x4.mul
f32x4.add
local.get $x28
local.get $w28_15
f32x4.mul
f32x4.add
local.get $x29
local.get $w29_15
f32x4.mul
f32x4.add
local.get $x30
local.get $w30_15
f32x4.mul
f32x4.add
local.get $x31
local.get $w31_15
f32x4.mul
f32x4.add
local.get $x32
local.get $w32_15
f32x4.mul
f32x4.add
local.get $x33
local.get $w33_15
f32x4.mul
f32x4.add
local.get $x34
local.get $w34_15
f32x4.mul
f32x4.add
local.get $x35
local.get $w35_15
f32x4.mul
f32x4.add
local.get $x36
local.get $w36_15
f32x4.mul
f32x4.add
local.get $x37
local.get $w37_15
f32x4.mul
f32x4.add
local.get $x38
local.get $w38_15
f32x4.mul
f32x4.add
local.get $x39
local.get $w39_15
f32x4.mul
f32x4.add
local.get $x40
local.get $w40_15
f32x4.mul
f32x4.add
local.get $x41
local.get $w41_15
f32x4.mul
f32x4.add
local.get $x42
local.get $w42_15
f32x4.mul
f32x4.add
local.get $x43
local.get $w43_15
f32x4.mul
f32x4.add
local.get $x44
local.get $w44_15
f32x4.mul
f32x4.add
local.get $x45
local.get $w45_15
f32x4.mul
f32x4.add
local.get $x46
local.get $w46_15
f32x4.mul
f32x4.add
local.get $x47
local.get $w47_15
f32x4.mul
f32x4.add
local.get $x48
local.get $w48_15
f32x4.mul
f32x4.add
local.get $x49
local.get $w49_15
f32x4.mul
f32x4.add
local.get $x50
local.get $w50_15
f32x4.mul
f32x4.add
local.get $x51
local.get $w51_15
f32x4.mul
f32x4.add
local.get $x52
local.get $w52_15
f32x4.mul
f32x4.add
local.get $x53
local.get $w53_15
f32x4.mul
f32x4.add
local.get $x54
local.get $w54_15
f32x4.mul
f32x4.add
local.get $x55
local.get $w55_15
f32x4.mul
f32x4.add
local.get $x56
local.get $w56_15
f32x4.mul
f32x4.add
local.get $x57
local.get $w57_15
f32x4.mul
f32x4.add
local.get $x58
local.get $w58_15
f32x4.mul
f32x4.add
local.get $x59
local.get $w59_15
f32x4.mul
f32x4.add
local.get $x60
local.get $w60_15
f32x4.mul
f32x4.add
local.get $x61
local.get $w61_15
f32x4.mul
f32x4.add
local.get $x62
local.get $w62_15
f32x4.mul
f32x4.add
local.get $x63
local.get $w63_15
f32x4.mul
f32x4.add
v128.store offset=240
(local.set $t (i32.add (local.get $t) (i32.const 1)))
br $tokens
))
))
